package vn.com.mcredit.digitallending.exceptions;

public class ForbiddenException extends RuntimeException {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    String code;

    public ForbiddenException() {
        super();
    }

    public ForbiddenException(String message) {
        super(message);
    }

    public ForbiddenException(String code, String message) {
        super((message));
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
