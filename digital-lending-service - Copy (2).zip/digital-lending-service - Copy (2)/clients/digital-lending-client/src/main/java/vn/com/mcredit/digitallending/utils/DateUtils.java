package vn.com.mcredit.digitallending.utils;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class DateUtils {

  private static final Logger LOGGER = LoggerFactory.getLogger(DateUtils.class);
  public static final String FORMAT_TIME_BPM_YYYY_MM_DD_HH_MM_SS_SSS = "yyyy-MM-dd HH:mm:ss.SSS";
  public static final String FORMAT_TIME_BPM_YYYY_MM_DD_HH_MM_SS = "dd/MM/yyyy HH:mm:ss";
  public static final String F_DDMMYYYYHHMMSS = "dd/MM/yyyy HH:mm:ss";
  public static final String F_DDMMYYYY = "dd/MM/yyyy";
  public static final String F_DMMYYYY = "d/MM/yyyy";
  public static final String DATE_TIME_FORMAT_VI = "dd-MM-yyyy HH:mm:ss";
  public static final String DATE_TIME_FORMAT_VI_OUTPUT = "yyyy-MM-dd HH:mm:ss";
  public static final String DATE_TIME_FORMAT_GENERAL = "EEE MMM dd HH:mm:ss zzz yyyy";
  public static final String YYYY = "yyyy";
  public static final String YYMMDD = "yyMMdd";
  public static final String YYYYMMDD = "yyyyMMdd";
  public static final String YYYY_MM = "yyyy-MM";
  public static final String YYYY_MM_DD = "yyyy-MM-dd";
  public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
  public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
  public static final String YYYY_MM_DD_HH_MM = "yyyy/MM/dd HH:mm";
  public static final String F_YYYY_MM_DD = "yyyy/MM/dd";
  public static final String HH_MM_SS = "HH:mm:ss";
  public static final String HHMMSS = "HHmmss";
  protected static final List<String> patterns;

  private DateUtils() {
    throw new IllegalStateException("Utility class");
  }


  static {
    patterns = new ArrayList<>();
    patterns.add(DATE_TIME_FORMAT_VI);
    patterns.add(DATE_TIME_FORMAT_VI_OUTPUT);
    patterns.add(F_DDMMYYYYHHMMSS);
    patterns.add(DATE_TIME_FORMAT_GENERAL);
  }

  public static Date addHours(Date date, int hours) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.HOUR_OF_DAY, hours);
    return calendar.getTime();
  }

  public static Date addMinute(Date date, int minute) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.MINUTE, minute);
    return calendar.getTime();
  }

  public static Date toDate(String date, String format) throws ParseException {
    SimpleDateFormat sdf = new SimpleDateFormat(format);
    return sdf.parse(date);
  }

  public static Date toDate(String date, String format, Date defaultVal) {
    try {
      SimpleDateFormat sdf = new SimpleDateFormat(format);
      return sdf.parse(date);
    } catch (Exception e) {
      return defaultVal;
    }
  }

  public static int calculateAge(Date first, Date second) {
    LocalDate birthDate = convertToLocalDateViaInstant(first);
    LocalDate currentDate = convertToLocalDateViaInstant(second);
    if ((birthDate != null) && (currentDate != null)) {
      return Period.between(currentDate,birthDate ).getYears();
    } else {
      return 0;
    }
  }

  public static LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
    return dateToConvert.toInstant()
            .atZone(ZoneId.systemDefault())
            .toLocalDate();
  }

  public static Date toDateElseNull(String date, String format) {
    return toDate(date, format, null);
  }

  public static String toStr(Date date, String format) {
    return date != null ? DateFormatUtils.format(date, format) : "";
  }

  public static boolean isValid(String strDate, String format) {
    try {
      if (StringUtils.isBlank(strDate) || format.length() != strDate.trim().length()) return false;
      SimpleDateFormat sdf = new SimpleDateFormat(format);
      sdf.setLenient(false);
      sdf.parse(strDate);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public static Date toDate(String dateStr, List<String> patterns) {

    Date date = null;
    for (String pattern : patterns) {
      try {
        date = new SimpleDateFormat(pattern).parse(dateStr);
        break;
      } catch (ParseException e) {
        LOGGER.error(e.getMessage());
      }
    }
    if (date == null) {
      throw new ApplicationException("định dạng ngày tháng không chính xác");
    }
    return date;
  }

  public static Date getNowDate() {
    return new Date();
  }

  public static String getDate() {
    return dateTimeNow(YYYY_MM_DD);
  }

  public static String getDate(String formatDate) {
    return dateTimeNow(formatDate);
  }

  public static String getDateYmd() {
    return dateTimeNow(YYMMDD);
  }

  public static String getTime() {
    return dateTimeNow(YYYY_MM_DD_HH_MM_SS);
  }

  public static String getDateYmdHm() {
    return dateTimeNow(YYYY_MM_DD_HH_MM);
  }

  public static String dateTimeNow() {
    return dateTimeNow(YYYYMMDDHHMMSS);
  }

  public static String datePath() {
    return dateTimeNow(F_YYYY_MM_DD);
  }

  public static String dateTime() {
    return dateTimeNow(YYYYMMDD);
  }

  public static String dateTimeNow(final String format) {
    return parseDateToStr(format, new Date());
  }

  public static String parseDateToStr(final String format, final Date date) {
    return new SimpleDateFormat(format).format(date);
  }

  public static Long dateToLong(final String dateString, final String dateFormat)
      throws ParseException {
    SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
    Date date = sdf.parse(dateString);
    return date.getTime();
  }

  public static String longToDate(final long lo, final String dateFormat) {
    try{
      Date date = new Date(lo);
      SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
      return sdf.format(date);
    } catch (Exception e){
      LogUtils.error("DateUtils.longToDate error {}", e.getMessage());
    }
    return Constants.EMPTY;
  }

  public static boolean checkDate(final String dateStr, final String format) {
    if (StringUtils.isNullOrEmpty(dateStr)) {
      return false;
    }
    SimpleDateFormat sdf = new SimpleDateFormat(format);
    sdf.setLenient(false);

    try {
      Date date = sdf.parse(dateStr);
      if (!sdf.format(date).equals(dateStr)) {
        return false;
      }
    } catch (ParseException e) {
      return false;
    }
    return true;
  }

  public static long getDateDiffInMinutes(Date startDate, Date endDate) {
    long diffInMillies = endDate.getTime() - startDate.getTime();
    return TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MINUTES);
  }

  public static Date getFirstDayOfWeek() {
    Calendar cal = Calendar.getInstance(new Locale("vi", "VN"));
    cal.setFirstDayOfWeek(Calendar.MONDAY);
    cal.setTime(new Date());
    cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
  }

  public static Date getFirstOfMonth() {
    Calendar cal = Calendar.getInstance(new Locale("vi", "VN"));
    cal.set(Calendar.DATE, 1);
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
  }

  public static Date getLastDayOfWeek() {
    Date first = getFirstDayOfWeek();
    GregorianCalendar cal = new GregorianCalendar();
    cal.setTime(first);
    cal.add(Calendar.DATE, 6);
    cal.set(Calendar.HOUR_OF_DAY, 23);
    cal.set(Calendar.MINUTE, 59);
    cal.set(Calendar.SECOND, 59);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
  }

  public static Date getFirstDayLastWeek() {
    Calendar cal = Calendar.getInstance();
    cal.setTime(getFirstDayOfWeek());
    cal.add(Calendar.DATE, -7);
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
  }

  public static Date getLastDayLastWeek() {
    Date first = getFirstDayLastWeek();
    GregorianCalendar cal = new GregorianCalendar();
    cal.setTime(first);
    cal.add(Calendar.DATE, 6);
    cal.set(Calendar.HOUR_OF_DAY, 23);
    cal.set(Calendar.MINUTE, 59);
    cal.set(Calendar.SECOND, 59);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
  }

  public static Date getCurrentDayFirstTime() {
    GregorianCalendar cal = new GregorianCalendar();
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
  }

  public static Date getCurrentDayLastTime() {
    GregorianCalendar cal = new GregorianCalendar();
    cal.set(Calendar.HOUR_OF_DAY, 23);
    cal.set(Calendar.MINUTE, 59);
    cal.set(Calendar.SECOND, 59);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
  }

  public static int getCurrentWeek() {
    Date date = new Date();
    Calendar cal = Calendar.getInstance(new Locale("vi", "VN"));
    cal.setFirstDayOfWeek(Calendar.MONDAY);
    cal.setTime(date);
    return cal.get(Calendar.WEEK_OF_YEAR);
  }
  public static Integer compareTo(String strDate1, String strDate2, String format){
    try {
      SimpleDateFormat sdf = new SimpleDateFormat(format);
      Date date1 = sdf.parse(strDate1);
      Date date2 = sdf.parse(strDate2);
      return date1.compareTo(date2);
    } catch (ParseException e) {
      return null;
    }
  }
  public static Date addSecond(Date date, int second) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.SECOND, second);
    return calendar.getTime();
  }
}
