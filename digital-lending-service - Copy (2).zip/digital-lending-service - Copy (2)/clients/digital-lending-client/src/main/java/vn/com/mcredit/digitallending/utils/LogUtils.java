package vn.com.mcredit.digitallending.utils;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import vn.com.mcredit.digitallending.models.Log;

@Slf4j
public class LogUtils {
    private LogUtils(){

    }
    public static void info(String content, Object data){
        try {
            Log l = new Log();
            Gson g = new Gson();
            l.setContent(content);
            l.setData(g.toJson(data));
            log.info("{}", g.toJson(l));
        } catch (Exception e){
            log.info(e.getMessage());
        }
    }
    public static void info(String content, String data){
        try {
            Log l = new Log();
            Gson g = new Gson();
            l.setContent(content);
            l.setData(data);
            log.info("{}", g.toJson(l));
        } catch (Exception e){
            log.info(e.getMessage());
        }
    }
    public static void info(String content, Object... data){
        try {
            log.info(content, data);
        } catch (Exception e){
            log.info(e.getMessage());
        }
    }
    public static void info(String content){
        try {
            Log l = new Log();
            Gson g = new Gson();
            l.setContent(content);
            log.info("{}", g.toJson(l));
        } catch (Exception e){
            log.info(e.getMessage());
        }
    }
    public static void error(String content, Object data){
        try {
            Log l = new Log();
            Gson g = new Gson();
            l.setContent(content);
            l.setData(data);
            log.error("{}", g.toJson(l));
        } catch (Exception e){
            log.info(e.getMessage());
        }
    }
    public static void error(String content){
        try {
            Log l = new Log();
            Gson g = new Gson();
            l.setContent(content);
            log.error("{}", g.toJson(l));
        } catch (Exception e){
            log.info(e.getMessage());
        }
    }
}
