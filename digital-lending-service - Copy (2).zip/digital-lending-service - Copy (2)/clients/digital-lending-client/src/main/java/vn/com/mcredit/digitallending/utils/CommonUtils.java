package vn.com.mcredit.digitallending.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Date;

public class CommonUtils {
	private CommonUtils() {
		throw new IllegalStateException("CommonUtils class");
	}

	public static long calculateRemainTime(Date dateCompare){
		java.util.Date currentDate = new Date();
		try {
			return (dateCompare.getTime()-currentDate.getTime());
		} catch (Exception e) {
			LogUtils.info("[CommonUtils] calculateRemainTime", e.getMessage());
		}
		return 0;
	}



	public static String toJsonString(Object object){
		try {
			ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			LogUtils.error("[CommonUtils] toJsonString" , e.getMessage());
		}
		return null;
	}
}
