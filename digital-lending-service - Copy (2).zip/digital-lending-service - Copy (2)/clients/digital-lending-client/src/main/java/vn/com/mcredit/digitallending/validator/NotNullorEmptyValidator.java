package vn.com.mcredit.digitallending.validator;

import vn.com.mcredit.digitallending.utils.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NotNullorEmptyValidator implements ConstraintValidator<NotNullorEmpty, String> {

  /**
   * Kiểm tra tính hợp lệ của trường được đánh dấu bởi @NotNullorEmpty
   *
   * @param s
   * @param constraintValidatorContext
   * @return
   */
  @Override
  public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
    return !StringUtils.isNullOrEmpty(s);
  }
}
