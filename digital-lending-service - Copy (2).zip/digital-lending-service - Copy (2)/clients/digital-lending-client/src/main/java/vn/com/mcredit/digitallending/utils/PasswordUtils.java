package vn.com.mcredit.digitallending.utils;

import java.security.MessageDigest;
import java.util.regex.Pattern;

public class PasswordUtils {


    private PasswordUtils() {

    }

    private static final String PATTERN_PW = "(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z])([A-Za-z0-9!@#$%^&*()+.?-]){6,}";

    //(?=.*[A-Z]): Có ít nhất 1 kí tự hoa
    //(?=.*[a-z]):  Có ít nhất 1 kí tự thường
    //(?=.*[0-9]) : Có ít nhất 1 số
    //Chỉ được chứa các kí tự !@#$%^&*()+.?-
    //Không có khoảng trắng
    //Độ dài ít nhất là 6 kí tự, nhiều nhất 100
    public static Boolean isValid(String password) {

        if (StringUtils.isNullOrEmpty(password))
            return false;

        final var pattern = Pattern.compile(PATTERN_PW);
        return pattern.matcher(password).matches();
    }

    public static String encodMd5(final String s) {
        final var MD5 = "MD5";
        try {
            // Create MD5 Hash
            var digest = MessageDigest
                    .getInstance(MD5);
            digest.update(s.getBytes());
            byte[] messageDigest = digest.digest();
            // Create Hex String
            var hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                var h = new StringBuilder(Integer.toHexString(0xFF & aMessageDigest));
                while (h.length() < 2)
                    h.insert(0, "0");
                hexString.append(h);
            }
            return hexString.toString();
        } catch (Exception e) {
            LogUtils.error("[PasswordUtils] ERROR generate encode password");
            return null;
        }
    }

}
