package vn.com.mcredit.digitallending.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;
import vn.com.mcredit.digitallending.validator.OTP;
import vn.com.mcredit.digitallending.validator.Username;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude
public class SendVerifyOtpDTO {
    @NotNullorEmpty(message = "Vui lòng nhập số điện thoại.")
    @Username
    private String username;

    @NotNullorEmpty(message = "Mã OTP không được để trống.")
    @OTP
    private String otp;

    private String phone;

    private String type;

    private String systemName;
}
