package vn.com.mcredit.digitallending.utils;

import java.util.Arrays;

public class UserNameUtils {

	private UserNameUtils(){

	}

	/*
	●	Số điện thoại bắt đầu bằng các đầu số: 09, 07, 08, 03, 05
	●	10 ký tự số
	*/
	public static Boolean isValid(String username) {

		if(StringUtils.isNullOrEmpty(username)) return false;
		if(!StringUtils.isOnlyNumber(username)) return false;

		/*10 ký tự số*/
		if(username.length() != 10) return false;

		/*Số điện thoại bắt đầu bằng các đầu số: 09, 07, 08, 03, 05*/
		return Arrays.asList("09", "08", "07", "03", "05").contains(username.substring(0, 2));
	}

	public static Boolean isValidMobile(String username) {
		return !StringUtils.isNullOrEmpty(username) && RegexUtils.isCheck(username, RegexUtils.ONLY_CHARACTER_NUMBER_STRING);
	}
}
