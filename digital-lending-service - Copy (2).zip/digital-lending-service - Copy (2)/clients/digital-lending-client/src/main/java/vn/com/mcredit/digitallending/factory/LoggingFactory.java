package vn.com.mcredit.digitallending.factory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import org.springframework.util.CollectionUtils;

import java.util.*;

public class LoggingFactory implements Logger {

    public static final String JAVA_LANG = "java.lang";

    private static final List<String> MASKING_KEY = List.of("dob", "dateOfBirth", "fullName", "identity", "identityCard", "cardId", "citizenId", "location", "address", "creditCardNumber", "accountNumber", "cardNumber", "nationality", "gender", "drivingLicense", "passportId", "idNumber", "oldIdNumber");
    private static final List<String> ENCRYPT_KEY = List.of("password", "encrypt", "secret", "token", "authorization");
    private static final List<String> EXCLUDE_KEY = List.of("username", "contractNumber");

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private final Logger logger;

    private LoggingFactory(Class<?> clazz) {
        logger = LoggerFactory.getLogger(clazz);
    }

    public static Logger getLogger(Class<?> clazz) {
        return new LoggingFactory(clazz);
    }

    @Override
    public String getName() {
        return logger.getName();
    }

    @Override
    public boolean isTraceEnabled() {
        return logger.isTraceEnabled();
    }

    @Override
    public void trace(String s) {
        if (logger.isTraceEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.trace(OBJECT_MAPPER.writeValueAsString(messageLogging));
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.trace(s);
    }

    @Override
    public void trace(String s, Object o) {
        if (logger.isTraceEnabled()) {
            try {
                o = maskingSensitiveData(o);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap()).build();
                logger.trace(OBJECT_MAPPER.writeValueAsString(messageLogging), o);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.trace(s, o);
    }

    @Override
    public void trace(String s, Object o, Object o1) {
        if (logger.isTraceEnabled()) {
            try {
                o = maskingSensitiveData(o);
                o1 = maskingSensitiveData(o1);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o, o1)).build();
                logger.trace(OBJECT_MAPPER.writeValueAsString(messageLogging), o, o1);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.trace(s, o);
    }

    @Override
    public void trace(String s, Object... objects) {
        if (logger.isTraceEnabled()) {
            try {
                objects = maskingSensitiveData(objects);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(objects)).build();
                logger.trace(OBJECT_MAPPER.writeValueAsString(messageLogging), objects);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.trace(s, objects);
    }

    @Override
    public void trace(String s, Throwable throwable) {
        if (logger.isTraceEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.trace(OBJECT_MAPPER.writeValueAsString(messageLogging), throwable);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.trace(s, throwable);
    }

    @Override
    public boolean isTraceEnabled(Marker marker) {
        return logger.isTraceEnabled(marker);
    }

    @Override
    public void trace(Marker marker, String s) {
        logger.trace(marker, s);
    }

    @Override
    public void trace(Marker marker, String s, Object o) {
        logger.trace(marker, s, o);
    }

    @Override
    public void trace(Marker marker, String s, Object o, Object o1) {
        logger.trace(marker, s, o, o1);
    }

    @Override
    public void trace(Marker marker, String s, Object... objects) {
        logger.trace(marker, s, objects);
    }

    @Override
    public void trace(Marker marker, String s, Throwable throwable) {
        logger.trace(marker, s, throwable);
    }

    @Override
    public boolean isDebugEnabled() {
        return logger.isDebugEnabled();
    }

    @Override
    public void debug(String s) {
        if (logger.isDebugEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.debug(OBJECT_MAPPER.writeValueAsString(messageLogging));
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.debug(s);
    }

    @Override
    public void debug(String s, Object o) {
        if (logger.isDebugEnabled()) {
            try {
                o = maskingSensitiveData(o);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o)).build();
                logger.debug(OBJECT_MAPPER.writeValueAsString(messageLogging), o);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.debug(s, o);
    }

    @Override
    public void debug(String s, Object o, Object o1) {
        if (logger.isDebugEnabled()) {
            try {
                o = maskingSensitiveData(o);
                o1 = maskingSensitiveData(o1);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o, o1)).build();
                logger.debug(OBJECT_MAPPER.writeValueAsString(messageLogging), o, o1);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.debug(s, o);
    }

    @Override
    public void debug(String s, Object... objects) {
        if (logger.isDebugEnabled()) {
            try {
                objects = maskingSensitiveData(objects);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(objects)).build();
                logger.debug(OBJECT_MAPPER.writeValueAsString(messageLogging), objects);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.debug(s, objects);
    }

    @Override
    public void debug(String s, Throwable throwable) {
        if (logger.isDebugEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.debug(OBJECT_MAPPER.writeValueAsString(messageLogging), throwable);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.debug(s, throwable);
    }

    @Override
    public boolean isDebugEnabled(Marker marker) {
        return logger.isDebugEnabled(marker);
    }

    @Override
    public void debug(Marker marker, String s) {
        logger.debug(marker, s);
    }

    @Override
    public void debug(Marker marker, String s, Object o) {
        logger.debug(marker, s, o);
    }

    @Override
    public void debug(Marker marker, String s, Object o, Object o1) {
        logger.debug(marker, s, o, o1);
    }

    @Override
    public void debug(Marker marker, String s, Object... objects) {
        logger.debug(marker, s, objects);
    }

    @Override
    public void debug(Marker marker, String s, Throwable throwable) {
        logger.debug(marker, s, throwable);
    }

    @Override
    public boolean isInfoEnabled() {
        return logger.isInfoEnabled();
    }

    @Override
    public void info(String s) {
        if (logger.isInfoEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.info(OBJECT_MAPPER.writeValueAsString(messageLogging));
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.info(s);
    }

    @Override
    public void info(String s, Object o) {
        if (logger.isInfoEnabled()) {
            try {
                o = maskingSensitiveData(o);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o)).build();
                logger.info(OBJECT_MAPPER.writeValueAsString(messageLogging), o);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.info(s, o);
    }

    @Override
    public void info(String s, Object o, Object o1) {
        if (logger.isInfoEnabled()) {
            try {
                o = maskingSensitiveData(o);
                o1 = maskingSensitiveData(o1);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o, o1)).build();
                logger.info(OBJECT_MAPPER.writeValueAsString(messageLogging), o, o1);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.info(s, o, o1);
    }

    @Override
    public void info(String s, Object... objects) {
        if (logger.isInfoEnabled()) {
            try {
                objects = maskingSensitiveData(objects);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(objects)).build();
                logger.info(OBJECT_MAPPER.writeValueAsString(messageLogging), objects);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.info(s, objects);
    }

    @Override
    public void info(String s, Throwable throwable) {
        if (logger.isInfoEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.info(OBJECT_MAPPER.writeValueAsString(messageLogging), throwable);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.info(s, throwable);
    }

    @Override
    public boolean isInfoEnabled(Marker marker) {
        return false;
    }

    @Override
    public void info(Marker marker, String s) {
        logger.info(s, s);
    }

    @Override
    public void info(Marker marker, String s, Object o) {
        logger.info(marker, s, o);
    }

    @Override
    public void info(Marker marker, String s, Object o, Object o1) {
        logger.info(marker, s, o, o1);
    }

    @Override
    public void info(Marker marker, String s, Object... objects) {
        logger.info(marker, s, objects);
    }

    @Override
    public void info(Marker marker, String s, Throwable throwable) {
        logger.info(marker, s, throwable);
    }

    @Override
    public boolean isWarnEnabled() {
        return logger.isWarnEnabled();
    }

    @Override
    public void warn(String s) {
        if (logger.isWarnEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.warn(OBJECT_MAPPER.writeValueAsString(messageLogging));
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.warn(s);
    }

    @Override
    public void warn(String s, Object o) {
        if (logger.isWarnEnabled()) {
            try {
                o = maskingSensitiveData(o);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o)).build();
                logger.warn(OBJECT_MAPPER.writeValueAsString(messageLogging), o);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.warn(s, o);
    }

    @Override
    public void warn(String s, Object... objects) {
        if (logger.isWarnEnabled()) {
            try {
                objects = maskingSensitiveData(objects);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(objects)).build();
                logger.warn(OBJECT_MAPPER.writeValueAsString(messageLogging), objects);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.warn(s, objects);
    }

    @Override
    public void warn(String s, Object o, Object o1) {
        if (logger.isWarnEnabled()) {
            try {
                o = maskingSensitiveData(o);
                o1 = maskingSensitiveData(o1);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o, o1)).build();
                logger.warn(OBJECT_MAPPER.writeValueAsString(messageLogging), o, o1);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.warn(s, o, o1);
    }

    @Override
    public void warn(String s, Throwable throwable) {
        if (logger.isWarnEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.warn(OBJECT_MAPPER.writeValueAsString(messageLogging), throwable);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.warn(s, throwable);
    }

    @Override
    public boolean isWarnEnabled(Marker marker) {
        return logger.isWarnEnabled(marker);
    }

    @Override
    public void warn(Marker marker, String s) {
        logger.warn(marker, s);
    }

    @Override
    public void warn(Marker marker, String s, Object o) {
        logger.warn(marker, s, o);
    }

    @Override
    public void warn(Marker marker, String s, Object o, Object o1) {
        logger.warn(marker, s, o, o1);
    }

    @Override
    public void warn(Marker marker, String s, Object... objects) {
        logger.warn(marker, s, objects);
    }

    @Override
    public void warn(Marker marker, String s, Throwable throwable) {
        logger.warn(marker, s, throwable);
    }

    @Override
    public boolean isErrorEnabled() {
        return logger.isErrorEnabled();
    }

    @Override
    public void error(String s) {
        if (logger.isErrorEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.error(OBJECT_MAPPER.writeValueAsString(messageLogging));
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.error(s);
    }

    @Override
    public void error(String s, Object o) {
        if (logger.isErrorEnabled()) {
            try {
                o = maskingSensitiveData(o);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o)).build();
                logger.error(OBJECT_MAPPER.writeValueAsString(messageLogging), o);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.error(s, o);
    }

    @Override
    public void error(String s, Object o, Object o1) {
        if (logger.isErrorEnabled()) {
            try {
                o = maskingSensitiveData(o);
                o1 = maskingSensitiveData(o1);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(o, o1)).build();
                logger.error(OBJECT_MAPPER.writeValueAsString(messageLogging), o, o1);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.error(s, o, o1);
    }

    @Override
    public void error(String s, Object... objects) {
        if (logger.isErrorEnabled()) {
            try {
                objects = maskingSensitiveData(objects);
                MessageLogging messageLogging = MessageLogging.builder().content(s).data(setParamToMap(objects)).build();
                logger.error(OBJECT_MAPPER.writeValueAsString(messageLogging), objects);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.error(s, objects);
    }

    @Override
    public void error(String s, Throwable throwable) {
        if (logger.isErrorEnabled()) {
            try {
                MessageLogging messageLogging = MessageLogging.builder().content(s).build();
                logger.error(OBJECT_MAPPER.writeValueAsString(messageLogging), throwable);
                return;
            } catch (JsonProcessingException e) {
                // no thing
            }
        }
        logger.error(s, throwable);
    }

    @Override
    public boolean isErrorEnabled(Marker marker) {
        return logger.isErrorEnabled(marker);
    }

    @Override
    public void error(Marker marker, String s) {
        logger.error(marker, s);
    }

    @Override
    public void error(Marker marker, String s, Object o) {
        logger.error(marker, s, o);
    }

    @Override
    public void error(Marker marker, String s, Object o, Object o1) {
        logger.error(marker, s, o, o1);
    }

    @Override
    public void error(Marker marker, String s, Object... objects) {
        logger.error(marker, s, objects);
    }

    @Override
    public void error(Marker marker, String s, Throwable throwable) {
        logger.error(marker, s, throwable);
    }

    private static Object maskingSensitiveData(Object o, boolean isEncryptString) {
        if (o == null) {
            return o;
        }
        try {
            Class<?> clazz = o.getClass();
            if (!clazz.getName().contains(JAVA_LANG)) {
                if (o instanceof Collection<?>) {
                    return maskingListData(o, isEncryptString);
                }
                return maskingMapData(o);
            } else {
                // Nếu trường hợp dữ liệu của map và list là 1 json map hoặc json object thì sẽ truy cập sâu vào các dữ liệu bên trong để mã hóa dữ liệu
                Object data = extractDataFromJsonString(o, isEncryptString);
                if (data != null) return data;
                if (isEncryptString) {
                    return "*******";
                }
                return o.toString();
            }
        } catch (Exception e) {
            // nothing
        }
        return o;
    }

    private static Object extractDataFromJsonString(Object o, boolean isEncryptString) {
        if (!(o instanceof String)) {
            return null;
        }
        String value = (String) o;
        if (value.contains("{") || value.contains("[")) {
            JsonNode jsonNode;
            try {
                jsonNode = OBJECT_MAPPER.readTree(value);
            } catch (Exception e) {
                return null;
            }
            if (jsonNode.isArray()) {
                return maskingListData(o, isEncryptString);
            } else if (jsonNode.isObject()) {
                return maskingMapData(o);
            }
        }
        return null;
    }

    private static Map<String, Object> maskingMapData(Object o) {
        Map<String, Object> map = getDataFromValue(o, new TypeReference<HashMap<String, Object>>() {
        });

        if (map == null) {
            return Collections.emptyMap();
        }

        for (Map.Entry<String, Object> value : map.entrySet()) {
            if (value.getValue() == null) {
                continue;
            }
            if (!value.getValue().getClass().getName().contains(JAVA_LANG)) {
                var maskingData = maskingSensitiveData(value.getValue(), isEncryptKey(value.getKey()));
                map.put(value.getKey(), maskingData);
                continue;
            }

            // Nếu trường hợp dữ liệu của map và list là 1 json map hoặc json object thì sẽ truy cập sâu vào các dữ liệu bên trong để mã hóa dữ liệu
            Object data = extractDataFromJsonString(value.getValue(), isEncryptKey(value.getKey()));
            if (data != null) {
                map.put(value.getKey(), data);
                continue;
            }

            if (isEncryptKey(value.getKey())) {
                map.put(value.getKey(), "*******");
            } else if (isMaskingKey(value.getKey())) {
                String maskStr = maskingValue(value.getValue());
                map.put(value.getKey(), maskStr);
            }
        }
        return map;
    }

    private static <T> T getDataFromValue(Object o, TypeReference<T> clazz) {
        if (o instanceof String) {
            try {
                return OBJECT_MAPPER.readValue((String) o, clazz);
            } catch (JsonProcessingException e) {
                return null;
            }
        } else {
            return OBJECT_MAPPER.convertValue(o, clazz);
        }
    }

    private static boolean isMaskingKey(String key) {
        if (isExcludeKey(key)) {
            return false;
        }
        for (String keyNeedMaking : MASKING_KEY) {
            if (StringUtils.containsIgnoreCase(key, keyNeedMaking)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isEncryptKey(String key) {

        if (isExcludeKey(key)) {
            return false;
        }
        for (String keyNeedEncrypt : ENCRYPT_KEY) {
            if (StringUtils.containsIgnoreCase(key, keyNeedEncrypt)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isExcludeKey(String key) {
        for (String excludeKey : EXCLUDE_KEY) {
            if (StringUtils.containsIgnoreCase(key, excludeKey)) {
                return true;
            }
        }
        return false;
    }

    private static List<Object> maskingListData(Object o, boolean isMaskingString) {
        List<Object> list = getDataFromValue(o, new TypeReference<>() {
        });
        List<Object> listResult = new ArrayList<>();
        if (CollectionUtils.isEmpty(list)) {
            return listResult;
        }
        for (Object object : list) {
            var maskingValue = maskingSensitiveData(object, isMaskingString);
            listResult.add(maskingValue);
        }
        return listResult;
    }

    private static String encryptValue(Object o) {
        return "*".repeat(o.toString().length());
    }

    private static String maskingValue(Object o) {
        String input = o.toString();
        int length = input.length() / 3;
        if (length < 1) return "*".repeat(input.length());
        return "*".repeat(length) + input.substring(length, input.length() - length) + "*".repeat(length);
    }

    private static Object[] maskingSensitiveData(Object... objects) {
        List<Object> objectList = new ArrayList<>();
        try {
            for (Object o : objects) {
                objectList.add(maskingSensitiveData(o, false));
            }
        } catch (Exception e) {
            // nothing
        }
        return objectList.toArray();
    }

    private static Object maskingSensitiveData(Object o) {
        return maskingSensitiveData(o, false);
    }

    private static Map<String, Object> setParamToMap(Object... objects) {
        Map<String, Object> objectMap = new HashMap<>();
        // Đảm bảo thứ tự nếu cùng 1 class trong logging
        Map<String, Integer> keyOrder = new HashMap<>();
        try {
            for (Object o : objects) {
                if (o != null && !o.getClass().getName().startsWith(JAVA_LANG)) {
                    String key = o.getClass().getSimpleName();
                    // nếu không có trong map thứ tự thì sẽ convert về 0
                    int order = keyOrder.get(key) == null ? 0 : keyOrder.get(key);
                    int nexOrder = order + 1;
                    keyOrder.put(key, nexOrder);
                    objectMap.put(key + nexOrder, o);
                }
            }
        } catch (Exception e) {
            // nothing
        }
        return objectMap;
    }

}

@Data
@Builder
class MessageLogging {
    private String content;
    private Map<String, Object> data;

    @Builder.Default
    private Boolean isCustomize = true;
}

