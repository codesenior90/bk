package vn.com.mcredit.digitallending.utils;


public class StringUtils {
  private StringUtils() {
    throw new IllegalStateException("StringUtils class");
  }

  public static boolean isNullOrEmpty(String val) {
    return val == null || val.trim().isBlank() || val.trim().isEmpty();
  }

  public static boolean isLength(int max, int min, String value) {
    return value.length() == min || value.length() == max;
  }
  public static String[] convertStringToArray(String val,String regex) {
    String[] empty = {};
    return val == null ? empty : val.split(regex);
  }

  public static boolean isOnlyNumber(String val) {
    if(isNullOrEmpty(val)) return false;

    return val.chars().allMatch(Character::isDigit);
  }

  public static boolean isNotBlank(String str) {
    return !StringUtils.isBlank(str);
  }

  public static boolean isBlank(String str) {
    int strLen;
    if (str == null || (strLen = str.length()) == 0) {
      return true;
    }
    for (int i = 0; i < strLen; i++) {
      if (!Character.isWhitespace(str.charAt(i))) {
        return false;
      }
    }
    return true;
  }

  public static boolean isNumeric(String string) {
    return string.matches("\\d+");
  }
}
