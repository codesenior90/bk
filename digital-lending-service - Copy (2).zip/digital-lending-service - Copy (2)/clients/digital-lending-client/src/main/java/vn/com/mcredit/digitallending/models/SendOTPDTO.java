package vn.com.mcredit.digitallending.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;
import vn.com.mcredit.digitallending.validator.Username;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude
public class SendOTPDTO {
    @NotNullorEmpty(message = "Vui lòng nhập số điện thoại")
    @Username
    private String username;

    @NotNullorEmpty(message = "Dữ liệu không được để trống.")
    private String type;

    private String systemName;
}
