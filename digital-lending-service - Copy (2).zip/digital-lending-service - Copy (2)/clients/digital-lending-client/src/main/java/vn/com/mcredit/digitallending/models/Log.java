package vn.com.mcredit.digitallending.models;

import lombok.Data;

@Data
public class Log {
    private Boolean isCustomize = true;
    private String content;
    private Object data;
}
