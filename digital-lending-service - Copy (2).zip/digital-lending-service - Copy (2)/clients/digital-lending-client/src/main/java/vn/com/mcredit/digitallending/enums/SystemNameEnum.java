package vn.com.mcredit.digitallending.enums;

public enum SystemNameEnum {
    MOBILE_DIGITAL_LENDING("MOBILE_DIGITAL_LENDING");

    private String value;

    SystemNameEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
