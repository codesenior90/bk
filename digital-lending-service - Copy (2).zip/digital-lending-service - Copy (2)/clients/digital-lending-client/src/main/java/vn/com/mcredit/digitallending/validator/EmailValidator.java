package vn.com.mcredit.digitallending.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

public class EmailValidator implements ConstraintValidator<vn.com.mcredit.digitallending.validator.Email, String> {

  private String regex =
      "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";

  /**
   * Kiểm tra định dạng email nếu email not empty and not null
   * @param s
   * @param constraintValidatorContext
   * @return
   */
  @Override
  public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
    if (s == null || s.isEmpty()) return true;

    var pattern = Pattern.compile(regex);

    var matcher = pattern.matcher(s);
    return matcher.matches();
  }
}
