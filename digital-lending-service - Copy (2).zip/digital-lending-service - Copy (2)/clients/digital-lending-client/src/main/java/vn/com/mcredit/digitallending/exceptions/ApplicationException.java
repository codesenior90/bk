package vn.com.mcredit.digitallending.exceptions;

import lombok.Data;
import vn.com.mcredit.digitallending.models.ErrorItem;

import java.io.Serializable;
import java.util.List;

@Data
public class ApplicationException extends RuntimeException implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<ErrorItem> errorItems;

  private String code;
  private String message;
  private Integer count;

  public ApplicationException(String message) {
    super(message);
  }

  public ApplicationException(String message, List<ErrorItem> errorItems) {
    super(message);
    this.errorItems = errorItems;
  }
  public ApplicationException(String code, String message, List<ErrorItem> errorItems) {
    super(message);
    this.code = code;
    this.errorItems = errorItems;
  }
  public ApplicationException(String code, String message) {
    super(message);
    this.message = message;
    this.code = code;
  }
  public ApplicationException(String code, String message, Integer count) {
    super(message);
    this.message = message;
    this.code = code;
    this.count = count;
  }
  @Override
  public String getMessage() {
    return this.message;
  }

}
