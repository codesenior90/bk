package vn.com.mcredit.digitallending.validator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = vn.com.mcredit.digitallending.validator.OTPValidator.class)
@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface OTP {
  // trường message là bắt buộc, khai báo nội dung sẽ trả về khi field k hợp lệ
  String message() default "Mã OTP không hợp lệ.";
  // Cái này là bắt buộc phải có để Hibernate Validator có thể hoạt động
  Class<?>[] groups() default {};
  // Cái này là bắt buộc phải có để Hibernate Validator có thể hoạt động
  Class<? extends Payload>[] payload() default {};
}
