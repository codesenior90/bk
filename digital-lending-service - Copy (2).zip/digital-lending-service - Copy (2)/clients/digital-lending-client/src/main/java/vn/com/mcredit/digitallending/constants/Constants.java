package vn.com.mcredit.digitallending.constants;

public class Constants {
  public class BadRequest {
    public static final String ERROR_400_03 = "400.03";
    public static final String ERROR_400 = "400";
    public static final String MESSAGE = "Bad request";
    protected BadRequest(){

    }
  }
  public class InternalServerError {
    public static final String ERROR_500 = "500";
    protected InternalServerError(){

    }
  }



  public static final String EMPTY = "";

}
