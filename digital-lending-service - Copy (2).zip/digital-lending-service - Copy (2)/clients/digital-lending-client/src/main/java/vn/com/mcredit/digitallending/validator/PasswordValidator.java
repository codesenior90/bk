package vn.com.mcredit.digitallending.validator;


import vn.com.mcredit.digitallending.utils.PasswordUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PasswordValidator implements ConstraintValidator<Password, String> {

  /**
   * Kiểm tra tính hợp lệ của trường được đánh dấu bởi @Username
   *
   * @param s
   * @param constraintValidatorContext
   * @return
   */
  @Override
  public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
    if (s != null && !s.trim().isEmpty()) return PasswordUtils.isValid(s);

    return true;
  }
}
