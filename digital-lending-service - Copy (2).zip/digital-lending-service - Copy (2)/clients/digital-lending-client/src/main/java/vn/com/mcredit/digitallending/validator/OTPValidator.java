package vn.com.mcredit.digitallending.validator;

import vn.com.mcredit.digitallending.utils.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class OTPValidator implements ConstraintValidator<OTP, String> {
	
/**
   * Kiểm tra tính hợp lệ của trường được đánh dấu bởi @Username
   *
   * @param s
   * @param constraintValidatorContext
   * @return
   */
  @Override
  public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
    if (s != null && !s.trim().isEmpty()) return StringUtils.isOnlyNumber(s);

    return true;
  }
}
