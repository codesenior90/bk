package vn.com.mcredit.digitallending.enums;

public enum TransactionKeeperEnum {
    SERVICE_MESSAGE_ID("x-service-message-id"), TRANSACTION_ID("x-transaction-id"), JWT("x-jwt"),
    SOURCE_SYSTEM("x-source-system"),LOG_INFO("x-log-info");

    private String value;

    TransactionKeeperEnum(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static TransactionKeeperEnum from(String text) {
        for (TransactionKeeperEnum b : TransactionKeeperEnum.values()) {
            if (b.value.equalsIgnoreCase(text)) {
                return b;
            }
        }
        return null;
    }
}
