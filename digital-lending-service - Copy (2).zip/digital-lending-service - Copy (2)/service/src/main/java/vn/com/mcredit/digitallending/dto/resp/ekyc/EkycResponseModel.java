package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

@Data
public class EkycResponseModel {
    private String code;
    private String ocrCode;
    private String citizenId;
    private String selfieCode;
    private String leftCode;
    private String rightCode;
    private String status;
    private String frontDimension;
    private String selfieDimension;
    private FaceMatchingModel faceMatching;
    private LivenessModel liveness;
    // Additional
    private String rightImageUrl;
    private String leftImageUrl;
    private String selfieImageUrl;
}
