package vn.com.mcredit.digitallending.dto.resp.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerResult {
    private Boolean hasAccountApp;
    private Boolean hasLoan;
    private String name;
    private String token;
    private Object user;
}
