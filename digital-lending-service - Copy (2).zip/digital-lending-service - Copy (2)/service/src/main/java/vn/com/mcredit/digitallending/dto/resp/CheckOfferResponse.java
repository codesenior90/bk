package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class CheckOfferResponse extends BpmBaseResponse{
    private String data;
}
