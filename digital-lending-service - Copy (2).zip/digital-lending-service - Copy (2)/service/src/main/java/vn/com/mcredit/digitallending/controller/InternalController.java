package vn.com.mcredit.digitallending.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.com.mcredit.digitallending.aop.InternalApi;
import vn.com.mcredit.digitallending.dto.req.MiniAppHomePageRequest;
import vn.com.mcredit.digitallending.dto.req.contract.ContractDTO;
import vn.com.mcredit.digitallending.services.AuthService;
import vn.com.mcredit.digitallending.services.BpmService;
import vn.com.mcredit.digitallending.services.EkycModelService;

@RequiredArgsConstructor
@RequestMapping("/api/internal")
@RestController
public class InternalController {
    private final AuthService authService;
    private final EkycModelService ekycModelService;
    private final BpmService bpmService;
    @InternalApi
    @PostMapping("/v1/page/tik-tak")
    public ResponseEntity<Object> generaTikTakPage(@RequestBody MiniAppHomePageRequest request) {
        return ResponseEntity.status(HttpStatus.OK).body(authService.generateTikTakPage(request));
    }

    @InternalApi
    @GetMapping(value = "/v1/{username}/links", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getS3Links(@PathVariable String username) {
        return ResponseEntity.status(HttpStatus.OK).body(ekycModelService.getUserLink(username));
    }
    @InternalApi
    @PostMapping(value = "/v1/contract-info", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getContractInfo(@RequestBody ContractDTO contract) {
        return ResponseEntity.status(HttpStatus.OK).body(bpmService.getContractInfo(contract));
    }
}
