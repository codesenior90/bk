package vn.com.mcredit.digitallending.dto.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CheckLeadResponse {
    private String status;
    private String reason;
    private String bankLeadId;
    private String dateTime;
    private String returnCode;
    private String returnMes;
}
