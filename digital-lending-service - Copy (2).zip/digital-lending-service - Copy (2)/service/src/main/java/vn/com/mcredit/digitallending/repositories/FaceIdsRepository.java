package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.FaceIds;

@Repository
public interface FaceIdsRepository extends JpaRepository<FaceIds, String> {
    FaceIds findByOcrRequestId(String requestId);
}
