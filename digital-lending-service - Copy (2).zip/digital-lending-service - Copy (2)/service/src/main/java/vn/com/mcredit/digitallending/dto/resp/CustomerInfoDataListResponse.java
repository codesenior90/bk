package vn.com.mcredit.digitallending.dto.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class CustomerInfoDataListResponse {

    private String criteriaGrpID;

    private String criteriaGrpNM;

    private String criteriaID;

    private String criteriaNM;

    private String criteriaValue;

}
