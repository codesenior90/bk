package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.LoginDTO;
import vn.com.mcredit.digitallending.entity.PartnerUserInfo;

public interface MiniAppService {

    void saveCustomerInfoMb(PartnerUserInfo partnerUserInfo);
}
