package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CheckDeviceResult {
    private String result;
    private String caseNumber;
    @JsonProperty("brithday")
    private String birthday;
    private String numberPhone;
    private String errorCode;
    private String fullName;
    @JsonProperty("createdate")
    private String createDate;
    private String numberId;
    private String numberExtraId;
}
