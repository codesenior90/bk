package vn.com.mcredit.digitallending.security;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import vn.com.mcredit.digitallending.utils.LogUtils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.Security;
import java.util.Base64;

/**
 * Mã hóa và giải mã aes
 * https://www.allkeysgenerator.com/Random/Security-Encryption-Key-Generator.aspx
 */
public class Aes {
    private Aes(){}
    private static final String CRYPTO_METHOD = "AES";
    private static final String CYPHER = "AES/ECB/PKCS7PADDING";
    private static final String BOUNCY_CAST_PROVIDER = "BC";

    private static SecretKeySpec secretKey;
    private static String secret;
    public static void init(String secretText) {

        secret = secretText;
    }
    static {
        Security.addProvider(new BouncyCastleProvider());
    }
    public static void setKey(final String myKey) {
        byte[] key = myKey.getBytes(StandardCharsets.UTF_8);
        secretKey = new SecretKeySpec(key, CRYPTO_METHOD);
    }
    public static String encrypt(final String strToEncrypt) {
        return encrypt(strToEncrypt, secret);
    }
    @SuppressWarnings("java:S5542")
    public static String encrypt(final String strToEncrypt, final String secret) {
        try {
            setKey(secret);
            Cipher cipher = Cipher.getInstance(CYPHER, BOUNCY_CAST_PROVIDER);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedData = cipher.doFinal(strToEncrypt.getBytes());
            return Base64.getEncoder().encodeToString(encryptedData);
        } catch (Exception e) {
            LogUtils.error("Error while encrypting: ", e.getMessage());
        }
        return null;
    }

    public static String decrypt(final String strToDecrypt) {
        return decrypt(strToDecrypt, secret);
    }
    @SuppressWarnings("java:S5542")
    public static String decrypt(final String strToDecrypt, final String secret) {
        try {
            setKey(secret);
            Cipher cipher = Cipher.getInstance(CYPHER, BOUNCY_CAST_PROVIDER);
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (Exception e) {
            LogUtils.error("Error while decrypting: ", e.getMessage());
        }
        return null;
    }
}
