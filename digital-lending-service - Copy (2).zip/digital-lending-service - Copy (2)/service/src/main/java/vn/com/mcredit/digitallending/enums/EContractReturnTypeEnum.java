package vn.com.mcredit.digitallending.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public enum EContractReturnTypeEnum {
    /**
     * Ký hợp đồng
     */
    SIGN("SIGN"),

    /**
     * Ký phụ lục
     */
    SIGN_APPENDIX("SIGN_APPENDIX"),

    /**
     * Hủy hợp đồng
     */
    REJECT("REJECT"),

    /**
     * Hủy ký phụ lục
     */
    REJECT_APPENDIX("REJECT_APPENDIX"),

    /**
     * Hoàn thiện hợp đồng
     */
    COMPLETE("DONE"),

    /**
     * Hoàn thiện hợp đồng phụ lục
     */
    COMPLETE_APPENDIX("COMPLETE_APPENDIX"),;

    private static final Map<String, EContractReturnTypeEnum> map = new HashMap<>();

    static {
        Arrays.stream(values()).forEach(m -> map.put(m.name(), m));
    }

    public static EContractReturnTypeEnum getType(String type) {
        return map.get(type);
    }



    private String value;

    EContractReturnTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }


}
