package vn.com.mcredit.digitallending.logging;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.LogDTO;


@Component
@Slf4j
public class Logging {

	@Autowired
    TransactionKeeper tk;
	
	Gson g = new Gson();

	public void info(String msg) {
		try {
			var l = g.fromJson(tk.getLogInfo(), LogDTO.class);
			if (l != null) {
				l.setErrorMes(msg);
				log.info(g.toJson(l));
			} else
				log.info(msg);
		} catch (Exception e) {
			log.error(msg);
			log.error("Logging.info = {}", e.getMessage());
		}
	}
	public void info(Object... vars){
		log.info("{}", vars);
	}
	public void error(String msg) {
		try {
			var l = g.fromJson(tk.getLogInfo(), LogDTO.class);
			if (l != null) {
				l.setErrorMes(msg);
				log.error(g.toJson(l));
			} else
				log.error(msg);
		} catch (Exception e) {
			log.error(msg);
			log.error("Logging.info = {}", e.getMessage());
		}
	}
}
