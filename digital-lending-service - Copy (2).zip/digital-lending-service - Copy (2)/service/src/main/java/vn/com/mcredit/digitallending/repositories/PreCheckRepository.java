package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.PreCheck;

@Repository
public interface PreCheckRepository extends JpaRepository<PreCheck, String> {
    @Query(value = "SELECT * FROM pre_check WHERE user_name = :userName order by updated_date desc limit 1 ", nativeQuery = true)
    PreCheck getPreCheckByUserName(String userName);
}
