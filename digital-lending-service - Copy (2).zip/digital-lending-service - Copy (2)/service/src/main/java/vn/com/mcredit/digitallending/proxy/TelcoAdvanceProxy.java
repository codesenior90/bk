package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.resp.TelcoAdvanceLocationCheckResponse;

@Component
public class TelcoAdvanceProxy extends BaseProxy{
    @Value("${custom.properties.telco-advance-api-host}")
    protected String telcoAdvanceHost;
    public TelcoAdvanceLocationCheckResponse telcoLocationCheck(Object body){
        String url = String.format("%s%s", telcoAdvanceHost, "/telco_location_check");
        return this.post(url, initHeaderAppJson(), body, TelcoAdvanceLocationCheckResponse.class);    }
}
