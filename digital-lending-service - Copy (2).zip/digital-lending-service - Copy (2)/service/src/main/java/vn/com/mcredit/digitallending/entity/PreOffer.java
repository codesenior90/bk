package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import java.math.BigInteger;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pre_offer")
public class PreOffer {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "birthDay")
    private String birthDay;
    @Column(name = "age")
    private Integer age;
    @Column(name = "businessChannel")
    private String businessChannel;
    @Column(name = "city")
    private String city;
    @Column(name = "customerGroup")
    private String customerGroup;
    @Column(name = "hasInsurance")
    private String hasInsurance;
    @Column(name = "insuranceCompany")
    private String insuranceCompany;
    @Column(name = "insuranceFee")
    private Double insuranceFee;
    @Column(name = "loanAmtMinusInsu")
    private BigInteger loanAmtMinusInsu;
    @Column(name = "loanPurpose")
    private String loanPurpose;
    @Column(name = "loanTenor")
    private BigInteger loanTenor;
    @Column(name = "request_id")
    private String requestId;
    @Column(name = "offer_id")
    private BigInteger offerId;
    @Column(name = "score")
    private String score;
    @Column(name = "sex")
    private String sex;
    @Column(name = "fullName")
    private String fullName;
    @Column(name = "phoneNumber")
    private String phoneNumber;
    @Column(name = "numberExtraId")
    private String numberExtraId;
    @Column(name = "numberId")
    private String numberId;
    @Column(name = "offerdgtresponse", columnDefinition = "text")
    private String offerDGTResponse;
    @Column(name = "offerdgtdetailresponse", columnDefinition = "text")
    private String offerDGTDetailResponse;
    @Column(name = "user_name")
    private String userName;
    @Column(name = "createdBy")
    private String createdBy;
    @Column(name = "updatedBy")
    private String updatedBy;
    @Column(name = "updatedDate")
    private Date updatedDate;
    @Column(name = "createdDate")
    private Date createdDate;
    @Column(name = "status",length = 30)
    private String status;
    @Column(name = "reason", columnDefinition = "text")
    private String reason;
    @Column(name = "reason_code", columnDefinition = "text")
    private String reasonCode;
    @Column(name = "offer_request", columnDefinition = "text")
    private String offerRequest;

    @Column(name = "refer_id")
    private String referId; // request_id ở bước check dup mc

    @Column(name = "partner_code", length = 25)
    private String partnerCode; // Dùng để trace khách hàng get offer từ đâu (Mini-app, web, app mcredit ...)
    @Column(name = "case_number")
    private String caseNumber;
}
