package vn.com.mcredit.digitallending.controller.internal;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.dto.req.CustomerInfoMbRequest;
import vn.com.mcredit.digitallending.dto.resp.CustomerInfoDataListResponse;
import vn.com.mcredit.digitallending.dto.resp.CustomerInfoMbResponse;
import vn.com.mcredit.digitallending.entity.Criteria;
import vn.com.mcredit.digitallending.entity.PartnerUserInfo;
import vn.com.mcredit.digitallending.proxy.MiniAppProxy;
import vn.com.mcredit.digitallending.repositories.CriteriaRepository;
import vn.com.mcredit.digitallending.utils.DateUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;

import java.util.List;

@RequiredArgsConstructor
@RequestMapping("/internal-support")
@RestController
public class SupportController {

    private final MiniAppProxy miniAppProxy;

    private final CriteriaRepository criteriaRepository;

    @Operation(summary = "decrypt")
    @PostMapping(value = "/thu-test")
    public ResponseEntity<Object> saveInfoMb(@RequestParam String customerCode) {
        return ResponseEntity.status(HttpStatus.OK).body(this.saveCustomerInfoMb(customerCode));
    }

    public String saveCustomerInfoMb(String customerCode) {
        try {
                CustomerInfoMbRequest customerInfoMbRequest = new CustomerInfoMbRequest();
                customerInfoMbRequest.setCustomerCode(customerCode);
                customerInfoMbRequest.setCriteriaType(Constants.CRITERIA_TYPE_G);
                customerInfoMbRequest.setCriteria(Constants.CRITERIA_ALL);
                customerInfoMbRequest.setLimit(Constants.CRITERIA_LIMIT);
                CustomerInfoMbResponse customerInfoMbResponse = miniAppProxy.getCustomerInfoMb(customerInfoMbRequest);
                if (customerInfoMbResponse != null) {
                    List<CustomerInfoDataListResponse> dataListResponse = customerInfoMbResponse.getData().getDataList();
                    if (ObjectUtils.isNotEmpty(dataListResponse)) {
                        for (CustomerInfoDataListResponse customerInfoDataListResponse :dataListResponse) {
                            Criteria criteria = new Criteria();
                            criteria.setCustomerCode(customerCode);
                            criteria.setClientMessageId(customerInfoMbResponse.getClientMessageId());
                            criteria.setCriteriaType(customerInfoMbRequest.getCriteriaType());
                            criteria.setCriteria(customerInfoMbRequest.getCriteria());
                            criteria.setCriteriaGrpId(customerInfoDataListResponse.getCriteriaGrpID());
                            criteria.setCriteriaGrpNm(customerInfoDataListResponse.getCriteriaGrpNM());
                            criteria.setCriteriaId(customerInfoDataListResponse.getCriteriaID());
                            criteria.setCriteriaNm(customerInfoDataListResponse.getCriteriaNM());
                            criteria.setCriteriaValue(customerInfoDataListResponse.getCriteriaValue());
                            criteria.setCreatedAt(DateUtils.getNowDate());
                            criteriaRepository.save(criteria);
                            LogUtils.info("[CustomerInfoMb] save success");
                        }
                    }
                }
        } catch (Exception e) {
            LogUtils.info("[CustomerInfoMb] err" + e.getMessage());
        }
        LogUtils.info("[CustomerInfoMb] save fail");
        return "hihi";
    }


}
