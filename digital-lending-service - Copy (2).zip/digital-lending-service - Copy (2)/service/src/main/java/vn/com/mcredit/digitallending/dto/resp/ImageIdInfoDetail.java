package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ImageIdInfoDetail {

    @JsonProperty("image_url")
    private String imageUrl;
    @JsonProperty("image_type")
    private String imageType;

    @JsonProperty("face_matching_score")
    private Float faceMatchingScore;

    @JsonProperty("case_number")
    private Float caseNumber;

    @JsonProperty("name")
    private String name;

    @JsonProperty("dob")
    private String dob;

    @JsonProperty("check_detail")
    private List<String> checkDetail;

    @JsonProperty("cccd_number")
    private String cccdNumber;

    @JsonProperty("cmndo_number")
    private String cmndoNumber;


}
