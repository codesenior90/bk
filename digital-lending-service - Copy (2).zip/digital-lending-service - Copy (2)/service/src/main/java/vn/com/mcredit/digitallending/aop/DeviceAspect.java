package vn.com.mcredit.digitallending.aop;

import lombok.RequiredArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.services.UserDeviceService;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;


@Aspect
@Configuration
@Order(0)
@RequiredArgsConstructor
public class DeviceAspect {

	private final UserDeviceService userDeviceService;

	@Before("@annotation(Device)")
	public void before(JoinPoint j) {
		this.verifyDevice();
	}
	private void verifyDevice(){
		String deviceId =  JWTUtils.getDeviceId();
		if (StringUtils.isBlank(deviceId)){
			throw new ApplicationException(Error.DEVICE_ID_IS_EMPTY.getCode(), Error.DEVICE_ID_IS_EMPTY.getMessage());
		}
	}
}
