package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.dto.req.CustomerInfoMbRequest;
import vn.com.mcredit.digitallending.dto.resp.CustomerInfoDataListResponse;
import vn.com.mcredit.digitallending.dto.resp.CustomerInfoMbResponse;
import vn.com.mcredit.digitallending.entity.Criteria;
import vn.com.mcredit.digitallending.entity.PartnerUserInfo;
import vn.com.mcredit.digitallending.proxy.MiniAppProxy;
import vn.com.mcredit.digitallending.repositories.CriteriaRepository;
import vn.com.mcredit.digitallending.repositories.PartnerUserInfoRepository;
import vn.com.mcredit.digitallending.services.MiniAppService;
import vn.com.mcredit.digitallending.utils.DateUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MiniAppServiceImpl implements MiniAppService {

    private final PartnerUserInfoRepository partnerUserInfoRepository;

    private final MiniAppProxy miniAppProxy;

    private final CriteriaRepository criteriaRepository;
    @Override
    public void saveCustomerInfoMb(PartnerUserInfo partnerUserInfo) {
        try {
            if (partnerUserInfo != null) {
                CustomerInfoMbRequest customerInfoMbRequest = new CustomerInfoMbRequest();
                customerInfoMbRequest.setCustomerCode(partnerUserInfo.getCode());
                customerInfoMbRequest.setCriteriaType(Constants.CRITERIA_TYPE_G);
                customerInfoMbRequest.setCriteria(Constants.CRITERIA_ALL);
                customerInfoMbRequest.setLimit(Constants.CRITERIA_LIMIT);
                CustomerInfoMbResponse customerInfoMbResponse = miniAppProxy.getCustomerInfoMb(customerInfoMbRequest);
                if (customerInfoMbResponse != null) {
                    List<CustomerInfoDataListResponse> dataListResponse = customerInfoMbResponse.getData().getDataList();
                    if (ObjectUtils.isNotEmpty(dataListResponse)) {
                        for (CustomerInfoDataListResponse customerInfoDataListResponse :dataListResponse) {
                            Criteria criteria = new Criteria();
                            criteria.setUserName(partnerUserInfo.getMobile());
                            criteria.setCustomerCode(partnerUserInfo.getCode());
                            criteria.setClientMessageId(customerInfoMbResponse.getClientMessageId());
                            criteria.setCriteriaType(customerInfoMbRequest.getCriteriaType());
                            criteria.setCriteria(customerInfoMbRequest.getCriteria());
                            criteria.setCriteriaGrpId(customerInfoDataListResponse.getCriteriaGrpID());
                            criteria.setCriteriaGrpNm(customerInfoDataListResponse.getCriteriaGrpNM());
                            criteria.setCriteriaId(customerInfoDataListResponse.getCriteriaID());
                            criteria.setCriteriaNm(customerInfoDataListResponse.getCriteriaNM());
                            criteria.setCriteriaValue(customerInfoDataListResponse.getCriteriaValue());
                            criteria.setCreatedAt(DateUtils.getNowDate());
                            criteriaRepository.save(criteria);
                            LogUtils.info("[CustomerInfoMb] save success");
                        }
                    }
                }
            }
        } catch (Exception e) {
            LogUtils.info("[CustomerInfoMb] err" + e.getMessage());
        }
        LogUtils.info("[CustomerInfoMb] save fail");
    }
}
