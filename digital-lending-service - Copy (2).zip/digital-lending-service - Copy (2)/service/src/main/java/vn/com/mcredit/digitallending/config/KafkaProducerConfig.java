package vn.com.mcredit.digitallending.config;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaProducerConfig {

	private static final String KAFKA_SASL_MECHANISM = "sasl.mechanism";
	private static final String KAFKA_SECURITY_PROTOCOL = "security.protocol";
	private static final String KAFKA_SASL_JAAS_CONFIG = "sasl.jaas.config";

	@Value(value = "${kafka.bootstrapAddress}")
	private String bootstrapAddress;

	@Value(value = "${kafka.autoOffsetResetConfig}")
	private String autoOffsetResetConfig;

	@Value(value = "${kafka.sasl.mechanism}")
	private String mechanism;

	private String config;

	@Value(value = "${kafka.security.protocol}")
	private String protocol;

	@Value(value = "${kafka.admin-user}")
	private String username;

	@Value(value = "${kafka.admin-password}")
	private String password;
	//1. Send string to Kafka

	@PostConstruct
	private void setSaslJassConfigs(){
		String jassConfig = "org.apache.kafka.common.security.scram.ScramLoginModule required username=\"%s\" password=\"%s\";";
		config  = String.format(jassConfig, username, password);
	}
	@Bean
	public ProducerFactory<String, String> producerFactory() {
		Map<String, Object> props = new HashMap<>();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetResetConfig);
		props.put(KAFKA_SASL_MECHANISM, mechanism);
		props.put(KAFKA_SASL_JAAS_CONFIG, config);
		props.put(KAFKA_SECURITY_PROTOCOL, protocol);
		return new DefaultKafkaProducerFactory<>(props);
	}

	@Bean
	public KafkaTemplate<String, String> kafkaTemplate() {
		return new KafkaTemplate<>(producerFactory());
	}

}