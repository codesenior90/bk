package vn.com.mcredit.digitallending.dto.resp.internal;

import lombok.*;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MiniAppHomePageResponse {
    private String url;
}
