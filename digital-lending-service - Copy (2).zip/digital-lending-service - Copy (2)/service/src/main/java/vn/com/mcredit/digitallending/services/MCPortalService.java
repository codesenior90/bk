package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.CreateLeadRequest;
import vn.com.mcredit.digitallending.dto.resp.OcrResultResponse;
import vn.com.mcredit.digitallending.dto.resp.OfferDGTResponse;
import vn.com.mcredit.digitallending.dto.resp.aws_auth.AwsAuthResponse;
import vn.com.mcredit.digitallending.entity.EkycModel;
import vn.com.mcredit.digitallending.entity.PreOffer;

import java.math.BigInteger;

public interface MCPortalService {
    AwsAuthResponse authenticate();
    void sendLeadToMcPortal(OcrResultResponse ocrResultResponse, String username, String partnerCode);
    void sendLeadToMcPortal(String idNumber, String name, String gender, BigInteger loanAmount, String address, String username);
    void sendData(CreateLeadRequest createLeadRequest, String username);
    void sendLeadToMcPortal(String data, String type);
    void sendLeadToMcPortal(OfferDGTResponse offerDGTResponse, String partnerCode);
    CreateLeadRequest buildCreateLeadRequest(EkycModel ekycModel, String username, BigInteger loanAmount, String other, String partnerCode);
    void sendLeadToMcPortal(String idNumber, String name, String gender, String address, String username, String partnerCode);
    void sendLeadOfferReject(PreOffer preOffer);
}
