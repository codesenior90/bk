package vn.com.mcredit.digitallending.dto.resp.aws_auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Credentials{
    @JsonProperty("AccessKeyId")
    public String accessKeyId;
    @JsonProperty("Expiration")
    public int expiration;
    @JsonProperty("SecretAccessKey")
    public String secretAccessKey;
    @JsonProperty("SessionToken")
    public String sessionToken;
}
