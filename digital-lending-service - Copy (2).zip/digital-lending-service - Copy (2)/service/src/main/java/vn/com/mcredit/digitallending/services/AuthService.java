package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.UserProfileCreateDTO;
import vn.com.mcredit.digitallending.dto.req.EncryptDTO;
import vn.com.mcredit.digitallending.dto.req.LoginDTO;
import vn.com.mcredit.digitallending.dto.req.MiniAppHomePageRequest;
import vn.com.mcredit.digitallending.dto.req.OpenWebviewRequest;
import vn.com.mcredit.digitallending.dto.resp.internal.MiniAppHomePageResponse;

public interface AuthService {
    Object register(UserProfileCreateDTO dto);
    Object login(LoginDTO dto);
    Object loginV6(EncryptDTO encryptDTO);
    Object loginV7(EncryptDTO encryptDTO);
    Object checkUrl(OpenWebviewRequest request);
    MiniAppHomePageResponse generateTikTakPage(MiniAppHomePageRequest request);
}
