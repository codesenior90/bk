package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class IdentityProfilesResponse {
    private String username;
    private String cardId;
    private String cardType;
    private String dob;
    private String cardIssuePlace;
    private String cardIssuedAt;
    private String cardExpiredAt;
    private String cardIdOld;
    private String permanentAddress;
    private String status;
    private String createdDate;
}
