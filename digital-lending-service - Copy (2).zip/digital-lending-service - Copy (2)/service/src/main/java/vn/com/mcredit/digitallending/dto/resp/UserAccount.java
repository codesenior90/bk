package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class UserAccount {
    private String username;
    private String cif;
    private String fullName;
    private String dob;
    private String phoneNumber;
    private String email;
    private String cardType;
    private String cardExpiredAt;
    private String cardIssuedAt;
    private String gender;
    private String isEkyc;
    private String linkAvatar;
    private String address;
    private String systemName;
    private String deviceId;
    private String avatar;
    private String userType;
}
