package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddVectorRequest {
    @JsonProperty("request_id")
    private String requestId;
    @JsonProperty("request_date")
    private String requestDate;
    @JsonProperty("vec")
    private String vec;

    @JsonProperty("db")
    private String db;

    @JsonProperty("uid")
    private String uid;
}
