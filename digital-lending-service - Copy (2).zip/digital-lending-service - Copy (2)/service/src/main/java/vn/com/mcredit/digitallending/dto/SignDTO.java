package vn.com.mcredit.digitallending.dto;

import lombok.*;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SignDTO {
    private String transactionId;
    private String customerCode;
}
