package vn.com.mcredit.digitallending.services;

import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.dto.req.FaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.req.OcrForm;
import vn.com.mcredit.digitallending.dto.req.UpdateFaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.req.ekyc.*;

import vn.com.mcredit.digitallending.dto.resp.OcrResponse;
import vn.com.mcredit.digitallending.dto.resp.ekyc.*;

public interface RecognitionService {
    OcrResponse ocr(OcrForm form, String username);
    EkycResponseModel faceMatching(String ocrCode, Boolean showVector, String username, MultipartFile selfieFile);
    EkycResponseModel faceMatchRaw(MultipartFile frontImg, MultipartFile selfieImg, String username);
    EkycResponseModel face3way(MultipartFile leftImg, MultipartFile rigthImg, MultipartFile selfieImg);

    EkycResponseModel liveness(String ocrCode, String idNumber, MultipartFile selfie, MultipartFile right, MultipartFile left, MultipartFile front);
    EkycResponseModel liveness(String username, String idNumber, String ocrCode, Boolean showVector, FaceMatchingDTO dto);
    EkycResponseModel livenessWithoutOcr(String username, String idNumber, Boolean showVector, UpdateFaceMatchingDTO dto);
    RecoBlackListRes blacklist(RecoFaceSearchReq req, String username);
    RecoFaceIdsRes faceIds(RecoFaceSearchReq req, String username);
    RecoIdFacesRes idFaces(RecoFaceSearchReq req, String username);
    RecoAddVectorRes addVector(RecoAddVectorReq req, String username);
    NFCVerifyResponse nfcVerify(NFCVerifyRequest request);
    RecoCustomerInfoResp checkInfo(String username, String cartType, String systems);
    DimensionByEkycCodeResp getDimensionByEkycCode(String code);
    EkycResponseModel livenessWithoutFace(String ocrCode, Boolean showVector, String selfieImgURL, String leftImgURL, String rightImgURL);
}
