package vn.com.mcredit.digitallending.controller;

import io.swagger.v3.oas.annotations.Operation;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import vn.com.mcredit.digitallending.aop.Secured;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.dto.req.CheckPhoneRequest;
import vn.com.mcredit.digitallending.dto.req.EcontractTransactionRequestDTO;
import vn.com.mcredit.digitallending.dto.req.NFCFailRequest;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.enums.SystemNameEnum;
import vn.com.mcredit.digitallending.models.SendOTPDTO;
import vn.com.mcredit.digitallending.models.SendVerifyOtpDTO;
import vn.com.mcredit.digitallending.services.AfcService;
import vn.com.mcredit.digitallending.services.DigitalLendingService;
import vn.com.mcredit.digitallending.services.NFCUserDataService;
import vn.com.mcredit.digitallending.services.OpenApiService;

import javax.validation.Valid;

@RequiredArgsConstructor
@RequestMapping("/api/v1")
@RestController
public class DigitalLendingController {
    @Autowired
    private DigitalLendingService digitalLendingService;
    @Autowired
    private AfcService afcService;
    @Autowired
    private OpenApiService openApiService;

    @Autowired
    private NFCUserDataService nfcUserDataService;

    @Operation(summary = "Kiểm tra hạn mức và đã đăng ký tài khoản trên ")
    @PostMapping(value = "/check-phone", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> checkPhone(@Valid @RequestBody CheckPhoneRequest checkPhoneRequest) {
        return ResponseEntity.status(HttpStatus.OK).body(digitalLendingService.checkPhone(checkPhoneRequest));
    }
    @PostMapping(value = "/home-lending", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getInfoHomeLending() {
        return ResponseEntity.status(HttpStatus.OK).body(digitalLendingService.getHomeLendingInfo());
    }
    @Operation(summary = "Gửi otp")
    @PostMapping(value = "/otp/send", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> sendOtp(@Valid @RequestBody SendOTPDTO dto) {
        return ResponseEntity.status(HttpStatus.OK).body(afcService.sendOtp(dto));
    }
    @Operation(summary = "Verify otp")
    @PostMapping(value = "/otp/verify", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> verifyPhoneOtp(@Valid @RequestBody SendVerifyOtpDTO dto) {
        return ResponseEntity.status(HttpStatus.OK).body(afcService.verifyPhoneOtp(dto));
    }
    @Operation(summary = "Lấy step của khoản vay digital lending. Bao gồm trạng thái ekyc|pre-offer|create-case")
    @GetMapping(value = "/summary", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> summary(@RequestParam(required = false) String system, @RequestParam(required = false) String deviceId) {
        return ResponseEntity.status(HttpStatus.OK).body(digitalLendingService.getSummary(system,deviceId));
    }

    @Operation(summary = "Lấy thông tin người dùng.")
    @GetMapping(value = "/user/info", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> getUserInfo() {
        DigitalLendingResponse response = DigitalLendingResponse.builder().status(Constants.SUCCESS_MESSAGE).data(digitalLendingService.getUserInfo()).code(Constants.SUCCESS_CODE).message(Constants.SUCCESS_MESSAGE).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @Operation(summary = "Trả lại file thông tin hợp động", security = @SecurityRequirement(name = "bearerAuth"))
    @GetMapping(value = "/econtract-transaction/view", produces = MediaType.APPLICATION_PDF_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> viewEcontract(@RequestParam  String citizenId, String customerName, String page, String email ){
        EcontractTransactionRequestDTO econtractTransactionRequestDTO = new EcontractTransactionRequestDTO();
        econtractTransactionRequestDTO.setCitizenId(citizenId);
        econtractTransactionRequestDTO.setCustomerName(customerName);
        econtractTransactionRequestDTO.setPage(page);
        econtractTransactionRequestDTO.setEmail(email);
        return ResponseEntity.status(HttpStatus.OK).body(afcService.viewEcontractTransaction(econtractTransactionRequestDTO));

    }

    @PostMapping(value = "/econtract-transaction/view", produces = MediaType.APPLICATION_PDF_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> viewEcontractTransaction(@Valid @RequestBody EcontractTransactionRequestDTO econtractTransactionRequestDTO) {
        return ResponseEntity.status(HttpStatus.OK).header(MediaType.APPLICATION_PDF_VALUE).body(afcService.viewEcontractTransaction(econtractTransactionRequestDTO));
    }

    @GetMapping(value = "/bank/list", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> getBanks() {
        return ResponseEntity.status(HttpStatus.OK).body(openApiService.getBanks());
    }

    @PostMapping(value = "/nfc/logging", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> nfcSaveError(@RequestBody NFCFailRequest request) {
        nfcUserDataService.saveFailData(request);
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
