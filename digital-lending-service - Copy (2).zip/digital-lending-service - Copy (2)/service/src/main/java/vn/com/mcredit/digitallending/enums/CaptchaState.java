package vn.com.mcredit.digitallending.enums;

public enum CaptchaState {
    IN_USE,
    NOT_YET
}
