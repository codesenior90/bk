package vn.com.mcredit.digitallending.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.aop.Device;
import vn.com.mcredit.digitallending.aop.Secured;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.dto.req.FaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.req.OcrForm;
import vn.com.mcredit.digitallending.dto.req.UpdateFaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.req.VoiceCaptchaDTO;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.req.ekyc.NFCVerifyRequest;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.enums.EPartnerCode;
import vn.com.mcredit.digitallending.enums.SourceEKYC;
import vn.com.mcredit.digitallending.enums.SystemNameEnum;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.services.EKycService;
import vn.com.mcredit.digitallending.services.VoiceCaptchaService;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;

import javax.validation.Valid;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@RequestMapping("/api/ekyc")
@RestController
public class EkycController {
    private final EKycService eKycService;
    private final VoiceCaptchaService voiceCaptchaService;
    @Operation(summary = "Lấy thông tin giấy tờ cá nhân", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v1/ocr")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> ocr(@ModelAttribute OcrForm ocrForm) {
        if (EPartnerCode.MB_BANK.value().equalsIgnoreCase(JWTUtils.getPartnerCode()) || SourceEKYC.EKYC_CENTRALIZATION.getValue().equalsIgnoreCase(JWTUtils.getSourceEkyc())){
            return ResponseEntity.status(HttpStatus.OK).body(eKycService.ocrV2(ocrForm));
        } else {
            return ResponseEntity.status(HttpStatus.OK).body(eKycService.ocr(ocrForm));
        }
    }
    @Operation(summary = "Kiểm tra thông tin ID nội bộ", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v1/check-id-internal")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkIdInternal(@RequestParam(value = "qrcodeImg") MultipartFile qrcodeImg,
                                                  @RequestParam(value = "qrcode") String qrcode,
                                                  @RequestParam(value = "requestId") String requestId) {
        return ResponseEntity.status(HttpStatus.OK).body(eKycService.checkIdInternal(qrcodeImg, qrcode, requestId));
    }

    @Operation(summary = "ekyc thông tin giấy tờ cá nhân và mặt của khách hàng", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v1/face-matching")
    @Device
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> faceMatching(@Valid @ModelAttribute FaceMatchingDTO faceMatchingDTO){
        if (EPartnerCode.MB_BANK.value().equalsIgnoreCase(JWTUtils.getPartnerCode()) || SourceEKYC.EKYC_CENTRALIZATION.getValue().equalsIgnoreCase(JWTUtils.getSourceEkyc())){
            return ResponseEntity.status(HttpStatus.OK).body(eKycService.faceMatchingV2(faceMatchingDTO));
        } else {
            return ResponseEntity.status(HttpStatus.OK).body(eKycService.faceMatching(faceMatchingDTO));
        }
    }

    @Operation(summary = "Bổ sung ekyc khi khách hàng đổi thiết bị", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v1/update/face-matching")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    @Device
    public ResponseEntity<Object> updateFaceMatching(@Valid @ModelAttribute UpdateFaceMatchingDTO faceMatchingDTO, BindingResult bindingResult) throws ApplicationException {
        ResponseEntity<Object> response = getObjectResponseEntity(bindingResult);
        if (response != null) return response;
        if (EPartnerCode.MB_BANK.value().equalsIgnoreCase(JWTUtils.getPartnerCode()) || SourceEKYC.EKYC_CENTRALIZATION.getValue().equalsIgnoreCase(JWTUtils.getSourceEkyc())){
            return ResponseEntity.status(HttpStatus.OK).body(eKycService.updateFaceMatchingV2(faceMatchingDTO));
        } else {
            return ResponseEntity.status(HttpStatus.OK).body(eKycService.updateFaceMatching(faceMatchingDTO));
        }
    }

    private ResponseEntity<Object> getObjectResponseEntity(BindingResult bindingResult) {
        if(bindingResult.hasFieldErrors()) {
            String errMess = bindingResult.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining("/"));
            DigitalLendingResponse response =  DigitalLendingResponse.builder().status(Constants.FAILED_MESSAGE).code(Constants.ERROR_400_BAD).message(errMess).build();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
        return null;
    }

    @Operation(summary = "Generate dãy số gồm 8 chữ số", security = @SecurityRequirement(name = "bearerAuth"))
    @GetMapping(value = "/v1/voice-captcha")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    @Device
    public ResponseEntity<Object> generateCaptcha(@RequestParam String requestId) throws ApplicationException {
        return ResponseEntity.status(HttpStatus.OK)
            .body(DigitalLendingResponse.builder()
                    .data(voiceCaptchaService.generateCaptcha(requestId, JWTUtils.getUsername(), JWTUtils.getDeviceId()))
                    .status(Constants.SUCCESS_MESSAGE)
                    .code(Constants.SUCCESS_CODE)
                    .message(Constants.SUCCESS_MESSAGE).build()
            );
    }

    @Operation(summary = "Kiểm tra thông tin ID nội bộ", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v1/nfc/check-id-internal")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkIdInternalEncrypt(@Valid @RequestBody CheckIdInternalNFCReq req) {
        return ResponseEntity.status(HttpStatus.OK).body(eKycService.checkIdInternalNFC(req.getData()));
    }

    @Operation(summary = "Kiểm tra thông tin ID nội bộ", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v1/nfc/verify")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> nfcVerify(@Valid @RequestBody NFCVerifyRequest req) {
        return ResponseEntity.status(HttpStatus.OK).body(eKycService.nfcVerify(req));
    }

    @Operation(summary = "Bổ sung ekyc khi khách hàng đổi thiết bị", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v1/voice-captcha/check")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    @Device
    public ResponseEntity<Object> voiceCaptchaCheck(@Valid @ModelAttribute VoiceCaptchaDTO voiceCaptchaDTO, BindingResult bindingResult) throws ApplicationException {
        ResponseEntity<Object> response = getObjectResponseEntity(bindingResult);
        if (response != null) return response;
        return ResponseEntity.status(HttpStatus.OK)
            .body(DigitalLendingResponse.builder()
                    .data(voiceCaptchaService.voiceCaptchaCheck(voiceCaptchaDTO))
                    .status(Constants.SUCCESS_MESSAGE)
                    .code(Constants.SUCCESS_CODE)
                    .message(Constants.SUCCESS_MESSAGE).build()
            );
    }
    @Operation(summary = "ekyc thông tin giấy tờ cá nhân và mặt của khách hàng", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v2/face-matching")
    @Device
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> faceMatchingV2(@Valid @ModelAttribute FaceMatchingDTO faceMatchingDTO){
        return ResponseEntity.status(HttpStatus.OK).body(eKycService.faceMatchingV2(faceMatchingDTO));
    }

    @Operation(summary = "Lấy thông tin giấy tờ cá nhân", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v2/ocr")
    @Device
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> ocrV2(@ModelAttribute OcrForm form) {
        return ResponseEntity.status(HttpStatus.OK).body(eKycService.ocrV2(form));
    }

    @Operation(summary = "Kiểm tra thông tin ID nội bộ", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v2/check-id-internal")
    @Device
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkIdInternalV2(@RequestParam(value = "qrcodeImg") MultipartFile qrcodeImg,
                                                    @RequestParam(value = "qrcode") String qrcode,
                                                    @RequestParam(value = "ocrCode") String ocrCode) {
        return ResponseEntity.status(HttpStatus.OK).body(eKycService.checkIdInternalV2(qrcodeImg, qrcode, ocrCode));
    }

    @Operation(summary = "Bổ sung ekyc khi khách hàng đổi thiết bị", security = @SecurityRequirement(name = "bearerAuth"))
    @PostMapping(value = "/v2/update/face-matching")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    @Device
    public ResponseEntity<Object> updateFaceMatchingV2(@Valid @ModelAttribute UpdateFaceMatchingDTO faceMatchingDTO, BindingResult bindingResult) throws ApplicationException {
        ResponseEntity<Object> response = getObjectResponseEntity(bindingResult);
        LogUtils.info("updateFaceMatchingV2");
        if (response != null) return response;
        return ResponseEntity.status(HttpStatus.OK).body(eKycService.updateFaceMatchingV2(faceMatchingDTO));
    }
}
