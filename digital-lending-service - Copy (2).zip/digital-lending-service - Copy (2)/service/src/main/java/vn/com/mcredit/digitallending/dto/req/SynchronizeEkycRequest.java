package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

import java.util.List;


@Data
public class SynchronizeEkycRequest {

    private String username;

    private String objectId;
    /*
     * Loại thẻ khi EKYC
     * */

    private String cardType;
    /*
    Kết quả ocr trả về từ ocr-service
    * */

    private SynchronizeOcrRequest ocr;

    /*
    Kết quả facematching trả về từ facemtching-service
    * */

    private SynchronizeFaceMatchingRequest faceMatching;
    /*
    Kết quả facematching3way trả về từ facemtching-service
    * */
    private SynchronizeFace3WayRequest faceMatching3Way;

    private String status;

    /*
     * Ảnh mặt trước của thẻ
     * */

    private String frontImageURL;
    /*
     * Ảnh mặt sau của thẻ
     * */

    private String backImageURL;
    /*
     * Ảnh mặt chính diện của khách hàng
     * */

    private String selfieImageURL;
    /*
     * Ảnh mặt trái của khách hàng
     * */
    private String leftImageURL;// link ảnh mặt trái
    /*
     * Ảnh mặt phải của khách hàng
     * */
    private String rightImageURL;// link ảnh mặt phải

    /*
     * Ảnh qrcode của mặt trước CCCD CHIP
     * */
    private String qrCodeImageURL;
    /*
     * Chuỗi qrcode của mặt trước CCCD CHIP
     **/
    private String qrCode;

    private List<FraudCheck> fraudChecks;
    /*
     * Tên hệ thống nguồn để đẩy dữ liệu cho AFC
     * */
    private String originSystem;

    private String deviceId;

    private String type;

    private String ekycCode;

    /*
     * audio voice captcha
     * */
    private String voiceCaptchaURL;
}
