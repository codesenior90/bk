package vn.com.mcredit.digitallending.config;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.springframework.beans.factory.annotation.Value;
import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

public class KafkaCommonConfig {
    @Value(value = "${kafka.bootstrapAddress}")
    protected String bootstrapAddress;

    @Value(value = "${kafka.autoOffsetResetConfig}")
    protected String autoOffsetResetConfig;

    @Value(value = "${kafka.sasl.mechanism}")
    protected String mechanism;

    protected String config;

    @Value(value = "${kafka.admin-user}")
    private String username;

    @Value(value = "${kafka.admin-password}")
    private String password;
    @Value(value = "${kafka.security.protocol}")
    protected String protocol;

    @Value(value = "${kafka.topic.group.id}")
    protected String groupId;
    @Value("${kafka.max-poll-interval-ms-config}")
    private int maxPollInterval;

    @Value("${kafka.max-records-config}")
    private int maxPollRecord;

    @PostConstruct
    private void setSaslJassConfigs(){
        String jassConfig = "org.apache.kafka.common.security.scram.ScramLoginModule required username=\"%s\" password=\"%s\";";
        config  = String.format(jassConfig, username, password);
    }

    protected Map<String, Object> setKafkaParam() {

        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetResetConfig);
        props.put(SaslConfigs.SASL_MECHANISM, mechanism);
        props.put(SaslConfigs.SASL_JAAS_CONFIG, config);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, protocol);
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollInterval);
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxPollRecord);
        return props;
    }

}
