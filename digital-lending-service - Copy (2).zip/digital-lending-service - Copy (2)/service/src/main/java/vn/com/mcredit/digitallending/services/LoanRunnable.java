package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.utils.LogUtils;

public class LoanRunnable implements Runnable {

    private String topic;
    private String data;
    private BpmService service;
    public LoanRunnable(String topic, String data, BpmService service){
        this.data = data;
        this.service = service;
        this.topic = topic;
    }
    @Override
    public void run() {

        switch (topic){
            case Constants.SEND_CREATE_OFFER:
                LogUtils.info("[LoanRunnable] Send create offer");
                service.sendGetOfferToKafka(data);
                break;
            case Constants.RECEIVE_CREATE_OFFER:
                LogUtils.info("[LoanRunnable] Receiver create offer");
                service.receiveGetOfferFromKafka(data);
                break;
            case Constants.SEND_CREATE_CASE:
                LogUtils.info("[LoanRunnable] Send create case");
                service.sendCreateCaseToKafka(this.data);
                break;
            case Constants.RECEIVE_CREATE_CASE:
                LogUtils.info("[LoanRunnable] Receiver create case");
                service.receiveCreateCaseFromKafka(this.data);
                break;
            case Constants.RECEIVE_MESSAGE_FROM_ECONTRACT:
                LogUtils.info("[LoanRunnable] Receiver message from econtract");
                service.receiveMessageFromEContract(this.data);
                break;
            default:
                break;
        }
    }
}
