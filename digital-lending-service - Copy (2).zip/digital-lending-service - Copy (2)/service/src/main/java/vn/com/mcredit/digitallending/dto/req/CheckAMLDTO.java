package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CheckAMLDTO {
    @JsonProperty("birthday")
    private String birthday;
    @JsonProperty("custName")
    private String custName;
    @JsonProperty("custCareer")
    private String custCareer;
    @JsonProperty("loansProfileId")
    private String loansProfileId;
    @JsonProperty("idNumber")
    private String idNumber;
    @JsonProperty("oldIdNumber")
    private String oldIdNumber;
    @JsonProperty("requestId")
    private String requestId;
}
