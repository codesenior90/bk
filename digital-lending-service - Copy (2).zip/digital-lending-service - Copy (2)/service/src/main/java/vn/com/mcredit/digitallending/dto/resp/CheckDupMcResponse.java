package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class CheckDupMcResponse extends BpmBaseResponse{
    @JsonProperty("data")
    private Object data;
    @JsonProperty("codeStatus")
    private List<CodeStatus> codeStatuses;
}
