package vn.com.mcredit.digitallending.dto.req;

import lombok.*;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class OptionDTO {
    private String code;
    private String name;
    private String type;
    private Long status;
    private Long order;
    private String value;
    private String description;
}
