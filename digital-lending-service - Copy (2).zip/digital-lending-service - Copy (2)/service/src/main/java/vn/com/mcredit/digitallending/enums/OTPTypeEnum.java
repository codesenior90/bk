package vn.com.mcredit.digitallending.enums;

import java.util.Arrays;

public enum OTPTypeEnum {
    REGISTER("REGISTER"),
    FORGOTPASSWORD("FORGOTPASSWORD");
    private final String value;

    private String message;

    OTPTypeEnum(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public String getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }
    public static boolean isExisted(String type) {
        return Arrays.stream(OTPTypeEnum.values()).anyMatch(p->p.value.equalsIgnoreCase(type));
    }
}
