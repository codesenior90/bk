package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.PartnerUserInfo;

@Repository
public interface PartnerUserInfoRepository extends JpaRepository<PartnerUserInfo, String> {
    boolean existsByCode(String code);
    PartnerUserInfo findFirstByMobile(String mobile);
    PartnerUserInfo findFirstByMobileAndStatus(String mobile, String status);
}
