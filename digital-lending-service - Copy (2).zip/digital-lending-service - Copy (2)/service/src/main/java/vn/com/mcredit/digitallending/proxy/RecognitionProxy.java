package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.req.ekyc.NFCVerifyRequest;
import vn.com.mcredit.digitallending.dto.resp.ekyc.*;

import java.util.HashMap;
import java.util.Map;


@Component
public class RecognitionProxy extends BaseProxy {
    public static final String SECRET_KEY = "secret";
    @Value("${recognition.hosts.recognition-service}")
    private String recognitionHost;

    @Value("${recognition.secret-key}")
    private String secretKey;
    @Override
    protected HttpHeaders initHeaderMultipartFormData() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAll(this.getHeader());
        return headers;
    }

    public OcrRecognitionResp ocr(Object body) {
        String url = String.format("%s%s", recognitionHost, "/ocr");
        return this.post(url, initHeaderMultipartFormData(), body, OcrRecognitionResp.class);
    }
    /**
     * So khớp 3 khuôn mặt
     * @param body
     * @return
     */
    public EkycResponseModel faceMatching(Object body) {
        String url = String.format("%s%s", recognitionHost, "/ekyc/face-matching");
        return this.post(url, initHeaderMultipartFormData(), body, EkycResponseModel.class);
    }

    /**
     * So khớp 3 khuôn mặt
     * @param body
     * @return
     */
    public EkycResponseModel liveness(Object body) {
        String url = String.format("%s%s", recognitionHost, "/ekyc/liveness");
        return this.post(url, initHeaderMultipartFormData(), body, EkycResponseModel.class);
    }

    /**
     * So khớp 3 khuôn mặt
     * @param body
     * @return
     */
    public EkycResponseModel livenessWithoutOcrDL(Object body) {
        String url = String.format("%s%s", recognitionHost, "/ekyc/liveness-without-ocr-dl");
        return this.post(url, initHeaderMultipartFormData(), body, EkycResponseModel.class);
    }

    /**
     * Add Vector vào kho
     * @param body
     * @return
     */
    public RecoAddVectorRes addVector(Object body) {
        String url = String.format("%s%s", recognitionHost, "/ekyc/add-vector");
        return this.post(url, initHeaderMultipartFormData(), body, RecoAddVectorRes.class);
    }

    /**
     * Kiểm tra trung khuôn mặt có nhiều CCCD
     * @param body
     * @return
     */
    public RecoFaceIdsRes faceIdsSearch(Object body) {
        String url = String.format("%s%s", recognitionHost, "/face/face-ids-search");
        return this.post(url, initHeaderMultipartFormData(), body, RecoFaceIdsRes.class);
    }

    /**
     * Kiểm tra CCCD nhưng có nhiều khuôn mặt
     * @param body
     * @return
     */
    public RecoIdFacesRes idFacesSearch(Object body) {
        String url = String.format("%s%s", recognitionHost, "/face/id-faces-search");
        return this.post(url, initHeaderMultipartFormData(), body, RecoIdFacesRes.class);
    }

    /**
     * Check ảnh trong kho blacklist
     * @param body
     * @return
     */
    public RecoBlackListRes blacklistSearch(Object body) {
        String url = String.format("%s%s", recognitionHost, "/face/blacklist-search-vector");
        return this.post(url, initHeaderMultipartFormData(), body, RecoBlackListRes.class);
    }
    public RecoCustomerInfoResp checkInfo(Object body) {
        String url = String.format("%s%s", recognitionHost, "/customer/check-info");
        return this.post(url, initHeaderMultipartFormData(), body, RecoCustomerInfoResp.class);
    }
    public NFCVerifyResponse nfcVerify(NFCVerifyRequest body) {
        String url = String.format("%s%s", recognitionHost, "/nfc/verify");
        return this.post(url, initHeader(this.getHeader()), body, NFCVerifyResponse.class);
    }

    public DimensionByStoreCodeResp getByStoreCode(String code) {
        String url = String.format("%s/dimension/get-by-store-code?code=%s", recognitionHost, code);
        return this.get(url, null, DimensionByStoreCodeResp.class);
    }
    public DimensionByFaceCodeResp getByFaceCode(String code) {
        String url = String.format("%s/dimension/get-by-face-code?code=%s", recognitionHost, code);
        return this.get(url, null, DimensionByFaceCodeResp.class);
    }
    public DimensionByEkycCodeResp getByEkycCode(String code) {
        String url = String.format("%s/dimension/get-by-ekyc-code?code=%s", recognitionHost, code);
        return this.get(url, null, DimensionByEkycCodeResp.class);
    }

    public EkycResponseModel livenessWithoutFace(Object body) {
        String url = String.format("%s%s", recognitionHost, "/ekyc/liveness-without-face");
        return this.post(url, initHeaderMultipartFormData(), body, EkycResponseModel.class);
    }
    private Map<String, String> getHeader() {
        Map<String, String> headers = new HashMap<>();
        headers.put(SECRET_KEY, secretKey);
        return headers;
    }
}
