package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.Criteria;

@Repository
public interface CriteriaRepository extends JpaRepository<Criteria,String> {
}
