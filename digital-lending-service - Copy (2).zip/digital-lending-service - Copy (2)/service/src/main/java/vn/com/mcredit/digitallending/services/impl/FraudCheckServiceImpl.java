package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.req.DocValidateDTO;
import vn.com.mcredit.digitallending.dto.req.RawUserDataReq;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.dto.resp.DocValidateResponse;
import vn.com.mcredit.digitallending.dto.resp.OcrResponse;
import vn.com.mcredit.digitallending.dto.resp.OcrResultResponse;
import vn.com.mcredit.digitallending.entity.Ocr;
import vn.com.mcredit.digitallending.proxy.FraudCheckProxy;
import vn.com.mcredit.digitallending.services.FraudCheckService;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class FraudCheckServiceImpl implements FraudCheckService {

    private final FraudCheckProxy fraudCheckProxy;
    private final ModelMapper modelMapper;

    @Override
    public DocValidateResponse callValidateDoc(DocValidateDTO docValidateDTO, Map<String, Object> map){
        try {

            LogUtils.info("[FraudCheckService] callValidateDoc request");
            DocValidateResponse docValidateResponse = fraudCheckProxy.validateDoc(docValidateDTO);
            LogUtils.info("[FraudCheckService] callValidateDoc response");
            this.handleValidateDocSuccess(map, docValidateResponse);
            return docValidateResponse;
        } catch (HttpStatusCodeException e){
            LogUtils.error("[FraudCheckService] callValidateDoc exception",e.getMessage());
            this.handleValidateDocFailure(e, map);
            return null;
        }
    }
    @Override
    public DocValidateDTO buildDocValidateRequest(Ocr ocr, String qrCode, RawUserDataReq rawUserDataReq){
        Object o = Utils.parseToJson(ocr.getResult());
        OcrResponse ocrResponse = modelMapper.map(o, OcrResponse.class);
        OcrResultResponse ocrResultResponse = ocrResponse.getResult();
        DocValidateDTO docValidateDTO = modelMapper.map(ocrResultResponse, DocValidateDTO.class);
        docValidateDTO.setQr(qrCode);
        if (rawUserDataReq != null) {
            docValidateDTO.setNfc(qrCode);
        }
        docValidateDTO.setRequestId(ocr.getRequestId());
        return docValidateDTO;
    }
    private void handleValidateDocSuccess(Map<String, Object> map, DocValidateResponse docValidateResponse){
        LogUtils.info("[FraudCheckService] callValidateDoc response success");
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        try {
            if (docValidateResponse.isSuccess() && StringUtils.isBlank(docValidateResponse.getErrorCode())){
                digitalLendingResponse.setMessage(Constants.SUCCESS_MESSAGE);
                digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
                digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
            } else {
                digitalLendingResponse.setMessage( Error.FAIL_ID_LOGIC.getMessage());
                digitalLendingResponse.setCode( docValidateResponse.getErrorCode());
                digitalLendingResponse.setStatus(Constants.FAILED_MESSAGE);
            }
            digitalLendingResponse.setData(docValidateResponse);
        } catch (Exception e){
            digitalLendingResponse.setMessage(e.getMessage());
            digitalLendingResponse.setCode(Constants.ERROR_400_CODE);
            digitalLendingResponse.setStatus(Constants.FAILED_MESSAGE);
            digitalLendingResponse.setData(e.getMessage());
        }
        map.put(Constants.DOC_VALIDATE_RESPONSE, digitalLendingResponse);
    }
    private void handleValidateDocFailure(HttpStatusCodeException statusCodeException, Map<String, Object> map){
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        digitalLendingResponse.setMessage(statusCodeException.getMessage());
        digitalLendingResponse.setData(statusCodeException.getResponseBodyAsString());
        digitalLendingResponse.setStatus(Constants.FAILED_MESSAGE);
        digitalLendingResponse.setCode(Constants.ERROR_400_CODE);
        map.put(Constants.DOC_VALIDATE_RESPONSE, digitalLendingResponse);
    }
}
