package vn.com.mcredit.digitallending.enums;

public enum DocumentType {

    CUSTOMER_RECORDS("R"),
    CONTRACT("C"),
    ASSETS("A"),
    FINANCIAL("F"),
    OTHER("O");

    private String value;

    DocumentType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
