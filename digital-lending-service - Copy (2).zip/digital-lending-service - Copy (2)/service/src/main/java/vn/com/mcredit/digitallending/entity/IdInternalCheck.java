package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import vn.com.mcredit.digitallending.enums.CheckIdInternalType;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "id_internal_check")
public class IdInternalCheck {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name = "request_id", length = 36)
    private String requestId;

    @Column(name = "check_dup_mc_result", columnDefinition = "text")
    private String checkDupMcResult;
    @Column(name = "check_dup_mc_request", columnDefinition = "text")
    private String checkDupMcRequest;
    @Column(name = "doc_validate_request", columnDefinition = "text")
    private String docValidateRequest;

    @Column(name = "check_dup_mc_status")
    private Boolean checkDupMcStatus = false;

    @Column(name = "doc_validate_result", columnDefinition = "text")
    private String docValidateResult;

    @Column(name = "doc_validate_status")
    private Boolean docValidateStatus = false;

    @Column(name = "status")
    private Boolean status = false;

    @Column(name = "qrcode_url")
    private String qrcodeUrl;

    @Column(name = "qr")
    private String qr;

    @Column(name = "id_number_old")
    private String idNumberOld;

    @Column(name = "username")
    private String username;

    @Column(name = "source_raw_data")
    private String sourceRawData = CheckIdInternalType.SCAN_QRCODE.name();

    @Column(name = "error_code")
    private String errorCode;

    @Column(name = "error_message")
    private String errorMessage;

    @Column(name = "source_ekyc", length = 36)
    private String sourceEkyc;

    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name = "device_id", length = 36)
    private String deviceId;
}
