package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

@Data
public class FaceMatchingModel {
    private CompareModel compare;
    private Float conditionScore;
    private Boolean pass;
}
