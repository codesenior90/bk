package vn.com.mcredit.digitallending.dto.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FraudCheck {
    private String[] rules;
    private Boolean status;
    private String system;
}
