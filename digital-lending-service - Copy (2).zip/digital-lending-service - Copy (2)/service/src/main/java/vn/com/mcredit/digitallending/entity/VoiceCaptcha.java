package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;
import vn.com.mcredit.digitallending.enums.CaptchaState;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "voice_captcha")
public class VoiceCaptcha {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name = "username", length = 10, nullable = false)
    private String username;

    @Column(name = "count")
    private Integer count = 0;

    @Column(name = "captcha", length = 8, nullable = false)
    private String captcha;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "url")
    private String url;

    @Column(name = "response_id")
    private String responseId;

    @Column(name = "request_id")
    private String requestId;

    @Column(name = "error_code")
    private String errorCode;

    @Column(name = "message", columnDefinition = "text")
    private String message;

    @Column(name = "state", length = 20)
    private String state = CaptchaState.NOT_YET.name(); // Tình trạng sử dụng IN_USED | NOT_YET

    @Column(name = "device_id", length = 36)
    private String deviceId;

    @CreationTimestamp
    @Column(name = "created_at")
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name = "partner_code", length = 25)
    private String partnerCode;

    @Column(name = "voice_check_status")
    private Boolean voiceCheckStatus;

    @Column(name = "text")
    private String text;

    @Column(name = "audio_quality")
    private String audioQuality;
}
