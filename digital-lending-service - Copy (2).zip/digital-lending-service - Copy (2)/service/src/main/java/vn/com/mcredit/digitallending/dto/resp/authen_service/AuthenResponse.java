package vn.com.mcredit.digitallending.dto.resp.authen_service;

import lombok.Data;

@Data
public class AuthenResponse {
    private int code;
    private int statusCode;
    private String description;
    private AuthenDataResponse data;
}
