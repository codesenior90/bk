package vn.com.mcredit.digitallending.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.dto.req.NFCFailRequest;
import vn.com.mcredit.digitallending.entity.NFCUserData;
import vn.com.mcredit.digitallending.entity.Ocr;
import vn.com.mcredit.digitallending.repositories.NFCUserDataRepository;
import vn.com.mcredit.digitallending.repositories.OcrRepository;
import vn.com.mcredit.digitallending.services.NFCUserDataService;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;

@Service
public class NFCUserDataServiceImpl implements NFCUserDataService {

    @Autowired
    private NFCUserDataRepository nfcUserDataRepository;

    @Autowired
    private OcrRepository ocrRepository;

    @Override
    public void saveFailData(NFCFailRequest nfcFailRequest) {
        LogUtils.info("[NFCUserDataServiceImpl] save NFC fail", nfcFailRequest);
        NFCUserData nfcUserData = new NFCUserData();
        String username = JWTUtils.getUsername();
        Ocr ocr = ocrRepository.findOcrByRequestIdAndUsername(nfcFailRequest.getRequestId(), username);
        if(ocr != null) {
            nfcUserData.setName(ocr.getName());
            nfcUserData.setDob(ocr.getDob());
            nfcUserData.setGender(ocr.getGender());
            nfcUserData.setHomeTown(ocr.getHomeTown());
            nfcUserData.setAddress(ocr.getAddress());
            nfcUserData.setExpiryDate(ocr.getExpiryDate());
            nfcUserData.setIssuedDate(ocr.getIssuedDate());
            nfcUserData.setIdNumber(ocr.getIdNumber());
        }
        nfcUserData.setErrorCode(nfcFailRequest.getErrorCode());
        nfcUserData.setErrorMessage(nfcFailRequest.getErrorMessage());
        nfcUserData.setUsername(username);
        nfcUserDataRepository.save(nfcUserData);

    }
}
