package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.resp.customer.CustomerInfoResponse;

import java.util.Map;

public interface LoanService {
    CustomerInfoResponse getCustomerInfo(Map<String, String> requestParams);
}
