package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CheckDupMcDataResponse {
    @JsonProperty("errorCode")
    private String errorCode;
    @JsonProperty("isValid")
    private Boolean valid;
    @JsonProperty("requestId")
    private String requestId;
    @JsonProperty("status")
    private String status;
    @JsonProperty("result")
    private String result;
}
