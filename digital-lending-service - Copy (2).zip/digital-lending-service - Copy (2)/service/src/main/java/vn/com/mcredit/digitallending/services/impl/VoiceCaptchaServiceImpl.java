package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.CaptchaData;
import vn.com.mcredit.digitallending.dto.req.VoiceCaptchaDTO;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.dto.resp.ekyc.VoiceCaptchaCheckResponse;
import vn.com.mcredit.digitallending.entity.VoiceCaptcha;
import vn.com.mcredit.digitallending.enums.CaptchaState;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.EkycProxy;
import vn.com.mcredit.digitallending.repositories.VoiceCaptchaRepository;
import vn.com.mcredit.digitallending.services.AwsS3Service;
import vn.com.mcredit.digitallending.services.VoiceCaptchaService;
import vn.com.mcredit.digitallending.utils.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VoiceCaptchaServiceImpl implements VoiceCaptchaService {
    public static final String AUDIO_NAME_FORMAT = "%s.%s.";
    public static final String AUDIO_NAME_FAIL_FORMAT = "%s.%s.FAIL.";
    @Value("${custom.properties.aws-s3-folder-task-name}")
    private String folderTaskName;
    @Value("${custom.properties.max-number-of-call-voice-captcha}")
    private Integer maxNumberOfCallVoiceCaptcha;
    @Value("${custom.properties.expire-time-captcha}")
    private Integer expireTimeCaptcha;

    private final VoiceCaptchaRepository voiceCaptchaRepository;
    private final AwsS3Service awsS3Service;
    private final EkycProxy ekycProxy;
    /**
     * Tạo request Body voice-captcha-check
     * @param form dữ liệu đầu vào gồm voice-captcha và captcha
     * @return request body
     * @throws IOException
     */
    private MultiValueMap<String, Object> buildVoiceCaptchaCheckRequest(VoiceCaptchaDTO form) {
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        try {
            Utils.addMapImage(body, "audio", form.getAudio());
        } catch (IOException e) {
            LogUtils.error("[VoiceCaptchaService] buildVoiceCaptchaCheckRequest exception");
        }
        body.add("captcha", form.getCaptcha());
        return body;
    }
    @Override
    public DigitalLendingResponse voiceCaptchaCheck(VoiceCaptchaDTO voiceCaptchaDTO) {
        if (StringUtils.isBlank(JWTUtils.getPartnerCode())){
            throw new ApplicationException(Error.PARTNER_CODE_IS_EMPTY.getCode(), Error.PARTNER_CODE_IS_EMPTY.getMessage());
        }
        List<String> errorCodes = Arrays.asList("INPUT_ERROR", "SYSTEM_ERROR");
        // lấy voice-captcha mới nhất chưa được sử dụng theo username
        VoiceCaptcha voiceCaptcha = voiceCaptchaRepository.findFirstByUsernameAndDeviceIdOrderByCreatedAtDesc(JWTUtils.getUsername(), JWTUtils.getDeviceId());
        LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck", voiceCaptcha.getCaptcha());
        this.validateVoiceCaptcha(voiceCaptcha, voiceCaptchaDTO.getCaptcha());
        voiceCaptcha.setState(CaptchaState.IN_USE.name());
        int count = voiceCaptchaRepository.countByUsernameAndRequestId(JWTUtils.getUsername(), voiceCaptcha.getRequestId(), CaptchaState.IN_USE.name(), errorCodes);
        if (count == maxNumberOfCallVoiceCaptcha) {
            voiceCaptcha.setErrorCode(Error.FAIL_VOICECAPCHA_OVER3TIMES.getCode());
            voiceCaptchaRepository.save(voiceCaptcha);
            throw new ApplicationException(Error.FAIL_VOICECAPCHA_OVER3TIMES.getCode(), Error.FAIL_VOICECAPCHA_OVER3TIMES.getMessage(), count);
        }

        try {
            var request = this.buildVoiceCaptchaCheckRequest(voiceCaptchaDTO);
            // Call api check voice captcha
            var response = ekycProxy.voiceCaptchaCheck(request);
            LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck handleSuccess response", response);
            this.handleSuccess(response, voiceCaptchaDTO, voiceCaptcha, count);
            return DigitalLendingResponse.builder()
                    .status(Constants.SUCCESS_MESSAGE)
                    .code(Constants.SUCCESS_CODE)
                    .message(Constants.SUCCESS_MESSAGE)
                    .build();
        } catch (HttpStatusCodeException e){
            LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck error", e.getResponseBodyAsString());
            this.handleError(voiceCaptcha, e, count, voiceCaptchaDTO.getAudio());
            return null;
        }
    }
    // Handle call api success
    private void handleSuccess(VoiceCaptchaCheckResponse response, VoiceCaptchaDTO voiceCaptchaDTO, VoiceCaptcha voiceCaptcha, int count) {
        Boolean match = false;
        this.handeldResponseNull(response, voiceCaptchaDTO, voiceCaptcha, count);
        LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck handleSuccess error-code", response.getErrorCode());
        LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck handleSuccess error-message", response.getErrorMessage());
        voiceCaptcha.setResponseId(response.getResponseId());
        voiceCaptcha.setVoiceCheckStatus(response.getStatus());
        if (response.getResult() != null) {
            voiceCaptcha.setText(response.getResult().getText());
            voiceCaptcha.setAudioQuality(response.getResult().getAudioQuality());
            if (response.getResult().getMatch() != null)
                match = response.getResult().getMatch();
            LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck match", match);
            voiceCaptcha.setStatus(match);
        }
        String errorCode = response.getErrorCode();
        voiceCaptcha.setErrorCode(errorCode);
        voiceCaptcha.setMessage(response.getErrorMessage());
        // upload voice captcha lên s3 nếu is_match=true hoặc count = maxNumberOfCallVoiceCaptcha
        LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck count", count);
        if (maxNumberOfCallVoiceCaptcha == count + 1 || Boolean.TRUE.equals(match)){
            String filename = String.format(AUDIO_NAME_FORMAT, JWTUtils.getUsername(), DateUtils.dateTime());
            if(!Boolean.TRUE.equals(match)) {
                filename = String.format(AUDIO_NAME_FAIL_FORMAT, JWTUtils.getUsername(), DateUtils.dateTime());
            }
            var url = this.uploadVoiceCaptchaToS3(voiceCaptchaDTO.getAudio(), filename);
            voiceCaptcha.setUrl(url);
        }
        // cập nhật voice-captcha khi call api check-voice-captcha thành công

        LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck ErrorCode", response.getErrorCode());
        if (Boolean.FALSE.equals(response.getStatus())){
            errorCode = this.getErrorCodeFromAudioQuanlity(response.getErrorCode());
            voiceCaptcha.setErrorCode(errorCode);
            voiceCaptchaRepository.save(voiceCaptcha);
            throw new ApplicationException(errorCode, response.getErrorMessage());
        }
        if (match == null || Boolean.FALSE.equals(match)){
            LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck AudioQuality", voiceCaptcha.getAudioQuality());
            if (StringUtils.isNotBlank(voiceCaptcha.getAudioQuality())){
                errorCode = this.getErrorCodeFromAudioQuanlity(voiceCaptcha.getAudioQuality());
                voiceCaptcha.setErrorCode(errorCode);
                voiceCaptchaRepository.save(voiceCaptcha);
                throw new ApplicationException(errorCode, voiceCaptcha.getAudioQuality());
            } else {
                voiceCaptcha.setErrorCode(Error.FAIL_VOICE_CAPTCHA_SYSTEM.getCode());
                voiceCaptchaRepository.save(voiceCaptcha);
                throw new ApplicationException(Error.FAIL_VOICE_CAPTCHA_SYSTEM.getCode(), Error.SYSTEM_ERROR.getMessage(), count);
            }
        }
        voiceCaptchaRepository.save(voiceCaptcha);
    }

    private void handeldResponseNull(VoiceCaptchaCheckResponse response, VoiceCaptchaDTO voiceCaptchaDTO, VoiceCaptcha voiceCaptcha, int count) {
        if (response == null) {
            LogUtils.info("[VoiceCaptchaService] voiceCaptchaCheck handleSuccess response null");
            voiceCaptcha.setErrorCode(Error.FAIL_VOICE_CAPTCHA_SYSTEM.getCode());
            voiceCaptcha.setMessage(Error.SYSTEM_ERROR.getMessage());
            if(maxNumberOfCallVoiceCaptcha == count + 1) {
                String filename = String.format(AUDIO_NAME_FAIL_FORMAT, JWTUtils.getUsername(), DateUtils.dateTime());
                voiceCaptcha.setUrl(this.uploadVoiceCaptchaToS3(voiceCaptchaDTO.getAudio(), filename));
            }
            voiceCaptchaRepository.save(voiceCaptcha);
            throw new ApplicationException(Error.FAIL_VOICE_CAPTCHA_SYSTEM.getCode(), Error.SYSTEM_ERROR.getMessage(), count);
        }
    }

    private String getErrorCodeFromAudioQuanlity(String error){
        switch (error){
            case "MUL_SPEAKER":
                return Error.FAIL_VOICECAPCHA_MULTI.getCode();
            case "SILENT_VOLUME":
                return Error.FAIL_VOICECAPCHA_TOOQUIET.getCode();
            case "NOISE":
                return Error.FAIL_VOICECAPCHA_TOOLOUD.getCode();
            case "NOT_SPEAKER":
                return Error.FAIL_VOICECAPCHA_INPUT.getCode();
            case "INPUT_ERROR":
            case "SYSTEM_ERROR":
                return Error.FAIL_VOICE_CAPTCHA_SYSTEM.getCode();
            default:
                return error;
        }
    }
    // Handle call api failure
    private void handleError(VoiceCaptcha voiceCaptcha, HttpStatusCodeException e, int count, MultipartFile audio) {
        LogUtils.info("[VoiceCaptchaService] handleError", e.getResponseBodyAsString());
        voiceCaptcha.setErrorCode(e.getStatusCode().name());
        voiceCaptcha.setMessage(e.getStatusText());
        if(maxNumberOfCallVoiceCaptcha == count + 1) {
            String filename = String.format(AUDIO_NAME_FAIL_FORMAT, JWTUtils.getUsername(), DateUtils.dateTime());
            voiceCaptcha.setUrl(this.uploadVoiceCaptchaToS3(audio, filename));
        }
        // cập nhật voice-captcha khi call api check-voice-captcha lỗi
        voiceCaptchaRepository.save(voiceCaptcha);
        throw new ApplicationException(Error.FAIL_VOICE_CAPTCHA_SYSTEM.getCode(), e.getStatusText());
    }


    private void validateVoiceCaptcha(VoiceCaptcha voiceCaptcha, String captcha){

        // Kiểm tra captcha có tồn tại, đã sử dụng chưa và có mới nhất không
        if (voiceCaptcha == null || !captcha.equals(voiceCaptcha.getCaptcha()) || CaptchaState.IN_USE.name().equalsIgnoreCase(voiceCaptcha.getState())){
            LogUtils.info("[VoiceCaptchaService] validateVoiceCaptcha VOICE_CAPTCHA_INVALID", captcha);
            if(voiceCaptcha != null) {
                voiceCaptcha.setState(CaptchaState.IN_USE.name());
                voiceCaptcha.setErrorCode(Error.VOICE_CAPTCHA_INVALID.getCode());
                voiceCaptchaRepository.save(voiceCaptcha);
            }
            throw new ApplicationException(Error.VOICE_CAPTCHA_INVALID.getCode(), Error.VOICE_CAPTCHA_INVALID.getMessage());
        }
        // Kiểm tra captcha đã bị expire chưa (1 phút)
        var now = new Date();
        if (now.getTime() - voiceCaptcha.getCreatedAt().getTime() > expireTimeCaptcha * 1000){
            LogUtils.info("[VoiceCaptchaService] validateVoiceCaptcha FAIL_CAPTCHA_EXPIRED", voiceCaptcha.getCaptcha());
            voiceCaptcha.setErrorCode(Error.FAIL_CAPTCHA_EXPIRED.getCode());
            voiceCaptchaRepository.save(voiceCaptcha);
            throw new ApplicationException(Error.FAIL_CAPTCHA_EXPIRED.getCode(), Error.FAIL_CAPTCHA_EXPIRED.getMessage());
        }

    }
    // upload audio file lên aws s3
    private String uploadVoiceCaptchaToS3(MultipartFile file, String filename){
        String filePath = Utils.generateFilePathOnS3(folderTaskName, JWTUtils.getUsername(), "voice-captcha");
        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        return awsS3Service.upload(file, filePath + filename, extension);
    }
    @Override
    public CaptchaData generateCaptcha(String requestId, String username, String deviceId) {
        if (StringUtils.isBlank(JWTUtils.getPartnerCode())){
            throw new ApplicationException(Error.PARTNER_CODE_IS_EMPTY.getCode(), Error.PARTNER_CODE_IS_EMPTY.getMessage());
        }
        String captchaText = StringUtils.get8DigitNumber();
        if (voiceCaptchaRepository.existsByUsernameAndCaptcha(username, captchaText)) {
            captchaText = StringUtils.get8DigitNumber();
        }
        CaptchaData captcha = new CaptchaData();
        captcha.setCaptcha(captchaText);
        captcha.setRequestId(requestId);
        var voiceCaptcha = new VoiceCaptcha();
        voiceCaptcha.setCaptcha(captchaText);
        voiceCaptcha.setRequestId(requestId);
        voiceCaptcha.setUsername(JWTUtils.getUsername());
        voiceCaptcha.setDeviceId(JWTUtils.getDeviceId());
        voiceCaptcha.setPartnerCode(JWTUtils.getPartnerCode());
        voiceCaptchaRepository.save(voiceCaptcha);
        return captcha;
    }
    @Override
    public VoiceCaptcha getVoiceCaptchaCheck(String username, String captcha, boolean status, String deviceId){
        VoiceCaptcha voiceCaptcha = null;
        if (captcha != null) {
            voiceCaptcha = voiceCaptchaRepository.findByUsernameAndCaptchaAndStatusAndDeviceId(username, captcha, status, deviceId);
        }
        return voiceCaptcha;
    }
}
