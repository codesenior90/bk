package vn.com.mcredit.digitallending.services.impl;

import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.aop.CacheParam;
import vn.com.mcredit.digitallending.aop.PreventDuplicateMethod;
import vn.com.mcredit.digitallending.services.SupportService;
import vn.com.mcredit.digitallending.utils.LogUtils;

@Service
public class SupportServiceImpl implements SupportService {
    @PreventDuplicateMethod
    public String preventDuplicateMethod(@CacheParam(name = "username") String username){
    try {
        Thread.sleep(10000);

    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        LogUtils.info("[SupportService] preventDuplicateMethod");
    }
    return username;
}

}
