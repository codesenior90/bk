package vn.com.mcredit.digitallending.aop;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.exceptions.UnauthorizedException;
import vn.com.mcredit.digitallending.redis.services.TokenService;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;


import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@Aspect
@Configuration
@Order(0)
public class SecuredAspect {


	@Autowired
	TokenService tokenService;

	@Before("@annotation(Secured)")
	public void before(JoinPoint j) {

		try {
			var system = getCurrentSystem(j);
			if (!StringUtils.isNotEmpty(system))
				throw new UnauthorizedException(Constants.AUTHORIZATION_INVALID);

			var token = getCurrentToken().trim();
			if (!StringUtils.isNotEmpty(token))
				throw new UnauthorizedException(Constants.AUTHORIZATION_INVALID);

			var t = getTokenFromRedis();
			if (!StringUtils.isNotEmpty(t))
				throw new UnauthorizedException(Constants.AUTHORIZATION_INVALID);

			if (!token.equals(t))
				throw new UnauthorizedException(Constants.AUTHORIZATION_INVALID);
		} catch (Exception e) {
			throw new UnauthorizedException(Constants.AUTHORIZATION_INVALID);
		}

	}

	private String getTokenFromRedis() {
		LogUtils.info("[SecuredAspect] userName", JWTUtils.getUsername());
		String t = tokenService.get(JWTUtils.getUsername()).trim();
		if (!StringUtils.isNotEmpty(t))
			throw new UnauthorizedException(Constants.AUTHORIZATION_INVALID);

		return t;
	}

	private String getCurrentSystem(JoinPoint j) {
		MethodSignature signature = (MethodSignature) j.getSignature();
		var method = signature.getMethod();

		var s = method.getAnnotation(Secured.class);
		return s.system().toString();
	}

	private String getCurrentToken() {
		try {
			HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes()))
					.getRequest();
			var authorization = request.getHeader("Authorization");

			return StringUtils.isNotBlank(authorization) ? authorization.replace("Bearer ", "") : "";
		} catch (Exception e) {
			throw new UnauthorizedException(Constants.AUTHORIZATION_INVALID);
		}
	}
}
