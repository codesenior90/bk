package vn.com.mcredit.digitallending.redis.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.dto.resp.WSO2TokenDTO;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.WSO2Proxy;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;

import java.util.concurrent.TimeUnit;

@Component
public class WSO2TokenService extends BaseService {
    @Autowired
    private WSO2Proxy wso2Proxy;

    public static final String WSO2_TOKEN_KEY_DIGITAL_LENDING = "WSO2_TOKEN_KEY_DIGITAL_LENDING";

    public void set() {
        try {

            WSO2TokenDTO obj = wso2Proxy.authorize();
            if (obj == null)
                throw new ApplicationException(Constants.EXCEPTION_MES);

            LogUtils.info("WSO2TokenService set obj WSO2_TOKEN_KEY_REDIS");

            set(WSO2_TOKEN_KEY_DIGITAL_LENDING, obj.getAccessToken(), obj.getExpiresIn(), TimeUnit.SECONDS);
        } catch (Exception e) {
            LogUtils.error("WSO2TokenService Exception", e.getMessage());
        }
    }

    public String get() {
        var token = get(WSO2_TOKEN_KEY_DIGITAL_LENDING);
        if(StringUtils.isNullOrEmpty(token) || StringUtils.isBlank(token))
            refresh();
        return get(WSO2_TOKEN_KEY_DIGITAL_LENDING);
    }

    public void refresh() {
        set();
    }
}