package vn.com.mcredit.digitallending.dto.req;

import lombok.*;


@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MiniAppHomePageRequest {
    private String customerCode;
    private String system;
}
