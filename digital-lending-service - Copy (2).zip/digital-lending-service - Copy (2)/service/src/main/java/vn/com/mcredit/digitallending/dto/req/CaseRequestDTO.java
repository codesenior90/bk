package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigInteger;
import java.util.List;

@Data
public class CaseRequestDTO {
    @JsonProperty("requestId")
    private String requestId;
    @JsonProperty("loansOfferId")
    private BigInteger loansOfferId;
    @JsonProperty("createBy")
    private String createBy;
    @JsonProperty("model")
    private String model;
    @JsonProperty("customerRequest")
    private CustomerRequest customerRequest;
    @JsonProperty("customerAddressRequests")
    private List<CustomerAddressRequest> customerAddressRequests;
    @JsonProperty("customerRelativesRequests")
    private List<CustomerRelativesRequest> customerRelativesRequests;
    @JsonProperty("identityPaperRequests")
    private List<IdentityPaperRequest> identityPaperRequests;
    @JsonProperty("loansFileUploadRequests")
    private List<LoansFileUploadRequest> loansFileUploadRequests;
    @JsonProperty("disbursementInfoRequest")
    private DisbursementInfoDTO disbursementInfoRequest;
    @JsonProperty("locationRequest")
    private LocationRequest locationRequest;
    private String deviceId;
    private String partnerCode;
}
