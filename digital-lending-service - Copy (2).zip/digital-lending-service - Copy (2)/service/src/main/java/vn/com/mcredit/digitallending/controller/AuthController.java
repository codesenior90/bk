package vn.com.mcredit.digitallending.controller;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.com.mcredit.digitallending.dto.UserProfileCreateDTO;
import vn.com.mcredit.digitallending.dto.req.OpenWebviewRequest;
import vn.com.mcredit.digitallending.dto.req.EncryptDTO;
import vn.com.mcredit.digitallending.dto.req.LoginDTO;
import vn.com.mcredit.digitallending.services.AuthService;

import javax.validation.Valid;

@RequiredArgsConstructor
@RequestMapping("")
@RestController
public class AuthController {
    @Autowired
    private AuthService authService;
    @PostMapping(value = "/api/auth/v1/register", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> create(@Valid @RequestBody UserProfileCreateDTO userProfileCreateDTO) {
        return ResponseEntity.status(HttpStatus.OK).body(authService.register(userProfileCreateDTO));
    }
    @PostMapping(value = "/api/auth/v1/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> login(@Valid @RequestBody LoginDTO loginDTO) {
        return ResponseEntity.status(HttpStatus.OK).body(authService.login(loginDTO));
    }
    @PostMapping(value = "/api/auth/v6/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> login(@Valid @RequestBody EncryptDTO encryptDTO) {
        return ResponseEntity.status(HttpStatus.OK).body(authService.loginV6(encryptDTO));
    }
    @PostMapping(value = "/api/auth/v7/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> loginV7(@Valid @RequestBody EncryptDTO encryptDTO) {
        return ResponseEntity.status(HttpStatus.OK).body(authService.loginV7(encryptDTO));
    }
    /**
     * Check url.
     *
     * @param dto to getToken
     * @return AuthResExternalDTO.
     */
    @PostMapping("/check/url-invalid")
    @Operation(summary = "Kiểm tra url có hợp lệ hay không")
    public ResponseEntity<Object> checkUrlInvalid(@RequestBody OpenWebviewRequest dto) {
        return ResponseEntity.status(HttpStatus.OK).body(authService.checkUrl(dto));
    }
}
