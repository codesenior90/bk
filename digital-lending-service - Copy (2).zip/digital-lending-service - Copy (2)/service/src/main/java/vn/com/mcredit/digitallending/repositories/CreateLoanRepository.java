package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.CreateLoan;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface CreateLoanRepository extends JpaRepository<CreateLoan, String> {
    CreateLoan findCreateLoanByRequestId(String requestId);
    CreateLoan findCreateLoanByUserName(String userName);
    @Query(value = "SELECT * FROM create_loan WHERE user_name = :userName order by updated_date desc limit 1 ", nativeQuery = true)
    CreateLoan getCreateLoanByName(String userName);
    CreateLoan findFirstByUserNameOrderByCreatedDate(String userName);
    CreateLoan findByContractNumber(String contractNumber);
    CreateLoan findCreateLoanByUserNameAndRequestId(String userName, String requestId);
    CreateLoan findByUserNameAndCaseNumberAndContractNumber(String userName, String caseNumber, String contractNumber);
    @Query(value = "SELECT * FROM create_loan WHERE case_number = :caseNUmber and request_id = :requestId and contract_number = :contractNumber", nativeQuery = true)
    CreateLoan getCreateLoanAbort(String caseNUmber, String requestId, String contractNumber);
    boolean existsByUserNameAndStatusIn(String username, List<String> status);
    @Query(value = "SELECT * FROM create_loan WHERE user_name = :userName and case_number = :caseNumber", nativeQuery = true)
    CreateLoan getCreateLoanByNameAndAndCaseNumber(String userName, String caseNumber);
    boolean existsByRequestIdAndOfferId(String requestId, BigInteger offerId);
    @Query(value = "SELECT em.username, em.idNumber, em.idNumberOld, em.name, em.gender, em.dob, em.issuedDate," +
            " em.expiryDate, em.address, em.frontImageURL, em.backImageURL ,em.selfieImageURL, em.leftImageURL," +
            " em.rightImageURL, cl.status, cl.contractNumber, cl.partnerCode" +
            " FROM CreateLoan cl left join EkycModel em on em.username=cl.userName" +
            " WHERE cl.userName =:userName and cl.contractNumber =:contractNumber and em.idNumber =:idNumber")
    List<Object[]> getContractInfo(@Param("userName") String userName, @Param("idNumber") String idNumber, @Param("contractNumber") String contractNumber);
}
