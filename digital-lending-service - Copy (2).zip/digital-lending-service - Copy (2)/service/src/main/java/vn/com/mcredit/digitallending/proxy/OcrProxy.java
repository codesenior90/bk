package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.resp.*;

@Component
public class OcrProxy extends BaseProxy {
    @Value("${custom.properties.face-matching-api-host}")
    protected String faceApiMatchingHost;
    @Value("${custom.properties.ocr-api-host}")
    protected String ocrApiHost;

    /** API này có chức năng phát hiện giấy tờ tuỳ thân (mặt trước, mặt sau) có chụp trên màn hình thiết bị thứ ba hay không.
     *
     * @param ocrScreenRequest
     * @return
     */
    public OcrScreenResponse ocrScreen(OcrScreenRequest ocrScreenRequest) {
        String url = String.format("%s%s", ocrApiHost, "/screen");
        return this.post(url, initHeaderFormData2(), ocrScreenRequest, OcrScreenResponse.class);
    }
    public OcrResponse ocr(Object body) {
        String url = String.format("%s%s", ocrApiHost, "/ocr/freetype");
        return this.post(url, initHeaderMultipartFormData(), body, OcrResponse.class);
    }

    /** API có chức năng nhận đầu vào là 2 ảnh gồm ảnh chân dung và ảnh giấy tờ tùy thân mặt trước của khách hàng, trả về các thông tin trong quá trình xử lý ảnh và xác suất trùng khớp khuôn mặt có trong 2 ảnh được truyền vào
     *
     * @param object
     * @return
     */
    public FaceMatchRawResponse faceMatchRaw(FaceMatchRawRequest object) {
        String url = String.format("%s%s", faceApiMatchingHost, "/face_match_raw");
        return this.post(url, initHeaderAppJson(), object, FaceMatchRawResponse.class);
    }


    /** API có chức năng nhận đầu vào là 4 ảnh (ảnh chụp chân dung thẳng mặt và ảnh quay phải, quay trái, ảnh chụp chứng minh thư của khách hàng), trả về các thông tin trong quá trình xử lý ảnh và xác suất trùng khớp các khuôn mặt của ảnh chụp chân dung thẳng mặt và các ảnh còn lại.
     *
     * @param object
     * @return
     */
    public FaceMatch4WayResponse faceMatch4way(FaceMatch4WayRequest object) {
        String url = String.format("%s%s", faceApiMatchingHost, "/face_match_4way");
        return this.post(url, initHeaderAppJson(), object, FaceMatch4WayResponse.class);
    }

    protected HttpHeaders initHeaderFormData(String accessToken) {
        var headers = new HttpHeaders();
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setBearerAuth(accessToken);
        return headers;
    }
    protected HttpHeaders initHeaderFormData() {
        var headers = new HttpHeaders();
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        return headers;
    }
}
