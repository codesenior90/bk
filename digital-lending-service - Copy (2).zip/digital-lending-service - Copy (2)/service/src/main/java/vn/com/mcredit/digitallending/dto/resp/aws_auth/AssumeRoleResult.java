package vn.com.mcredit.digitallending.dto.resp.aws_auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AssumeRoleResult{
    @JsonProperty("AssumedRoleUser")
    public AssumedRoleUser assumedRoleUser;
    @JsonProperty("Credentials")
    public Credentials credentials;
    @JsonProperty("PackedPolicySize")
    public Object packedPolicySize;
    @JsonProperty("SourceIdentity")
    public Object sourceIdentity;
}
