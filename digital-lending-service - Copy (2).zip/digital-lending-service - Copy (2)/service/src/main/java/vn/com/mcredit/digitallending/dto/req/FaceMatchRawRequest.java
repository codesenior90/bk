package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.File;

@Data
public class FaceMatchRawRequest {
    @JsonProperty("process_id") // Option: Id của request gửi lên
    private String processId;
    @JsonProperty("img1")
    private File img1; // Require: Ảnh giấy tờ tùy thân mặt trước của khách hàng
    @JsonProperty("img2")
    private File img2; // Require: Ảnh chân dung của khách hàng
}
