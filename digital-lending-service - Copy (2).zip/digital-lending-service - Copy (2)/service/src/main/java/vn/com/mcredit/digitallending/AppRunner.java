package vn.com.mcredit.digitallending;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.entity.ConditionLending;
import vn.com.mcredit.digitallending.entity.HomeLending;
import vn.com.mcredit.digitallending.repositories.HomeLendingRepository;
import vn.com.mcredit.digitallending.utils.LogUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class AppRunner implements ApplicationRunner {

    private final HomeLendingRepository homeLendingRepository;
    @Override
    public void run(ApplicationArguments applicationArguments) {
        setHomeLendingDefault();
    }
    private void setHomeLendingDefault(){
        try {
            Optional<HomeLending> optionalHomeLending = homeLendingRepository.findById(Constants.HOME_LENDING_PAGE_CONFIG);
            if (optionalHomeLending.isEmpty()) {
                List<ConditionLending> conditionLendingResponses = new ArrayList<>();
                HomeLending homeLending = new HomeLending();
                homeLending.setId(Constants.HOME_LENDING_PAGE_CONFIG);
                homeLending.setBannerUrl(
                    "https://prod-external-channel-s3-mcredit-website.s3.ap-southeast-1.amazonaws.com/132835212869708617_Banner%20vay%20tr%E1%BA%A3%20g%C3%B3p.png");
                homeLending.setMonthLending(36);
                homeLending.setTitle("VAY SIÊU TỐC");
                homeLending.setContent("Cần vay liền nhận liền sau 5 phút");
                homeLending.setMainImageUrl(
                    "https://prod-external-channel-s3-mcredit-website.s3.ap-southeast-1.amazonaws.com/132834451531084876_chrome_CpUQcG9OuJ.jpg");
                homeLending.setMaxValueLendingTitle("Mức vay tối đa lên đến");
                homeLending.setMaxValueLending(15000000);
                homeLending.setMinValueVending(5000000);
                homeLending.setRatePerMonth(0.025);

                ConditionLending conditionLending = new ConditionLending();

                conditionLending.setContent("Chỉ xác minh bằng CCCD mới (có gắn chíp)");
                conditionLending.setTitle("Vay không thế chấp");
                String icon =
                    "https://prod-external-channel-s3-mcredit-website.s3.ap-southeast-1.amazonaws.com/132834451530731865_chrome_s9skfPtTQt.jpg";
                conditionLending.setIcon(icon);
                conditionLendingResponses.add(conditionLending);
                conditionLending = new ConditionLending();
                conditionLending.setContent("Chỉ từ 12k/ngày (tương đương 1 ổ bánh mì)");
                conditionLending.setTitle("Trả góp");
                conditionLending.setIcon(icon);
                conditionLendingResponses.add(conditionLending);
                conditionLending = new ConditionLending();
                conditionLending.setContent("Khách cho khách hàng chưa có hợp đồng vay hạn mức");
                conditionLending.setTitle("Đối tượng áp dụng");
                conditionLending.setIcon(icon);
                conditionLendingResponses.add(conditionLending);
                homeLending.setConditions(conditionLendingResponses);
                homeLendingRepository.save(homeLending);
            }
        } catch (Exception e){
            LogUtils.error("[AppRunner] setHomeLendingDefault", e.getMessage());
        }
    }
}
