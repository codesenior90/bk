package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class CustomerRequest {
    private String custName;
    private String custDob;
    private String custGender;
    private String listPhone;
    private String phone;
    private String custEducation;
    private String custMaritalStatus;
    private String custEmail;
    private String custCareer;
    private String custProfessional;
    private String tempSamePermAddress;
    private String incomeRange;
    private String companyName;
    private String custPosition;
    private String companyPhone;
    private String companyAddress;
}
