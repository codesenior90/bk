package vn.com.mcredit.digitallending.dto.resp;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class OfferDGTDetailResponse {
    private String returnCode;
    private String returnMes;
    private List<OfferDGTDataResponse> offers;
    @JsonProperty("codeStatus")
    private List<CodeStatus> codeStatus;
}
