package vn.com.mcredit.digitallending.services.impl;

import org.keycloak.admin.client.KeycloakBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.config.CachingConfiguration;
import vn.com.mcredit.digitallending.services.KeycloakService;

@Service
public class KeycloakServiceImpl implements KeycloakService {
    @Value("${custom.keycloak.realm}")
    protected String documentLibraryKeycloakRealm;

    @Value("${custom.keycloak.url}")
    protected String documentLibraryKeycloakUrl;

    @Value("${custom.keycloak.client-secret}")
    protected String documentLibraryKeycloakClientSecret;

    @Value("${custom.keycloak.client-id}")
    protected String documentLibraryKeycloakClientID;

    @Override
    @Cacheable(CachingConfiguration.DL_PARTNER_SERVICE_TOKEN_CACHE)
    public String issueDocumentLibraryToken() {
        var keycloak = KeycloakBuilder.builder()
                .serverUrl(documentLibraryKeycloakUrl)
                .realm(documentLibraryKeycloakRealm)
                .clientSecret(documentLibraryKeycloakClientSecret)
                .clientId(documentLibraryKeycloakClientID)
                .grantType("client_credentials")
                .build();
        return keycloak.tokenManager().getAccessToken().getToken();
    }
}
