package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class BlacklistCheckResponse {
    @JsonProperty("request_id") // Require: Request id
    private String requestId;

    @JsonProperty("response_id") // Require: Response id
    private String responseId;

    @JsonProperty("request_date") // Require: Thời điểm gửi request
    private String requestDate;

    @JsonProperty("error_code") // Mã lỗi nghiệp vụ
    private String errorCode;
    @JsonProperty("message") // Mô tả lỗi nghiệp vụ
    private String message;
    @JsonProperty("blacklist_selfie_img_cut_off_threshold") // Ngưỡng cut-off trùng ảnh selfie
    private Float blacklistSelfieImgCutOffThreshold;

    @JsonProperty("blacklist_id_img_cut_off_threshold") // Ngưỡng cut-off trùng ảnh ID
    private Float blacklistIdImgCutOffThreshold;

    @JsonProperty("blacklist_check_detail") // Thông tin url + score các ảnh trong blacklist trùng với ảnh đầu vào
    private List<BlackListCheckDetail> blacklistCheckDetails;

    @JsonProperty("blacklist_check_result") // Kết quả check
    private boolean blacklistCheckResult;
}
