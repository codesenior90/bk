package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.Data;

@Data
public class OcrResultResponse {
    @JsonProperty("address")
    private String address;
    @JsonProperty("address_correction")
    private String addressCorrection;
    @JsonProperty("address_correction_prob")
    private String addressCorrectionProb;
    @JsonProperty("address_prob")
    private String addressProb;
    @JsonProperty("dob")
    private String dob;
    @JsonProperty("dob_prob")
    private String dobProb;
    @JsonProperty("expire_date")
    private String expireDate;
    @JsonProperty("expire_date_prob")
    private String expireDateProb;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("gender_prob")
    private String genderProb;

    @JsonProperty("hometown")
    private String hometown;
    @JsonProperty("hometown_correction")
    private String hometownCorrection;
    @JsonProperty("hometown_correction_prob")
    private String hometownCorrectionProb;
    @JsonProperty("hometown_prob")
    private String hometownProb;

    @SerializedName("idNumber")
    @JsonProperty("id_number")
    private String idNumber;

    @JsonProperty("id_number_prob")
    private String idNumberProb;

    @JsonProperty("issue_date")
    private String issueDate;
    @JsonProperty("issue_date_prob")
    private String issueDateProb;


    @JsonProperty("name")
    private String name;
    @JsonProperty("name_prob")
    private String nameProb;
    @JsonProperty("nationality")
    private String nationality;
    @JsonProperty("nationality_prob")
    private String nationalityProb;

    @JsonProperty("mrz")
    private Mrz mrz;

}
