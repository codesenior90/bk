package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FaceMatchingResponse {
    @JsonProperty("id_angle")
    private String idAngle;
    @JsonProperty("detection_time")
    private String detectionTime; // Thời gian xác định khuôn mặt trong ảnh
    @JsonProperty("embedding_time")
    private String embeddingTime; // Thời gian chuyển các đặc trưng trên khuôn mặt sang vector

    @JsonProperty("s1")
    private String s1;

    @JsonProperty("selfie_angle")
    private String selfieAngle;

    @JsonProperty("error")
    private Object error;
    @JsonProperty("status")
    private boolean status;
    @JsonProperty("pass")
    private boolean pass;

    private String responseId; // Id của response trả về
}
