package vn.com.mcredit.digitallending.dto.req.ekyc;

import lombok.Data;

@Data
public class NFCVerifyRequest {
    private String username;
    private String system;
    private String ipAddress;
    private String faceImage;
    private String com;
    private String sod;
    private String dg1;
    private String dg2;
    private String dg3;
    private String dg4;
    private String dg5;
    private String dg6;
    private String dg7;
    private String dg8;
    private String dg9;
    private String dg10;
    private String dg11;
    private String dg12;
    private String dg13;
    private String dg14;
    private String dg15;
    private String dg16;
    private String requestId; // request id từ bước ocr
}
