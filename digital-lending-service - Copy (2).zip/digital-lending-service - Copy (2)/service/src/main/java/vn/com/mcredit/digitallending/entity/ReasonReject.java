package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "reason_reject")
public class ReasonReject {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "status")
    private String status;
    @Column(name = "reason_code")
    private String reasonCode;
    @Column(name = "reason_message", columnDefinition = "text")
    private String reasonMessage;
    @CreatedDate
    @Column(name = "create_date")
    private Date createDate;
    @Column(name = "modify_date")
    private Date modifyDate;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "type")
    private String type;
    @Column(name = "is_free_text")
    private boolean isFreeText;
}
