package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class LoanState {
    private String offerStatus; // true|false
    private String createStatus; // true|false

}
