package vn.com.mcredit.digitallending.middleware;

import org.apache.logging.log4j.ThreadContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

public class HttpMessageObject {
    private String sourceAppIp;
    private String destAppIp;
    private int destAppPort;
    private String httpPath;
    private String httpMethod;
    private int responseCode;
    private Map<String, String> header = new HashMap<>();
    private String body = null;

    public HttpMessageObject(HttpServletRequest httpRequest) {
        sourceAppIp = httpRequest.getRemoteHost();
        destAppIp = httpRequest.getLocalAddr();
        destAppPort = httpRequest.getLocalPort();
        httpMethod = httpRequest.getMethod();
        httpPath = httpRequest.getRequestURI();
        Enumeration<String> headerNames = httpRequest.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            if (headerName.equalsIgnoreCase("Authorization")) {
                header.put(headerName, "<<Not recorded to log>>");
            } else {
                header.put(headerName, httpRequest.getHeader(headerName));
            }

            header.put("serviceMessageId", ThreadContext.get("serviceMessageId"));
        }
    }

    public HttpMessageObject(HttpServletRequest httpRequest, String body) {
        sourceAppIp = httpRequest.getRemoteHost();
        destAppIp = httpRequest.getLocalAddr();
        destAppPort = httpRequest.getLocalPort();
        httpMethod = httpRequest.getMethod();
        httpPath = httpRequest.getRequestURI();
        Enumeration<String> headerNames = httpRequest.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            if (headerName.equalsIgnoreCase("Authorization")) {
                header.put(headerName, "<<Not recorded to log>>");
            } else {
                header.put(headerName, httpRequest.getHeader(headerName));
            }
        }
        this.body = body;
    }

    public HttpMessageObject(HttpServletRequest httpRequest, HttpServletResponse httpResponse, String body) {
        sourceAppIp = httpRequest.getRemoteHost();
        destAppIp = httpRequest.getLocalAddr();
        destAppPort = httpRequest.getLocalPort();
        httpMethod = httpRequest.getMethod();
        httpPath = httpRequest.getRequestURI();
        responseCode = httpResponse.getStatus();
        Collection<String> headerNames = httpResponse.getHeaderNames();
        for (String headerName : headerNames) {
            header.put(headerName, httpResponse.getHeader(headerName));
        }
        this.body = body;
    }

    @SuppressWarnings("unused")
    public int getResponseCode() {
        return responseCode;
    }

    @SuppressWarnings("unused")
    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @SuppressWarnings("unused")
    public String getSourceAppIp() {
        return sourceAppIp;
    }

    @SuppressWarnings("unused")
    public void setSourceAppIp(String sourceAppIp) {
        this.sourceAppIp = sourceAppIp;
    }

    @SuppressWarnings("unused")
    public String getDestAppIp() {
        return destAppIp;
    }

    @SuppressWarnings("unused")
    public void setDestAppIp(String destAppIp) {
        this.destAppIp = destAppIp;
    }

    @SuppressWarnings("unused")
    public int getDestAppPort() {
        return destAppPort;
    }

    @SuppressWarnings("unused")
    public void setDestAppPort(int destAppPort) {
        this.destAppPort = destAppPort;
    }

    @SuppressWarnings("unused")
    public String getHttpPath() {
        return httpPath;
    }

    @SuppressWarnings("unused")
    public void setHttpPath(String httpPath) {
        this.httpPath = httpPath;
    }

    @SuppressWarnings("unused")
    public String getHttpMethod() {
        return httpMethod;
    }

    @SuppressWarnings("unused")
    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    @SuppressWarnings("unused")
    public Map<String, String> getHeader() {
        return header;
    }

    @SuppressWarnings("unused")
    public void setHeader(Map<String, String> header) {
        this.header = header;
    }

    @SuppressWarnings("unused")
    public String getBody() {
        return body;
    }

    @SuppressWarnings("unused")
    public void setBody(String body) {
        this.body = body;
    }
}

