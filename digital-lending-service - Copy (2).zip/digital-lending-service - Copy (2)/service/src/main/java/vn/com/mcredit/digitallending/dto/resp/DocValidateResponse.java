package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DocValidateResponse {
    @JsonProperty("request_id")
    private String requestId;
    @JsonProperty("response_id")
    private String responseId;
    @JsonProperty("success")
    private boolean success;
    @JsonProperty("error")
    private String error;
    @JsonProperty("error_code")
    private String errorCode;
    @JsonProperty("system_error")
    private String systemError;
    @JsonProperty("body")
    private DocValidateBodyResponse docValidateBodyResponse;

}
