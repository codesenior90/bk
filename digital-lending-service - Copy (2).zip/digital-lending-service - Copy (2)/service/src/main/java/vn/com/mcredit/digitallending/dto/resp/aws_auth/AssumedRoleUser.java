package vn.com.mcredit.digitallending.dto.resp.aws_auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AssumedRoleUser{
    @JsonProperty("Arn")
    public String arn;
    @JsonProperty("AssumedRoleId")
    public String assumedRoleId;
}
