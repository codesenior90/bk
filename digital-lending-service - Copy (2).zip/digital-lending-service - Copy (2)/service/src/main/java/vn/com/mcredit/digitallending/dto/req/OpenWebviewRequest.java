package vn.com.mcredit.digitallending.dto.req;

import lombok.*;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class OpenWebviewRequest {
    private String sign;
}
