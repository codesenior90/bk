package vn.com.mcredit.digitallending.dto.req.ekyc;

import lombok.Data;

@Data
public class RecoAddVectorReq {
    private String dimensionCode;
    private String db;
    private String uid;
}