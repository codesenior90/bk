package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;
import vn.com.mcredit.digitallending.dto.PreCheckResultDTO;

@Data
public class PreCheckResponse extends BpmBaseResponse{
    private PreCheckResultDTO data;
}
