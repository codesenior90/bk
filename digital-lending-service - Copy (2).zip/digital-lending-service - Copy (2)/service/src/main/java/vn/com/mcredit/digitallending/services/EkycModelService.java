package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.resp.internal.UserLinkResponse;
import vn.com.mcredit.digitallending.entity.EkycModel;

public interface EkycModelService {
    EkycModel findEkycModelByUsername(String username);
    Boolean existsByUsername(String username);
    EkycModel save(EkycModel ekycModel);
    void verifyDeviceId(EkycModel ekycModel);
    UserLinkResponse getUserLink(String username);
}
