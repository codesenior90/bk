package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class OcrRequest {
    private String idNumber;
    private String homeTown;
    private String address;
    private String gender;
    private String nationality;
    private String issuedDate;
    private String dob;
    private String expiryDate;
    private String name;
    private String idType;
    private String idName;
    private String addressCorrectionProb;
    private String issueDateProb;
    private String nameProb;
    private String expireDateProb;
    private String dobProb;
    private String addressProb;
    private String hometownProb;
    private String idNumberProb;
    private Boolean pass;
}
