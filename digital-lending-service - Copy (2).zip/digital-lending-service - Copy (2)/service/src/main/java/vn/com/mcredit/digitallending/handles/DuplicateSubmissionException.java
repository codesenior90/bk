package vn.com.mcredit.digitallending.handles;

import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;

public class DuplicateSubmissionException extends ApplicationException {

	public DuplicateSubmissionException(Error error) {
		super(error.getMessage());
		this.setCode(error.getCode());
		this.setMessage(error.getMessage());
	}
}
