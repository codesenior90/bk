package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.enums.DocumentType;
import vn.com.mcredit.digitallending.proxy.EcmProxy;
import vn.com.mcredit.digitallending.services.AwsS3Service;
import vn.com.mcredit.digitallending.services.EcmService;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.Utils;
import java.io.IOException;

@Service
@RequiredArgsConstructor
public class EcmServiceImpl implements EcmService {
    private final EcmProxy ecmProxy;
    private final AwsS3Service awsS3Service;
    @Override
    public String upload(Object body) {
        try {
            return ecmProxy.upload(body);
        } catch (Exception e){
            LogUtils.error("[EcmService] uploadFileToEcm ex", e.getMessage());
            return null;
        }
    }

    @Override
    public String upload(String idNumber, DocumentType documentType, MultipartFile file) throws IOException {
        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        map.add("idNumber", idNumber);
        map.add("documentType", documentType);
        Utils.addMapImage(map, "file", file);
        return this.upload(map);
    }
    @Override
    public String upload(String idNumber, DocumentType documentType, String url, String fileName) {
        try {
            MultipartFile file = awsS3Service.dowload2S3bucketWithName(Utils.getFileUrlKeyS3(url), fileName);
            return this.upload(idNumber, DocumentType.CUSTOMER_RECORDS, file);
        } catch (Exception e){
            LogUtils.error("[EcmService] uploadFileToEcm ex", e.getMessage());
            return null;
        }
    }
}
