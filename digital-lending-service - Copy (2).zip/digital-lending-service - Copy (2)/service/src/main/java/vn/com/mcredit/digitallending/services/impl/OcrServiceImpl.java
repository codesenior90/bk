package vn.com.mcredit.digitallending.services.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.ScreenScoreDTO;
import vn.com.mcredit.digitallending.dto.req.OcrForm;

import vn.com.mcredit.digitallending.dto.resp.OcrResponse;
import vn.com.mcredit.digitallending.dto.resp.OcrResultResponse;
import vn.com.mcredit.digitallending.entity.Ocr;
import vn.com.mcredit.digitallending.enums.*;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.OcrProxy;
import vn.com.mcredit.digitallending.services.OcrService;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.io.IOException;

import java.util.Date;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OcrServiceImpl extends OcrBaseService implements OcrService {
    private final OcrProxy proxy;
    private final ObjectMapper objectMapper;

    @Value("${custom.properties.cutoff-screen}")
    private Float cutoffScreen;

    @Override
    public OcrResponse ocr(OcrForm ocrForm) {
        OcrResponse ocrResponse;
        Ocr ocr = new Ocr();
        try {
            ocr.setUsername(JWTUtils.getUsername());
            ocrResponse = proxy.ocr(this.buildOcrRequest(ocrForm));
            LogUtils.info("[OcrService] ocr response");
            ocrResponse.setRequestId(UUID.randomUUID().toString());
            String idNumber = null;
            if (ocrResponse.getResult() != null){
                idNumber = ocrResponse.getResult().getIdNumber();
            }
            LogUtils.info("[OcrService] ocr idNumber", idNumber);
            this.upload(ocrForm.getFrontImg(), ocrForm.getBackImg(), JWTUtils.getUsername(), idNumber, ocr);
            boolean pass = this.verifyOcrResult(ocrResponse);
            LogUtils.error("[OcrService] ocr pass", pass);
            this.saveOcr(ocrResponse, ocr,null, pass, ocrForm.getProcessEkyc());
            this.verifyCCCDChip(ocr, ocrResponse);
            if (!pass) throw new ApplicationException(Error.FAIL_OCR_CCCD_CHIP.name(), Error.FAIL_OCR_CCCD_CHIP.getMessage());
            this.validateInformationOcr(ocr, idNumber, ocrResponse.getResult().getGender(), ocrResponse.getResult().getDob(), ocrResponse.getResult().getIssueDate(), ocrResponse.getResult().getExpireDate());
            this.verifyIdentifyNumber(ocr, idNumber, ocrForm.getProcessEkyc());
        } catch (IOException e) {
            LogUtils.error("[OcrService] ocr exception", e.getMessage());
            this.saveOcr(null, ocr, e.getMessage(), false, ocrForm.getProcessEkyc());
            throw new ApplicationException(Error.FAIL_OCR_CCCD_CHIP.name(), Error.FAIL_OCR_CCCD_CHIP.getMessage());
        } catch (HttpStatusCodeException statusCodeException){
            this.saveOcr(null, ocr, statusCodeException.getResponseBodyAsString(), false, ocrForm.getProcessEkyc());
            throw new ApplicationException(statusCodeException.getStatusCode().name(), statusCodeException.getStatusText());
        }
        return ocrResponse;
    }

    /**
     * Lưu kết quả ocr (bảo gồm thành công và thất bại)
     *
     * @param ocrResponse
     * @param ocr
     * @param errorResult
     */
    private void saveOcr(OcrResponse ocrResponse, Ocr ocr, String errorResult, boolean pass, Integer processEkyc){
        if (ocrResponse != null){
            ocr.setRequestId(ocrResponse.getRequestId());
            ocr.setIdType(ocrResponse.getIdType());
            ocr.setIdName(ocrResponse.getIdName());
            ocr.setStatus(ocrResponse.isStatus());
            ocr.setPass(pass);
            ocr.setTicketStatus(TicketState.OPEN.getValue());
            if (ocrResponse.getResult() != null) {
                OcrResultResponse result = ocrResponse.getResult();
                ocr.setIdNumber(result.getIdNumber());
                ocr.setName(result.getName());
                ocr.setDob(result.getDob());
                ocr.setAddressCorrection(result.getAddressCorrection());
                ocr.setNationality(result.getNationality());
                if (Gender.MALE.getValue().equalsIgnoreCase(result.getGender())){
                    ocr.setGender(Gender.MALE.name());
                } else if (Gender.FEMALE.getValue().equalsIgnoreCase(result.getGender())){
                    ocr.setGender(Gender.FEMALE.name());
                } else {
                    ocr.setGender(result.getGender());
                }
                ocr.setAddress(result.getAddress());
                ocr.setExpiryDate(result.getExpireDate());
                ocr.setIssuedDate(result.getIssueDate());
                ocr.setHomeTown(result.getHometown());
                ocr.setHometownCorrection(result.getHometownCorrection());
                ocr.setDob(result.getDob());
            }
            ocr.setResult(Utils.toJson(ocrResponse));
            String partnerCode = JWTUtils.getPartnerCode();
            ocr.setPartnerCode(partnerCode);
            try {
                if (ocrResponse.isStatus()) {
                    ocr.setFrontScreenDetectionScore(getScreenDetectionScore(ocrResponse.getFrontScreenScore()));
                    ocr.setBackScreenDetectionScore(getScreenDetectionScore(ocrResponse.getBackScreenScore()));
                }
            }catch (Exception e) {
                LogUtils.error("[OcrServiceImpl] saveOcr: Can't get screenScore from ocrResponse!");
            }
        } else {
            ocr.setPass(pass);
            ocr.setResult(errorResult);
        }
        if(processEkyc != null) {
            ocr.setProcessEkyc(processEkyc);
        }
        ocr.setCreatedAt(new Date());
        ocr.setUpdatedAt(new Date());
        ocr.setSourceEkyc(SourceEKYC.OTHER.getValue());
        ocrRepository.save(ocr);
    }

    private boolean verifyOcrResult(OcrResponse ocrResponse) {
        try {
            if (!ocrResponse.isStatus()) return false;
            Float backScreenScore = this.getScreenDetectionScore(ocrResponse.getBackScreenScore());
            Float frontScreenScore = this.getScreenDetectionScore(ocrResponse.getFrontScreenScore());
            LogUtils.info("[OcrService] verifyOcrResult backScreenScore", backScreenScore);
            LogUtils.info("[OcrService] verifyOcrResult frontScreenScore", frontScreenScore);
            LogUtils.info("[OcrService] verifyOcrResult idType", ocrResponse.getIdType());
            return ocrResponse.isStatus()
                    && CardType.CCCD_CHIP_TYPE.getValue().equalsIgnoreCase(ocrResponse.getIdType())
                    && backScreenScore <= cutoffScreen && frontScreenScore <= cutoffScreen ;
        } catch (Exception e){
            return false;
        }
    }
    private float getScreenDetectionScore(String screenScore){
        Object json = Utils.parseToJson(screenScore);
        ScreenScoreDTO screenScoreDTO = objectMapper.convertValue(json, ScreenScoreDTO.class);
        return Float.parseFloat(screenScoreDTO.getScreenDetectionScore());
    }

}
