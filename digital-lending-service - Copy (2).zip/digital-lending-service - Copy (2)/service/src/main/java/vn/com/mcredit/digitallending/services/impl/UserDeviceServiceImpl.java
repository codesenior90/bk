package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.dto.req.CheckDeviceRequest;
import vn.com.mcredit.digitallending.dto.resp.CheckDeviceResponse;
import vn.com.mcredit.digitallending.dto.resp.DeviceVerificationResponse;
import vn.com.mcredit.digitallending.proxy.AfcProxy;
import vn.com.mcredit.digitallending.services.UserDeviceService;
import vn.com.mcredit.digitallending.utils.LogUtils;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class UserDeviceServiceImpl implements UserDeviceService {
    private final AfcProxy afcProxy;
    @Override
    public CheckDeviceResponse checkDevice(CheckDeviceRequest request) {
        try {
            LogUtils.info("[UserDeviceService] checkDevice response");
            return afcProxy.checkDevice(request);
        } catch (HttpStatusCodeException e){
            LogUtils.error("[UserDeviceService] checkDevice exception getResponseBodyAsString", e.getResponseBodyAsString());
            return null;
        }
    }

    @Override
    public DeviceVerificationResponse getDeviceVerification(Map<String, String> requestParams) {
        try {

            DeviceVerificationResponse response = afcProxy.getDeviceVerification(requestParams);
            LogUtils.info("[UserDeviceService] updateDevice response");
            return response;
        } catch (HttpStatusCodeException e){
            LogUtils.info("[UserDeviceService] checkDevice exception getResponseBodyAsString", e.getResponseBodyAsString());
            return null;
        }
    }

    @Override
    public boolean verifyDevice(CheckDeviceResponse response) {
        return false;
    }
}
