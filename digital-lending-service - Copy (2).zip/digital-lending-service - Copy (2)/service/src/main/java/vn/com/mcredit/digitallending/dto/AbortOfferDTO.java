package vn.com.mcredit.digitallending.dto;

import lombok.Data;

import java.math.BigInteger;

@Data
public class AbortOfferDTO {
    private String topic;
    private String caseNumber;
    private BigInteger offerId;
    private String contentType;
    private String requestId;
    private String status;
    private String sourceCreate;
    private String message;
    private String contractNumber;
    private String partnerCode;
}
