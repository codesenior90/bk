package vn.com.mcredit.digitallending.enums;

public enum ReasonAbort {
    OFFER_REJECT_72H("OFFER_REJECT_72H","KH quá 72h xác nhận offer."),
    INVALID_CMT("INVALID_CMT","KH định danh không thành công vì đã dùng CCCD không gắn chip."),
    CASE_REJECT_15D("CASE_REJECT_15D","KH quá 15 ngày ký hợp đồng."),
    FAIL_CALL_TELCO("NO_CALL_TELCO", "Không gọi Telco"),
    OFFER_REJECT("OFFER_REJECT", "KH từ chối offer"),
    ;
    private String code;

    private String message;

    ReasonAbort(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
