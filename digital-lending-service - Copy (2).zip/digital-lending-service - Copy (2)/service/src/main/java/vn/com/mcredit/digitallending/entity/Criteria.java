package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "criteria")
public class Criteria {

    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name = "username")
    private String userName;

    @Column(name = "customer_code")
    private String customerCode;

    @Column(name = "client_message_id")
    private String clientMessageId;

    @Column(name = "criteria_type")
    private String criteriaType;

    @Column(name = "criteria")
    private String criteria;

    @Column(name = "criteria_grp_id")
    private String criteriaGrpId;

    @Column(name = "criteria_grp_nm")
    private String criteriaGrpNm;

    @Column(name = "criteria_id")
    private String criteriaId;

    @Column(name = "criteria_nm")
    private String criteriaNm;

    @Column(name = "criteria_value")
    private String criteriaValue;

    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;

}
