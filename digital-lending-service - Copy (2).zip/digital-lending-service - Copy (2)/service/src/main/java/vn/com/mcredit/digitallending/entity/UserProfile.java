package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_profile")
public class UserProfile {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "username")
    private String username;
    @Column(name = "phone_number")
    private String phoneNumber;
    @Column(name = "password")
    private String password;
    @Size(max = 100)
    @Column(name = "full_name")
    private String fullName;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "modified_date")
    private Date modifiedDate;
    @Column(name = "device_id")
    private String deviceId;
    @Column(name = "is_ekyc")
    private Boolean isEkyc;
    @Column(name = "gender")
    private String gender;
    @Column(name = "dob")
    private String dob;
    @Column(name = "keycloak_id")
    private String keycloakId;
    @Column(name = "cif")
    private String cif;
    @Column(name = "redeem_code")
    private String redeemCode;
    @Column
    private String email;
    @Column(name = "card_id")
    private String cardId;
    @Column(name = "card_type")
    private String cardType;
    @Column(name = "card_issued_at")
    private String cardIssuedAt;
    @Column(name = "card_expired_at")
    private String cardExpiredAt;
    @Column(name = "address")
    private String address;
    @Column(name = "province")
    private String province;
    @Column(name = "district")
    private String district;
    @Column(name = "city")
    private String city;
    @Column(name = "avatar", columnDefinition = "text")
    private String avatar;
    @Column(name = "user_type")
    private String userType;
    @Column(name = "is_matching")
    private Boolean isMatching;
    @Column(name = "is_inhouse")
    private Boolean isInhouse;
    @Column(name = "position")
    private String position;
    @Column(name = "request_id", length = 36)
    private String requestId; // được thiết lập ở api 03
}
