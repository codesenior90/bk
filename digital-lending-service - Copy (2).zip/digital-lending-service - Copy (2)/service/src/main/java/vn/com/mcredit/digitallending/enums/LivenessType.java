package vn.com.mcredit.digitallending.enums;

public enum LivenessType {
    LIVENESS,
    LIVENESS_WITHOUT_FACE,
    LIVENESS_WITHOUT_OCR;
}
