package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

@Data
public class OcrRecognitionResp {
    private String code;
    private String cardGroup;
    private String cardGroupType;
    private String status;
    private String dimensionCode;
    private String frontImage;
    private String backImage;
    private OcrModel info;
    private BlurScore frontBlurScore;
    private BlurScore backBlurScore;
    private ScreenScore frontScreenScore;
    private ScreenScore backScreenScore;
}
