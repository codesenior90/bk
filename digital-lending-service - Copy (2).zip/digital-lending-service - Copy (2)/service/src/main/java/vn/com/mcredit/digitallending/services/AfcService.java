package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.ekyc.EkycResponseModel;
import vn.com.mcredit.digitallending.entity.EkycModel;
import vn.com.mcredit.digitallending.entity.IdInternalCheck;
import vn.com.mcredit.digitallending.entity.Ocr;
import vn.com.mcredit.digitallending.enums.EkycType;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.models.SendOTPDTO;
import vn.com.mcredit.digitallending.models.SendVerifyOtpDTO;

public interface AfcService {
    CheckAccountRegisterResponse checkAccountRegisterByPhone(String phone);
    Object sendOtp(SendOTPDTO dto);
    Object verifyPhoneOtp(SendVerifyOtpDTO dto);
    SynchronizeEkycResponse synchronizeEKyc(SynchronizeEkycRequest body, String username);
    SynchronizeEkycRequest buildSynchronizeEkycRequest(EkycModel ekycModel, Ocr ocr, FaceMatchRawResponse faceMatchRawResponse, FaceMatch3WayResponse faceMatch3WayResponse, String deviceId, EkycType ekycType, IdInternalCheck idInternalCheck);
    SynchronizeOcrRequest buildSynchronizeOcrRequest(Ocr ocr, IdInternalCheck idInternalCheck);
    IdentityPresentResponse identityPresent(String identity);
    EkycDetailResponse getEkycDetail(String username);
    Object viewEcontractTransaction(Object dto);
    ApplicationException verifyIdentifyNumber(String idNumber);
    SynchronizeEkycRequest buildSynchronizeEkycRequest(EkycModel ekycModel, Ocr ocr, EkycResponseModel liveness, String deviceId, EkycType ekycType, IdInternalCheck idInternalCheck);
    void pushUserNotify(String username);
    AccessTokenV7DTO loginV7(LoginDTO body);
}