package vn.com.mcredit.digitallending.enums;

import java.util.Arrays;

public enum EPartnerCode {
    MB_BANK("mbbank"),
    MC_CREDIT_APP("mCreditApp"),
    WEB_APP("web_app");
    private final String value;

    private String message;

    EPartnerCode(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public String getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }
    public static boolean isExisted(String value) {
        return Arrays.stream(EPartnerCode.values()).anyMatch(p->p.value.equalsIgnoreCase(value));
    }
}
