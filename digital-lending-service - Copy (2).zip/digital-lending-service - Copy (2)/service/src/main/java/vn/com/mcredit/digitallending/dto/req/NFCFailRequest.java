package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class NFCFailRequest {
    private String requestId;
    private String errorCode;
    private String errorMessage;
}
