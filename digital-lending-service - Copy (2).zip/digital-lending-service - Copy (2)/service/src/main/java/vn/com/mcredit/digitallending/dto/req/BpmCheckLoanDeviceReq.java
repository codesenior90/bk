package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class BpmCheckLoanDeviceReq {
    private String phoneNumber;
    private String deviceId;
    private String requestId;
}
