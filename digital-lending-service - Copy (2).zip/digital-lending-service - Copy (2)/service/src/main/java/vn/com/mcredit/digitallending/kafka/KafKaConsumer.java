package vn.com.mcredit.digitallending.kafka;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.dto.AbortOfferDTO;
import vn.com.mcredit.digitallending.entity.CreateLoan;
import vn.com.mcredit.digitallending.entity.EkycModel;
import vn.com.mcredit.digitallending.entity.PreOffer;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.enums.AbortType;
import vn.com.mcredit.digitallending.enums.LoanState;
import vn.com.mcredit.digitallending.enums.OfferState;
import vn.com.mcredit.digitallending.enums.ReasonAbort;
import vn.com.mcredit.digitallending.repositories.CreateLoanRepository;
import vn.com.mcredit.digitallending.repositories.EkycModelRepository;
import vn.com.mcredit.digitallending.repositories.PreOfferRepository;
import vn.com.mcredit.digitallending.services.AfcService;
import vn.com.mcredit.digitallending.services.BpmService;
import vn.com.mcredit.digitallending.services.LoanRunnable;
import vn.com.mcredit.digitallending.services.MCPortalService;
import vn.com.mcredit.digitallending.utils.DateUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;


@Service
@RequiredArgsConstructor
public class KafKaConsumer {
    @Autowired
    private final BpmService bpmService;
    @Autowired
    @Qualifier("receiveMessageThreadPoolTaskExecutor")
    private TaskExecutor taskExecutor;

    @Autowired
    private MCPortalService mcPortalService;

    @Autowired
    private AfcService afcService;

    private final ObjectMapper objectMapper;

    private final PreOfferRepository preOfferRepository;

    private final EkycModelRepository ekycModelRepository;

    private final CreateLoanRepository createLoanRepository;
    @KafkaListener(topics = "${kafka.topic.digital-create-offer-reply}",
            groupId = "${kafka.topic.group.id}",
            containerFactory = "kafkaListenerContainerFactory")
    public void receiveMessageCreateOffer(String data) {
        try {
            taskExecutor.execute(new LoanRunnable(Constants.RECEIVE_CREATE_OFFER, data, bpmService));
        } catch (Exception e){
            LogUtils.error("[KafKaConsumer] receiveMessageCreateOffer ", e.getMessage());
        }
    }

    @KafkaListener(topics = "${kafka.topic.digital-create-case-reply}",
            groupId = "${kafka.topic.group.id}",
            containerFactory = "kafkaListenerContainerFactory")
    public void receiveMessageCreateCase(String data) {
        try {
            taskExecutor.execute(new LoanRunnable(Constants.RECEIVE_CREATE_CASE, data, bpmService));
        } catch (Exception e){
            LogUtils.error("[KafKaConsumer] receiveMessageCreateCase ", e.getMessage());
        }
    }
    @KafkaListener(topics = "${kafka.topic.digital-eContract}",
            groupId = "${kafka.topic.group.econtract-id}",
            containerFactory = "kafkaListenerContainerFactory")
    public void receiveMessageFromEContract(String data) {
        try {
            taskExecutor.execute(new LoanRunnable(Constants.RECEIVE_MESSAGE_FROM_ECONTRACT, data, bpmService));
        } catch (Exception e){
            LogUtils.error("[KafKaConsumer] receiveMessageFromEContract execute error", e.getMessage());
        }
    }

    @KafkaListener(topics = "${kafka.topic.digital-abort-offer-case}",
            groupId = "${kafka.topic.group.id}",
            containerFactory = "kafkaListenerContainerFactory")
    public void receiveAbortOfferCase(String data) {
        mcPortalService.sendLeadToMcPortal(data, AbortType.OFFER.name());
    }

    @KafkaListener(topics = "${kafka.topic.digital-abort-case-15d}",
            groupId = "${kafka.topic.group.id}",
            containerFactory = "kafkaListenerContainerFactory")
    public void receiveAbortCase15Day(String data) {
        this.processAbort(data, AbortType.CASE.name());
    }

    public void processAbort(String data, String type) {
        try {
            LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal abort case ", data);
            LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal type ", type);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            objectMapper.setDateFormat(new SimpleDateFormat(DateUtils.FORMAT_TIME_BPM_YYYY_MM_DD_HH_MM_SS_SSS));
            AbortOfferDTO abortOffer = objectMapper.readValue(data, AbortOfferDTO.class);

            String other;
            BigInteger offerId = abortOffer.getOfferId();
            String preOfferStatus;
            String reasonCode;
            CreateLoan createLoan;
            if (AbortType.CASE.name().equals(type)) {
                createLoan = createLoanRepository.getCreateLoanAbort(abortOffer.getCaseNumber(), abortOffer.getRequestId(), abortOffer.getContractNumber());
                if (createLoan == null) {
                    LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal pre_offer not found caseNumber " + abortOffer.getCaseNumber() + " requestId " + abortOffer.getRequestId() + " contractNumber " + abortOffer.getContractNumber());
                    return;
                }
                createLoan.setStatus(LoanState.CREATE_CASE_REJECT.getValue());
                createLoan.setReason(ReasonAbort.CASE_REJECT_15D.getMessage());
                createLoan.setUpdatedDate(new Date());
                createLoanRepository.save(createLoan);

                other = ReasonAbort.CASE_REJECT_15D.getMessage();
                offerId = createLoan.getOfferId();
                preOfferStatus = OfferState.LOAN_ABORT_15D.getValue();
                reasonCode = ReasonAbort.CASE_REJECT_15D.getCode();
                // send notify abort case to AFC
                afcService.pushUserNotify(createLoan.getUserName());
            } else {
                other = ReasonAbort.OFFER_REJECT_72H.getMessage();
                reasonCode = ReasonAbort.OFFER_REJECT_72H.getCode();
                preOfferStatus = OfferState.OFFER_REJECT.getValue();
            }
            PreOffer preOffer = preOfferRepository.findByOfferIdAndRequestId(offerId, abortOffer.getRequestId());
            if (preOffer == null) {
                LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal pre_offer not found requestId " + abortOffer.getRequestId() + " offerId " + offerId);
                return;
            }
            if (AbortType.OFFER.name().equals(type)) {
                createLoan = createLoanRepository.findCreateLoanByUserNameAndRequestId(preOffer.getUserName(), preOffer.getRequestId());
                if (createLoan != null) return;
            }
            preOffer.setStatus(preOfferStatus);
            preOffer.setReason(other);
            preOffer.setReasonCode(reasonCode);
            preOffer.setUpdatedDate(new Date());
            preOfferRepository.save(preOffer);

            LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal abort case username", preOffer.getUserName());

            EkycModel ekycModel = ekycModelRepository.findByUsername(preOffer.getUserName());
            // Send lead to MCPortal
            mcPortalService.sendData(mcPortalService.buildCreateLeadRequest(ekycModel, ekycModel.getUsername(), preOffer.getLoanAmtMinusInsu(), other, abortOffer.getPartnerCode()), preOffer.getUserName());
        } catch (Exception e) {
            LogUtils.info("[MCPortalService] sendLeadToMcPortal abort case failed");
        }
    }
}