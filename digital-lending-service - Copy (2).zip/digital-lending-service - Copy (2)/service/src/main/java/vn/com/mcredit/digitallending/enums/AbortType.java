package vn.com.mcredit.digitallending.enums;

public enum AbortType {
    OFFER,
    CASE;
}
