package vn.com.mcredit.digitallending.dto.resp.internal;

import lombok.Data;

@Data
public class MiniAppUserInfo {
    private String system;
    private String mobile;
    private String email;
    private String partner;
    private String dateOfBirth;
    private Extras extras;
    private String id;
    private String code;
    private String name;
    private String createdBy;
    private String createdDate;
    private String lastModified;
    private String status;
    private String transactionId;
}
