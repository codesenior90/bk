package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

import java.util.List;

@Data
public class AfcNotifyRequest {
    private String keyNoti;
    private List<String> listKeyBodyNoti;
    private String systemId;
    private List<String> usernames;
}
