package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class CheckAccountMBResponse extends BpmBaseResponse {
    private String result; // Pass/ fail
    private String errorCode; // Lỗi TK không active: FAIL_ACCBANK_INVALID, Lỗi không khớp thông tin: FAIL_ACCBANK_INFO, Lỗi không định danh level 3: FAIL_ACCBANK_LEVEL3
    private String accountStatus; // Trạng thái tài khoản (active/ invalid)
    private String accountName; // Tên khách hàng
    private String idCardNumber; // Số GTTT của số tk
    private String customerSector; // Mã level định danh
}
