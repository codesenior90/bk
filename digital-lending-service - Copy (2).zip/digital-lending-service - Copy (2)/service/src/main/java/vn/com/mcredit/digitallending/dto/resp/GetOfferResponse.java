package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetOfferResponse extends BpmBaseResponse{
    @JsonProperty("data")
    private Object data;
}
