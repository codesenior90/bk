package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class CallLogRequest {
    private String requestId;
    @NotNullorEmpty(message = "Username không được để trống.")
    private String username;
    private String uri;
    @NotNullorEmpty(message = "Định dạng dd/MM/yyyy")
    private String fromDate;
}
