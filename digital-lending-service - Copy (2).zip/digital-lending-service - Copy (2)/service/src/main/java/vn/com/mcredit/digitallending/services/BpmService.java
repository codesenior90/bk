package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.req.contract.ContractDTO;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.internal.UserLinkResponse;
import vn.com.mcredit.digitallending.entity.Ocr;

import java.math.BigInteger;
import java.util.Map;

public interface BpmService {
    void callCheckDupMC(Ocr ocr, CheckFraudC3AppRequestDTO dto, Map<String, Object> map);

    CheckFraudC3AppRequestDTO buildCheckDupMcRequest(Ocr ocr, String idNumberOld);
    Object checkDupMc(CheckFraudC3AppRequestDTO checkFraudC3AppRequestDTO); // check dup nội bộ mc
    PreCheckResponse preCheck(PreCheckRequestDTO preCheckRequestDTO); // Lay thong tin pre offer
    BpmBaseResponse preOffer(OfferRequestDTO offerRequestDTO); // check dup-mc & nợ xấu + blacklist + nợ mc + s37

    DigitalLendingResponse getOffer(GetOfferRequestDTO getOfferRequestDTO); // pre-check + get offer
    DigitalLendingResponse getStatusOffer(StatusOfferRequestDTO statusOfferRequestDTO); // get status offer
    DigitalLendingResponse getStatusOffer(String caseNumber); // get status offer

    BpmBaseResponse rejectOffer(RejectOfferRequestDTO rejectOfferRequestDTO); // refuse offer

    DigitalLendingResponse createCase(CreateCaseRequestDTO createCaseRequestDTO); // create case

    DigitalLendingResponse getStatusCase(StatusCaseRequestDTO statusCaseRequestDTO); // get status case
    DigitalLendingResponse getStatusCase(String caseNumber); // get status case

    void receiveGetOfferFromKafka(String data);
    void receiveCreateCaseFromKafka(String data);
    void sendGetOfferToKafka(String data);
    void sendCreateCaseToKafka(String data);
    void receiveMessageFromEContract(String data);
    CompleteCaseResponse completeCase(String loansProfileId, String contractNumber);
    CustomerResponseInfo customerCheckInfo(CustomerRequestDTO dto);
    String checkAccMBInfo(String dto);
    CheckAccountResponse checkMBAccount(MbAccountDTO dto);
    MBAccountQueryRes getMBAccountInfo(MBAccountQueryReq dto);
    Object searchOption(OptionDTO dto);
    MatrixResponse disbursementMatrix(BigInteger offerId);
    CheckAccountMBResponse checkAccountMB(CheckAccountMBRequest request);
    DigitalLendingResponse checkAccountDisbursement(CheckAccountDisbursementRequestDTO checkAccountDisbursementRequestDTO);

    BpmCheckDeviceResponse checkLoanDevice(BpmCheckDeviceReq req);

    void updateLoanRequest(String reasonCode, String reasonDetail, String username);
    UserLinkResponse getContractInfo(ContractDTO contract);
}
