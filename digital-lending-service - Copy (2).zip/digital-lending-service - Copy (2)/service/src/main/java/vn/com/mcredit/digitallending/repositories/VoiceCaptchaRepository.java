package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.VoiceCaptcha;

import java.util.List;

@Repository
public interface VoiceCaptchaRepository extends JpaRepository<VoiceCaptcha, String> {

    boolean existsByUsernameAndCaptcha(String username, String captcha);
    VoiceCaptcha findFirstByUsernameAndDeviceIdOrderByCreatedAtDesc(String username, String deviceId);
    VoiceCaptcha findFirstByUsername(String username);
    VoiceCaptcha findByUsernameAndCaptcha(String username, String captcha);
    int countByUsernameAndRequestId(String username, String requestId);
    int countByUsernameAndRequestIdAndState(String username, String requestId, String state);
    @Query(value = "select count(vc.requestId) from VoiceCaptcha vc where vc.username=:username and vc.requestId=:requestId and vc.state=:state and (vc.errorCode not in :errorCodes or vc.errorCode is null)")
    int countByUsernameAndRequestId(String username, String requestId, String state, List<String> errorCodes);

    VoiceCaptcha findByUsernameAndCaptchaAndStatusAndDeviceId(String username, String captcha, boolean status, String deviceId);
}
