package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MrzDTO {


    @JsonProperty("nationality")
    @NotNullorEmpty(message = "Vui lòng cung cấp quốc tịch của khách hàng")
    private String nationality;

    @SerializedName("id_number")
    @JsonProperty("id_number")
    @NotNullorEmpty(message = "Vui lòng cung cấp số CCCD")
    private String idNumber;

    @SerializedName("id_9_number")
    @JsonProperty("id_9_number")
    private String idN9Number;

    @NotNullorEmpty(message = "Vui lòng cung cấp ngày sinh")
    @JsonProperty("dob")
    private String dob;

    @NotNullorEmpty(message = "Vui lòng cung cấp giới tính")
    @JsonProperty("gender")
    private String gender;

    @NotNullorEmpty(message = "Vui lòng cung cấp Ngày hết hạn CCCD")
    @JsonProperty("expire_date")
    @SerializedName("expire_date")
    private String expireDate;

    @SerializedName("dob_checksum")
    @JsonProperty("dob_checksum")
    private boolean dobChecksum;

    @SerializedName("expire_date_checksum")
    @JsonProperty("expire_date_checksum")
    private boolean expireDateChecksum;

    @SerializedName("id12_checksum")
    @JsonProperty("id12_checksum")
    private Boolean id12Checksum;

    @JsonProperty("name")
    @NotNullorEmpty(message = "Vui lòng cung cấp tên khách hàng")
    private String name;

    @JsonProperty("id9_checksum")
    private String id9Checksum;
}
