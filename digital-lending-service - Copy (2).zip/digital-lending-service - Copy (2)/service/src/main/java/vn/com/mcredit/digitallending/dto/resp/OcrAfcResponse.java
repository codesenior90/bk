package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OcrAfcResponse {
    private boolean pass;
    private String idNumberOld;
    @JsonProperty(value = "id_number")
    private String idNumber;
    @JsonProperty(value = "home_town")
    private String homeTown;
    private String address;
    private String gender;
    private String nationality;
    @JsonProperty(value = "issued_date")
    private String issuedDate;
    private String dob;
    @JsonProperty(value = "expiry_date")
    private String expiryDate;
    private String name;
    @JsonProperty(value = "id_type")
    private String idType;
    @JsonProperty(value = "id_name")
    private String idName;
    private String addressCorrectionProb;
    private String issueDateProb;
    private String nameProb;
    private String expireDateProb;
    private String dobProb;
    private String addressProb;
    private String hometownProb;
    private String idNumberProb;
    @JsonProperty(value = "hometown_correction")
    private String hometownCorrection;
    private String hometownCorrectionProb;
    @JsonProperty(value = "addressCorrection")
    private String addressCorrection;
    private String issuePlace;
    @JsonProperty(value = "front_screen_score")
    private String frontScreenScore;
    @JsonProperty(value = "back_screen_score")
    private String backScreenScore;
    @JsonProperty(value = "front_blur_score")
    private String frontBlurScore;
    @JsonProperty(value = "back_blur_score")
    private String backBlurScore;
    private Object mrz;
}
