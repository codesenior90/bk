package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FaceSearchRequest {
    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("request_date")
    private String requestDate;

    @JsonProperty("selfie_image_vector")
    private String selfieImageVector;

    @JsonProperty("id_image_vector")
    private String idImageVector;

    @JsonProperty("name")
    private String name;

    @JsonProperty("dob")
    private String dob;

    @JsonProperty("cccd_number")
    private String cccdNumber;

    @JsonProperty("cmndo_number")
    private String cmndoNumber;
}
