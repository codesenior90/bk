package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EkycDataResponse {
    private String statusEkyc;
    private String statusCard;
    private String objectId;
    private String cardType;
    @JsonProperty("ocr")
    private OcrResponse ocr;
    @JsonProperty("ocr_raw")
    private OcrResponse ocrRaw;
    @JsonProperty("face_matching")
    private FaceMatchingResponse faceMatching;
    @JsonProperty("face_matching_3_way")
    private FaceMatch3WayResponse faceMatch3WayResponse;
    @JsonProperty("face_matching_4_way")
    private FaceMatch4WayResponse faceMatch4WayResponse;
}
