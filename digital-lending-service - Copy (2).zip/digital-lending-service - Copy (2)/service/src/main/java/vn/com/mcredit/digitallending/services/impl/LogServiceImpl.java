package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.aop.PreventDuplicateMethod;
import vn.com.mcredit.digitallending.repositories.CallApiLogRepository;
import vn.com.mcredit.digitallending.services.LogService;
import vn.com.mcredit.digitallending.utils.LogUtils;

import java.util.Calendar;
import java.util.Date;

@Service
@RequiredArgsConstructor
public class LogServiceImpl implements LogService {
    private final CallApiLogRepository callApiLogRepository;

    @Value("${custom.properties.log-storage-time}")
    private int logStorageTime;
    @Value("${custom.properties.log-storage-enable}")
    private Boolean logStorageEnable;

    @PreventDuplicateMethod
    @Override
    public void cleanup(){
        try {
            if (Boolean.TRUE.equals(logStorageEnable)) {
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DATE, logStorageTime);
                Date previousMonth = cal.getTime();
                LogUtils.info("[LogSchedule] cleanup call log api", previousMonth.toString());
                callApiLogRepository.cleanUpData(previousMonth);
            }
        } catch (Exception e){
            LogUtils.error("[LogSchedule] cleanup call log api exception", e.getMessage());
        }
    }
}
