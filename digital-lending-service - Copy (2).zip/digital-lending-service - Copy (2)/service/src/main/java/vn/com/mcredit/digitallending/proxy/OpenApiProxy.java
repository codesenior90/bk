package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.resp.BankListResponse;

import java.util.UUID;

@Component
public class OpenApiProxy extends BaseProxy {
    private static final String CLIENT_MESSAGE_ID = "clientMessageId";
    private static final String X_PARTNER_ACCCESS = "X-Partner-Access";
    private static final String X_PARTNER_SECRET = "X-Partner-Secret";

    @Value("${open-api.host}")
    private String openApiHost;
    @Value("${open-api.x-partner-access}")
    private String xPartnerAccess;
    @Value("${open-api.x-partner-secret}")
    private String xPartnerSecret;
    @Value("${open-api.api-partner-code}")
    private String partnerCode;
    protected HttpHeaders initHeaderOpenApi() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON );
        headers.set(CLIENT_MESSAGE_ID, UUID.randomUUID().toString());
        headers.set(X_PARTNER_ACCCESS, xPartnerAccess);
        headers.set(X_PARTNER_SECRET, xPartnerSecret);
        return headers;
    }
    public BankListResponse getBanks() {
        String url = String.format("%s/3p/%s/disbursement/v1/list-bank", openApiHost, partnerCode);
        return this.get(url, initHeaderOpenApi(), BankListResponse.class);
    }
}
