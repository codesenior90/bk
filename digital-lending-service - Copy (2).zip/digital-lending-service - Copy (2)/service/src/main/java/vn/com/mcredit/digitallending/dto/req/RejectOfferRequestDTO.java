package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigInteger;

@Data
public class RejectOfferRequestDTO {
    @JsonProperty("requestId")
    private String requestId;
    @JsonProperty("offerId")
    private BigInteger offerId;
    @JsonProperty("reasonCode")
    private String reasonCode;
    @JsonProperty("reasonMessage")
    private String reasonMessage;
}
