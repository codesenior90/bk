package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;
import java.math.BigInteger;

@Data
public class TelcoLocationRequest {
    @NotNullorEmpty
    private String province;
    @NotNullorEmpty
    private String district;
    @NotNullorEmpty
    private String ward;
    private BigInteger offerId;
}
