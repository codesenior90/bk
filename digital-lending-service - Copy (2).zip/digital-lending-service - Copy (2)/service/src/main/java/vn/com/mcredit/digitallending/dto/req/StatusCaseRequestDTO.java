package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatusCaseRequestDTO {
    private String data;
}
