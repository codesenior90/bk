package vn.com.mcredit.digitallending.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude()
public class PointUserProfileDTO implements Serializable {

    private Integer point;

    private Integer maxPoint;

    private Integer minPoint;

    private String rankNameCurrent;

    private String nextRankNameCurrent;

    private String type;

    private Integer totalPoint;
}
