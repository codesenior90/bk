package vn.com.mcredit.digitallending.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "face_match_raw")
public class FaceMatchRaw {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name = "id_angle")
    private Float idAngle;
    @Column(name = "detection_time")
    private Float detectionTime; // Thời gian xác định khuôn mặt trong ảnh
    @Column(name = "embedding_time")
    private Float embeddingTime; // Thời gian chuyển các đặc trưng trên khuôn mặt sang vector

    @Column(name = "s1")
    private Float s1;

    @Column(name = "selfie_angle")
    private Float selfieAngle;

    @Column(name = "error", columnDefinition = "text")
    private String error;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "response_id")
    private String responseId; // Id của response trả về

    @Column(name = "ocr_request_id")
    private String ocrRequestId;
    @Column(name = "username")
    private String username;
    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;
    @Column(name = "vec1", columnDefinition = "text")
    private String vec1;
    @Column(name = "vec2", columnDefinition = "text")
    private String vec2;
    @Column(name = "source_ekyc", length = 36)
    private String sourceEkyc;
    @Column(name = "device_id", length = 36)
    private String deviceId;
}
