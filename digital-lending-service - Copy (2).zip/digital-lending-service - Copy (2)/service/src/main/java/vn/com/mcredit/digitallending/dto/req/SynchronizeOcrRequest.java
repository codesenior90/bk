package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.Data;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SynchronizeOcrRequest {
    @JsonProperty("id_number")
    @SerializedName("id_number")
    private String idNumber;

    @SerializedName("home_town")
    @JsonProperty("hometown")
    private String hometown;

    @JsonProperty("address")
    private String address;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("nationality")
    private String nationality;

    @SerializedName("issued_date")
    @JsonProperty("issued_date")
    private String issuedDate;

    @JsonProperty("dob")
    private String dob;

    @SerializedName("expiry_date")
    @JsonProperty("expiry_date")
    private String expiryDate;

    @JsonProperty("name")
    private String name;

    @SerializedName("id_type")
    @JsonProperty("id_type")
    private String idType;

    @SerializedName("id_name")
    @JsonProperty("id_name")
    private String idName;

    @SerializedName("addressCorrectionProb")
    @JsonProperty("addressCorrectionProb")
    private String addressCorrectionProb;

    @SerializedName("issueDateProb")
    @JsonProperty("issueDateProb")
    private String issueDateProb;

    @SerializedName("nameProb")
    @JsonProperty("name_prob")
    private String nameProb;

    @SerializedName("expireDateProb")
    @JsonProperty("expireDateProb")
    private String expireDateProb;

    @SerializedName("dobProb")
    @JsonProperty("dob_prob")
    private String dobProb;

    @SerializedName("addressProb")
    @JsonProperty("addressProb")
    private String addressProb;

    @SerializedName("hometownProb")
    @JsonProperty("hometownProb")
    private String hometownProb;

    @SerializedName("idNumberProb")
    @JsonProperty("idNumberProb")
    private String idNumberProb;

    @SerializedName("hometown_correction")
    @JsonProperty("hometown_correction")
    private String hometownCorrection;

    @SerializedName("hometownCorrectionProb")
    @JsonProperty("hometownCorrectionProb")
    private String hometownCorrectionProb;

    @SerializedName("address_correction")
    @JsonProperty("address_correction")
    private String addressCorrection;

    @JsonProperty("pass")
    private Boolean pass;

    private String idNumberOld;

    @SerializedName("issuePlace")
    @JsonProperty("issue_place")
    private String issuePlace;

    @SerializedName("front_screen_score")
    @JsonProperty("front_screen_score")
    private String frontScreenScore;

    @SerializedName("back_screen_score")
    @JsonProperty("back_screen_score")
    private String backScreenScore;

    @SerializedName("front_blur_score")
    @JsonProperty("front_blur_score")
    private String frontBlurScore;

    @SerializedName("back_blur_score")
    @JsonProperty("back_blur_score")
    private String backBlurScore;

    @JsonProperty("mrz")
    private MrzDTO mrz;
}
