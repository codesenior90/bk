package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.FaceMatching3Way;

@Repository
public interface FaceMatching3WayRepository extends JpaRepository<FaceMatching3Way, String> {
}
