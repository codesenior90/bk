package vn.com.mcredit.digitallending.dto;

import lombok.Data;

@Data
public class CaptchaData {
    private String captcha;
    private String requestId;
}
