package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class CodeStatus {
    private String rule;
    private String result;
}
