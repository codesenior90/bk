package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ocr")
public class Ocr {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name = "id_number")
    private String idNumber;

    @Column(name = "home_town")
    private String homeTown;

    @Column(name = "hometown_correction")
    private String hometownCorrection;

    @Column(name = "address")
    private String address;

    @Column(name = "address_correction")
    private String addressCorrection;

    @Column(name = "nationality")
    private String nationality;

    @Column(name = "issued_date")
    private String issuedDate;

    @Column(name = "dob")
    private String dob;

    @Column(name = "expiry_date")
    private String expiryDate;

    @Column(name = "name")
    private String name;

    @Column(name = "id_type")
    private String idType;

    @Column(name = "id_name")
    private String idName;

    @Column(name = "username")
    private String username;

    @Column(name = "request_id")
    private String requestId;

    @Column(name = "gender")
    private String gender;

    @Column(name = "pass")
    private Boolean pass;

    @Column(name = "status")
    private Boolean status;

    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name = "error", columnDefinition = "text")
    private String error;

    @Column(name = "result", columnDefinition = "text")
    private String result;

    @Column(name = "ticket_status")
    private String ticketStatus; // True đã sử dụng, False chưa sử dụng

    @Column(name = "back_image_url")
    private String backImageURL;

    @Column(name = "front_image_url")
    private String frontImageURL;

    @Column(name = "back_image")
    private String backImage;

    @Column(name = "front_image")
    private String frontImage;

    @Column(name = "process_ekyc")
    private Integer processEkyc;

    @Column(name = "front_screen_detection_score")
    private Float frontScreenDetectionScore;

    @Column(name = "back_screen_detection_score")
    private Float backScreenDetectionScore;

    @Column(name = "partner_code", length = 25)
    private String partnerCode; // Dùng để trace khách hàng ekyc từ đâu (Mini-app, web, app mcredit ...)

    @Column(name = "source_ekyc", length = 36)
    private String sourceEkyc;

    @Column(name = "device_id", length = 36)
    private String deviceId;
    @Column(name = "error_message", columnDefinition = "text")
    private String errorMessage;
}
