package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AddVectorResponse {
    @JsonProperty("request_id")
    private String requestId;
    @JsonProperty("response_id")
    private String responseId;
    @JsonProperty("result")
    private AddVectorResult result;

    @JsonProperty("message")
    private String message;
    @JsonProperty("success")
    private boolean success;
}
