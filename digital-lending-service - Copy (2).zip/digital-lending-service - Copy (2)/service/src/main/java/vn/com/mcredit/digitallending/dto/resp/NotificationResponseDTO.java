package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationResponseDTO {
    @JsonProperty("topic")
    private String topic;
    @JsonProperty("contentType")
    private String contentType;
    @JsonProperty("caseNumber")
    private String caseNumber;
    @JsonProperty("requestId")
    private String requestId;
    @JsonProperty("contractNumber")
    private String contractNumber;
    @JsonProperty("status")
    private String status;
    @JsonProperty("sourceCreate")
    private String sourceCreate;
    @JsonProperty("system")
    private String system;
    @JsonProperty("reasonLogDTOS")
    private String reasonLogDTOS;
    @JsonProperty("message")
    private NotificationResponseDetailDTO message;
    @JsonProperty("process")
    private String process;
    @JsonProperty("data")
    private Object data;
}
