package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.NotificationEContract;
@Repository
public interface NotificationEContractRepository extends JpaRepository<NotificationEContract, String> {
}
