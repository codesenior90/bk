package vn.com.mcredit.digitallending.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.MatchingData;
import vn.com.mcredit.digitallending.dto.UserData;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.req.ekyc.*;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.ekyc.*;
import vn.com.mcredit.digitallending.entity.*;
import vn.com.mcredit.digitallending.enums.*;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;

import vn.com.mcredit.digitallending.proxy.AfcProxy;
import vn.com.mcredit.digitallending.repositories.*;
import vn.com.mcredit.digitallending.security.Aes;
import vn.com.mcredit.digitallending.services.*;
import vn.com.mcredit.digitallending.utils.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicReference;


@Service
@RequiredArgsConstructor
public class EKycServiceImpl implements EKycService {

    public static final String ACCURACY_FAIL_MESS = "Accuracy Fail ";
    private final OcrService ocrService;
    private final RecognitionService recognitionService;
    private final FraudCheckService fraudCheckService;
    private final AfcService afcService;
    private final OcrRepository ocrRepository;
    private final EkycModelService ekycModelService;
    private final IdInternalCheckRepository idInternalCheckRepository;
    private final ImageSearchService imageSearchService;
    private final AwsS3Service awsS3Service;
    private final UserProfileProxy userProfileProxy;
    private final EkycModelRepository ekycModelRepository;
    private final VoiceCaptchaService voiceCaptchaService;
    private final ObjectMapper objectMapper;
    @Qualifier("synchronizeThreadPoolTaskExecutor")
    @Autowired
    private TaskExecutor taskExecutor;
    private static final int ID_NUMBER_OLD = 1;
    private static final int ID_NUMBER = 0;
    private static final int ADDRESS_POSITION_IN_QRCODE = 5;

    private final BpmService bpmService;
    private final ModelMapper modelMapper;
    private final UserDeviceRepo userDeviceRepo;
    private final AfcProxy afcProxy;
    private final NFCUserDataRepository nfcUserDataRepository;
    private final FaceMatchRawRepository faceMatchRawRepository;

    @Value("${custom.properties.rate-face-match-raw}")
    private Float rateFaceMatchRaw;
    @Value("${custom.properties.rate-face-match-3way}")
    private Float rateFaceMatch3Way;
    @Value("${custom.properties.fraud-check-rules}")
    private String fraudCheckRules;
    @Value("${custom.properties.aws-s3-folder-task-name}")
    private String folderTaskName;

    @Value("${nfc.accuracy}")
    private Integer nfcAccuracy;
    @Override
    public Object checkIdInternal(MultipartFile qrcodeImg, String qrcode, String requestId) {
        return this.processCheckIdInternal(qrcodeImg, qrcode, requestId, null, SourceEKYC.OTHER.getValue());
    }

    private DigitalLendingResponse processCheckIdInternal(MultipartFile qrcodeImg, String qrcode, String requestId, RawUserDataReq rawUserDataReq, String sourceEkyc) {
        LogUtils.info("[EKycService] checkIdInternal requestId", requestId);
        LogUtils.info("[EKycService] checkIdInternal qrcode");
        this.validateInfoQrcode(qrcode);
        Ocr ocr = this.getOcrByRequestId(requestId, TicketState.OPEN.getValue());
        this.updateTicketStatus(ocr, TicketState.PENDING.getValue());
        this.matchDataOcrWithRawUserData(rawUserDataReq, ocr);
        this.verifyOcr(ocr, null, 1, sourceEkyc);
        String idNumberOld = Utils.getInfoFromQrCode(qrcode, ID_NUMBER_OLD);
        if(ocr.getProcessEkyc() != null && !ProcessTypeEnum.NONE_EKYC.getValue().equals(ocr.getProcessEkyc())) {
            EkycDetailResponse ekycDetailResponse =  afcService.getEkycDetail(JWTUtils.getUsername());
            LogUtils.info("[EKycService] checkIdInternal ekycDetailResponse success");
            if(StringUtils.isNullOrEmpty(idNumberOld)) {
                idNumberOld = getIdNumberOldFromAfc(ekycDetailResponse, idNumberOld);
            }
            this.matchOcrData(ocr,ekycDetailResponse, qrcode);
        }
        return this.checkIdInternalProcess(qrcodeImg, qrcode, requestId, rawUserDataReq, ocr, idNumberOld, sourceEkyc);
    }

    private DigitalLendingResponse checkIdInternalProcess(MultipartFile qrcodeImg, String qrcode, String requestId, RawUserDataReq rawUserDataReq, Ocr ocr, String idNumberOld, String sourceEkyc) {
        String username = JWTUtils.getUsername();
        DigitalLendingResponse digitalLendingResponse;
        LogUtils.info("[EKycService] checkIdInternal", idNumberOld);
        if (StringUtils.isNotBlank(idNumberOld)) {
            ApplicationException exception = afcService.verifyIdentifyNumber(idNumberOld);
            if (exception != null) {
                this.upsertErrorStepEkyc(ocr, 2, exception.getCode(), exception.getMessage(), sourceEkyc);
                throw exception;
            }
        }

        Map<String, Object> map = new HashMap<>();
        List<CompletableFuture<Void>> completableFutures = new ArrayList<>();
        // Check dup mc
        CheckFraudC3AppRequestDTO checkFraudC3AppRequestDTO = bpmService.buildCheckDupMcRequest(ocr, idNumberOld);
        CompletableFuture<Void> checkDupMcFuture = CompletableFuture.runAsync(() -> bpmService.callCheckDupMC(ocr, checkFraudC3AppRequestDTO, map));
        completableFutures.add(checkDupMcFuture);
        // Upload qrcode
        AtomicReference<String> urlQrcodeAtomic = new AtomicReference<>("");
        if(qrcodeImg != null) {
            CompletableFuture<Void> uploadQrFuture = CompletableFuture.runAsync(() -> urlQrcodeAtomic.set(this.uploadQrcode(qrcodeImg, ocr.getIdNumber(), username)));
            completableFutures.add(uploadQrFuture);
        }
        // doc validate
        DocValidateDTO docValidateDTO = fraudCheckService.buildDocValidateRequest(ocr, qrcode, rawUserDataReq);
        CompletableFuture<Void> checkInternalIdResponseFuture = CompletableFuture.runAsync(() -> fraudCheckService.callValidateDoc(docValidateDTO, map));
        completableFutures.add(checkInternalIdResponseFuture);
        // combine
        CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(completableFutures.toArray(new CompletableFuture[0]));
        try {
            combinedFuture.get();
            LogUtils.info("[EKycService] checkIdInternal map");
            // Nguồn thông tin qrcode
            String sourceRawData = rawUserDataReq == null ? CheckIdInternalType.SCAN_QRCODE.name() : CheckIdInternalType.NFC.name();

            // save database for check id internal
            IdInternalCheck idInternalCheck = this.buildCheckIdInternalDataSave(checkFraudC3AppRequestDTO, docValidateDTO, requestId, map,  urlQrcodeAtomic.get(), username, qrcode);
            idInternalCheck.setSourceRawData(sourceRawData);
            idInternalCheck.setSourceEkyc(sourceEkyc);
            idInternalCheck.setDeviceId(JWTUtils.getDeviceId());
            idInternalCheck =  idInternalCheckRepository.save(idInternalCheck);
            // Lưu thông tin user lấy từ NFC nếu có
            this.saveNFCUserData(rawUserDataReq, idInternalCheck, username);

            digitalLendingResponse = this.verifyCheckIdInternalResult(map);

            CheckIdInternalResponse data = this.buildCheckIdInternalResponseData(requestId, rawUserDataReq, ocr, idNumberOld);
            digitalLendingResponse.setData(data);
        } catch (InterruptedException | ExecutionException e) {
            LogUtils.info("[EKycService] checkIdInternal InterruptedException|ExecutionException  ", e.getMessage());
            Thread.currentThread().interrupt();
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, e.getMessage());
        }
        return digitalLendingResponse;
    }

    private DigitalLendingResponse verifyCheckIdInternalResult(Map<String, Object> map) {
        DigitalLendingResponse digitalLendingResponse;
        digitalLendingResponse = (DigitalLendingResponse) map.get(Constants.CHECK_DUP_RESPONSE);

        if(!Constants.SUCCESS_CODE.equalsIgnoreCase(digitalLendingResponse.getCode())){
            throw new ApplicationException(digitalLendingResponse.getCode(), digitalLendingResponse.getMessage());
        }
        digitalLendingResponse = (DigitalLendingResponse) map.get(Constants.DOC_VALIDATE_RESPONSE);
        if(!Constants.SUCCESS_CODE.equalsIgnoreCase(digitalLendingResponse.getCode())){
            throw new ApplicationException(digitalLendingResponse.getCode(), digitalLendingResponse.getMessage());
        }
        return digitalLendingResponse;
    }

    private CheckIdInternalResponse buildCheckIdInternalResponseData(String requestId, RawUserDataReq rawUserDataReq, Ocr ocr, String idNumberOld) {
        CheckIdInternalResponse data = new CheckIdInternalResponse();
        data.setRequestId(requestId);
        CheckIdInternalUserData userData;
        if(rawUserDataReq != null) {
            userData =  modelMapper.map(rawUserDataReq.getUserData(), CheckIdInternalUserData.class);
        } else {
            userData = new CheckIdInternalUserData();
            userData.setGender(ocr.getGender());
            userData.setIdNumber(ocr.getIdNumber());
            userData.setIdNumberOld(idNumberOld);
            userData.setName(ocr.getName());
            userData.setAddress(ocr.getAddress());
            userData.setNationality(ocr.getNationality());
            userData.setHomeTown(ocr.getHomeTown());
            userData.setIssuedDate(ocr.getIssuedDate());
            userData.setDob(ocr.getDob());
            userData.setExpiryDate(ocr.getExpiryDate());
        }
        data.setUser(userData);
        return data;
    }
    private void validateInfoQrcode(String qrcode){
        String idNumber = Utils.getInfoFromQrCode(qrcode, ID_NUMBER);
        String address = Utils.getInfoFromQrCode(qrcode, ADDRESS_POSITION_IN_QRCODE);
        // Kiểm tra số căn cước 12 số
        if(!Utils.isCccd(idNumber)){
            LogUtils.error("[EKycService] checkIdInternal id number invalid");
            throw new ApplicationException(Error.ID_NUMBER_INVALID_FORMAT.getCode(), Error.ID_NUMBER_INVALID_FORMAT.getMessage());
        }
        if (StringUtils.isBlank(address)){
            LogUtils.error("[EKycService] checkIdInternal address invalid");
            throw new ApplicationException(Error.CHECK_ID_INTERNAL_NOT_INCORRECT.getCode(), Error.CHECK_ID_INTERNAL_NOT_INCORRECT.getMessage());
        }
    }
    private void matchDataOcrWithRawUserData(RawUserDataReq rawUserDataReq, Ocr ocr) {
        if(rawUserDataReq != null && (ocr == null || !ocr.getIdNumber().equalsIgnoreCase(rawUserDataReq.getUserData().getIdNumber()))) {
            throw new ApplicationException(Error.ID_NUMBER_DO_NOT_MATCH_NFC.getCode(), Error.ID_NUMBER_DO_NOT_MATCH_NFC.getMessage());
        }
    }


    @Override
    public Object checkIdInternalNFC(String data) {
        try {
            String json = Aes.decrypt(data);
            RawUserDataReq req = objectMapper.readValue(json, RawUserDataReq.class);
            LogUtils.info("[EKycService] checkIdInternalNFC RawUserDataReq");
            ApplicationException exception = this.validateRawUserDataRequest(req);
            if (exception != null){
                // - lưu thông tin lỗi khi validate
                LogUtils.info("[EKycService] checkIdInternalNFC exception");
                this.saveIdInternalNFCException(req, exception);
                throw exception;
            }
            String qrcode = this.generateQRCode(req.getUserData());
            LogUtils.info("[EKycService] checkIdInternalNFC RawUserDataReq : qrcode");
            return processCheckIdInternal(null, qrcode , req.getRequestId(), req, SourceEKYC.EKYC_CENTRALIZATION.getValue());
        } catch (JsonProcessingException e) {
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.APP_EXCEPTION_MESSAGE);
        }
    }

    private void saveIdInternalNFCException(RawUserDataReq req, ApplicationException exception) {
        try {
            LogUtils.info("[EKycService] saveIdInternalNFCException ", exception.getMessage());
            String username = JWTUtils.getUsername();
            IdInternalCheck idInternalCheck = new IdInternalCheck();
            idInternalCheck.setRequestId(req.getRequestId());
            idInternalCheck.setUsername(username);
            idInternalCheck.setStatus(false);
            idInternalCheck.setSourceRawData(CheckIdInternalType.NFC.name());
            idInternalCheck.setErrorCode(exception.getCode());
            idInternalCheck.setErrorMessage(exception.getMessage());
            idInternalCheck.setCreatedAt(new Date());
            idInternalCheck.setUpdatedAt(new Date());
            idInternalCheck.setDeviceId(JWTUtils.getDeviceId());
            idInternalCheck = idInternalCheckRepository.save(idInternalCheck);
            this.saveNFCUserData(req, idInternalCheck, username);
        } catch (Exception e){
            LogUtils.info("[EKycService] saveIdInternalNFCException error : " , e.getMessage());
        }
    }

    private void saveNFCUserData(RawUserDataReq rawUserDataReq, IdInternalCheck idInternalCheck, String username) {
        if(rawUserDataReq != null) {
            NFCUserData rawUserData = modelMapper.map(rawUserDataReq.getUserData(), NFCUserData.class);
            rawUserData.setInternalCheckId(idInternalCheck.getId());
            rawUserData.setUsername(username);
            LogUtils.info("[EKycService] saveNFCUserData RawUserData:", rawUserData);
            nfcUserDataRepository.save(rawUserData);
        }
    }

    private String generateQRCode(RawUserDataDTO rawUserDataDTO) {
        String qrCode = "%s|%s|%s|%s|%s|%s|%s";
        String idNumberOld = StringUtils.isNotBlank(rawUserDataDTO.getIdNumberOld()) ? rawUserDataDTO.getIdNumberOld() : Constants.EMPTY;
        String dob = rawUserDataDTO.getDob().replace("/", "");
        String issuedDate = rawUserDataDTO.getIssuedDate().replace("/", "");
        return String.format(qrCode, rawUserDataDTO.getIdNumber(), idNumberOld, rawUserDataDTO.getName(), dob, rawUserDataDTO.getGender(), rawUserDataDTO.getAddress(), issuedDate);
    }

    private ApplicationException validateRawUserDataRequest(RawUserDataReq rawUserDataReq) {
        RawUserDataDTO rawUserDataDTO =  rawUserDataReq.getUserData();
        if(rawUserDataDTO == null) {
            return new ApplicationException(Error.BAD_REQUEST.getCode(), Error.BAD_REQUEST.getMessage());
        }
        LogUtils.error("[EKycService] validateRawUserDataRequest idNumber", rawUserDataDTO.getIdNumber());
        // Kiểm tra số căn cước 12 số
        if(!Utils.isCccd(rawUserDataDTO.getIdNumber())){
            return new ApplicationException(Error.ID_NUMBER_INVALID_FORMAT.getCode(), Error.ID_NUMBER_INVALID_FORMAT.getMessage());
        }
        // Kiểm tra số chứng minh thư 9 số
        if(rawUserDataDTO.getIdNumberOld() != null && !Utils.isCmnd(rawUserDataDTO.getIdNumberOld())){
            return new ApplicationException(Error.ID_NUMBER_INVALID_FORMAT.getCode(), Error.ID_NUMBER_INVALID_FORMAT.getMessage());
        }
        ApplicationException exception = this.validateDateFormat(rawUserDataDTO);
        if(exception != null){
            return exception;
        }
        // Kiểm tra ngày hết hạn với ngày cấp CCCD
        var resultCompare = DateUtils.compareTo(rawUserDataDTO.getExpiryDate(), rawUserDataDTO.getIssuedDate(), DateUtils.F_DDMMYYYY);
        if (resultCompare == null || resultCompare <= 0){
            return new ApplicationException(Error.EXPIRE_DATE_LESS_ISSUE_DATE.getCode(), Error.EXPIRE_DATE_LESS_ISSUE_DATE.getMessage());
        }
        // Kiểm tra giới tính Nam|Nữ
        if (!(Constants.MALE.equalsIgnoreCase(rawUserDataDTO.getGender()) || Constants.FEMALE.equalsIgnoreCase(rawUserDataDTO.getGender()))){
            return new ApplicationException(Error.GENDER_INVALID.getCode(), Error.GENDER_INVALID.getMessage());
        }
        return null;
    }

    private ApplicationException validateDateFormat(RawUserDataDTO rawUserDataDTO) {
        // Kiểm tra định dạng ngày sinh
        boolean dobValid = DateUtils.isValid(rawUserDataDTO.getDob(), DateUtils.F_DDMMYYYY);
        LogUtils.error("[EKycService] validateDateFormat dob", rawUserDataDTO.getDob());
        if(!dobValid){
            return new ApplicationException(Error.DOB_INVALID_FORMAT.getCode(), Error.DOB_INVALID_FORMAT.getMessage());
        }
        // Kiểm tra định dạng ngày cấp
        LogUtils.error("[EKycService] validateDateFormat issueDateValid", rawUserDataDTO.getIssuedDate());
        boolean issueDateValid = DateUtils.isValid(rawUserDataDTO.getIssuedDate(), DateUtils.F_DDMMYYYY);
        if (!issueDateValid){
            return new ApplicationException(Error.ISSUE_DATE_INVALID_FORMAT.getCode(), Error.ISSUE_DATE_INVALID_FORMAT.getMessage());
        }
        // Kiểm tra định dạng ngày hết hạn
        LogUtils.error("[EKycService] validateDateFormat expiryDate", rawUserDataDTO.getExpiryDate());
        boolean expiryDate = DateUtils.isValid(rawUserDataDTO.getExpiryDate(), DateUtils.F_DDMMYYYY);
        if (!expiryDate){
            return new ApplicationException(Error.EXPIRE_DATE_INVALID_FORMAT.getCode(), Error.EXPIRE_DATE_INVALID_FORMAT.getMessage());
        }
        return null;
    }

    private String getIdNumberOldFromAfc(EkycDetailResponse ekycDetailResponse, String idNumberOld) {
        try {
            OcrAfcResponse ocrAfc = objectMapper.readValue(Utils.toJson(ekycDetailResponse.getOcr()),OcrAfcResponse.class);
            LogUtils.info("[EKycService] checkIdInternal " + ocrAfc.getIdNumber());
            LogUtils.info("[EKycService] checkIdInternal " + ocrAfc.getIdNumberOld());
            if(!StringUtils.isNullOrEmpty(ocrAfc.getIdNumberOld()) && ocrAfc.getIdNumberOld().trim().length() == 9) idNumberOld = ocrAfc.getIdNumberOld();
            else idNumberOld =  ocrAfc.getIdNumber().trim().length() == 9 ? ocrAfc.getIdNumber() : Constants.EMPTY;
        } catch (JsonProcessingException e) {
            LogUtils.error("[EKycService] checkIdInternal parse OcrAfcResponse");
        }
        return idNumberOld;
    }

    /**
     * upload qrcode to s3
     *
     * @param qrcodeImg ảnh Qrcode
     * @param idNumber CCCD Gắn chíp
     * @param username
     * @return
     */
    private String uploadQrcode(MultipartFile qrcodeImg, String idNumber, String username){
        String filePath = Utils.generateFilePathOnS3(folderTaskName, username, idNumber);
        return awsS3Service.upload(qrcodeImg, filePath + Constants.PREFIX_QRCODE);
    }
    private void verifyOcr(Ocr ocr, Integer processEkyc, int step, String sourceEkyc){
        ApplicationException exception = null;
        if (ocr == null ) {
            exception = new ApplicationException(Error.OCR_NOT_READY.getCode(), Error.OCR_NOT_READY.getMessage());
        }
        if (ocr != null && !Boolean.TRUE.equals(ocr.getPass())) {
            exception = new ApplicationException(Error.INFORMATION_OCR_INCORRECT.getCode(), Error.INFORMATION_OCR_INCORRECT.getMessage());
        }
        if (processEkyc != null && ocr != null && !processEkyc.equals(ocr.getProcessEkyc())) {
            exception = new ApplicationException(Error.BAD_REQUEST.getCode(), Error.BAD_REQUEST.getMessage());
        }

        if (exception != null) {
            this.upsertErrorStepEkyc(ocr, step, exception.getCode(), exception.getMessage(), sourceEkyc);
            throw exception;
        }
    }

    /**
     *
     * @param ocr
     * @param step
     * @param errorCode
     * @param errorMessage
     * 0: OCR, 1: Check-id-internal, 2: face-matching
     */
    private void upsertErrorStepEkyc(Ocr ocr, int step, String errorCode, String errorMessage, String sourceEkyc){
        try {
            switch (step){
                case 1:
                    this.upsertCheckIdInternal(ocr, errorCode, errorMessage, sourceEkyc);
                    break;
                case 2:
                    this.upsertFaceMatching(ocr, errorCode, sourceEkyc);
                    break;
                default:
                    break;
            }
        } catch (Exception e){
            LogUtils.info("upsertErrorStepEkyc error", step);
        }
    }
    private void upsertCheckIdInternal(Ocr ocr, String errorCode, String errorMessage, String sourceEkyc){
        IdInternalCheck idInternalCheck = IdInternalCheck.builder()
                .status(false)
                .requestId(ocr!=null ? ocr.getRequestId(): UUID.randomUUID().toString())
                .errorCode(errorCode)
                .errorMessage(errorMessage)
                .username(JWTUtils.getUsername())
                .deviceId(JWTUtils.getDeviceId())
                .sourceEkyc(sourceEkyc)
                .createdAt(new Date()).updatedAt(new Date())
                .build();
        idInternalCheckRepository.save(idInternalCheck);
    }
    private void upsertFaceMatching(Ocr ocr, String errorCode, String sourceEkyc){
        FaceMatchRaw faceMatchRaw = new FaceMatchRaw();
        faceMatchRaw.setStatus(false);
        faceMatchRaw.setOcrRequestId(ocr.getRequestId());
        faceMatchRaw.setError(errorCode);
        faceMatchRaw.setUsername(ocr.getUsername());
        faceMatchRaw.setDeviceId(ocr.getDeviceId());
        faceMatchRaw.setSourceEkyc(sourceEkyc);
        faceMatchRaw.setCreatedAt(new Date());
        faceMatchRaw.setUpdatedAt(new Date());
        faceMatchRawRepository.save(faceMatchRaw);
    }
    /**
     * Verify information before call api check-dup-mc and doc-validte
     * @param idInternalCheck
     */
    private void verifyCheckIdInternal(IdInternalCheck idInternalCheck, Ocr ocr){
        ApplicationException exception = null;
        if (idInternalCheck == null) {
            exception = new ApplicationException(Error.CHECK_ID_INTERNAL_NOT_READY.getCode(), Error.CHECK_ID_INTERNAL_NOT_READY.getMessage());
        }
        if (idInternalCheck != null && Boolean.FALSE.equals(idInternalCheck.getStatus())){
            exception = new ApplicationException(Error.CHECK_ID_INTERNAL_NOT_INCORRECT.getCode(), Error.CHECK_ID_INTERNAL_NOT_INCORRECT.getMessage());
        }
        if (exception != null) {
            this.upsertFaceMatching(ocr, exception.getCode(), ocr.getSourceEkyc());
            throw exception;
        }
    }

    /**
     * storage information request/response check dup mc and doc validate to database
     * @param checkFraudC3AppRequestDTO
     * @param docValidateDTO
     * @param requestId
     * @param map
     * @param s3QrcodeUrl
     * @param username
     * @param qr
     */
    private IdInternalCheck buildCheckIdInternalDataSave(CheckFraudC3AppRequestDTO checkFraudC3AppRequestDTO, DocValidateDTO docValidateDTO, String requestId, Map<String, Object> map, String s3QrcodeUrl, String username, String qr){
        try {
            IdInternalCheck idInternalCheck = new IdInternalCheck();
            idInternalCheck.setRequestId(requestId);
            idInternalCheck.setQrcodeUrl(s3QrcodeUrl);
            if (!StringUtils.isNullOrEmpty(checkFraudC3AppRequestDTO.getNumberExtraId())) {
                idInternalCheck.setIdNumberOld(checkFraudC3AppRequestDTO.getNumberExtraId());
            }
            idInternalCheck.setUsername(username);
            idInternalCheck.setQr(qr);
            idInternalCheck.setCheckDupMcRequest(Utils.toJson(checkFraudC3AppRequestDTO));
            idInternalCheck.setDocValidateRequest(Utils.toJson(docValidateDTO));
            DigitalLendingResponse digitalLendingResponse = (DigitalLendingResponse) map.get(Constants.CHECK_DUP_RESPONSE);
            boolean checkDupMcStatus = false;
            boolean docValidateStatus = false;
            if(Constants.SUCCESS_CODE.equalsIgnoreCase(digitalLendingResponse.getCode())){
                CheckDupMcResponse checkDupMcResponse = (CheckDupMcResponse)digitalLendingResponse.getData();
                checkDupMcStatus = true;
                idInternalCheck.setCheckDupMcStatus(true);
                idInternalCheck.setCheckDupMcResult(Utils.toJson(checkDupMcResponse));
            } else {
                idInternalCheck.setCheckDupMcResult(Utils.toJson(digitalLendingResponse.getData()));
            }
            digitalLendingResponse = (DigitalLendingResponse) map.get(Constants.DOC_VALIDATE_RESPONSE);

            if(Constants.SUCCESS_CODE.equalsIgnoreCase(digitalLendingResponse.getCode()) || Error.FAIL_ID_LOGIC.getCode().equals(digitalLendingResponse.getCode())){

                DocValidateResponse docValidateResponse = (DocValidateResponse) digitalLendingResponse.getData();
                docValidateStatus = docValidateResponse.isSuccess();
                idInternalCheck.setDocValidateStatus(docValidateStatus);
                idInternalCheck.setDocValidateResult(Utils.toJson(docValidateResponse));
            } else {
                idInternalCheck.setDocValidateResult(digitalLendingResponse.getMessage());
            }

            idInternalCheck.setStatus(checkDupMcStatus && docValidateStatus);
            idInternalCheck.setCreatedAt(new Date());
            idInternalCheck.setUpdatedAt(new Date());
            return idInternalCheck;
        }catch (Exception e){
            LogUtils.error("[EKycServiceImpl] buildCheckIdInternalDataSave ex:" , e.getMessage());
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.APP_EXCEPTION_MESSAGE);
        }
    }
    /**
     * Cập nhật trạng thái của ocr sau khi sử dung (OPEN, PENDING, CLOSE).
     * @param ocr
     * @param ticketStatus
     */
    private void updateTicketStatus(Ocr ocr, String ticketStatus){
        ocr.setTicketStatus(ticketStatus);
        ocrRepository.save(ocr);
    }
    private Ocr getOcrByRequestId(String requestId, String ticketStatus){
        return ocrRepository.findOcrByRequestIdAndUsernameAndTicketStatus(requestId, JWTUtils.getUsername(), ticketStatus);
    }

    /**
     * Download file from S3
     * @param fileUrl
     * @return
     */
    public MultipartFile getFileFromS3(String fileUrl){
        LogUtils.info("[EKycServiceImpl] getFileFromS3 fileUrl", fileUrl);
        return awsS3Service.dowload2S3bucketWithName(Utils.getFileUrlKeyS3(fileUrl), UUID.randomUUID() + ".jpg");
    }
    @Override
    public Object ocr(OcrForm ocrForm) {
        LogUtils.info("[EKycService] ocr processEkyc", ocrForm.getProcessEkyc());
        if(ProcessTypeEnum.IDENTIFIED_DL_EKYC.getValue().equals(ocrForm.getProcessEkyc())) {
            throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.BAD_REQUEST.getMessage());
        }
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        OcrResponse ocrResponse = ocrService.ocr(ocrForm);
        if(ocrForm.getProcessEkyc() == null || ProcessTypeEnum.NONE_EKYC.getValue().equals(ocrForm.getProcessEkyc())) {
            this.checkCCCD(ocrResponse);
        }
        digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
        digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
        digitalLendingResponse.setData(ocrResponse);
        return digitalLendingResponse;
    }
    public void checkCCCD(OcrResponse ocrResponse){
        if (ocrResponse.getResult() != null){
            String idNumber = ocrResponse.getResult().getIdNumber();
            afcService.verifyIdentifyNumber(idNumber);
        }
    }

    /**
     * Kiểm tra người dùng đã được ekyc chưa (bao gồm AFC và DL), nếu đã ekyc rồi dừng luồng
     * @param username
     */
    public void verifyIsEkyc(String username){
        Optional<UserProfile> userProfile = userProfileProxy.findByUsername(username);
        if (userProfile.isPresent() && Boolean.TRUE.equals(userProfile.get().getIsEkyc())) {
            throw new ApplicationException(
                    Error.PHONE_EKYC_IDENTIFIED_AT_OTHER_SYSTEM.getCode(),
                    Error.PHONE_EKYC_IDENTIFIED_AT_OTHER_SYSTEM.getMessage());
        }
    }
    /**
     * Kiểm tra CCCD đã được định danh trên hệ thống. (Note: cần bổ sung thêm check identify afc)
     * @param idNumber
     * @return
     */
    public EkycModel getEkycModelByIdNumber(String idNumber){
        return ekycModelRepository.findByIdNumber(idNumber);
    }
    @Override
    public Object faceMatching(FaceMatchingDTO faceMatchingDTO) {
        String deviceId = JWTUtils.getDeviceId();
        LogUtils.info("[EKycService] faceMatching faceMatchingDTO.requestId", faceMatchingDTO.getRequestId());
        LogUtils.info("[EKycService] faceMatching faceMatchingDTO.email", faceMatchingDTO.getEmail());
        LogUtils.info("[EKycService] faceMatching processEkyc", faceMatchingDTO.getProcessEkyc());
        LogUtils.info("[EKycService] faceMatching", deviceId);
        LogUtils.info("[EKycService] faceMatching captcha", faceMatchingDTO.getCaptcha());
        String username = JWTUtils.getUsername();
        // Kiểm tra dữ liệu đầu vào khi face-matching
        this.validateInputFaceMatching(faceMatchingDTO);
        Ocr ocr = this.getOcrByRequestId(faceMatchingDTO.getRequestId(), TicketState.PENDING.getValue());
        this.updateTicketStatus(ocr, TicketState.CLOSE.getValue());
        // Kiểm tra thông tin có khớp với thông tin ocr trước đó không
        this.verifyOcr(ocr, faceMatchingDTO.getProcessEkyc(), 2, SourceEKYC.OTHER.getValue());
        List<CompletableFuture<Void>> completableFutures = new ArrayList<>();
        AtomicReference<Boolean> faceMatchRawWithOldIdCardAtomic = new AtomicReference<>(null);
        //Check khơp ảnh selfie với giấy tờ cũ trong trường hợp đã ekyc ở đâu afc và thiếu ảnh liveness
        if(ProcessTypeEnum.MISS_FACE3WAY.getValue().equals(faceMatchingDTO.getProcessEkyc())) {
            CompletableFuture<Void> checkMatchRawFaceWithOldIdCard = CompletableFuture.runAsync(()-> faceMatchRawWithOldIdCardAtomic.set(this.matchFaceRawWithOldIdCard(faceMatchingDTO.getSelfieImg(), username)));
            completableFutures.add(checkMatchRawFaceWithOldIdCard);
        }
        // Download ảnh liveness
        this.downloadImgLiveness(faceMatchingDTO);
        LogUtils.info("[EKycService] faceMatching =>getFrontImageURL", ocr.getFrontImageURL());
        var frontImg = this.getFileFromS3(ocr.getFrontImageURL());
        LogUtils.info("[EKycService] faceMatching =>frontImg");
        IdInternalCheck idInternalCheck = idInternalCheckRepository.findIdInternalCheckByRequestIdAndUsername(faceMatchingDTO.getRequestId(), username);
        LogUtils.info("[EKycService] faceMatching=> checkIdInternal status", idInternalCheck.getStatus());
        // Kiểm trả thông tin có khớp với thông tin check-dup-mc và check-id-logic
        this.verifyCheckIdInternal(idInternalCheck, ocr);
        // Kiểm tra ảnh selfie khớp với ảnh trong CCCD
        AtomicReference<FaceMatchRawResponse> faceMatchRawAtomic = new AtomicReference<>(null);
        CompletableFuture<Void> faceMatchRawFuture = CompletableFuture.runAsync(() ->
                faceMatchRawAtomic.set(imageSearchService.faceMatchRaw(ocr, frontImg, faceMatchingDTO, username))
        );
        completableFutures.add(faceMatchRawFuture);
        // Kiểm tra trùng khớp giữa 3 ảnh trái, phải, selfie.
        AtomicReference<FaceMatch3WayResponse> faceMatch3WayAtomic = new AtomicReference<>(null);
        CompletableFuture<Void> faceMatch3WayFuture = CompletableFuture.runAsync(() ->
                faceMatch3WayAtomic.set(imageSearchService.faceMatch3Way(faceMatchingDTO, ocr.getRequestId(), username, ocr.getIdNumber(), faceMatchingDTO.getProcessEkyc()))
        );

        completableFutures.add(faceMatch3WayFuture);
        CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(completableFutures.toArray(new CompletableFuture[0]));
        try {
            combinedFuture.get();
        } catch (InterruptedException | ExecutionException e) {
            LogUtils.info("[EKycService] faceMatching InterruptedException|ExecutionException  ", e.getMessage());
            Thread.currentThread().interrupt();
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }

        FaceMatch3WayResponse faceMatch3WayResponse = faceMatch3WayAtomic.get();
        FaceMatchRawResponse faceMatchRawResponse = faceMatchRawAtomic.get();

        if(ProcessTypeEnum.MISS_FACE3WAY.getValue().equals(faceMatchingDTO.getProcessEkyc()) && Boolean.FALSE.equals(faceMatchRawWithOldIdCardAtomic.get())) {
            LogUtils.error("[EKycService] faceMatching error face with old id card");
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }
        // Kiểm tra khớp ảnh
        this.verifyMatchingImage(faceMatch3WayResponse, faceMatchRawResponse);
        Map<String, Object> map = new HashMap<>();
        String cccdNumber = ocr.getIdNumber();
        String cmndoNumber = idInternalCheck.getIdNumberOld();
        completableFutures = new ArrayList<>();
        // Kiểm tra blacklist
        AtomicReference<BlacklistCheckResponse> blacklistCheckResponse = new AtomicReference<>(null);
        CompletableFuture<Void> checkBlacklistFuture = CompletableFuture.runAsync(() ->
            blacklistCheckResponse.set(imageSearchService.checkBlacklist(ocr, faceMatchRawResponse.getVec1(), faceMatchRawResponse.getVec2(), cccdNumber, cmndoNumber, map, username))
        );
        completableFutures.add(checkBlacklistFuture);
        // kiểm tra 1 mặt nhiều Id (1 user dùng nhiều cccd)
        AtomicReference<FaceIdsCheckResponse> faceIdsCheckResponse = new AtomicReference<>(null);
        CompletableFuture<Void> checkFaceIdsFuture = CompletableFuture.runAsync(() ->
            faceIdsCheckResponse.set(imageSearchService.checkFaceIds(ocr, faceMatchRawResponse.getVec1(), faceMatchRawResponse.getVec2(), cccdNumber, cmndoNumber, map, username))
        );
        completableFutures.add(checkFaceIdsFuture);
        // kiểm tra 1 id (cccd) sử dụng cho nhiều mặt
        AtomicReference<IdFacesCheckResponse> facesCheckResponse =  new AtomicReference<>(null);
        CompletableFuture<Void> checkIdsFaceFuture = CompletableFuture.runAsync(() ->
            facesCheckResponse.set(imageSearchService.checkIdsFace(ocr, faceMatchRawResponse.getVec1(), faceMatchRawResponse.getVec2(), cccdNumber, cmndoNumber, map, username))
        );
        completableFutures.add(checkIdsFaceFuture);
        combinedFuture = CompletableFuture.allOf(completableFutures.toArray(new CompletableFuture[0]));
        try {
            combinedFuture.get();
        } catch (InterruptedException | ExecutionException e) {
            LogUtils.info("[EKycService] faceMatching InterruptedException|ExecutionException 2 ", e.getMessage());
            Thread.currentThread().interrupt();
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }
        LogUtils.info("[EKycService] faceMatching map");
        DigitalLendingResponse digitalLendingResponse;

        digitalLendingResponse = (DigitalLendingResponse) map.get(Constants.CHECK_BLACKLIST_RESPONSE);
        if (!Constants.SUCCESS_CODE.equals(digitalLendingResponse.getCode())){
            LogUtils.info("[EKycService] faceMatching blacklistCheckResponse  ", digitalLendingResponse);
            throw new ApplicationException(digitalLendingResponse.getCode(), digitalLendingResponse.getMessage());
        }

        digitalLendingResponse = (DigitalLendingResponse) map.get(Constants.CHECK_IDS_FACE_RESPONSE);
        if (!Constants.SUCCESS_CODE.equals(digitalLendingResponse.getCode())){
            LogUtils.info("[EKycService] faceMatching faceIdsCheckResponse  ", digitalLendingResponse);
            throw new ApplicationException(digitalLendingResponse.getCode(), digitalLendingResponse.getMessage());
        }

        digitalLendingResponse = (DigitalLendingResponse) map.get(Constants.CHECK_FACE_IDS_RESPONSE);
        if (!Constants.SUCCESS_CODE.equals(digitalLendingResponse.getCode())){
            LogUtils.info("[EKycService] faceMatching facesCheckResponse  ", digitalLendingResponse);
            throw new ApplicationException(digitalLendingResponse.getCode(), digitalLendingResponse.getMessage());
        }

        EkycModel ekycModel = this.initialEkycModel();
        ekycModel.setEmail(faceMatchingDTO.getEmail());
        // Set thông tin của ekyc model từ ocr
        this.setInfoEkycModelFromOcr(ekycModel, ocr);
        // Set thông tin của ekyc model từ idInternalCheck
        this.setInfoEkycModelFromIdInternal(ekycModel, idInternalCheck);
        // Set thông tin của ekyc model từ face 3 way
        this.setInfoEkycModelFromFaceMatching(ekycModel, faceMatch3WayResponse.getRightImageURL(), faceMatch3WayResponse.getLeftImageURL(), faceMatch3WayResponse.getSelfieImageURL());
        // Set thông tin của ekyc model từ face search
        this.setFaceMatchingResultForEkycModel(facesCheckResponse.get(), faceIdsCheckResponse.get(), blacklistCheckResponse.get(), ekycModel);
        this.setVoiceCaptchaEkycModel(ekycModel, faceMatchingDTO.getCaptcha());
        // lưu thông tin vào db
        ekycModel = this.saveFaceMatchingData(ekycModel);
        // cập nhật trạng thái của user_device
        this.upsertStatusUserDevice(username, deviceId, ekycModel);
        // đồng bộ dữ liệu sang AFC
        this.synchronizeEkyc(ekycModel, ocr, faceMatchRawResponse, faceMatch3WayResponse, deviceId, EkycType.EKYC, idInternalCheck);

        return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE)
                .message(Constants.SUCCESS_MESSAGE).data(ekycModel).build();

    }

    /**
     * Download ảnh selfie, left, right trong trường hợp đã ekyc ở đầu afc và đầy đủ ảnh liveness ProcessEkyc=2
     * @param faceMatchingDTO
     */
    private void downloadImgLiveness(FaceMatchingDTO faceMatchingDTO) {
        if(ProcessTypeEnum.EKYC_NOT_DL_FULL.getValue().equals(faceMatchingDTO.getProcessEkyc())) {
            CompletableFuture<MultipartFile> selfieImg = this.getUserImgFromS3Sync(faceMatchingDTO.getSelfieImgURL());
            CompletableFuture<MultipartFile> leftImg = this.getUserImgFromS3Sync(faceMatchingDTO.getLeftImgURL());
            CompletableFuture<MultipartFile> rightImg = this.getUserImgFromS3Sync(faceMatchingDTO.getRightImgURL());
            CompletableFuture.allOf(leftImg,rightImg,selfieImg);
            try {
                faceMatchingDTO.setLeftImg(leftImg.get());
                faceMatchingDTO.setRightImg(rightImg.get());
                faceMatchingDTO.setSelfieImg(selfieImg.get());
            } catch (ExecutionException | InterruptedException e) {
                LogUtils.info("[EKycService] downloadImgLiveness", e.getMessage());
                Thread.currentThread().interrupt();
                throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.APP_EXCEPTION_MESSAGE);
            }
        }
    }

    /**
     * Kiểm tra khớp giữa ảnh mặt trong cccd với ảnh selfie và kiểm tra khớp giữa các ảnh live ness với nhau
     * @param faceMatch3WayResponse
     * @param faceMatchRawResponse
     */

    private void verifyMatchingImage(FaceMatch3WayResponse faceMatch3WayResponse, FaceMatchRawResponse faceMatchRawResponse) {
        if (!this.verifyCheckFaceMatchRaw(faceMatchRawResponse)) {
            LogUtils.error("[EKycService] updateFaceMatching error faceRaw");
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }
        if (!this.verifyCheckFaceMatch3Way(faceMatch3WayResponse)) {
            LogUtils.error("[EKycService] updateFaceMatching error face3way");
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }
    }

    private void validateInputFaceMatching(FaceMatchingDTO faceMatchingDTO){
        if(ProcessTypeEnum.IDENTIFIED_DL_EKYC.getValue().equals(faceMatchingDTO.getProcessEkyc())) {
            throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.BAD_REQUEST.getMessage());
        }
        if (ProcessTypeEnum.IDENTIFIED_DL_EKYC_CHANGE_DEVICE.getValue().equals(faceMatchingDTO.getProcessEkyc())
                || !ProcessTypeEnum.checkExist(faceMatchingDTO.getProcessEkyc())){
            throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.BAD_REQUEST.getMessage());
        }
        this.validateImgFaceMatchingDTO(faceMatchingDTO);
    }

    private void validateImgFaceMatchingDTO(FaceMatchingDTO faceMatchingDTO) {
        if(!ProcessTypeEnum.EKYC_NOT_DL_FULL.getValue().equals(faceMatchingDTO.getProcessEkyc())) {
            if (faceMatchingDTO.getLeftImg() == null){
                throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.MISS_LEFT_IMG.getMessage());
            }
            if (faceMatchingDTO.getRightImg() == null){
                throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.MISS_RIGHT_IMG.getMessage());
            }
            if (faceMatchingDTO.getSelfieImg() == null){
                throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.MISS_SELFIE_IMG.getMessage());
            }
        }else {
            if (StringUtils.isBlank(faceMatchingDTO.getLeftImgURL())){
                throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.MISS_LEFT_IMG_URL.getMessage());
            }
            if (StringUtils.isBlank(faceMatchingDTO.getRightImgURL())){
                throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.MISS_RIGHT_IMG_URL.getMessage());
            }
            if (StringUtils.isBlank(faceMatchingDTO.getSelfieImgURL())){
                throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.MISS_SELFIE_IMG_URL.getMessage());
            }
        }
    }

    @Override
    public Object updateFaceMatching(UpdateFaceMatchingDTO faceMatchingDTO) {
        String username = JWTUtils.getUsername();
        String deviceId = faceMatchingDTO.getDeviceId();
        LogUtils.info("[EKycService] updateFaceMatching deviceId", deviceId);

        EkycModel ekycModel = ekycModelRepository.findByUsername(username);

        EkycDetailResponse ekycDetailResponse =  afcService.getEkycDetail(username);
        LogUtils.info("[EKycService] updateFaceMatching =>ekycDetailResponse", ekycDetailResponse);
        var frontImg = this.getFileFromS3(ekycDetailResponse.getFrontImageURL());
        LogUtils.info("[EKycService] updateFaceMatching =>frontImg", frontImg.getOriginalFilename());
        faceMatchingDTO.setFrontImg(frontImg);

        List<CompletableFuture<Void>> completableFutures = new ArrayList<>();
        // call bất đồng bộ api Kiểm tra khớp ảnh kh trong cccd với ảnh selfie
        AtomicReference<FaceMatchRawResponse> faceMatchRawAtomic = new AtomicReference<>(null);
        CompletableFuture<Void> faceMatchRawFuture = CompletableFuture.runAsync(() ->
                faceMatchRawAtomic.set(imageSearchService.faceMatchRaw(faceMatchingDTO.getFrontImg(), faceMatchingDTO.getSelfieImg(), username))
        );
        completableFutures.add(faceMatchRawFuture);
        // call bất đồng bộ api Kiểm tra khớp giữa 3 ảnh khuông mặt left, right, selfie
        AtomicReference<FaceMatch3WayResponse> faceMatch3WayAtomic = new AtomicReference<>(null);
        CompletableFuture<Void> faceMatch3WayFuture = CompletableFuture.runAsync(() ->
                faceMatch3WayAtomic.set(imageSearchService.faceMatch3Way(faceMatchingDTO, username, UUID.randomUUID().toString()))
        );
        completableFutures.add(faceMatch3WayFuture);
        CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(completableFutures.toArray(new CompletableFuture[0]));
        try {
            combinedFuture.get();
        } catch (InterruptedException | ExecutionException e) {
            LogUtils.info("[EKycService] updateFaceMatching InterruptedException|ExecutionException  ", e.getMessage());
            Thread.currentThread().interrupt();
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }

        FaceMatch3WayResponse faceMatch3WayResponse = faceMatch3WayAtomic.get();
        FaceMatchRawResponse faceMatchRawResponse = faceMatchRawAtomic.get();
        // Kiểm tra khớp
        this.verifyMatchingImage(faceMatch3WayResponse, faceMatchRawResponse);
        if(ekycModel != null) {
            // cập nhật trạng thái user-device với deviceId mới
            userDeviceRepo.updateUserDeviceStatus(username);
            if (deviceId != null) {
                UserDevice userDevice = userDeviceRepo.findLastUserDevice(username, deviceId);
                if(userDevice != null) {
                    userDevice.setSelfieImageURL(faceMatch3WayResponse.getSelfieImageURL());
                    userDevice.setLeftImageURL(faceMatch3WayResponse.getLeftImageURL());
                    userDevice.setRightImageURL(faceMatch3WayResponse.getRightImageURL());
                    userDevice.setStatus(Constants.VERIFIED);
                    userDeviceRepo.save(userDevice);
                }
            }
            // cập nhật device-id
            ekycModel.setDeviceId(deviceId);
            ekycModelRepository.save(ekycModel);
        }else {
            // Dùng cho các hệ thống khác sử dụng (ngoài Digital Lending)
            ekycModel = new EkycModel();
            ekycModel.setDeviceId(deviceId);
            ekycModel.setUsername(username);
        }

        ekycModel.setSelfieImageURL(faceMatch3WayResponse.getSelfieImageURL());
        ekycModel.setRightImageURL(faceMatch3WayResponse.getRightImageURL());
        ekycModel.setLeftImageURL(faceMatch3WayResponse.getLeftImageURL());
        ekycModel.setFrontImageURL(ekycDetailResponse.getFrontImageURL());
        ekycModel.setBackImageURL(ekycDetailResponse.getBackImageURL());
        ekycModel.setStatus(EkycStatus.VERIFIED.getValue());
        ekycModel.setSystem(faceMatchingDTO.getSystem());
        this.synchronizeEkyc(ekycModel, null, faceMatchRawResponse, faceMatch3WayResponse, deviceId, EkycType.LIVENESS, null);
        return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE)
                .message(Constants.SUCCESS_MESSAGE).status(Constants.SUCCESS_MESSAGE).build();
    }

    @Override
    public Object nfcVerify(NFCVerifyRequest request) {
        try {
            String username = JWTUtils.getUsername();
            request.setUsername(username);
            request.setSystem(Constants.DIGITAL_LENDING);
            request.setIpAddress(HttpReqRespUtils.getClientIpAddress());
            NFCVerifyResponse response = recognitionService.nfcVerify(request);
            LogUtils.info("[EkycServiceImpl] nfcVerify response", response);
            if(response != null && Boolean.TRUE.equals(response.isSuccess()) && response.getData() != null) {
                this.isExpriedResult(response);
                String filePath = Utils.generateFilePathOnS3(folderTaskName, username, response.getData().getCardNumber());
                String imgUrl = awsS3Service.upload(this.getFaceImageBase64(response.getData().getFaceImage()), filePath);
                RawUserDataReq rawUserDataReq = this.mapNFCDataToRawUserDataReq(request, imgUrl, response);
                if(response.getAccuracy() < nfcAccuracy) {
                    this.saveFailNFCData(rawUserDataReq, JWTUtils.getUsername(),Error.FAIL_FACE_IMAGE_NFC_VERIFY.getCode(), ACCURACY_FAIL_MESS + response.getAccuracy());
                    throw new ApplicationException(Error.FAIL_FACE_IMAGE_NFC_VERIFY.getCode(), Error.FAIL_FACE_IMAGE_NFC_VERIFY.getMessage());
                }
                String qrcode = this.generateQRCode(rawUserDataReq.getUserData());
                return processCheckIdInternal(null, qrcode , rawUserDataReq.getRequestId(), rawUserDataReq, SourceEKYC.OTHER.getValue());
            } else {
                throw new ApplicationException(Error.FAIL_NFC_VERIFY.getCode(), Error.FAIL_NFC_VERIFY.getMessage());
            }
        } catch (HttpStatusCodeException ex) {
            LogUtils.info("[EkycServiceImpl] nfcVerify -ex", ex.getMessage());
            String code = Utils.getCodeError(ex.getResponseBodyAsString());
            if(NfcVerifyCode.NOTVERIFRIED.getValue().equalsIgnoreCase(code) || NfcVerifyCode.UNAUTHORIZED.getValue().equalsIgnoreCase(Utils.getCodeError(code))) {
                throw new ApplicationException(code, Utils.getMessageError(ex.getResponseBodyAsString()));
            }
            throw new ApplicationException(Error.FAIL_NFC_VERIFY.getCode(), Utils.getMessageError(ex.getResponseBodyAsString()));
        }
    }

    private void saveFailNFCData(RawUserDataReq failData, String username, String errorCode, String errorMess) {
        if(failData != null) {
            NFCUserData rawUserData = modelMapper.map(failData.getUserData(), NFCUserData.class);
            rawUserData.setInternalCheckId(null);
            rawUserData.setUsername(username);
            rawUserData.setErrorCode(errorCode);
            rawUserData.setErrorMessage(errorMess);
            LogUtils.info("[EKycService] saveFailNFCData RawUserData:", rawUserData);
            nfcUserDataRepository.save(rawUserData);
        }
    }

    private String getFaceImageBase64(String image) {
        return image.replace("data:image/png;base64,", "")
                .replace("data:image/jpeg;base64,", "");
    }

    private void isExpriedResult(NFCVerifyResponse response) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime date = LocalDateTime.parse(response.getExpiredTimeResponse(), formatter);
        if(LocalDateTime.now().compareTo(date) > 0) {
            throw new ApplicationException(Error.FAIL_NFC_VERIFY.getCode(), Error.FAIL_NFC_VERIFY.getMessage());
        }
    }

    private RawUserDataReq mapNFCDataToRawUserDataReq(NFCVerifyRequest request, String imgUrl, NFCVerifyResponse nfcVerifyResponse) {
        NFCVerifyData data = nfcVerifyResponse.getData();
        RawUserDataDTO userDataDTO = new RawUserDataDTO();
        userDataDTO.setGender(data.getSex());
        userDataDTO.setIdNumber(data.getCardNumber());
        userDataDTO.setIdNumberOld(data.getPreviousNumber());
        userDataDTO.setName(data.getName());
        userDataDTO.setAddress(data.getAddress());
        userDataDTO.setNationality(data.getNationality());
        userDataDTO.setHomeTown(data.getHometown());
        userDataDTO.setIssuedDate(data.getIssueDate());
        userDataDTO.setDob(data.getDateOfBirth());
        userDataDTO.setExpiryDate(data.getExpiredDate());
        userDataDTO.setReligion(data.getReligion());
        userDataDTO.setEthnic(data.getNation());
        userDataDTO.setPersonalIdentification(data.getCharacter());
        userDataDTO.setFatherName(data.getFatherName());
        userDataDTO.setMotherName(data.getMotherName());
        userDataDTO.setFaceImageUrl(imgUrl);
        userDataDTO.setScoreAccuracy(String.valueOf(nfcVerifyResponse.getAccuracy()));

        RawUserDataReq rawUserDataReq = new RawUserDataReq();
        rawUserDataReq.setUserData(userDataDTO);
        rawUserDataReq.setRequestId(request.getRequestId());
        return rawUserDataReq;
    }

    /**
     * verify image
     * @param faceMatch3WayResponse
     * @return
     */
    private boolean verifyCheckFaceMatch3Way(FaceMatch3WayResponse faceMatch3WayResponse){
        LogUtils.info("[EkycService] verifyCheckFaceMatch3Way");
        LogUtils.info("[EkycService] verifyCheckFaceMatch3Way rateFaceMatch3Way");
        return (faceMatch3WayResponse != null
            && faceMatch3WayResponse.getS23() >= rateFaceMatch3Way
            && faceMatch3WayResponse.getS31() >= rateFaceMatch3Way
            && faceMatch3WayResponse.getS12() >= rateFaceMatch3Way
        );
    }
    private boolean verifyCheckFaceMatchRaw(FaceMatchRawResponse faceMatchRawResponse){
        LogUtils.info("[EkycService] verifyCheckFaceMatchRaw");
        return (faceMatchRawResponse != null
                && faceMatchRawResponse.getS1() >= rateFaceMatchRaw);
    }
    private EkycModel saveFaceMatchingData(EkycModel ekycModel){
        return ekycModelService.save(ekycModel);
    }
    private EkycModel initialEkycModel(){
        String username = JWTUtils.getUsername();
        EkycModel ekycModel = new EkycModel();
        ekycModel.setUsername(username);
        ekycModel.setFraudChecks(fraudCheckRules);
        ekycModel.setSystem(SourceAppType.DIGITAL_LENDING.getValue());
        ekycModel.setCardType(CardType.CCCD_CHIP.name());
        ekycModel.setIsEkyc(true);
        ekycModel.setCreatedAt(new Date());
        ekycModel.setUpdatedAt(new Date());
        ekycModel.setStatus(EkycStatus.VERIFIED.getValue());
        ekycModel.setDeviceId(JWTUtils.getDeviceId());
        return ekycModel;
    }
    private void setInfoEkycModelFromOcr(EkycModel ekycModel, Ocr ocr){
        ekycModel.setObjectId(ocr.getRequestId());
        ekycModel.setFrontImageURL(ocr.getFrontImageURL());
        ekycModel.setBackImageURL(ocr.getBackImageURL());
        ekycModel.setGender(ocr.getGender());
        ekycModel.setIdNumber(ocr.getIdNumber());
        ekycModel.setName(ocr.getName());
        ekycModel.setAddress(ocr.getAddress());
        ekycModel.setAddressCorrection(ocr.getAddressCorrection());
        ekycModel.setNationality(ocr.getNationality());
        ekycModel.setHomeTown(ocr.getHomeTown());
        ekycModel.setHometownCorrection(ocr.getHometownCorrection());
        ekycModel.setDob(ocr.getDob());
        ekycModel.setIssuedDate(ocr.getIssuedDate());
        ekycModel.setExpiryDate(ocr.getExpiryDate());
    }
    private void setInfoEkycModelFromFaceMatching(EkycModel ekycModel, String rightImageUrl, String leftImageUrl, String selfieImageUrl){
        ekycModel.setRightImageURL(rightImageUrl);
        ekycModel.setLeftImageURL(leftImageUrl);
        ekycModel.setSelfieImageURL(selfieImageUrl);
    }
    private void setInfoEkycModelFromIdInternal(EkycModel ekycModel, IdInternalCheck idInternalCheck){
        ekycModel.setIdNumberOld(idInternalCheck.getIdNumberOld());
        String address = Utils.getInfoFromQrCode(idInternalCheck.getQr(), ADDRESS_POSITION_IN_QRCODE);
        ekycModel.setAddress(address);
        ekycModel.setAddressCorrection(address);
        ekycModel.setQrCodeImageURL(idInternalCheck.getQrcodeUrl());
        ekycModel.setQrCode(idInternalCheck.getQr());
        this.setRuleC3AndRuleC4ForEkycModel(idInternalCheck, ekycModel);
    }
    private void synchronizeEkyc(EkycModel ekycModel, Ocr ocr, FaceMatchRawResponse faceMatchRawResponse, FaceMatch3WayResponse faceMatch3WayResponse, String deviceId, EkycType ekycType, IdInternalCheck idInternalCheck){
        try {
            LogUtils.info("[EkycService] synchronizeEkyc");
            taskExecutor.execute(() -> {
                SynchronizeEkycRequest body = afcService.buildSynchronizeEkycRequest(ekycModel, ocr, faceMatchRawResponse, faceMatch3WayResponse,deviceId, ekycType, idInternalCheck);
                if(EkycType.EKYC.equals(ekycType)) {
                    this.updateUserProfile(ekycModel);
                }
                afcService.synchronizeEKyc(body, ekycModel.getUsername());
            });
        } catch (Exception e){
            LogUtils.info("[EkycService] synchronizeEkyc exception", e.getMessage());
        }
    }
    private void updateUserProfile(EkycModel ekycModel){
        try {
            Optional<UserProfile> userProfileOptional = userProfileProxy.findByUsername(ekycModel.getUsername());
            if (userProfileOptional.isPresent()){
                UserProfile userProfile = userProfileOptional.get();
                userProfile.setFullName(ekycModel.getName());
                userProfile.setAddress(ekycModel.getAddress());
                userProfile.setCardType(ekycModel.getCardType());
                userProfile.setEmail(ekycModel.getEmail());
                userProfile.setCardExpiredAt(ekycModel.getExpiryDate());
                userProfile.setCif(ekycModel.getIdNumber());
                userProfile.setProvince(ekycModel.getProvince());
                userProfile.setCity(ekycModel.getCity());
                userProfile.setDistrict(ekycModel.getDistrict());
                userProfile.setCardIssuedAt(ekycModel.getIssuedDate());
                userProfile.setGender(ekycModel.getGender());
                userProfile.setDob(ekycModel.getDob());
                userProfile.setIsEkyc(true);
                userProfile.setIsMatching(true);
                userProfileProxy.save(userProfile);
            }
        } catch (Exception e){
            LogUtils.info("[EkycService] updateUserProfile exception", e.getMessage());
        }
    }
    private MatchingData buildDataCompare(Ocr ocr, OcrAfcResponse ocrAfc, String qrCode, String oldQrCode){
        // Thông user mới đọc từ ocr
        UserData data = new UserData();
        data.setDob(ocr.getDob());
        data.setName(ocr.getName());
        data.setIdNumber(ocr.getIdNumber());
        data.setQrcode(qrCode);

        // thông tin từ afc trả về
        UserData oldData = new UserData();
        oldData.setDob(ocrAfc.getDob());
        oldData.setName(ocrAfc.getName());
        oldData.setIdNumber(ocrAfc.getIdNumber());
        oldData.setQrcode(oldQrCode);

        MatchingData matchingData = new MatchingData();
        matchingData.setData(data);
        matchingData.setOldData(oldData);
        matchingData.setErrorCode(Error.FAIL_ID_COMPARE.getCode());
        return matchingData;
    }
    // So khớp thông tin KH vừa thực hiện ocr với thông tin cũ đã ekyc ở afc
    private void matchOcrData(Ocr ocr, EkycDetailResponse ekycDetailResponse, String qrCode) {
        try {
            OcrAfcResponse ocrAfc = objectMapper.readValue(Utils.toJson(ekycDetailResponse.getOcr()),OcrAfcResponse.class);
            String name = ocr.getName().trim();
            String dob = ocr.getDob().trim();
            String idNumber = ocr.getIdNumber().trim();
            String oldDob = ocrAfc.getDob().trim();
            String oldIdNumber = ocrAfc.getIdNumber().trim();
            String oldName = ocrAfc.getName().trim();
            String oldCardType = ekycDetailResponse.getCardType().trim();
            String oldQrCode = ekycDetailResponse.getQrCode();
            String cmt = null; // số chứng minh 9 số.
            if(!StringUtils.isNullOrEmpty(qrCode)) {
                cmt = Utils.getInfoFromQrCode(qrCode,ID_NUMBER_OLD).trim();
            }

            boolean check = this.compareData(name, oldName) && this.compareData(dob,oldDob); // so khớp name, ngày sinh
            if (CardType.CCCD_CHIP.name().equalsIgnoreCase(oldCardType)) {
                if(StringUtils.isNotBlank(cmt) && StringUtils.isNotBlank(oldQrCode)) { // và so khớp số chứng minh 9 số
                    String oldCmt = Utils.getInfoFromQrCode(oldQrCode.trim(), ID_NUMBER_OLD); // số chứng minh 9 số
                    check = this.combineCheck(check, oldCmt.equalsIgnoreCase(cmt));
                }
                check = this.combineCheck(check, idNumber.equalsIgnoreCase(oldIdNumber)); // và so khớp số CCCD_CHIP
            } else if(CardType.CMTND1.name().equalsIgnoreCase(oldCardType)) {
                if (!StringUtils.isNullOrEmpty(cmt)) {
                    check = this.combineCheck(check, oldIdNumber.equalsIgnoreCase(cmt)); // so khớp số chứng minh 9 số
                }
            } else if(CardType.CCCD.name().equalsIgnoreCase(oldCardType) || CardType.CMTND2.name().equalsIgnoreCase(oldCardType)) {
                check = this.combineCheck(check, idNumber.equalsIgnoreCase(oldIdNumber)); // so khớp idNumber 12 số
            }
            if (!check) {
                MatchingData matchingData = this.buildDataCompare(ocr, ocrAfc, qrCode, ekycDetailResponse.getQrCode());
                LogUtils.info("[EKycService] matchOcrData matchingData", matchingData);
                ocr.setStatus(false);
                ocr.setError(Utils.toJson(matchingData));
                ocrRepository.save(ocr);
                throw new ApplicationException(Error.FAIL_ID_COMPARE.getCode(), Error.FAIL_ID_COMPARE.getMessage());
            }
        } catch (JsonProcessingException e) {
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE,Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }
    }
    private boolean compareData(String data, String oldData){
        return data.equalsIgnoreCase(oldData);
    }
    private boolean combineCheck(boolean check1, boolean check2){
        return check1 && check2;
    }

    private CompletableFuture<MultipartFile> getUserImgFromS3Sync(String url) {
        LogUtils.info("[EKycServiceImpl] getUserImgFromS3Sync");
        return CompletableFuture.supplyAsync(() -> this.getFileFromS3(url));
    }

    private void setRuleC3AndRuleC4ForEkycModel(IdInternalCheck idInternalCheck, EkycModel ekycModel) {
        try {
            CheckDupMcResponse checkDupMcResponse =  Utils.fromJson(idInternalCheck.getCheckDupMcResult(), CheckDupMcResponse.class);
            if(checkDupMcResponse == null) {
                LogUtils.error("Data checkDupMcResponse is null");
                throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.APP_EXCEPTION_MESSAGE);
            }
            CodeStatus ruleC3 = getCodeStatusByRule(Constants.RULE_C3, checkDupMcResponse.getCodeStatuses());
            CodeStatus ruleC4 = getCodeStatusByRule(Constants.RULE_C4, checkDupMcResponse.getCodeStatuses());
            LogUtils.info("[EKycServiceImpl] getRuleC3AndRuleC4ForEkycModel ruleC3: ", ruleC3);
            LogUtils.info("[EKycServiceImpl] getRuleC3AndRuleC4ForEkycModel ruleC4: ", ruleC4);
            if(ruleC3 != null) {
                ekycModel.setInternalIdC3(ruleC3.getResult());
            }
            if(ruleC4 != null) {
                ekycModel.setOfflineIdC4(ruleC4.getResult());
            }
        } catch (Exception e) {
            LogUtils.error("Can't parse Json to CheckDupMcResponse: saveFaceMatchingData");
        }
    }

    private void setFaceMatchingResultForEkycModel(IdFacesCheckResponse facesCheckResponse, FaceIdsCheckResponse faceIdsCheckResponse, BlacklistCheckResponse blacklistCheckResponse, EkycModel ekycModel) {
        if(Boolean.TRUE.equals(facesCheckResponse.getImageSearchByIdCheckResult())) {
            if(facesCheckResponse.getImageSearchByIdCheckDetails() != null && !facesCheckResponse.getImageSearchByIdCheckDetails().isEmpty()) ekycModel.setImageSearchOneIdMultiFaceC5(Constants.YES);
            else ekycModel.setImageSearchOneIdMultiFaceC5(Constants.NA);
        }
        if(Boolean.TRUE.equals(faceIdsCheckResponse.getImageSearchByIdCheckResult())) {
            if(faceIdsCheckResponse.getImageIdInfoDetails() != null && !faceIdsCheckResponse.getImageIdInfoDetails().isEmpty()) ekycModel.setImageSearchOneFaceMultiIdC62(Constants.YES);
            else ekycModel.setImageSearchOneFaceMultiIdC62(Constants.NA);
        }
        if(Boolean.TRUE.equals(blacklistCheckResponse.isBlacklistCheckResult())) {
            if(blacklistCheckResponse.getBlacklistCheckDetails() != null && !blacklistCheckResponse.getBlacklistCheckDetails().isEmpty()) ekycModel.setBlackListCheck(Constants.YES);
            else ekycModel.setBlackListCheck(Constants.NA);
        }
    }

    private boolean matchFaceRawWithOldIdCard(MultipartFile selfieImg, String username) {
        EkycDetailResponse ekycDetailResponse = afcService.getEkycDetail(username);
        MultipartFile frontImg = this.getFileFromS3(ekycDetailResponse.getFrontImageURL());
        return this.verifyCheckFaceMatchRaw(imageSearchService.faceMatchRaw(frontImg,selfieImg,username));
    }

    private CodeStatus getCodeStatusByRule(String rule, List<CodeStatus> codeStatuses) {
        if (codeStatuses == null) return null;
        for(CodeStatus code: codeStatuses) {
            if(rule.equalsIgnoreCase(code.getRule())) return code;
        }
        return null;
    }

    private void upsertStatusUserDevice(String username, String deviceId, EkycModel ekycModel) {
        if (deviceId == null) return;
        LogUtils.info("[EKycService] updateStatusUserDevice username + deviceId", username + " + " + deviceId);
        UserDevice userDevice = userDeviceRepo.findLastUserDevice(username, deviceId);
        if(userDevice == null) {
            userDevice = new UserDevice();
            userDevice.setUsername(username);
            userDevice.setDeviceId(deviceId);
        }
        userDevice.setStatus(Constants.VERIFIED);
        userDevice.setEkycDate(new Date());
        userDevice.setLeftImageURL(ekycModel.getLeftImageURL());
        userDevice.setRightImageURL(ekycModel.getRightImageURL());
        userDevice.setSelfieImageURL(ekycModel.getSelfieImageURL());
        userDevice.setLastUpdated(new Date());
        userDeviceRepo.save(userDevice);
    }

    @Override
    public Object ocrV2(OcrForm form) {
        String partnerCode = JWTUtils.getPartnerCode();
        LogUtils.info("[EKycService] ocr partnerCode", partnerCode);
        if (!EPartnerCode.isExisted(partnerCode)){
            throw new ApplicationException(Error.ERROR_PARTNER_CODE.getCode(), Error.ERROR_PARTNER_CODE.getMessage());
        }
        LogUtils.info("[EKycService] ocr processEkyc", form.getProcessEkyc());
        if(ProcessTypeEnum.IDENTIFIED_DL_EKYC.getValue().equals(form.getProcessEkyc())) {
            throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.BAD_REQUEST.getMessage());
        }
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        OcrResponse response = recognitionService.ocr(form, JWTUtils.getUsername());
        digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
        digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
        digitalLendingResponse.setData(response);
        return digitalLendingResponse;

    }

    @Override
    public Object checkIdInternalV2(MultipartFile qrcodeImg, String qrcode, String ocrCode) {
        return this.processCheckIdInternal(qrcodeImg, qrcode, ocrCode, null, SourceEKYC.EKYC_CENTRALIZATION.getValue());
    }

    @Override
    public Object faceMatchingV2(FaceMatchingDTO dto) {
        this.validateInputFaceMatching(dto);
        String username = JWTUtils.getUsername();
        String deviceId = JWTUtils.getDeviceId();
        Ocr ocr = this.getOcrByRequestId(dto.getRequestId(), TicketState.PENDING.getValue());

        this.updateTicketStatus(ocr, TicketState.CLOSE.getValue());
        // Kiểm tra thông tin có khớp với thông tin ocr trước đó không
        this.verifyOcr(ocr, dto.getProcessEkyc(), 2, SourceEKYC.EKYC_CENTRALIZATION.getValue());
        IdInternalCheck idInternalCheck = idInternalCheckRepository.findIdInternalCheckByRequestIdAndUsername(dto.getRequestId(), username);
        LogUtils.info("[EKycService] faceMatchingV2=> checkIdInternal status", idInternalCheck.getStatus());
        // Kiểm trả thông tin có khớp với thông tin check-dup-mc và check-id-logic
        this.verifyCheckIdInternal(idInternalCheck, ocr);
        // lấy ocrCode từ recognition-service hoặc từ bảng ocr (trường request_id)
        String ocrCode = ocr.getRequestId();

        EkycResponseModel livenessRes;
        if(!ProcessTypeEnum.EKYC_NOT_DL_FULL.getValue().equals(dto.getProcessEkyc())) {
            livenessRes = recognitionService.liveness(username, ocr.getIdNumber(), ocrCode, Boolean.TRUE, dto);
        } else {
            RecoCustomerInfoResp customerInfoResp = recognitionService.checkInfo(username, CardType.CCCD_CHIP.getValue(), Constants.DIGITAL_LENDING);
            if (customerInfoResp != null && customerInfoResp.getEkycCode() != null && customerInfoResp.getOcrCode() != null) {
                livenessRes = recognitionService.livenessWithoutFace(ocrCode, true, dto.getSelfieImgURL(), dto.getLeftImgURL(), dto.getRightImgURL());
            } else {
                // Download ảnh liveness nếu KH đã ekyc cccd chip từ super app
                this.downloadImgLiveness(dto);
                livenessRes = recognitionService.liveness(username, ocr.getIdNumber(), ocrCode, Boolean.TRUE, dto);
            }
        }
        this.verifyFaceMatchingReco(livenessRes);
        FaceSearchRequest faceSearchRequest = imageSearchService.buildFaceSearchRequest(ocr.getIdNumber(),
                                                idInternalCheck.getIdNumberOld(), ocr.getName(),
                                                ocr.getDob(), livenessRes.getFrontDimension(), livenessRes.getSelfieDimension());
        // call bất đồng bộ các api blacklist, face-ids và id-faces
        Map<String, Object> map = imageSearchService.checkFaceSearch(faceSearchRequest, username, ocr.getRequestId());

        EkycModel ekycModel = this.initialEkycModel();
        ekycModel.setEmail(dto.getEmail());
        // Set thông tin của ekyc model từ ocr
        this.setInfoEkycModelFromOcr(ekycModel, ocr);
        // Set thông tin của ekyc model từ idInternalCheck
        this.setInfoEkycModelFromIdInternal(ekycModel, idInternalCheck);
        // Set thông tin của ekyc model từ face 3 way
        this.setInfoEkycModelFromFaceMatching(ekycModel, livenessRes.getRightImageUrl(), livenessRes.getLeftImageUrl(), livenessRes.getSelfieImageUrl());
        ekycModel.setEkycCode(livenessRes.getCode());
        // Set thông tin của ekyc model từ face search
        BlacklistCheckResponse blacklistCheckResponse = (BlacklistCheckResponse) map.get(Constants.CHECK_BLACKLIST_RESPONSE);
        FaceIdsCheckResponse faceIdsCheckResponse = (FaceIdsCheckResponse) map.get(Constants.CHECK_FACE_IDS_RESPONSE);
        IdFacesCheckResponse idFacesCheckResponse = (IdFacesCheckResponse) map.get(Constants.CHECK_IDS_FACE_RESPONSE);
        this.setFaceMatchingResultForEkycModel(idFacesCheckResponse, faceIdsCheckResponse, blacklistCheckResponse, ekycModel);
        // lưu thông tin vào db
        ekycModel = this.saveFaceMatchingData(ekycModel);
        // cập nhật trạng thái của user_device
        this.upsertStatusUserDevice(username, deviceId, ekycModel);
        // đồng bộ dữ liệu sang AFC
        this.synchronizeEkyc(ekycModel, ocr, livenessRes, deviceId, EkycType.EKYC, idInternalCheck);
        EkycData ekycData = modelMapper.map(ekycModel, EkycData.class);
        return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE)
                .message(Constants.SUCCESS_MESSAGE).data(ekycData).build();
    }
    private void verifyFaceMatchingReco(EkycResponseModel liveness) {
        if (liveness == null){
            LogUtils.error("[EKycService] faceMatching v2 error liveness null");
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }
        if(!Constants.ACTIVE.equalsIgnoreCase(liveness.getStatus())){
            LogUtils.error("[EKycService] faceMatching v2 error not active liveness");
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }
    }
    @Override
    public Object updateFaceMatchingV2(UpdateFaceMatchingDTO dto){
        String username = JWTUtils.getUsername();
        String deviceId = dto.getDeviceId();
        LogUtils.info("[EKycService] updateFaceMatchingV2", deviceId);

        EkycDetailResponse ekycDetailResponse = afcService.getEkycDetail(username);
        if (ekycDetailResponse == null || StringUtils.isBlank(ekycDetailResponse.getFrontImageURL())) {
            throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
        }

        LogUtils.info("[EKycService] updateFaceMatching v2 =>ekycDetailResponse user", ekycDetailResponse.getUsername());
        EkycModel ekycModel = ekycModelRepository.findByUsername(username);
        String idNumber;
        if (ekycModel == null){
            idNumber = UUID.randomUUID().toString();
            // Dùng cho các hệ thống khác sử dụng (ngoài Digital Lending)
            ekycModel = new EkycModel();
            ekycModel.setDeviceId(deviceId);
            ekycModel.setUsername(username);
        } else {
            idNumber = ekycModel.getIdNumber();
        }
        EkycResponseModel liveness = recognitionService.livenessWithoutOcr(username, idNumber, true, dto);
        // Verify so khớp
        this.verifyFaceMatchingReco(liveness);
        LogUtils.info("[EKycService] updateFaceMatchingV2 success");
        if(EkycStatus.VERIFIED.getValue().equals(ekycModel.getStatus())) {
            // cập nhật trạng thái user-device với username hiện tại có status VERIFIED thành UNVERIFIED
            userDeviceRepo.updateUserDeviceStatus(username);
            // cập nhật trạng thái user-device với username hiện tại với deviceId mới thành VERIFIED
            this.upsertStatusUserDevice(username, deviceId, ekycModel);
            // cập nhật device-id cho ekyc_model
            ekycModel.setDeviceId(deviceId);
            ekycModelRepository.save(ekycModel);
        }

        ekycModel.setSelfieImageURL(liveness.getSelfieImageUrl());
        ekycModel.setRightImageURL(liveness.getRightImageUrl());
        ekycModel.setLeftImageURL(liveness.getLeftImageUrl());
        ekycModel.setFrontImageURL(ekycDetailResponse.getFrontImageURL());
        ekycModel.setBackImageURL(ekycDetailResponse.getBackImageURL());
        ekycModel.setStatus(EkycStatus.VERIFIED.getValue());
        ekycModel.setSystem(dto.getSystem());

        // đồng bộ dữ liệu sang AFC
        this.synchronizeEkyc(ekycModel, null, liveness, deviceId, EkycType.LIVENESS, null);
        return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE)
                .message(Constants.SUCCESS_MESSAGE).status(Constants.SUCCESS_MESSAGE).build();
    }
    private void synchronizeEkyc(EkycModel ekycModel, Ocr ocr, EkycResponseModel liveness, String deviceId, EkycType ekycType, IdInternalCheck idInternalCheck){
        try {
            LogUtils.info("[EkycService] synchronizeEkyc with recognition");
            SynchronizeEkycRequest body = afcService.buildSynchronizeEkycRequest(ekycModel, ocr, liveness,deviceId, ekycType, idInternalCheck);
                if(EkycType.EKYC.equals(ekycType)) {
                    this.updateUserProfile(ekycModel);
                }
                afcService.synchronizeEKyc(body, ekycModel.getUsername());
        } catch (Exception e){
            LogUtils.info("[EkycService] synchronizeEkyc exception with recognition", e.getMessage());
        }
    }
    private void setVoiceCaptchaEkycModel(EkycModel ekycModel, String captcha){
        LogUtils.info("[EKycService] setVoiceCaptchaEkycModel ", JWTUtils.getUsername() + " - " + JWTUtils.getDeviceId() + " - " + captcha);
        if (StringUtils.isNotBlank(captcha)) {
            ekycModel.setCaptcha(captcha);
            var voiceCaptcha =
                    voiceCaptchaService.getVoiceCaptchaCheck(JWTUtils.getUsername(), captcha, true, JWTUtils.getDeviceId());
            if (voiceCaptcha != null) {
                LogUtils.info("[EKycService] setVoiceCaptchaEkycModel getVoiceCaptchaCheck");
                // cập nhật captcha và url voice captcha vào ekyc_model
                ekycModel.setVoiceCaptchaURL(voiceCaptcha.getUrl());
                // cập nhật rule c17
            }
        }
    }
}
