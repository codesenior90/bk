package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.Email;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigInteger;
import java.util.List;
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateCaseRequestDTO {
    @JsonProperty("custProfessional")
    @NotNullorEmpty(message = "Vui lòng cung cấp nghề nghiệp")
    private String custProfessional;
    @JsonProperty("tempSamePermAddress")
    @NotNullorEmpty(message = "Địa chỉ thường chú và địa chỉ sinh sống giống nhau")
    private String tempSamePermAddress;
    @JsonProperty("incomeRange")
    @NotNullorEmpty(message = "Vui lòng cung cấp khoảng thu nhập")
    private String incomeRange;
    @JsonProperty("companyName")
    @NotNullorEmpty(message = "Vui lòng cung cấp tên công ty")
    private String companyName;
    @JsonProperty("custPosition")
    private String custPosition;
    @Email
    private String email;
    @JsonProperty("maritalStatus")
    @NotNullorEmpty(message = "Vui lòng cung cấp trạng thái hôn nhân")
    private String maritalStatus;
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("accountName")
    private String accountName;
    @JsonProperty("disbursementType")
    private String disbursementType;
    @JsonProperty("payPartnerCode")
    private String payPartnerCode;
    @JsonProperty("offerId")
    private BigInteger offerId;
    @JsonProperty("requestId")
    private String requestId;
    @JsonProperty("customerRelativesRequests")
    @NotNull
    private List<CustomerRelativesRequest> customerRelativesRequests;
    @JsonProperty("customerAddressRequests")
    @NotNull
    private List<CustomerAddressRequest> customerAddressRequests;
    @Size(max = 36, message = "Telco Location Tối đa 36 ký tự")
    private String locationTelcoRequestId;
    private Double latitude;
    private Double longitude;

    private String bank;
    private String smlCode;
    private String disbursementModel;
    private String bankCode;
    private String bankName;

    private String companyPhone;
    private String companyAddress;
}
