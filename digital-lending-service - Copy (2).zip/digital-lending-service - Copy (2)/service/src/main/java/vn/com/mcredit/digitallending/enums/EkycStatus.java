package vn.com.mcredit.digitallending.enums;

public enum EkycStatus {
    VERIFIED("VERIFIED"),
    LIVENESS_VERIFIED("LIVENESS_VERIFIED"),;

    private String value;

    EkycStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
