package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.mcredit.digitallending.entity.EkycModel;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@SuppressWarnings("all")
@JsonInclude(JsonInclude.Include.ALWAYS)
public class AccessTokenDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("access_token")
    protected String token;

    @JsonProperty("expires_in")
    protected long expiresIn;

    @JsonProperty("refresh_expires_in")
    protected long refreshExpiresIn;

    @JsonProperty("refresh_token")
    protected String refreshToken;

    @JsonProperty("token_type")
    protected String tokenType;

    @JsonProperty("id_token")
    protected String idToken;

    @JsonProperty("not_before_policy")
    protected int notBeforePolicy;

    @JsonProperty("session_state")
    protected String sessionState;

    @JsonProperty("scope")
    protected String scope;

    @JsonProperty("user_profile")
    private UserProfileDTO userProfile;

    private EkycData ekycModel;

    private LoanState loanProfile;
}
