package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.req.CustomerInfoMbRequest;
import vn.com.mcredit.digitallending.dto.resp.CustomerInfoMbResponse;
import vn.com.mcredit.digitallending.dto.resp.internal.MiniAppUserInfo;

@Component
public class MiniAppProxy extends BaseProxy {
    @Value("${mini-app.host}")
    private String host;
    @Value("${mini-app.x-application-access}")
    private String accessKey;
    @Value("${mini-app.x-application-secret}")
    private String secretKey;
    public MiniAppUserInfo getMiniAppUserInfo(String customerCode) {
        String url = String.format("%s/integration/digital-lending?code=%s", host, customerCode);
        return this.post(url,  initOpenAPIHeader(accessKey, secretKey),null, MiniAppUserInfo.class);
    }

    public CustomerInfoMbResponse getCustomerInfoMb (CustomerInfoMbRequest customerInfoMbRequest) {
        String url = String.format("%s/integration/digital-lending/customer-info",host,customerInfoMbRequest);
        return this.post(url,initOpenAPIHeader(accessKey,secretKey), customerInfoMbRequest,CustomerInfoMbResponse.class);
    }

}
