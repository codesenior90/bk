package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class DisbursementRequest {
    private String internalId;
    private String offlineId;
    private String imageSearchOneIdMultiFace;
    private String imageSearchOneFaceMultiId;
    private String offlineMobile;
}
