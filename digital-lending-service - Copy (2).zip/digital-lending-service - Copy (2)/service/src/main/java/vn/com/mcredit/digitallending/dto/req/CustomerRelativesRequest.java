package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class CustomerRelativesRequest {
    @JsonProperty("numberRelative")
    @NotNullorEmpty(message = "Vui lòng cung cấp số thứ tự người tham chiếu")
    private Integer numberRelative;
    @JsonProperty("relationSpouse")
    private String relationSpouse;
    @JsonProperty("relativesIdNumber")
    private String relativesIdNumber;
    @JsonProperty("relativesName")
    private String relativesName;
    @JsonProperty("relativesPhone")
    private String relativesPhone;
    @JsonProperty("type")
    @NotNullorEmpty(message = "Vui lòng cung cấp loại người tham chiếu")
    private String type;
}
