package vn.com.mcredit.digitallending.dto.req.ekyc;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

@Data
public class OcrRecognitionFrom extends BaseRecognitionForm{
    @NotNull(message = "Vui lòng chọn mặt trước CCCD")
    private MultipartFile front;
    @NotNull(message = "Vui lòng chọn mặt sau CCCD")
    private MultipartFile back;
    private Integer processEkyc;
}
