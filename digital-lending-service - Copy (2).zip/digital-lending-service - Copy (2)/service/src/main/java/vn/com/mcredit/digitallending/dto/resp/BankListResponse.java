package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

import java.util.List;

@Data
public class BankListResponse {
    private String clientMessageId; // Thông tin tạo bởi consumer (khuyên dùng UUID)
    private String timestamp;
    private String code; // Mã lỗi
    private String message; // Mô tả lỗi
    private List<BankInfo> data; // Danh sách ngân hàng
    private String status;

}
