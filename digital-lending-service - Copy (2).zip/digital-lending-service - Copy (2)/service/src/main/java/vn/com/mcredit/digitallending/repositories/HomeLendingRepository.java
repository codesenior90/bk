package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.HomeLending;

import java.util.Optional;

@Repository
public interface HomeLendingRepository extends JpaRepository<HomeLending, String> {
    Optional<HomeLending> findById(String id);
}
