package vn.com.mcredit.digitallending.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import vn.com.mcredit.digitallending.aop.Secured;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.enums.SystemNameEnum;
import vn.com.mcredit.digitallending.services.BpmService;
import vn.com.mcredit.digitallending.services.ReasonRejectService;

import javax.validation.Valid;
import java.math.BigInteger;

@RequiredArgsConstructor
@RequestMapping("/api/bpm/v1")
@RestController
public class BpmController {
    @Autowired
    private BpmService bpmService;
    @Autowired
    private ReasonRejectService reasonRejectService;

    /**
     * @param getOfferRequestDTO
     *
     * @return
     */
    @PostMapping(value = "/offer/get", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> getOffer(@Valid @RequestBody GetOfferRequestDTO getOfferRequestDTO) {
        return ResponseEntity.status(HttpStatus.OK).body(bpmService.getOffer(getOfferRequestDTO));
    }

    /**
     * @param
     *
     * @return : Get trạng thái của offer
     */
    @GetMapping(value = "/offer/status")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> getStatusOffer(@RequestParam(required = false) String caseNumber, @RequestParam(required = false) String status ) {
        return ResponseEntity.status(HttpStatus.OK).body(bpmService.getStatusOffer(caseNumber));
    }


    /**
     * @param rejectOfferRequestDTO
     *
     * @return reject offer
     */
    @PostMapping(value = "/offer/reject", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> rejectOffer(@Valid @RequestBody RejectOfferRequestDTO rejectOfferRequestDTO) {
        return ResponseEntity.status(HttpStatus.OK).body(bpmService.rejectOffer(rejectOfferRequestDTO));
    }

    /**
     * @param createCaseRequestDTO
     *
     * @return: Tạo case Digital Lending
     */
    @PostMapping(value = "/case/create", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> createCase(@Valid @RequestBody CreateCaseRequestDTO createCaseRequestDTO) {
        return ResponseEntity.status(HttpStatus.OK).body(bpmService.createCase(createCaseRequestDTO));
    }

    /**
     * @param
     *
     * @return Lấy trạng thái tạo case trên Digital Lending
     */
    @GetMapping(value = "/case/status")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> getStatusCase(@RequestParam(required = false) String caseNumber, @RequestParam(required = false) String status) {
        return ResponseEntity.status(HttpStatus.OK).body(bpmService.getStatusCase(caseNumber));
    }

    /**
     * @param type
     *
     * @return Danh sách các lí do từ chối
     */
    @GetMapping(value = "offer/reject/list", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> getReasonRejectSurvey(@Valid ReasonRejectRequest type) {
        var response = DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(reasonRejectService.getAllByActiveAndType(true, type.getType())).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
    /**
     * @param
     *
     * @return Hoàn thành khoản vay
     */
    @GetMapping(value = "/case/complete/{loansProfileId}/{contractNumber}")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> completeCase(@PathVariable String loansProfileId, @PathVariable String contractNumber) {
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.completeCase(loansProfileId, contractNumber)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
    /**
     * @param
     *
     * @return Customer check info
     */
    @PostMapping(value = "/customer/checkinfo")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> customerCheckInfo(@RequestBody CustomerRequestDTO dto) {
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.customerCheckInfo(dto)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping(value = "/customer/check-account-mb")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkAccMBInfo(@RequestParam String accountNumber) {
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.checkAccMBInfo(accountNumber)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping(value = "/check-mb-account")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkMBAccount(@RequestBody MbAccountDTO dto) {
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.checkMBAccount(dto)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
    @PostMapping(value = "/mb-account-info")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkMBAccount(@RequestBody MBAccountQueryReq dto) {
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.getMBAccountInfo(dto)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
    @PostMapping("/search-option")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> searchOption(@RequestBody OptionDTO optionDTO){
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.searchOption(optionDTO)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/decision/disbursement/matrix")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> disbursementMatrix(@RequestParam BigInteger offerId){
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.disbursementMatrix(offerId)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
    @GetMapping(value = "/mb/check-account", produces = MediaType.APPLICATION_JSON_VALUE)
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkAccountMB(@RequestBody CheckAccountMBRequest request) {
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.checkAccountMB(request)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }


    @PostMapping("/check-account-disbursement")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkAccountDisbursement(@RequestBody CheckAccountDisbursementRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.OK).body(bpmService.checkAccountDisbursement(requestDTO));
    }

    @PostMapping("/check-loan-device")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> checkLoanDevice(@RequestBody BpmCheckDeviceReq req){
        var response = DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE)
                .data(bpmService.checkLoanDevice(req)).build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
