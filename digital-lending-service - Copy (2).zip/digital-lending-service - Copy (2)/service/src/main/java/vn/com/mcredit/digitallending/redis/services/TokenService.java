package vn.com.mcredit.digitallending.redis.services;

import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.concurrent.TimeUnit;

@Component
public class TokenService extends BaseService {

    private static final String ACCESS_TOKEN_SUFFIX = "_access_token_mobile_4_customers";
    private static final String REFRESH_TOKEN_SUFFIX = "_refresh_token_mobile_4_customers";
    private static final String WEBVIEW_ACCESS_TOKEN_SUFFIX = "_dl_webview_token_4_customers";
    private static final String WEBVIEW_ACCESS_DATA_SUFFIX = "_dl_webview_data_4_customers";
    public void set(String key, String token, Date expiredDate) {
        long diff = expiredDate.getTime() - new Date().getTime();
        redisTemplate.opsForValue().set(key.toLowerCase() + ACCESS_TOKEN_SUFFIX, token, diff, TimeUnit.MILLISECONDS);
    }
    @Override
    public String get(String key) {
        return (String) redisTemplate.opsForValue().get(key.toLowerCase() + ACCESS_TOKEN_SUFFIX);
    }

    @SuppressWarnings("unchecked")
    public void delete(String key) {
        redisTemplate.delete(key.toLowerCase() + ACCESS_TOKEN_SUFFIX);
    }

    //Xử lý refresh token
    @SuppressWarnings("unchecked")
    public void setRefreshToken(String key, String token, Date expiredDate) {
        long diff = expiredDate.getTime() - new Date().getTime();
        redisTemplate.opsForValue().set(key.toLowerCase() + REFRESH_TOKEN_SUFFIX, token, diff, TimeUnit.MILLISECONDS);
    }

    public String getRefreshToken(String key) {
        return (String) redisTemplate.opsForValue().get(key.toLowerCase() + REFRESH_TOKEN_SUFFIX);
    }

    @SuppressWarnings("unchecked")
    public void deleteRefreshToken(String key) {
        redisTemplate.delete(key.toLowerCase() + ACCESS_TOKEN_SUFFIX);
    }

    public void setWebview(String key, String token, Date expiredDate) {
        long diff = expiredDate.getTime() - new Date().getTime();
        redisTemplate.opsForValue().set(key.toLowerCase() + WEBVIEW_ACCESS_TOKEN_SUFFIX, token, diff, TimeUnit.MILLISECONDS);
    }

    public String getWebview(String key) {
        return (String) redisTemplate.opsForValue().get(key.toLowerCase() + WEBVIEW_ACCESS_TOKEN_SUFFIX);
    }
    public boolean deleteWebview(String key) {
        return redisTemplate.delete(key.toLowerCase() + WEBVIEW_ACCESS_TOKEN_SUFFIX);
    }
    public void setWebviewData(String key, String value, Date expiredDate) {
        long diff = expiredDate.getTime() - new Date().getTime();
        redisTemplate.opsForValue().set(key.toLowerCase() + WEBVIEW_ACCESS_DATA_SUFFIX, value, diff, TimeUnit.MILLISECONDS);
    }
    public String getWebviewData(String key) {
        return (String) redisTemplate.opsForValue().get(key.toLowerCase() + WEBVIEW_ACCESS_DATA_SUFFIX);
    }
    public boolean deleteWebviewData(String key) {
        return redisTemplate.delete(key.toLowerCase() + WEBVIEW_ACCESS_DATA_SUFFIX);
    }
}