package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.IdInternalCheck;
@Repository
public interface IdInternalCheckRepository  extends JpaRepository<IdInternalCheck, String> {
    IdInternalCheck findIdInternalCheckByRequestIdAndUsername(String requestId, String username);
}
