package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "notification_econtract")
public class NotificationEContract {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name = "contract_number", length = 36)
    private String contractNumber;

    @Column(name = "type", length = 50)
    private String type;

    @Column(name = "reasons_code")
    private String reasonsCode;

    @Column(name = "reasons_name")
    private String reasonsName;

    @Column(name = "user_complete")
    private String userComplete;

    @Column(name = "complete_date")
    private String completeDate;

    @Column(name = "sign_date")
    private String signDate;

    @Column(name = "user_sign")
    private String userSign;

    @Column(name = "citizen_id")
    private String citizenID;

    @CreationTimestamp
    @Column(name = "created_at")
    private Date createdAt;
    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updatedAt;
}
