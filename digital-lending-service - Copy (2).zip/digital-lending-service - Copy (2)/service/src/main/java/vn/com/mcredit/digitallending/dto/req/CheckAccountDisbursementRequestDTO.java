package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class CheckAccountDisbursementRequestDTO {
    private String accountNumber;
    private String phoneNumber;
    private String smlCode;
    private String fullName;
    private String idNumber;
    private String idNumberOld;
}
