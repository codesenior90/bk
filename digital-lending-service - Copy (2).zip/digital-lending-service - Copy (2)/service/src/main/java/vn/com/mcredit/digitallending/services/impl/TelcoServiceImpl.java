package vn.com.mcredit.digitallending.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.req.TelcoAdvanceLocationCheckRequest;
import vn.com.mcredit.digitallending.dto.req.TelcoLocationRequest;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.dto.resp.OfferDGTDetailResponse;
import vn.com.mcredit.digitallending.dto.resp.TelcoAdvanceLocationCheckResponse;
import vn.com.mcredit.digitallending.entity.EkycModel;
import vn.com.mcredit.digitallending.entity.PreOffer;
import vn.com.mcredit.digitallending.entity.TelcoLocation;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.TelcoAdvanceProxy;
import vn.com.mcredit.digitallending.repositories.EkycModelRepository;
import vn.com.mcredit.digitallending.repositories.PreOfferRepository;
import vn.com.mcredit.digitallending.repositories.TelcoRepository;
import vn.com.mcredit.digitallending.services.BpmService;
import vn.com.mcredit.digitallending.services.TelcoService;
import vn.com.mcredit.digitallending.utils.*;

import java.util.Date;
import java.util.UUID;

@Service
public class TelcoServiceImpl implements TelcoService {
    @Value("${telco.ratio-province-1-month}")
    private Float ratioProvince1Month;

    @Value("${telco.ratio-district-1-month}")
    private Float ratioDistrict1Month;

    @Value("${telco.ratio-ward-1-month}")
    private Float ratioWard1Month;

    @Value("${telco.ratio-province-3-month}")
    private Float ratioProvince3Month;

    @Value("${telco.ratio-district-3-month}")
    private Float ratioDistrict3Month;

    @Value("${telco.ratio-ward-3-month}")
    private Float ratioWard3Month;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private TelcoAdvanceProxy telcoProxy;
    @Autowired
    private EkycModelRepository ekycModelRepository;
    @Autowired
    private TelcoRepository telcoRepository;

    @Autowired
    private PreOfferRepository preOfferRepository;

    @Autowired
    private BpmService bpmService;

    @Override
    public DigitalLendingResponse telcoLocationCheck(TelcoLocationRequest request) {
        LogUtils.error("[TelcoService] telcoLocationCheck request", request);

        TelcoAdvanceLocationCheckRequest locationCheckRequest = new TelcoAdvanceLocationCheckRequest();
        String requestId = UUID.randomUUID().toString();
        locationCheckRequest.setRequestId(requestId);
        locationCheckRequest.setRequestDate(DateUtils.parseDateToStr(DateUtils.DATE_TIME_FORMAT_VI_OUTPUT, new Date()));
        locationCheckRequest.setLocation(request);
        String username = JWTUtils.getUsername();
        String phoneNumber = username.replaceFirst(Constants.FIRSTPHONENUMBER, Constants.REPLACEFIRSTPHONENUMBER);
        locationCheckRequest.setPhoneNumber(phoneNumber);
        DigitalLendingResponse response = this.checkRuleC102(request);
        if (response != null) return response;
        EkycModel ekycModel = ekycModelRepository.findByUsername(username);
        locationCheckRequest.setName(ekycModel.getName());
        String dob = ekycModel.getDob();
        locationCheckRequest.setDob(dob);
        locationCheckRequest.setCccdNumber(ekycModel.getIdNumber());
        locationCheckRequest.setCmndoNumber(ekycModel.getIdNumberOld());

        TelcoLocation telcoLocation = this.builDataLocation(locationCheckRequest);
        TelcoAdvanceLocationCheckResponse telcoAdvanceLocationCheckResponse;
        response = new DigitalLendingResponse();
        //Call api telco
        try {
            telcoAdvanceLocationCheckResponse = telcoProxy.telcoLocationCheck(locationCheckRequest);
            LogUtils.info("[TelcoService] telcoLocationCheck response");
        } catch (HttpStatusCodeException statusCodeException) {
            LogUtils.info("[TelcoService] telcoLocationCheck HttpStatusCodeException", statusCodeException.getResponseBodyAsString());
            telcoLocation.setMessage(statusCodeException.getStatusText());
            telcoLocation.setErrorCode(statusCodeException.getStatusCode().name());
            telcoRepository.save(telcoLocation);
            throw new ApplicationException(String.valueOf(statusCodeException.getStatusCode().value()), statusCodeException.getStatusText());
        }

        this.addDataLocationTelco(telcoLocation, telcoAdvanceLocationCheckResponse);
        if (!checkRatioTelcoLocation(telcoAdvanceLocationCheckResponse)) {
            telcoLocation.setStatus(false);
            telcoLocation.setErrorCode(telcoAdvanceLocationCheckResponse.getErrorCode());
            telcoLocation.setMessage(telcoAdvanceLocationCheckResponse.getMessage());
            telcoRepository.save(telcoLocation);
            String errorMessage = StringUtils.isNullOrEmpty(telcoAdvanceLocationCheckResponse.getMessage()) ? Error.FAIL_LOCATION_TELCO.getMessage() : telcoAdvanceLocationCheckResponse.getMessage();
            bpmService.updateLoanRequest(Error.FAIL_LOCATION_TELCO.getCode(), Error.FAIL_LOCATION_TELCO.getMessage(), username );
            throw new ApplicationException(Error.FAIL_LOCATION_TELCO.getCode(), errorMessage);
        }
        telcoLocation.setStatus(true);
        telcoRepository.save(telcoLocation);
        response.setCode(Constants.SUCCESS_CODE);
        response.setStatus(Constants.PASS);
        response.setData(telcoAdvanceLocationCheckResponse);
        return response;
    }

    private DigitalLendingResponse checkRuleC102(TelcoLocationRequest request) {
        PreOffer preOffer;
        if (request.getOfferId() == null){
            preOffer = preOfferRepository.findFirstByUserNameOrderByUpdatedDateDesc(JWTUtils.getUsername());
        } else {
            preOffer = preOfferRepository.findByOfferIdAndUsername(request.getOfferId(), JWTUtils.getUsername());
        }
        if (preOffer != null){
            try {
                OfferDGTDetailResponse offerDGTDetailResponse = objectMapper.readValue(preOffer.getOfferDGTDetailResponse(), OfferDGTDetailResponse.class);
                String result = Utils.getResultByRule(offerDGTDetailResponse.getCodeStatus(), Constants.RULE_C10_2);
                LogUtils.info("[TelcoService] telcoLocationCheck checkRuleC102 result", result);
                if (!Constants.YES.equalsIgnoreCase(result)){
                    DigitalLendingResponse response = new DigitalLendingResponse();
                    response.setCode(Constants.SUCCESS_CODE);
                    response.setStatus(Constants.PASS);
                    return response;
                }
            } catch (JsonProcessingException e) {
                LogUtils.error("[TelcoService] telcoLocationCheck checkRuleC102 JsonProcessingException", e.getMessage());
                throw new ApplicationException(Error.FAIL_LOCATION_TELCO.getCode(), Error.FAIL_LOCATION_TELCO.getMessage());
            }
        }
        return null;
    }

    private boolean checkRatioTelcoLocation(TelcoAdvanceLocationCheckResponse telcoLocationCheck) {
        if (telcoLocationCheck != null && telcoLocationCheck.getLocationCheckResult() != null
                && telcoLocationCheck.getErrorCode() == null) {

            Float ratio3monthsInWard = telcoLocationCheck.getLocationCheckResult().getWard().getRatio3Months();
            Float ratio1monthsInWard = telcoLocationCheck.getLocationCheckResult().getWard().getRatio1Month();
            if (ratio3monthsInWard != null && ratio1monthsInWard != null &&
                ratio3monthsInWard >= ratioWard3Month && ratio1monthsInWard >= ratioWard1Month) {
                return true;
            }
        }
        return false;
    }

    private TelcoLocation builDataLocation(TelcoAdvanceLocationCheckRequest locationCheckRequest) {
        TelcoLocation telcoLocation = new TelcoLocation();
        telcoLocation.setDob(locationCheckRequest.getDob());
        telcoLocation.setDistrict(locationCheckRequest.getLocation().getDistrict());
        telcoLocation.setProvince(locationCheckRequest.getLocation().getProvince());
        telcoLocation.setWard(locationCheckRequest.getLocation().getWard());
        telcoLocation.setRequestId(locationCheckRequest.getRequestId());
        String username = JWTUtils.getUsername();
        telcoLocation.setUsername(username);
        return telcoLocation;

    }

    private void addDataLocationTelco(TelcoLocation telcoLocation, TelcoAdvanceLocationCheckResponse telcoAdvanceLocationCheckResponse) {
        if (telcoAdvanceLocationCheckResponse.getLocationCheckResult() != null) {
            telcoLocation.setRatio1MonthProvince(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getProvince().getRatio1Month());
            telcoLocation.setRatioRange1MonthProvince(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getProvince().getRatioRange1Month());
            telcoLocation.setRatio3MonthsProvince(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getProvince().getRatio3Months());
            telcoLocation.setRatioRange3MonthsProvince(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getProvince().getRatioRange3Months());

            telcoLocation.setRatio1MonthDistrict(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getDistrict().getRatio1Month());
            telcoLocation.setRatioRange1MonthPDistrict(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getDistrict().getRatioRange1Month());
            telcoLocation.setRatio3monthsDistrict(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getDistrict().getRatio3Months());
            telcoLocation.setRatioRange3MonthsDistrict(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getDistrict().getRatioRange3Months());

            telcoLocation.setRatio1MonthWard(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getWard().getRatio1Month());
            telcoLocation.setRatioRange1MonthWard(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getWard().getRatioRange1Month());
            telcoLocation.setRatio3monthsWard(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getWard().getRatio3Months());
            telcoLocation.setRatioRange3MonthsWard(telcoAdvanceLocationCheckResponse.getLocationCheckResult().getWard().getRatioRange3Months());

            telcoLocation.setErrorCode(telcoAdvanceLocationCheckResponse.getErrorCode());
            telcoLocation.setMessage(telcoAdvanceLocationCheckResponse.getMessage());
            telcoLocation.setResponseId(telcoAdvanceLocationCheckResponse.getResponseId());

        }
    }
}
