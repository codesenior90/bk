package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class RawUserDataReq {
    private RawUserDataDTO userData;
    private String requestId;
}
