package vn.com.mcredit.digitallending.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserData {
    private String type;
    private String idNumberOld;
    private String name;
    private String idNumber;
    private String dob;
    private Boolean isPass;
    private String qrcode;
}
