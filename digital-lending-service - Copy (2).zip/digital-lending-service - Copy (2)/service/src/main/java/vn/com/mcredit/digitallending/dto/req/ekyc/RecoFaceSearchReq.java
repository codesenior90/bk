package vn.com.mcredit.digitallending.dto.req.ekyc;

import lombok.Data;

@Data
public class RecoFaceSearchReq {
    private String frontCode;
    private String selfieCode;
    private String name;
    private String dob;
    private String citizenId;
    private String citizenIdOld;
}
