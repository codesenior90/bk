package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import vn.com.mcredit.digitallending.dto.resp.OcrResponse;
@Data
public class CheckInternalIdDTO {
    private OcrResponse ocr;
    private String qrcode;

}
