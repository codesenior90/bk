package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationResponseDetailDTO {
    @JsonProperty("returnCode")
    private String returnCode;
    @JsonProperty("returnMess")
    private String returnMess;
    @JsonProperty("caseNumber")
    private String caseNumber;
    @JsonProperty("contractNumber")
    private String contractNumber;
}
