package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class IdentityPaperRequest {
    private String identityCode;
    private String identityType;
    private String idNumber;
    private String identityIssueDate;
    private String identityExpiredDate;
    private String identityIssuePlaceCode;
    private String identityIssuePlace;
}
