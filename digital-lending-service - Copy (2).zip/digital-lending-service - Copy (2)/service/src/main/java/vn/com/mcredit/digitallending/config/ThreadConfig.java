package vn.com.mcredit.digitallending.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class ThreadConfig {

    private TaskExecutor threadPoolTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(6);
        executor.setMaxPoolSize(40);
        executor.setQueueCapacity(100);
        executor.initialize();
        return executor;
    }
    @Bean("sendMessageThreadPoolTaskExecutor")
    public TaskExecutor sendMessageThreadPoolTaskExecutor() {
        return threadPoolTaskExecutor();
    }
    @Bean("receiveMessageThreadPoolTaskExecutor")
    public TaskExecutor receiveMessageThreadPoolTaskExecutor() {
        return threadPoolTaskExecutor();
    }
    @Bean("synchronizeThreadPoolTaskExecutor")
    public TaskExecutor synchronizeThreadPoolTaskExecutor() {
        return threadPoolTaskExecutor();
    }
    @Bean("addVectorThreadPoolTaskExecutor")
    public TaskExecutor addVectorThreadPoolTaskExecutor() {
        return threadPoolTaskExecutor();
    }
    @Bean("updateCaseStatusThreadPoolTaskExecutor")
    public TaskExecutor updateCaseStatusThreadPoolTaskExecutor() {
        return threadPoolTaskExecutor();
    }
    @Bean("callLogApiThreadPoolTaskExecutor")
    public TaskExecutor callLogApiThreadPoolTaskExecutor() {
        return threadPoolTaskExecutor();
    }
    @Bean("sendLeadToMCPortalThreadPoolTaskExecutor")
    public TaskExecutor sendLeadToMCPortalThreadPoolTaskExecutor() {
        return threadPoolTaskExecutor();
    }
    @Bean("sendUpdateLoanRequestThreadPoolTaskExecutor")
    public TaskExecutor sendUpdateLoanRequestThreadPoolTaskExecutor() {
        return threadPoolTaskExecutor();
    }
}