package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

@Data
public class DimensionByFaceCodeResp {
}
