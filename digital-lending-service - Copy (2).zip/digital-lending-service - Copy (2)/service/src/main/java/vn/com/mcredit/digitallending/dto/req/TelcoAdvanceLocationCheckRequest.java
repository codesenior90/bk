package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class TelcoAdvanceLocationCheckRequest {

    @SerializedName("request_id")
    @JsonProperty("request_id")
    private String requestId;

    @SerializedName("request_date")
    @JsonProperty("request_date")
    private String requestDate;

    @SerializedName("phone_number")
    @JsonProperty("phone_number")
    @NotNullorEmpty
    private String phoneNumber;
    private String name;

    @NotNullorEmpty
    private TelcoLocationRequest location;

    @NotNullorEmpty
    private String dob;

    @SerializedName("cccd_number")
    @JsonProperty("cccd_number")
    @NotNullorEmpty
    private String cccdNumber;

    @SerializedName("cmndo_number")
    @JsonProperty("cmndo_number")
    private String cmndoNumber;

}
