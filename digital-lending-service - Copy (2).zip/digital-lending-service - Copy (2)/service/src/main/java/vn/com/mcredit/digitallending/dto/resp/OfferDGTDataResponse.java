package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

import java.math.BigInteger;

@Data
public class OfferDGTDataResponse {
    private BigInteger id;
    private String requestId;
    private String programName;
    private Integer loanAmount;
    private Double loanAmtMinusInsu;
    private Double approveAmount; // -- Số tiền phê duyệt
    private String programCode;
    private String status;
    private BigInteger loanTenor;
    private Double insuranceRate; // -- tỉ lệ phí bảo hiểm
    private String loanMethod;
    private String insuranceCompany;
    private Double insuranceFee;
    private Double baseRate;
    private String expiredTime;
}
