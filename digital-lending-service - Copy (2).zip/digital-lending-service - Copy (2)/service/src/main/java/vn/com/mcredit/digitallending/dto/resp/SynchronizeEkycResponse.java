package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class SynchronizeEkycResponse {
    private String id;
}
