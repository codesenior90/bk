package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CheckDupMcDTO {
    @JsonProperty("brithday")
    private String birthDay;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("numberExtraId")
    private String numberExtraId;
    @JsonProperty("numberId")
    private String numberId;
    @JsonProperty("requestId")
    private String requestId;
}
