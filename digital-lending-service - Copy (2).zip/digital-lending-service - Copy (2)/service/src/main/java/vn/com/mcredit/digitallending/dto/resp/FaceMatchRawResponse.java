package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FaceMatchRawResponse {
    @JsonProperty("ID_angle")
    private Float idAngle; // Góc quay của giấy tờ tùy thân mặt trước để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("detection_time")
    private Float detectionTime; // Thời gian xác định khuôn mặt trong ảnh
    @JsonProperty("embedding_time")
    private Float embeddingTime; // Thời gian chuyển các đặc trưng trên khuôn mặt sang vector
    @JsonProperty("s1")
    private Float s1; // Xác xuất trùng khớp giữa 2 khuôn mặt trong ảnh giấy tờ mặt trước và ảnh chụp chân dung
    @JsonProperty("selfie_angle")
    private Float selfieAngle; // Góc quay ảnh chân dung để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("response_id") //
    private String responseId; // Id của response trả về
    @JsonProperty("process_id") //
    private String processId; // Id của response trả về
    @JsonProperty("vec1")
    private String vec1;
    @JsonProperty("vec2")
    private String vec2;
    @JsonProperty("error")
    private String error;
}
