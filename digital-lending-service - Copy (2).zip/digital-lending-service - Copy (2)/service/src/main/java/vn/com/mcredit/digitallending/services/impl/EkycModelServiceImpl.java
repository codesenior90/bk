package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.dto.resp.internal.UserLinkResponse;
import vn.com.mcredit.digitallending.entity.EkycModel;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.repositories.EkycModelRepository;
import vn.com.mcredit.digitallending.services.EkycModelService;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;

@Service
@RequiredArgsConstructor
public class EkycModelServiceImpl implements EkycModelService {
    private final EkycModelRepository ekycModelRepository;
    public EkycModel findEkycModelByUsername(String username){

        return ekycModelRepository.findByUsername(username);
    }
    public Boolean existsByUsername(String username){
        return ekycModelRepository.existsByUsername(username);

    }

    @Override
    public EkycModel save(EkycModel ekycModel) {
        return ekycModelRepository.save(ekycModel);
    }

    public void verifyDeviceId(EkycModel ekycModel){
        String deviceId = JWTUtils.getDeviceId();
        if (ekycModel.getDeviceId() != null && !ekycModel.getDeviceId().equals(deviceId)){
            LogUtils.info("[BpmService] verifyDeviceId ", ekycModel.getDeviceId() + " != " + deviceId);
            throw new ApplicationException(Error.DEVICE_VERIFICATION_ERROR.getCode(), Error.DEVICE_VERIFICATION_ERROR.getMessage());
        }
    }

    @Override
    public UserLinkResponse getUserLink(String username) {
        EkycModel ekycModel =  ekycModelRepository.findByUsername(username);
        if (ekycModel == null)
            throw new ApplicationException(Constants.ERROR_400_BAD, "Truy vấn dữ liệu không thành công.");
        if (StringUtils.isBlank(ekycModel.getBackImageURL())
                || StringUtils.isBlank(ekycModel.getSelfieImageURL())
                || StringUtils.isBlank(ekycModel.getFrontImageURL()))
            throw new ApplicationException(Constants.ERROR_400_BAD, "Truy vấn dữ liệu không thành công.");
        UserLinkResponse response = UserLinkResponse.builder()
                .selfieImageUrl(ekycModel.getSelfieImageURL())
                .frontImageUrl(ekycModel.getFrontImageURL())
                .backImageUrl(ekycModel.getBackImageURL())
                .build();
        LogUtils.info("User-link", response);
        return response;
    }

}
