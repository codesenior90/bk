package vn.com.mcredit.digitallending.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.apache.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.aop.PreventDuplicateMethod;
import vn.com.mcredit.digitallending.dto.req.SynchronizeEkycRequest;
import vn.com.mcredit.digitallending.entity.Synchronize;
import vn.com.mcredit.digitallending.proxy.AfcProxy;
import vn.com.mcredit.digitallending.repositories.SynchronizeRepository;
import vn.com.mcredit.digitallending.services.SynchronizeService;
import vn.com.mcredit.digitallending.utils.DateUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;

import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SynchronizeServiceImpl implements SynchronizeService {
    private final SynchronizeRepository synchronizeRepository;
    private final ObjectMapper objectMapper;
    private final AfcProxy afcProxy;
    List<Integer> httpStatusCodes = Arrays.asList(HttpStatus.SC_GATEWAY_TIMEOUT, HttpStatus.SC_REQUEST_TIMEOUT,
            HttpStatus.SC_BAD_GATEWAY, HttpStatus.SC_UNAUTHORIZED, HttpStatus.SC_INTERNAL_SERVER_ERROR, HttpStatus.SC_SERVICE_UNAVAILABLE);

    @PreventDuplicateMethod
    @Override
    public void synchronizes(){
        LogUtils.info("[SynchronizeService] synchronizes");
        List<Synchronize> synchronizes = synchronizeRepository.findSynchronizeFailure(httpStatusCodes, 5);
        for (Synchronize synchronize: synchronizes){
            LogUtils.info("[SynchronizeSchedule] synchronizes user");
            this.synchronize(synchronize);
        }
    }
    private void synchronize(Synchronize synchronize){
        try {
            afcProxy.synchronize(this.build(synchronize.getRequest()), "");
            synchronizeRepository.delete(synchronize);
        } catch (HttpStatusCodeException e){
            LogUtils.error("[SynchronizeService] synchronizes exception", e.getResponseBodyAsString());
            synchronize.setHttpStatusCode(e.getStatusCode().value());
            synchronize.setCount(synchronize.getCount() + 1);
            synchronize.setUpdatedAt(DateUtils.getNowDate());
            synchronize.setHttpStatusText(e.getStatusText());
            synchronize.setResponse(e.getResponseBodyAsString());
            synchronizeRepository.save(synchronize);
        }
    }
    private SynchronizeEkycRequest build(String data){
        try {
            return objectMapper.readValue(data, SynchronizeEkycRequest.class);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
