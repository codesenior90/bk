package vn.com.mcredit.digitallending.dto;

import lombok.Data;

@Data
public class CaseInforDTO {
    private String caseNumber;
    private String status;
    private String fullName;
    private String brithday;
    private String numberExtraId;
    private String creatdate;
    private String numberPhone;
    private String numberId;
}
