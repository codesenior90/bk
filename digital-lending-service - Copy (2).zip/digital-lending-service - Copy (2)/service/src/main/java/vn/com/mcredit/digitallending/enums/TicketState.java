package vn.com.mcredit.digitallending.enums;

public enum TicketState {
    OPEN("OPEN"),
    PENDING("PENDING"),
    CLOSE("CLOSE");
    private String value;

    TicketState(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
