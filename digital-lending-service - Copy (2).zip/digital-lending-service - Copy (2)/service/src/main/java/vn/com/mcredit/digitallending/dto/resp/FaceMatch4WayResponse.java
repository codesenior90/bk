package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FaceMatch4WayResponse {
    @JsonProperty("straight_angle")
    private String straightAngle; // Góc quay của chụp chính diện để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("img1_angle")
    private String img1Angle; // Góc quay của ảnh thứ nhất để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("Img2_angle")
    private String img2Angle; // Góc quay của ảnh thứ hai để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("Img3_angle")
    private String img3Angle; // Góc quay của ảnh thứ ba để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("ss1")
    private String ss1; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ nhất và ảnh chính diện
    @JsonProperty("ss2")
    private String ss2; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ hai và ảnh chính diện
    @JsonProperty("ss3")
    private String ss3; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ ba và ảnh chính diện
    @JsonProperty("detection_time")
    private String detectionTime; // Thời gian xác định khuôn mặt trong ảnh
    @JsonProperty("embedding_time")
    private String embeddingTime; // Thời gian chuyển các đặc trưng trên khuôn mặt sang vector
    @JsonProperty("response_id")
    private String responseId; // Id của response trả về
    @JsonProperty("error")
    private Object error;
    @JsonProperty("status")
    private boolean status;
    @JsonProperty("pass")
    private boolean pass;

}
