package vn.com.mcredit.digitallending.dto.resp;


import lombok.Data;

@Data
public class StatusCaseResponse{
    private String detailCase;
    private Integer caseNumber;
    private String contractNumber;
    private String message;
    private Integer loanAmtMinusInsu;
    private Integer status;
    private Integer loanAmount;
    private Integer insuranceFee;
    private Double insuranceRate;
    private String loanTenor;
    private Double recurringPaymentRate;
    private String insuranceCompany;
    private Double interestRate;
    private String loanMethod;
    private String campaignCode;
    private String campaignName;
}
