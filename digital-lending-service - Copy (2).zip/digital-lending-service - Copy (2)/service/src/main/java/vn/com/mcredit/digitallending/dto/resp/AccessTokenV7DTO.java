package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@SuppressWarnings("all")
@JsonInclude(JsonInclude.Include.ALWAYS)
public class AccessTokenV7DTO implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("accessToken")
    protected String accessToken;

    @JsonProperty("expiresIn")
    protected long expiresIn;

    @JsonProperty("tokenType")
    protected String tokenType;

    @JsonProperty("username")
    protected String username;

    @JsonProperty("system")
    protected String system;

    @JsonProperty("applicationType")
    protected String applicationType;

    @JsonProperty("name")
    protected String name;

}
