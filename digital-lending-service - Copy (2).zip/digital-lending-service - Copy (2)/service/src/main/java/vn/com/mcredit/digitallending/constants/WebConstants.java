package vn.com.mcredit.digitallending.constants;

public interface WebConstants {
    String API_VERSION = "/api/v1/";
    String API_VERSION_SECU = API_VERSION + "secu/";

    final class Headers {
        private Headers() {}
        public static final String X_SIGN = "X-Sign";
        public static final String X_CURRENT_USER = "X-Current-User";
        public static final String ORIGIN = "origin";
        public static final String REFERER = "referer";
        public static final String POSTMAN_TOKEN = "postman-token";
        public static final String X_ORIGIN_FORARDER_FOR = "x-original-forwarded-for";
        public static final String PATH = "path";
        public static final String URI_KEY = "uri-key";
    }
}
