package vn.com.mcredit.digitallending.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RedisConfiguration {

	@Value("${spring.redis.host}")
	protected String redisHost;

	@Value("${spring.redis.port}")
	protected int redisPort;

	@Value("${spring.redis.password}")
	protected String redisPassword;

	@Value("${spring.redis.timeout}")
	protected int redisTimeout;
}
