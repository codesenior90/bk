package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class FaceMatchingRequest {
    private Float detectionTime;
    private Float embeddingTime;
    private Float s1;
    private Boolean pass;
}
