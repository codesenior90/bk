package vn.com.mcredit.digitallending.proxy;

import com.amazonaws.auth.*;
import lombok.extern.slf4j.Slf4j;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import vn.com.mcredit.digitallending.middleware.AWSRequestSigningApacheInterceptor;
import vn.com.mcredit.digitallending.utils.LogUtils;
import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

@Slf4j
@Component
public class AWSProxy extends BaseProxy {

    private static final String EXECUTE_API = "execute-api";
    private static final String STS = "sts";
    private static final String AP_SOUTHEAST_1 = "ap-southeast-1";


    public <T> Object authenticate(String api, String accessKey, String secretKey,  Class<T> clazz){
        var rest = new RestTemplate(this.authClientHttpRequestFactory(accessKey, secretKey, STS));
        HttpEntity<String> entity = new HttpEntity<>(initHeaderWithContentType());
        ResponseEntity<T> response = rest.exchange(api, HttpMethod.GET, entity, clazz);
        return response.getBody();
    }
    public <T> Object get(String api, String accessKey, String secretKey, String sessionToken, Class<T> clazz) {
        var rest = new RestTemplate(this.clientHttpRequestFactory(accessKey, secretKey, sessionToken));
        HttpEntity<String> entity = new HttpEntity<>(initHeaderWithContentType());
        ResponseEntity<T> response = rest.exchange(api, HttpMethod.GET, entity, clazz);
        return response.getBody();
    }
    public <T> T post(String api, String accessKey, String secretKey, String sessionToken, Object payload, Class<T> clazz){
        var rest = new RestTemplate(this.clientHttpRequestFactory(accessKey, secretKey, sessionToken));
        final HttpEntity<Object> entity = new HttpEntity<>(payload , initHeaderWithContentType());
        ResponseEntity<T> response = rest.exchange(api, HttpMethod.POST, entity, clazz);
        return response.getBody();
    }
    public HttpComponentsClientHttpRequestFactory authClientHttpRequestFactory(String accessKey, String secretKey, String serviceName) {
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();

        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
        AWS4Signer signer = new AWS4Signer();
        signer.setServiceName(serviceName);

        AWSCredentialsProvider awsCredentialsProvider = new AWSCredentialsProvider() {
            @Override
            public AWSCredentials getCredentials() {
                return new BasicAWSCredentials(accessKey, secretKey);
            }

            @Override
            public void refresh() {
                LogUtils.info("[AWSProxy] authClientHttpRequestFactory refresh");
            }
        };

        AWSRequestSigningApacheInterceptor apacheInterceptor = new AWSRequestSigningApacheInterceptor(serviceName, signer, awsCredentialsProvider);
        httpClientBuilder.addInterceptorLast(apacheInterceptor);
        clientHttpRequestFactory.setHttpClient(httpClientBuilder.build());
        return clientHttpRequestFactory;
    }
    public HttpComponentsClientHttpRequestFactory clientHttpRequestFactory(String accessKey, String secretKey, String sessionToken) {
        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

        SSLContext sslContext = null;
        try {
            sslContext = org.apache.http.ssl.SSLContexts.custom()
                    .loadTrustMaterial(null, acceptingTrustStrategy)
                    .build();
        } catch (NoSuchAlgorithmException | KeyManagementException | KeyStoreException e) {
            LogUtils.error("[AWSProxy] clientHttpRequestFactory error", e.getMessage());
        }

        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        httpClientBuilder.setSSLSocketFactory(csf);


        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
        AWS4Signer signer = new AWS4Signer();
        signer.setServiceName(EXECUTE_API);
        signer.setRegionName(AP_SOUTHEAST_1);

        AWSSessionCredentialsProvider awsSessionCredentialsProvider = new AWSSessionCredentialsProvider() {
            @Override
            public AWSSessionCredentials getCredentials() {
                return new BasicSessionCredentials(accessKey, secretKey, sessionToken);
            }

            @Override
            public void refresh() {
                LogUtils.info("[AWSProxy] clientHttpRequestFactory refresh");
            }
        };

        AWSRequestSigningApacheInterceptor apacheInterceptor = new AWSRequestSigningApacheInterceptor(EXECUTE_API, signer, awsSessionCredentialsProvider);
        httpClientBuilder.addInterceptorLast(apacheInterceptor);
        clientHttpRequestFactory.setHttpClient(httpClientBuilder.build());
        return clientHttpRequestFactory;
    }
}
