package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

import java.util.List;

@Data
public class CompareModel {
    private Float score;
    private List<String> dimensionCodes;
}
