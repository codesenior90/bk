package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class CreateLeadResponse {
    private String status;
    private String reason;
    private String bankLeadId;
    private String dateTime;
}
