package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.entity.HomeLending;

public interface HomeLendingService {
    HomeLending getHomeLending(String id);
}
