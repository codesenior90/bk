package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class SearchOptionData {
    private String code;
    private String name;
    private String type;
    private Integer status;
    private Integer order;
    private String value;
    private String description;
}
