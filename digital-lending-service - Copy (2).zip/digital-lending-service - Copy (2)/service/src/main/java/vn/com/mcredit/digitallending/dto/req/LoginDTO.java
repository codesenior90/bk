package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class LoginDTO {
    @NotNullorEmpty(message = "Vui lòng nhập số điện thoại.")
    private String username;
    @NotNullorEmpty(message = "Vui lòng nhập mật khẩu.")
    private String password;

    private String deviceId;
    private String system;
    private String applicationType;
}
