package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

import java.math.BigInteger;

@Data
public class OfferRequestDTO {
    @NotNullorEmpty(message = "Ngày Sinh không được để trống")
    @JsonProperty("brithday")
    private String birthDay;
    private String topic;
    private String createBy;
    private Integer age;
    @NotNullorEmpty(message = "Kênh kinh doanh không được để trống")
    private String businessChannel;
    @NotNullorEmpty(message = "Tỉnh thành không được để trống")
    private String city;
    @NotNullorEmpty(message = "Nhóm khách hàng không được để trống")
    private String customerGroup;
    @NotNullorEmpty(message = "Có tham gia bảo hiểm không không được để trống")
    private String hasInsurance;
    @NotNullorEmpty(message = "Công ty bảo hiểm không được để trống")
    private String insuranceCompany;
    private Double insuranceFee;
    private BigInteger loanAmtMinusInsu;
    @NotNullorEmpty(message = "Mã mục đích vay không được để trống")
    private String loanPurpose;
    private BigInteger loanTenor;
    @NotNullorEmpty(message = "requestId không được để trống")
    private String requestId;
    @NotNullorEmpty(message = "Điểm Score không được để trống")
    private String score;
    @NotNullorEmpty(message = "Giới tính không được để trống")
    private String sex;
    @NotNullorEmpty(message = "Họ tên không được để trống")
    private String fullName;
    @NotNullorEmpty(message = "Số điện thoại không được để trống")
    private String phoneNumber;
    private String numberExtraId;
    @NotNullorEmpty(message = "CCCD không được để trống")
    private String numberId;
    private String partnerCode;

}
