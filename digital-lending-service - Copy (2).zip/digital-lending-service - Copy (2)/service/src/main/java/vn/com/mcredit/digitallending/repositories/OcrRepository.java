package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.mcredit.digitallending.entity.Ocr;

public interface OcrRepository extends JpaRepository<Ocr, String> {
    Ocr findOcrByRequestIdAndUsername(String requestId, String username);
    Ocr findOcrByRequestIdAndUsernameAndTicketStatus(String requestId, String username, String ticketStatus);
}
