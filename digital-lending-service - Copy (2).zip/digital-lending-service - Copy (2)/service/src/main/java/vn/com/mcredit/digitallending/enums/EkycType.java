package vn.com.mcredit.digitallending.enums;

public enum EkycType {
    OCR("OCR"),
    FACE_RAW("FACE_RAW"),
    FACE_3WAY("FACE_3WAY"),
    FACE_4WAY("FACE_4WAY"),
    LIVENESS("LIVENESS"),
    EKYC("EKYC"),
    VERIFIED("VERIFIED");

    private String value;

    EkycType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
