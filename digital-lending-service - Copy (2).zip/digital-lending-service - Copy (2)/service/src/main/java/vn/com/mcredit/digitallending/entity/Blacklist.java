package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "blacklist")
public class Blacklist {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "request_id") // Require: Request id
    private String requestId;

    @Column(name = "response_id") // Require: Response id
    private String responseId;

    @Column(name = "request_date") // Require: Thời điểm gửi request
    private String requestDate;

    @Column(name = "error_code") // Mã lỗi nghiệp vụ
    private String errorCode;

    @Column(name = "blacklist_selfie_img_cut_off_threshold") // Ngưỡng cut-off trùng ảnh selfie
    private Float blacklistSelfieImgCutOffThreshold;

    @Column(name = "blacklist_id_img_cut_off_threshold") // Ngưỡng cut-off trùng ảnh ID
    private Float blacklistIdImgCutOffThreshold;

    @Column(name = "blacklist_check_detail", columnDefinition = "text") // Thông tin url + score các ảnh trong blacklist trùng với ảnh đầu vào
    private String blacklistCheckDetails;

    @Column(name = "blacklist_check_result") // Kết quả check
    private Boolean blacklistCheckResult;
    @Column(name = "ocr_request_id")
    private String ocrRequestId;
    @Column(name = "error_message", columnDefinition = "text")
    private String errorMessage;
    @Column(name = "username")
    private String username;
    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;
    @Column(name = "source_ekyc", length = 36)
    private String sourceEkyc;
}
