package vn.com.mcredit.digitallending.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import vn.com.mcredit.digitallending.dto.LogDTO;
import vn.com.mcredit.digitallending.dto.req.CallLogRequest;
import vn.com.mcredit.digitallending.entity.CallLogApi;
import vn.com.mcredit.digitallending.repositories.CallApiLogRepository;
import vn.com.mcredit.digitallending.services.CallApiLogService;
import vn.com.mcredit.digitallending.utils.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@Service
public class CalApiLogServiceImpl implements CallApiLogService {
    @Autowired
    private CallApiLogRepository repository;
    @Autowired
    @Qualifier("callLogApiThreadPoolTaskExecutor")
    private TaskExecutor taskExecutor;
    @Value("${custom.properties.log-storage-enable}")
    private Boolean logStorageEnable;
    @Override
    public Object getLog(CallLogRequest request) {
        try {
            if (StringUtils.isNotBlank(request.getUri()) && StringUtils.isNotBlank(request.getUsername())){

                return repository.findByUsernameAndUri(request.getUsername(), request.getUri(), DateUtils.toDate(request.getFromDate(), DateUtils.F_YYYY_MM_DD));
            } else if (StringUtils.isNotBlank(request.getUsername())) {
                return repository.findByUsername(request.getUsername(), DateUtils.toDate(request.getFromDate(), DateUtils.F_YYYY_MM_DD));
            }
        } catch (ParseException e) {
            LogUtils.error("[CallApiLogService] getLog error", e.getMessage());
        }
        return null;
    }

    @Override
    public void saveLog(Object body, HttpServletRequest request, HttpServletResponse response, LogDTO logInfo) {
        try {
            if (Boolean.TRUE.equals(logStorageEnable)) {
                CallLogApi callLogApi = buildLogApi(body, request, response, logInfo);
                taskExecutor.execute(() -> repository.save(callLogApi));
            }
        } catch (Exception e) {
            LogUtils.error("[CallApiLogService] saveLog error", e.getMessage());
        }
    }

    @Override
    public void saveLog(Object body, HttpRequest request, ClientHttpResponse response) {
        try {
            if (Boolean.TRUE.equals(logStorageEnable)) {
                CallLogApi callLogApi = buildLogApi(body, request, response);
                taskExecutor.execute(() -> repository.save(callLogApi));
            }
        } catch (Exception e) {
            LogUtils.error("[CallApiLogService] saveLog error", e.getMessage());
        }
    }

    private CallLogApi buildLogApi(Object body, HttpRequest request, ClientHttpResponse response) {
        CallLogApi callLogApi = new CallLogApi();
        try {
            callLogApi.setHttpStatus(response.getStatusCode().value());
            callLogApi.setUri(request.getURI().getPath());
            callLogApi.setUsername(JWTUtils.getUsername());
            List<String> contentType = request.getHeaders().get("Content-Type");
            if (!Utils.apiContainSensitiveData(request.getURI().toString()) && !CollectionUtils.isEmpty(contentType) && !contentType.get(0).contains("multipart/form-data")){
                callLogApi.setRequest(Utils.toJson(Utils.handleLogHugeData(body)));
            }
            if (!request.getURI().toString().contains("/uploadFile")) {
                callLogApi.setResponse(Utils.toJson(Utils.handleLogHugeData(response)));
            }

        } catch (IOException e) {
            LogUtils.error("[CallApiLogService] buildLogApi error", e.getMessage());
        }

        return callLogApi;
    }
    private CallLogApi buildLogApi(Object body, HttpServletRequest request, HttpServletResponse httpServletResponse, LogDTO logInfo) {
        CallLogApi callLogApi = new CallLogApi();
        callLogApi.setHttpStatus(httpServletResponse.getStatus());
        callLogApi.setUri(request.getRequestURI());
        callLogApi.setUsername(JWTUtils.getUsername());
        if (!Utils.apiContainSensitiveData(request.getRequestURI())){
            callLogApi.setRequest(Utils.toJson(Utils.handleLogHugeData(logInfo.getPayload())));
        }
        if (!request.getRequestURI().contains("/econtract-transaction/view")) {
            callLogApi.setResponse(Utils.toJson(Utils.handleLogHugeData(body)));
        }

        return callLogApi;
    }
}
