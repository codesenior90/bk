package vn.com.mcredit.digitallending.services.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import org.springframework.web.client.HttpStatusCodeException;

import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.ekyc.*;
import vn.com.mcredit.digitallending.entity.*;
import vn.com.mcredit.digitallending.enums.CheckIdInternalType;
import vn.com.mcredit.digitallending.enums.EkycType;
import vn.com.mcredit.digitallending.enums.OTPTypeEnum;
import vn.com.mcredit.digitallending.enums.SourceAppType;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.models.SendOTPDTO;
import vn.com.mcredit.digitallending.models.SendVerifyOtpDTO;
import vn.com.mcredit.digitallending.proxy.AfcProxy;
import vn.com.mcredit.digitallending.repositories.NFCUserDataRepository;
import vn.com.mcredit.digitallending.repositories.SynchronizeRepository;
import vn.com.mcredit.digitallending.security.RSADecryt;
import vn.com.mcredit.digitallending.services.AfcService;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AfcServiceImpl implements AfcService {
    @Value("${custom.properties.fraud-check-rules}")
    private String fraudCheckRules;
    private final AfcProxy afcProxy;
    private final ModelMapper modelMapper;
    private final SynchronizeRepository synchronizeRepository;
    private final ObjectMapper objectMapper;
    private final NFCUserDataRepository nfcUserDataRepository;
    @Value("${afc.key-notify}")
    private String keyNotify;
    @Value("${afc.system-id}")
    private String systemId;
    @Override
    public CheckAccountRegisterResponse checkAccountRegisterByPhone(String phone) {
        try {
            return afcProxy.checkUserAccount(phone);
        } catch (HttpStatusCodeException e){
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(e.getResponseBodyAsString()));
        }

    }
    @Override
    public Object sendOtp(SendOTPDTO dto) {
        this.validateSendOTP(dto);
        try {
            afcProxy.sendOtp(dto);
            DigitalLendingResponse response = new DigitalLendingResponse();
            response.setMessage(Constants.SEND_OTP_MESSAGE_SUCCESS);
            response.setCode(Constants.SUCCESS_CODE);
            response.setStatus(Constants.SUCCESS_MESSAGE);
            return response;
        } catch (HttpStatusCodeException e){
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(e.getResponseBodyAsString()));
        }
    }
    private void validateSendOTP(SendOTPDTO sendOTPDTO){
        if (!OTPTypeEnum.isExisted(sendOTPDTO.getType())){
            throw new ApplicationException(Constants.ERROR_400_BAD, Constants.APP_EXCEPTION_MESSAGE);
        }
    }
    /**
     * Verify otp được gửi số điển thoại
     *
     * @param dto
     * @return
     */
    @Override
    public Object verifyPhoneOtp(SendVerifyOtpDTO dto) {
        try {
            afcProxy.verifyPhoneOtp(dto);
            DigitalLendingResponse response = new DigitalLendingResponse();
            response.setMessage(Constants.VERIFY_OTP_MESSAGE_SUCCESS);
            response.setCode(Constants.SUCCESS_CODE);
            response.setStatus(Constants.SUCCESS_MESSAGE);
            return response;
        } catch (HttpStatusCodeException e){
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(e.getResponseBodyAsString()));
        }
    }

    /**
     * Đồng bộ dữ liệu ekyc sang afc
     *
     * @param body
     * @return
     */
    public SynchronizeEkycResponse synchronizeEKyc(SynchronizeEkycRequest body, String username){
        try {
            LogUtils.info("[AfcService] synchronizeEkyc");
            SynchronizeEkycResponse response = afcProxy.synchronize(body, JWTUtils.getToken());
            this.saveSynchronizeData(body, response, null, username);
            LogUtils.info("[AfcService] synchronizeEkyc response");
            return response;
        } catch (HttpStatusCodeException e){
            LogUtils.error("[AfcService] synchronizeEKyc exception", e.getResponseBodyAsString());
            this.saveSynchronizeData(body, null, e, username);
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(e.getResponseBodyAsString()));
        }
    }

    /**
     * Lưu thông tin request/response khi đồng bộ dữ liệu ekyc sang afc
     *
     * @param request
     * @param response
     * @param statusCode
     */
    private void saveSynchronizeData(SynchronizeEkycRequest request, SynchronizeEkycResponse response, HttpStatusCodeException statusCode, String username){
        Synchronize synchronize = new Synchronize();
        synchronize.setRequest(Utils.toJson(request));
        if (response != null){
            synchronize.setHttpStatusText(Constants.SUCCESS_MESSAGE);
            synchronize.setHttpStatusCode(HttpStatus.OK.value());
            synchronize.setResponse(Utils.toJson(response));
        } else if (statusCode != null) {
            synchronize.setHttpStatusText(statusCode.getStatusText());
            synchronize.setHttpStatusCode(statusCode.getStatusCode().value());
            synchronize.setResponse(statusCode.getResponseBodyAsString());
        }
        synchronize.setUsername(username);
        synchronize.setCount(0);
        synchronize.setCreatedAt(new Date());
        synchronize.setUpdatedAt(new Date());
        synchronizeRepository.save(synchronize);
    }
    @Override
    public SynchronizeEkycRequest buildSynchronizeEkycRequest(EkycModel ekycModel, Ocr ocr, FaceMatchRawResponse faceMatchRawResponse, FaceMatch3WayResponse faceMatch3WayResponse, String deviceId, EkycType ekycType, IdInternalCheck idInternalCheck) {

        SynchronizeEkycRequest synchronizeEkycRequest = this.buildSynchronizeEkycRequest(ekycModel, ocr, deviceId, ekycType);
        if(EkycType.EKYC.equals(ekycType)) {
            synchronizeEkycRequest.setOcr(this.buildSynchronizeOcrRequest(ocr, idInternalCheck));
        }
        synchronizeEkycRequest.setFaceMatching(this.buildSynchronizeFaceMatchingRequest(faceMatchRawResponse));
        synchronizeEkycRequest.setFaceMatching3Way(this.buildSynchronizeFace3WayRequest(faceMatch3WayResponse));
        return synchronizeEkycRequest;
    }
    private SynchronizeFaceMatchingRequest buildSynchronizeFaceMatchingRequest(FaceMatchRawResponse res) {
        return this.buildSyncFaceMatching(res.getS1(), res.getDetectionTime(), res.getEmbeddingTime(), res.getError());
    }
    SynchronizeFace3WayRequest buildSynchronizeFace3WayRequest(Float s12, Float s23, Float s31,
                                                               Float detectionTime, Float embeddingTime, String error) {
        SynchronizeFace3WayRequest synchronizeFace3WayRequest = new SynchronizeFace3WayRequest();
        synchronizeFace3WayRequest.setS12(s12);
        synchronizeFace3WayRequest.setS23(s23);
        synchronizeFace3WayRequest.setS31(s31);
        synchronizeFace3WayRequest.setDetectionTime(detectionTime);
        synchronizeFace3WayRequest.setEmbeddingTime(embeddingTime);
        synchronizeFace3WayRequest.setError(error);
        synchronizeFace3WayRequest.setPass(Boolean.TRUE);
        return synchronizeFace3WayRequest;
    }
    private SynchronizeFace3WayRequest buildSynchronizeFace3WayRequest(FaceMatch3WayResponse res) {
        return this.buildSynchronizeFace3WayRequest(res.getS12(), res.getS23(), res.getS31(),
                res.getDetectionTime(), res.getEmbeddingTime(), res.getError());
    }
    @Override
    public SynchronizeOcrRequest buildSynchronizeOcrRequest(Ocr ocr, IdInternalCheck idInternalCheck) {
        SynchronizeOcrRequest synchronizeOcrRequest;
        try {
            String result = ocr.getResult();
            Object o = Utils.parseToJson(result);
            OcrResponse ocrResponse  = modelMapper.map(o, OcrResponse.class);
            synchronizeOcrRequest = modelMapper.map(ocrResponse.getResult(), SynchronizeOcrRequest.class);
            synchronizeOcrRequest.setIdName(ocrResponse.getIdName());
            synchronizeOcrRequest.setIdType(ocrResponse.getIdType());
            synchronizeOcrRequest.setFrontBlurScore(ocrResponse.getFrontBlurScore());
            synchronizeOcrRequest.setBackBlurScore(ocrResponse.getBackBlurScore());
            synchronizeOcrRequest.setFrontScreenScore(ocrResponse.getFrontScreenScore());
            synchronizeOcrRequest.setBackScreenScore(ocrResponse.getBackScreenScore());
            synchronizeOcrRequest.setPass(ocr.getPass());
            synchronizeOcrRequest.setExpiryDate(ocrResponse.getResult().getExpireDate());
            synchronizeOcrRequest.setIssuedDate(ocrResponse.getResult().getIssueDate());
            synchronizeOcrRequest.setMrz(this.getMrzDTO(ocrResponse.getResult().getMrz()));
            this.setOcrInfoFromIdInternalCheck(idInternalCheck, synchronizeOcrRequest);
            return synchronizeOcrRequest;
        } catch (Exception e) {
            return null;
        }
    }

    private void setOcrInfoFromIdInternalCheck(IdInternalCheck idInternalCheck, SynchronizeOcrRequest synchronizeOcrRequest) {
        if(idInternalCheck != null && CheckIdInternalType.NFC.name().equalsIgnoreCase(idInternalCheck.getSourceRawData())) {
            NFCUserData nfcUserData = nfcUserDataRepository.findByUsernameAndInternalCheckId(idInternalCheck.getUsername(), idInternalCheck.getId());
            if(nfcUserData != null) {
                synchronizeOcrRequest.setAddress(nfcUserData.getAddress());
                synchronizeOcrRequest.setDob(nfcUserData.getDob());
                synchronizeOcrRequest.setGender(nfcUserData.getGender());
                synchronizeOcrRequest.setAddressCorrection(nfcUserData.getAddress());
                synchronizeOcrRequest.setHometown(nfcUserData.getHomeTown());
                synchronizeOcrRequest.setName(nfcUserData.getName());
                synchronizeOcrRequest.setNationality(nfcUserData.getNationality());
                synchronizeOcrRequest.setIssuedDate(nfcUserData.getIssuedDate());
                synchronizeOcrRequest.setExpiryDate(nfcUserData.getExpiryDate());
            }
        }
    }

    public IdentityPresentResponse identityPresent(String identity){
        try {
            return afcProxy.checkIdentityPresent(identity);
        } catch (HttpStatusCodeException statusCodeException){
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EXCEPTION_MES);
        }
    }

    @Override
    public Object viewEcontractTransaction(Object dto) {
        try {
            return afcProxy.viewEcontractTransaction(dto);
        } catch (HttpStatusCodeException statusCodeException){
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EXCEPTION_MES);
        }
    }

    @Override
    public EkycDetailResponse getEkycDetail(String username) {
        try {
            return afcProxy.getEkycDetail(username);
        } catch (HttpStatusCodeException statusCodeException){
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EXCEPTION_MES);
        }
    }
    private MrzDTO getMrzDTO(Mrz mrz){
        MrzDTO mrzDTO = new MrzDTO();
        if (mrz != null) {
            mrzDTO.setName(mrz.getName());
            mrzDTO.setDob(mrz.getDob());
            mrzDTO.setDobChecksum(mrz.isDobChecksum());
            mrzDTO.setExpireDate(mrz.getExpireDate());
            mrzDTO.setExpireDateChecksum(mrz.isExpireDateChecksum());
            mrzDTO.setIdNumber(mrz.getIdNumber());
            mrzDTO.setId12Checksum(mrz.getId12Checksum());
            mrzDTO.setIdN9Number(mrz.getIdN9Number());
            mrzDTO.setId9Checksum(mrz.getId9Checksum());
            mrzDTO.setNationality(mrz.getNationality());
            mrzDTO.setGender(mrz.getGender());
        }
        return mrzDTO;
    }

    /**
     * Kiểm tra CCCD|CMND đã được ekyc trên app afc
     * @param idNumber
     *
     * @return
     */
    public ApplicationException verifyIdentifyNumber(String idNumber) {
        IdentityPresentResponse identityPresentResponse = this.identityPresent(idNumber);
        LogUtils.info("[EKycService] verifyIdentifyNumber");
        if (identityPresentResponse != null && identityPresentResponse.getIdentityProfile() != null) {
            String username = identityPresentResponse.getIdentityProfile().getUsername();
            LogUtils.info("[EKycService] verifyIdentifyNumber identityPresentResponse username", username + " - " +JWTUtils.getUsername());
            String currentUser = JWTUtils.getUsername();
            if(!currentUser.equals(username)) {
                if (username != null) username = username.substring(username.length() - 3);
                idNumber = idNumber.substring(idNumber.length() - 3);
                String message = String.format(Error.CCCD_EKYC_IDENTIFIED.getMessage(), username, idNumber);
                return new ApplicationException(Error.CCCD_EKYC_IDENTIFIED.getCode(), message);
            }
        }
        return null;
    }
    @Override
    public SynchronizeEkycRequest buildSynchronizeEkycRequest(EkycModel ekycModel, Ocr ocr, EkycResponseModel liveness,
                                                              String deviceId, EkycType ekycType, IdInternalCheck idInternalCheck){
        SynchronizeEkycRequest synchronizeEkycRequest = this.buildSynchronizeEkycRequest(ekycModel, ocr, deviceId, ekycType);
        if(EkycType.EKYC.equals(ekycType)) {
            synchronizeEkycRequest.setOcr(this.buildSynchronizeOcrRequest(ocr, idInternalCheck));
        }
        Float s1 = liveness.getFaceMatching().getCompare().getScore();
        SynchronizeFaceMatchingRequest fmReq = this.buildSyncFaceMatching(s1, null, null,
                null);
        synchronizeEkycRequest.setFaceMatching(fmReq);
        Compares compares = liveness.getLiveness().getCompares();
        Float s12 = compares.getS12().getScore();
        Float s23 = compares.getS23().getScore();
        Float s31 = compares.getS31().getScore();
        SynchronizeFace3WayRequest f3wReq = this.buildSynchronizeFace3WayRequest(s12, s23, s31, null, null, null);
        synchronizeEkycRequest.setFaceMatching3Way(f3wReq);
        return synchronizeEkycRequest;
    }

    private SynchronizeFaceMatchingRequest buildSyncFaceMatching(Float s1, Float detectionTime, Float embeddingTime,
                                                                 String error){
        SynchronizeFaceMatchingRequest synchronizeFaceMatchingRequest = new SynchronizeFaceMatchingRequest();
        synchronizeFaceMatchingRequest.setDetectionTime(detectionTime);
        synchronizeFaceMatchingRequest.setError(error);
        synchronizeFaceMatchingRequest.setEmbeddingTime(embeddingTime);
        synchronizeFaceMatchingRequest.setS1(s1);
        synchronizeFaceMatchingRequest.setPass(Boolean.TRUE);
        return synchronizeFaceMatchingRequest;
    }
    private SynchronizeEkycRequest buildSynchronizeEkycRequest(EkycModel ekycModel, Ocr ocr, String deviceId, EkycType ekycType){
        SynchronizeEkycRequest synchronizeEkycRequest = new SynchronizeEkycRequest();

        if(EkycType.EKYC.equals(ekycType)) {
            synchronizeEkycRequest.setQrCodeImageURL(ekycModel.getQrCodeImageURL());
            List<FraudCheck> fraudChecks = new ArrayList<>();
            fraudChecks.add(FraudCheck.builder().system(SourceAppType.DIGITAL_LENDING.getValue())
                    .status(true).rules(fraudCheckRules.split(",")).build());
            synchronizeEkycRequest.setFraudChecks(fraudChecks);
            synchronizeEkycRequest.setQrCode(ekycModel.getQrCode());
            synchronizeEkycRequest.setCardType(ekycModel.getCardType());
            synchronizeEkycRequest.setObjectId(ocr.getId());
        }
        synchronizeEkycRequest.setStatus(ekycModel.getStatus());
        synchronizeEkycRequest.setFrontImageURL(ekycModel.getFrontImageURL());
        synchronizeEkycRequest.setBackImageURL(ekycModel.getBackImageURL());
        synchronizeEkycRequest.setLeftImageURL(ekycModel.getLeftImageURL());
        synchronizeEkycRequest.setRightImageURL(ekycModel.getRightImageURL());
        synchronizeEkycRequest.setSelfieImageURL(ekycModel.getSelfieImageURL());
        synchronizeEkycRequest.setType(ekycType.getValue());
        synchronizeEkycRequest.setUsername(ekycModel.getUsername());
        synchronizeEkycRequest.setDeviceId(deviceId);
        synchronizeEkycRequest.setEkycCode(ekycModel.getEkycCode());
        synchronizeEkycRequest.setOriginSystem(ekycModel.getSystem());
        return synchronizeEkycRequest;
    }

    @Override
    public void pushUserNotify(String username) {
        try {
            AfcNotifyRequest request = new AfcNotifyRequest();
            request.setKeyNoti(keyNotify);
            request.setSystemId(systemId);
            request.setUsernames(List.of(username));
            afcProxy.pushUserNotify(request);
        } catch (Exception e) {
            LogUtils.error("[AfcServiceImpl] pushUserNotify error", e.getMessage());
        }
    }

    @Override
    public AccessTokenV7DTO loginV7(LoginDTO body){
        return afcProxy.loginV7(body);
    }
}

