package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "liveness")
public class Liveness {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "request_id") // Require: Request id
    private String requestId;
    @Column(name = "selfie_code")
    private String selfieCode;
    @Column(name = "left_code")
    private String leftCode;
    @Column(name = "right_code")
    private String rightCode;
    @Column(name = "status")
    private String status;
    @Column(name = "front_dimension", columnDefinition = "text")
    private String frontDimension;
    @Column(name = "selfie_dimension", columnDefinition = "text")
    private String selfieDimension;
    @Column(name = "code")
    private String code;
    @Column(name = "ocr_code")
    private String ocrCode;
    @Column(name = "citizen_id")
    private String citizenId;
    @Column(name = "liveness_pass")
    private Boolean livenessPass;
    @Column(name = "liveness_result", columnDefinition = "text")
    private String livenessResult;
    @Column(name = "face_matching_result", columnDefinition = "text")
    private String faceMatchingResult;
    @Column(name = "face_matching_pass")
    private Boolean faceMatchingPass;
    @Column(name = "condition_score")
    private Float conditionScore;
    @Column(name = "s1")
    private Float s1;
    @Column(name = "s12")
    private Float s12;
    @Column(name = "s23")
    private Float s23;
    @Column(name = "s31")
    private Float s31;
    @Column(name = "face_cutoff_score")
    private Float faceCutoffScore;
    @Column(name ="error_code")
    private String errorCode;
    @Column(name ="right_image_url")
    private String rightImageUrl;
    @Column(name ="left_image_url")
    private String leftImageUrl;
    @Column(name ="selfie_image_url")
    private String selfieImageUrl;
    @Column(name ="error_message", columnDefinition = "text")
    private String errorMessage;

    @Column(name = "device_id", length = 36)
    private String deviceId;
    @Column(name = "username", length = 10, nullable = false)
    private String username;
    @Column(name = "type", length = 10, nullable = false)
    private String type;

    @CreationTimestamp
    @Column(name = "created_at")
    private Date createdAt;
    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updatedAt;
}
