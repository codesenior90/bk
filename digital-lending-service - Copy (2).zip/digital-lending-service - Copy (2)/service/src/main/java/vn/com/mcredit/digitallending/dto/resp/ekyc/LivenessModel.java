package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;


@Data
public class LivenessModel {
    private Compares compares;
    private Float conditionScore;
    private Boolean pass;
}
