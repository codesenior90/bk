package vn.com.mcredit.digitallending.dto.resp.aws_auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AssumeRoleResponse{
    @JsonProperty("AssumeRoleResult")
    public AssumeRoleResult assumeRoleResult;
    @JsonProperty("ResponseMetadata")
    public ResponseMetadata responseMetadata;
}
