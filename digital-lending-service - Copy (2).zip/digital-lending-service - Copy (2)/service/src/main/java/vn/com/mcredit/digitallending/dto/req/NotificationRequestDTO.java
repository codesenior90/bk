package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class NotificationRequestDTO
{
    private String topic = "KAFKA_DEFAULT";
    private String contentType;
    private String caseNumber;
    private String requestId;
    private String contractNumber;
    private String status;
    private String sourceCreate;
    private Object message;
    private String system;
    private String deviceId;
}
