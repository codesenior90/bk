package vn.com.mcredit.digitallending.proxy;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Component("basedProxy")
public class BaseProxy {

    @Value("${custom.properties.am-api-manager-host}")
    protected String apiManagerHost;

    @Value("${custom.properties.am-api-manager-client-key}")
    protected String amClientKey;

    @Value("${custom.properties.am-api-manager-client-secret}")
    protected String amClientSecret;

    private String keyXVersion= "x-version";
    private String keyXSecurity= "x-security";

    private String miniAppAccessKey = "x-application-access";
    private String miniAppScretKey = "x-application-secret";

    private static final String USERNAME = "username";

    @Autowired
    RestTemplate restTemplate;

    protected Gson gson = new Gson();

    protected HttpHeaders initHeader() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED );
        headers.setAccept(Collections.singletonList(MediaType.ALL));
        return headers;
    }

    protected HttpHeaders initHeader(String username, String password, MediaType mediaType) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(mediaType);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setBasicAuth(username, password);
        return headers;
    }

    public HttpHeaders initHeader(String beareToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setBearerAuth(beareToken);
        return headers;
    }

    protected HttpHeaders initHeaderAppJson() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON );
        return headers;
    }
    protected HttpHeaders initHeaderAppJson(String username) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON );
        headers.set(USERNAME, username);
        return headers;
    }

    protected HttpHeaders initHeader(Map<String, String> headerKeys) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON );
        headers.setAll(headerKeys);
        return headers;
    }

    protected <T> Object get(String api, Class<T> clazz) {
        HttpEntity<String> entity = new HttpEntity<>(initHeader());
        ResponseEntity<T> response = restTemplate.exchange(api, HttpMethod.GET, entity, clazz);
        return response.getBody();
    }

    public <T> T get(String api, HttpHeaders headers, Class<T> clazz) {
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<T> response = restTemplate.exchange(api, HttpMethod.GET, entity, clazz);
        return response.getBody();
    }
    protected <T> T post(String api, HttpHeaders headers, String payload, Class<T> clazz) {

        final HttpEntity<String> entity = new HttpEntity<>(payload,
                headers);
        ResponseEntity<T> response = restTemplate.exchange(api, HttpMethod.POST, entity, clazz);
        return response.getBody();
    }
    protected <T> T post(String api, Object payload, Class<T> clazz) {
        HttpEntity<Object> entity = new HttpEntity<>(payload);
        ResponseEntity<T> response = restTemplate.exchange(api, HttpMethod.POST, entity, clazz);
        return response.getBody();
    }
    protected <T> T post(String api, HttpHeaders headers, Object payload, Class<T> clazz) {

        final HttpEntity<Object> entity = new HttpEntity<>(payload, headers);
        ResponseEntity<T> response = restTemplate.exchange(api, HttpMethod.POST, entity, clazz);

        return response.getBody();

    }
    protected HttpHeaders initHeaderWithContentType() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        return headers;
    }

    protected HttpHeaders initCustomerServiceHeader(String beareToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setBearerAuth(beareToken);
        return headers;
    }
    protected HttpHeaders initOpenAPIHeader(String accessKey, String secretKey) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(miniAppAccessKey, accessKey);
        headers.set(miniAppScretKey, secretKey);
        return headers;
    }
    protected HttpHeaders initEContractHeader(String xVersion, String xSecurity, String accessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(keyXVersion, xVersion);
        headers.set(keyXSecurity, xSecurity);
        headers.setBearerAuth(accessToken);
        return headers;
    }

    protected HttpHeaders initEContractHeaderFile(String xVersion, String xSecurity, String accessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.ALL));
        headers.set(keyXVersion, xVersion);
        headers.set(keyXSecurity, xSecurity);
        headers.setBearerAuth(accessToken);
        return headers;
    }

    protected HttpHeaders initEContractHeader(String xVersion, String xSecurity) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(keyXVersion, xVersion);
        headers.set(keyXSecurity, xSecurity);
        return headers;
    }

    protected HttpHeaders initHeaderMultipartFormData(String bearerToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setBearerAuth(bearerToken);
        return headers;
    }
    protected HttpHeaders initHeaderMultipartFormData() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        return headers;
    }
    protected HttpHeaders initHeaderAppFormUrl() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        return headers;
    }

    protected <T> T postAppFormUrl(String username, String password, String api, HttpHeaders headers, Class<T> clazz) {
        MultiValueMap<String, String> map= new LinkedMultiValueMap<>();
        map.add("grant_type", "client_credentials");
        map.add("client_secret", password);
        map.add("client_id", username);
        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, headers);
        ResponseEntity<T> response = restTemplate.exchange(api, HttpMethod.POST, httpEntity, clazz);
        return response.getBody();
    }

    protected <T> T postAppFormUrl( String api, HttpHeaders headers, MultiValueMap<String, String> map, Class<T> clazz) {
        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, headers);
        ResponseEntity<T> response = restTemplate.exchange(api, HttpMethod.POST, httpEntity, clazz);
        return response.getBody();
    }


    protected HttpHeaders initHeaderFormData2(String accessToken) {
        var headers = new HttpHeaders();
        headers.set(HttpHeaders.ACCEPT, MediaType.MULTIPART_FORM_DATA_VALUE);
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setBearerAuth(accessToken);
        return headers;
    }
    protected HttpHeaders initHeaderFormData2() {
        var headers = new HttpHeaders();
        headers.set(HttpHeaders.ACCEPT, MediaType.MULTIPART_FORM_DATA_VALUE);
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        return headers;
    }
}
