package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class OcrScore {
    @JsonProperty("screen_detection_score")
    private String screenDetectionScore;
    @JsonProperty("screen_detection_result")
    private String screenDetectionResult;
}
