package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.CallLogApi;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;

@Repository
public interface CallApiLogRepository extends JpaRepository<CallLogApi, String> {
    @Query(value = "SELECT * FROM call_log_api WHERE username=:username and uri=:uri and created_at >= :createdAt order by created_at desc", nativeQuery = true)
    List<CallLogApi> findByUsernameAndUri(@Param("username") String username,@Param("uri") String uri, @Param("createdAt") Date createdAt);
    @Query(value = "SELECT * FROM call_log_api WHERE username=:username and created_at >= :createdAt order by created_at desc", nativeQuery = true)
    List<CallLogApi> findByUsername(@Param("username") String username, @Param("createdAt") Date createdAt);
    @Modifying
    @Transactional
    @Query(value = "delete FROM call_log_api where created_at <= :createdAt", nativeQuery = true)
    void cleanUpData(@Param("createdAt") Date createdAt);
}
