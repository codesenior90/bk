package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.req.FaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.req.OcrForm;
import vn.com.mcredit.digitallending.dto.req.UpdateFaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.req.ekyc.*;
import vn.com.mcredit.digitallending.dto.resp.OcrResponse;
import vn.com.mcredit.digitallending.dto.resp.OcrResultResponse;
import vn.com.mcredit.digitallending.dto.resp.ekyc.*;
import vn.com.mcredit.digitallending.entity.Liveness;
import vn.com.mcredit.digitallending.entity.Ocr;
import vn.com.mcredit.digitallending.enums.*;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.RecognitionProxy;
import vn.com.mcredit.digitallending.repositories.LivenessRepository;
import vn.com.mcredit.digitallending.services.AwsS3Service;
import vn.com.mcredit.digitallending.services.RecognitionService;
import vn.com.mcredit.digitallending.utils.*;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@RequiredArgsConstructor
public class RecognitionServiceImpl extends OcrBaseService implements RecognitionService {
    public static final String USERNAME = "username";
    public static final String SYSTEM = "system";
    public static final String SYSTEMS = "systems";
    public static final String CARD_TYPE = "cardType";
    public static final String SCREEN_DETECTION_SCORE = "screenDetectionScore";
    public static final String OCR_CODE = "ocrCode";
    public static final String CONDITION_SCORE = "conditionScore";
    public static final String FACE_CUT_OFF_SCORE = "faceCutoffScore";
    public static final String SHOW_VECTOR = "showVector";
    public static final String IP_ADDRESS = "ipAddress";

    @Value("${custom.properties.cutoff-screen}")
    private Float cutoffScreen;
    @Value("${custom.properties.rate-face-match-raw}")
    private Float rateFaceMatchRaw;
    @Value("${custom.properties.rate-face-match-3way}")
    private Float rateFaceMatch3Way;
    @Value("${custom.properties.aws-s3-folder-task-name}")
    private String folderTaskName;
    private final RecognitionProxy proxy;
    private final AwsS3Service awsS3Service;
    private final ModelMapper modelMapper;
    private final LivenessRepository livenessRepository;

    public OcrResponse ocr(OcrForm form, String username){
        OcrRecognitionResp resp;
        Ocr ocr = new Ocr();
        ocr.setUsername(username);
        try {
            resp = proxy.ocr(this.buildOcrRequest(form));
            LogUtils.info("[RecognitionService] ocr resp", resp);
            boolean pass = this.verifyCutOff(resp);
            String idNumber = null;
            String cardGroup = null;
            String name = null;
            String address = null;
            String gender = null;
            String dob = null;
            String issueDate = null;
            String expireDate = null;
            if (resp != null){
                idNumber =  resp.getInfo().getIdNumber();
                cardGroup = resp.getCardGroup();
                name = resp.getInfo().getName();
                gender = resp.getInfo().getGender();
                address = resp.getInfo().getAddress();
                dob = resp.getInfo().getDob();
                issueDate = resp.getInfo().getIssueDate();
                expireDate = resp.getInfo().getExpireDate();
            }
            LogUtils.info("[RecognitionService] ocr", idNumber);
            this.upload(form.getFrontImg(), form.getBackImg(), username, idNumber, ocr);
            this.saveOcr(resp, ocr, null, pass, form.getProcessEkyc());
            this.verifyCCCDChip(ocr, cardGroup, idNumber, name, gender, address);
            if (!pass) throw new ApplicationException(Error.FAIL_OCR_CCCD_CHIP.name(), Error.FAIL_OCR_CCCD_CHIP.getMessage());
            this.validateInformationOcr(ocr, idNumber, gender, dob, issueDate, expireDate);
            this.verifyIdentifyNumber(ocr, idNumber, form.getProcessEkyc());
        } catch (IOException e) {
            LogUtils.error("[RecognitionService] ocr IOException", e.getMessage());
            this.saveOcr(null, ocr, e.getMessage(), false, form.getProcessEkyc());
            throw new ApplicationException(Error.FAIL_OCR_CCCD_CHIP.name(), Error.FAIL_OCR_CCCD_CHIP.getMessage());
        } catch (HttpStatusCodeException e){
            LogUtils.error("[RecognitionService] ocr HttpStatusCodeException", e.getResponseBodyAsString());
            this.saveOcr(null, ocr, e.getResponseBodyAsString(), false, form.getProcessEkyc());
            throw new ApplicationException(e.getStatusCode().name(), e.getStatusText());
        }
        return this.map(resp);
    }
    OcrResponse map(OcrRecognitionResp resp){
        OcrResponse ocrResponse = new OcrResponse();
        ocrResponse.setRequestId(resp.getCode());
        ocrResponse.setIdType(resp.getCardGroupType());
        ocrResponse.setIdName(resp.getCardGroup());
        ocrResponse.setResult(this.map(resp.getInfo()));
        ocrResponse.setStatus(true);
        return ocrResponse;
    }
    OcrResultResponse map(OcrModel model) {
        return modelMapper.map(model, OcrResultResponse.class);
    }
    /**
     * Tạo request Body ocr
     * @param form
     * @return
     * @throws IOException
     */
    @Override
    public MultiValueMap<String, Object> buildOcrRequest(OcrForm form) throws IOException {
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        Utils.addMapImage(body, FRONT, form.getFrontImg());
        Utils.addMapImage(body, BACK, form.getBackImg());
        body.add(SCREEN_DETECTION_SCORE, cutoffScreen);
        this.addData(body);
        return body;
    }

    private MultiValueMap<String, Object> buildFaceMatchingRequest(String ocrCode, Boolean showVector, MultipartFile selfieFile) throws IOException {
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        Utils.addMapImage(body, SELFIE, selfieFile);
        body.add(OCR_CODE, ocrCode);
        body.add(CONDITION_SCORE, rateFaceMatchRaw);
        body.add(SHOW_VECTOR, showVector);
        this.addData(body);
        return body;
    }

    private MultiValueMap<String, Object> buildLivenessRequest(String ocrCode, Boolean showVector, MultipartFile selfie, MultipartFile right, MultipartFile left, MultipartFile front) throws IOException {
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        if (front != null) Utils.addMapImage(body, FRONT, front);
        if(selfie != null) Utils.addMapImage(body, SELFIE, selfie);
        if(right != null) Utils.addMapImage(body, RIGHT, right);
        if(left != null) Utils.addMapImage(body, LEFT, left);

        if (StringUtils.isNotBlank(ocrCode )) body.add(OCR_CODE, ocrCode);
        body.add(CONDITION_SCORE, rateFaceMatchRaw);
        body.add(FACE_CUT_OFF_SCORE, rateFaceMatch3Way);
        if(showVector != null) body.add(SHOW_VECTOR, showVector);
        this.addData(body);
        return body;
    }
    private void addData(MultiValueMap<String, Object> body) {
        body.add(USERNAME,JWTUtils.getUsername());
        body.add(SYSTEM, SourceAppType.DIGITAL_LENDING.name());
        body.add(IP_ADDRESS, HttpReqRespUtils.getClientIpAddress());
    }

    private boolean verifyCutOff(OcrRecognitionResp resp){
        return  (resp == null || resp.getFrontScreenScore() == null || resp.getBackScreenScore() == null
                || resp.getFrontScreenScore().getScreenDetectionScore() <= cutoffScreen
                || resp.getBackScreenScore().getScreenDetectionScore() <= cutoffScreen);
    }

    private void saveOcr(OcrRecognitionResp resp, Ocr ocr, String errorResult, Boolean pass, Integer processEkyc){
        if (resp != null){
            ocr.setRequestId(resp.getCode());
            ocr.setIdType(resp.getCardGroupType());
            ocr.setIdName(resp.getCardGroup());
            ocr.setStatus(Constants.ACTIVE.equalsIgnoreCase(resp.getStatus()));
            ocr.setPass(pass);
            ocr.setTicketStatus(TicketState.OPEN.getValue());
            ocr.setFrontImage(resp.getFrontImage());
            ocr.setBackImage(resp.getBackImage());
            if (resp.getInfo() != null) {
                OcrModel info = resp.getInfo();
                ocr.setIdNumber(info.getIdNumber());
                ocr.setName(info.getName());
                ocr.setDob(info.getDob());
                ocr.setAddressCorrection(info.getAddressCorrection());
                ocr.setNationality(info.getNationality());
                if (Gender.MALE.getValue().equalsIgnoreCase(info.getGender())){
                    ocr.setGender(Gender.MALE.name());
                } else if (Gender.FEMALE.getValue().equalsIgnoreCase(info.getGender())){
                    ocr.setGender(Gender.FEMALE.name());
                } else {
                    ocr.setGender(info.getGender());
                }
                ocr.setAddress(info.getAddress());
                ocr.setExpiryDate(info.getExpireDate());
                ocr.setIssuedDate(info.getIssueDate());
                ocr.setHomeTown(info.getHometown());
                ocr.setHometownCorrection(info.getHometownCorrection());
                ocr.setDob(info.getDob());
            }
            ocr.setResult(Utils.toJson(this.convertOcrData(resp)));
            String partnerCode = JWTUtils.getPartnerCode();
            if(StringUtils.isNotBlank(partnerCode))
                ocr.setPartnerCode(partnerCode);
            ocr.setFrontScreenDetectionScore(resp.getFrontScreenScore().getScreenDetectionScore());
            ocr.setBackScreenDetectionScore(resp.getBackScreenScore().getScreenDetectionScore());
        } else {
            ocr.setPass(pass);
            ocr.setResult(errorResult);
        }
        if(processEkyc != null) {
            ocr.setProcessEkyc(processEkyc);
        }
        ocr.setCreatedAt(new Date());
        ocr.setUpdatedAt(new Date());
        ocr.setSourceEkyc(SourceEKYC.EKYC_CENTRALIZATION.getValue());
        ocrRepository.save(ocr);
    }

    @Override
    public EkycResponseModel faceMatching(String ocrCode, Boolean showVector, String username, MultipartFile selfieFile) {
        EkycResponseModel model = null;
        try {
            model = proxy.faceMatching(this.buildFaceMatchingRequest(ocrCode, showVector, selfieFile));
        } catch (IOException e) {
            LogUtils.error("[RecognitionService] faceMatching", e.getMessage());
        }
        return model;
    }

    @Override
    public EkycResponseModel liveness(String ocrCode, String idNumber, MultipartFile selfie, MultipartFile right, MultipartFile left, MultipartFile front) {
        EkycResponseModel model = null;
        Liveness liveness = this.initLiveness();
        try {
            Map<String, String> map = this.uploadImages(null, null, selfie, left, right, idNumber);
            String rightImgUrl = map.get(Constants.RIGHT);
            String leftImgUrl = map.get(Constants.LEFT);
            String selfieImgUrl = map.get(Constants.SELFIE);
            this.verifyImageUrls(rightImgUrl, leftImgUrl, selfieImgUrl);
            this.setImageUrls(liveness, rightImgUrl, leftImgUrl, selfieImgUrl);

            model = proxy.liveness(this.buildLivenessRequest(ocrCode, true, selfie, right, left, front));
            if (model != null){
                this.setImageUrls(model, rightImgUrl, leftImgUrl, selfieImgUrl);
                this.buildLiveness(model, liveness, LivenessType.LIVENESS.name());
            }
        } catch (HttpStatusCodeException e){
            LogUtils.error("[RecognitionService] liveness HttpStatusCodeException", e.getResponseBodyAsString());
            this.buildLivenessError(liveness, e.getStatusCode().name(), e.getStatusText());
        } catch (IOException e) {
            LogUtils.error("[RecognitionService] liveness", e.getMessage());
            this.buildLivenessError(liveness, Constants.APP_EXCEPTION_CODE, e.getMessage());
        }
        this.storeLiveness(liveness);
        return model;
    }

    @Override
    public EkycResponseModel liveness(String username, String idNumber, String ocrCode, Boolean showVector, FaceMatchingDTO dto){
        EkycResponseModel model = null;
        Liveness liveness = this.initLiveness();
        try {
            String rightImgUrl = dto.getRightImgURL();
            String leftImgUrl = dto.getLeftImgURL();
            String selfieImgUrl = dto.getSelfieImgURL();

            if (!ProcessTypeEnum.EKYC_NOT_DL_FULL.getValue().equals(dto.getProcessEkyc())) {
                Map<String, String> map = this.uploadImages(null, null, dto.getSelfieImg(), dto.getLeftImg(), dto.getRightImg(), idNumber);
                rightImgUrl = map.get(Constants.RIGHT);
                leftImgUrl = map.get(Constants.LEFT);
                selfieImgUrl = map.get(Constants.SELFIE);
            }
            this.setImageUrls(liveness, rightImgUrl, leftImgUrl, selfieImgUrl);
            this.verifyImageUrls(rightImgUrl, leftImgUrl, selfieImgUrl);
            model = proxy.liveness(this.buildLivenessRequest(ocrCode, showVector, dto.getSelfieImg(), dto.getRightImg(), dto.getLeftImg(), null));
            if (model != null) {
                this.setImageUrls(model, rightImgUrl, leftImgUrl, selfieImgUrl);
                this.buildLiveness(model, liveness, LivenessType.LIVENESS.name());
                this.storeLiveness(liveness);
            }
        } catch (HttpStatusCodeException e){
            LogUtils.error("[RecognitionService] liveness HttpStatusCodeException", e.getResponseBodyAsString());
            this.storeLiveness(this.buildLivenessError(liveness, e.getStatusCode().name(), e.getStatusText()));
        } catch (IOException e) {
            LogUtils.error("[RecognitionService] liveness", e.getMessage());
            this.storeLiveness(this.buildLivenessError(liveness, Constants.APP_EXCEPTION_CODE, e.getMessage()));

        }
        return model;
    }

    private void setImageUrls(EkycResponseModel model, String rightImgUrl, String leftImgUrl, String selfieImgUrl) {
        model.setRightImageUrl(rightImgUrl);
        model.setLeftImageUrl(leftImgUrl);
        model.setSelfieImageUrl(selfieImgUrl);
    }

    private void setImageUrls(Liveness liveness, String rightImgUrl, String leftImgUrl, String selfieImgUrl) {
        liveness.setRightImageUrl(rightImgUrl);
        liveness.setLeftImageUrl(leftImgUrl);
        liveness.setSelfieImageUrl(selfieImgUrl);
    }

    private void storeLiveness(Liveness liveness){
        try {
            if (liveness != null) {
                livenessRepository.save(liveness);
            }
        } catch (Exception e){
            LogUtils.error("[RecognitionService] storeLiveness", e.getMessage());
        }
    }
    private Liveness buildLivenessError(Liveness liveness, String errorCode, String errorMessage){
        if (liveness == null) liveness = new Liveness();
        liveness.setDeviceId(JWTUtils.getDeviceId());
        liveness.setUsername(JWTUtils.getUsername());
        liveness.setErrorCode(errorCode);
        liveness.setErrorMessage(errorMessage);
        liveness.setStatus(Constants.INACTIVE);
        return liveness;
    }

    private Liveness initLiveness(){
        Liveness liveness = new Liveness();
        liveness.setUsername(JWTUtils.getUsername());
        liveness.setDeviceId(JWTUtils.getDeviceId());
        return liveness;
    }
    private Liveness buildLiveness(EkycResponseModel ekycResponseModel, Liveness liveness, String type){
        liveness.setCode(ekycResponseModel.getCode());
        liveness.setOcrCode(ekycResponseModel.getOcrCode());
        liveness.setSelfieCode(ekycResponseModel.getSelfieCode());
        liveness.setType(type);
        liveness.setCitizenId(ekycResponseModel.getCitizenId());
        liveness.setStatus(ekycResponseModel.getStatus());
        liveness.setLeftCode(ekycResponseModel.getLeftCode());
        liveness.setRightCode(ekycResponseModel.getRightCode());
        liveness.setFrontDimension(ekycResponseModel.getFrontDimension());
        liveness.setSelfieDimension(ekycResponseModel.getSelfieDimension());
        liveness.setStatus(ekycResponseModel.getStatus());
        liveness.setFaceCutoffScore(rateFaceMatch3Way);
        liveness.setConditionScore(rateFaceMatchRaw);

        if (ekycResponseModel.getLiveness() != null){
            if (ekycResponseModel.getLiveness().getCompares() != null) {
                if(ekycResponseModel.getLiveness().getCompares().getS12() != null){
                    liveness.setS12(ekycResponseModel.getLiveness().getCompares().getS12().getScore());
                }
                if(ekycResponseModel.getLiveness().getCompares().getS23() != null) {
                    liveness.setS23(ekycResponseModel.getLiveness().getCompares().getS23().getScore());
                }
                if(ekycResponseModel.getLiveness().getCompares().getS31() != null) {
                    liveness.setS31(ekycResponseModel.getLiveness().getCompares().getS31().getScore());
                }
            }
            liveness.setLivenessResult(Utils.toJson(ekycResponseModel.getLiveness()));
            liveness.setLivenessPass(ekycResponseModel.getLiveness().getPass());
        }

        if (ekycResponseModel.getFaceMatching() != null){
            if (ekycResponseModel.getFaceMatching().getCompare() != null)
                liveness.setS1(ekycResponseModel.getFaceMatching().getCompare().getScore());
            liveness.setFaceMatchingResult(Utils.toJson(ekycResponseModel.getFaceMatching()));
            liveness.setFaceMatchingPass(ekycResponseModel.getFaceMatching().getPass());
        }

        return liveness;
    }

    private void verifyImageUrls(String rightImgUrl, String leftImgUrl, String selfieImgUrl) {
        if (StringUtils.isBlank(rightImgUrl) || StringUtils.isBlank(leftImgUrl) || StringUtils.isBlank(selfieImgUrl)) {
            LogUtils.info("[EKycService] faceMatchingV2=> update image to s3 error");
            this.storeLiveness(this.buildLivenessError(null, Error.SYSTEM_ERROR.getCode(), "Error upload image to s3"));
            throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
        }
    }

    @Override
    public EkycResponseModel livenessWithoutOcr(String username, String idNumber, Boolean showVector, UpdateFaceMatchingDTO dto){
        EkycResponseModel model = null;
        try {
            Map<String, String> map = this.uploadImages(null, null, dto.getSelfieImg(), dto.getLeftImg(), dto.getRightImg(), idNumber);
            String rightImgUrl = map.get(Constants.RIGHT);
            String leftImgUrl = map.get(Constants.LEFT);
            String selfieImgUrl = map.get(Constants.SELFIE);
            Liveness liveness = this.initLiveness();
            this.setImageUrls(liveness, rightImgUrl, leftImgUrl, selfieImgUrl);
            this.verifyImageUrls(rightImgUrl, leftImgUrl, selfieImgUrl);
            model = proxy.livenessWithoutOcrDL(this.buildLivenessRequest(null, showVector, dto.getSelfieImg(), dto.getRightImg(), dto.getLeftImg(), null));
            if (model != null) {
                this.setImageUrls(model, rightImgUrl, leftImgUrl, selfieImgUrl);
                this.buildLiveness(model, liveness, LivenessType.LIVENESS_WITHOUT_OCR.name());
                this.storeLiveness(liveness);
            }
        } catch (HttpStatusCodeException e) {
            LogUtils.error("[RecognitionService] livenessWithoutOcr HttpStatusCodeException", e.getResponseBodyAsString());
        } catch (IOException e) {
            LogUtils.error("[RecognitionService] livenessWithoutOcr", e.getMessage());
        }
        return model;
    }
    private Map<String, String> uploadImages(MultipartFile front, MultipartFile back, MultipartFile selfie, MultipartFile left, MultipartFile right, String idNumber){
        Map<String, String> map = new HashMap<>();
        String filePath = Utils.generateFilePathOnS3(folderTaskName, JWTUtils.getUsername(), idNumber);
        List<CompletableFuture<String>> listCF = new ArrayList<>();
        CompletableFuture<String> frontCF = null;
        CompletableFuture<String> backCF = null;
        CompletableFuture<String> selfieCF = null;
        CompletableFuture<String> leftCF = null;
        CompletableFuture<String> rightCF = null;
        if (front != null){
            frontCF = CompletableFuture.supplyAsync(()-> awsS3Service.upload(front, filePath + Constants.PREFIX_FRONT));
            listCF.add(frontCF);
        }
        if (back != null){
            backCF = CompletableFuture.supplyAsync(()-> awsS3Service.upload(back, filePath + Constants.PREFIX_BACK));
            listCF.add(backCF);
        }
        if (selfie != null){
            selfieCF = CompletableFuture.supplyAsync(()-> awsS3Service.upload(selfie, filePath + Constants.PREFIX_SELFIE));
            listCF.add(selfieCF);
        }
        if (left != null){
            leftCF = CompletableFuture.supplyAsync(()-> awsS3Service.upload(left, filePath + Constants.PREFIX_LEFT));
            listCF.add(leftCF);
        }
        if (right != null){
            rightCF = CompletableFuture.supplyAsync(()-> awsS3Service.upload(right, filePath + Constants.PREFIX_RIGHT));
            listCF.add(rightCF);
        }
        CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(listCF.toArray(new CompletableFuture[0]));
        try {
            combinedFuture.get();
            if (frontCF != null) map.put(Constants.FRONT, frontCF.get());
            if (backCF != null) map.put(Constants.BACK, backCF.get());
            if (selfieCF != null) map.put(Constants.SELFIE, selfieCF.get());
            if (leftCF != null) map.put(Constants.LEFT, leftCF.get());
            if (rightCF != null) map.put(Constants.RIGHT, rightCF.get());
            LogUtils.info("[EKycService] uploadImages");
        } catch (InterruptedException | ExecutionException e) {
            LogUtils.info("[EKycService] checkIdInternal InterruptedException|ExecutionException", e.getMessage());
            Thread.currentThread().interrupt();
        }
        return map;
    }
    private CompletableFuture<MultipartFile> getUserImgFromS3Sync(String url) {
        LogUtils.info("[EKycServiceImpl] getUserImgFromS3Sync");
        return CompletableFuture.supplyAsync(() -> this.getFileFromS3(url));
    }
    /**
     * Download file from S3
     * @param fileUrl
     * @return
     */
    public MultipartFile getFileFromS3(String fileUrl){
        LogUtils.info("[EKycServiceImpl] getFileFromS3 fileUrl", fileUrl);
        return awsS3Service.dowload2S3bucketWithName(Utils.getFileUrlKeyS3(fileUrl), UUID.randomUUID() + ".jpg");
    }
    @Override
    public RecoBlackListRes blacklist(RecoFaceSearchReq req, String username) {
        RecoBlackListRes response = null;
        try {
            response = proxy.blacklistSearch(req);
        } catch (HttpStatusCodeException e) {
            LogUtils.error("[RecognitionService] blacklist", e.getResponseBodyAsString());
        }
        return response;
    }

    @Override
    public RecoFaceIdsRes faceIds(RecoFaceSearchReq req, String username) {
        RecoFaceIdsRes response = null;
        try {
            response = proxy.faceIdsSearch(req);
        } catch (HttpStatusCodeException e) {
            LogUtils.error("[RecognitionService] faceIds", e.getResponseBodyAsString());
        }
        return response;
    }

    @Override
    public RecoIdFacesRes idFaces(RecoFaceSearchReq req, String username) {
        RecoIdFacesRes response = null;
        try {
            response = proxy.idFacesSearch(req);
        } catch (HttpStatusCodeException e) {
            LogUtils.error("[RecognitionService] idFaces", e.getResponseBodyAsString());
        }
        return response;
    }

    @Override
    public RecoAddVectorRes addVector(RecoAddVectorReq req, String username) {
        RecoAddVectorRes response = null;
        try {
            response = proxy.addVector(req);
        } catch (HttpStatusCodeException e) {
            LogUtils.error("[RecognitionService] addVector", e.getResponseBodyAsString());
        }
        return response;
    }

    @Override
    public EkycResponseModel faceMatchRaw(MultipartFile frontImg, MultipartFile selfieImg, String username) {
        return null;
    }

    @Override
    public EkycResponseModel face3way(MultipartFile leftImg, MultipartFile rigthImg, MultipartFile selfieImg) {
        return null;
    }
    @Override
    public NFCVerifyResponse nfcVerify(NFCVerifyRequest request) {
        return proxy.nfcVerify(request);
    }

    @Override
    public RecoCustomerInfoResp checkInfo(String username, String cardType, String systems){
        RecoCustomerInfoResp res = null;
        try {
            MultiValueMap<String, Object> body = new LinkedMultiValueMap();
            body.add(USERNAME,username);
            body.add(SYSTEMS, systems);
            body.add(CARD_TYPE, cardType);
            res = proxy.checkInfo(body);
            this.handleCheckInfo(res, null);
        } catch (HttpStatusCodeException e){
            this.handleCheckInfo(null, e);
        }
        return res;
    }
    private void handleCheckInfo(RecoCustomerInfoResp res, HttpStatusCodeException e){
        if (res != null) {
            LogUtils.info("[RecognitionService] handleCheckInfo success", res.getOcrCode() + " - " + res.getEkycCode());
        } else if(e != null){
            LogUtils.info("[RecognitionService] handleCheckInfo HttpStatusCodeException error", e.getResponseBodyAsString());
        }
    }
    @Override
    public DimensionByEkycCodeResp getDimensionByEkycCode(String code){
        DimensionByEkycCodeResp res = null;
        try {
            res = proxy.getByEkycCode(code);
            this.handleByEkycCode(res, null);
        } catch (HttpStatusCodeException e){
            this.handleByEkycCode(null, e);
        }
        return res;
    }
    private void handleByEkycCode(DimensionByEkycCodeResp resp, HttpStatusCodeException e){
        if (resp != null) {
            LogUtils.info("[RecognitionService] handleByEkycCode success");
        } else if(e != null){
            LogUtils.info("[RecognitionService] handleByEkycCode failure", e.getResponseBodyAsString());
        }
    }
    private OcrResponse convertOcrData(OcrRecognitionResp resp){

        OcrResponse ocrResponse = new OcrResponse();
        ocrResponse.setStatus(Constants.ACTIVE.equalsIgnoreCase(resp.getStatus()));
        ocrResponse.setRequestId(resp.getCode());
        ocrResponse.setIdName(resp.getCardGroup());
        ocrResponse.setFrontBlurScore(Utils.toJson(resp.getFrontScreenScore()));
        ocrResponse.setBackBlurScore(Utils.toJson(resp.getBackScreenScore()));
        ocrResponse.setFrontScreenScore(Utils.toJson(resp.getFrontScreenScore()));
        ocrResponse.setBackScreenScore(Utils.toJson(resp.getBackScreenScore()));

        OcrResultResponse result = modelMapper.map(resp.getInfo(), OcrResultResponse.class);
        ocrResponse.setResult(result);
        return ocrResponse;
    }
    @Override
    public EkycResponseModel livenessWithoutFace(String ocrCode, Boolean showVector, String selfieImgURL, String leftImgURL, String rightImgURL) {
        EkycResponseModel model = null;
        Liveness liveness = new Liveness();
        try {
            model = proxy.livenessWithoutFace(this.buildLivenessRequest(ocrCode, showVector, null, null, null, null));
            if (model != null) {
                this.buildLiveness(model, liveness, LivenessType.LIVENESS_WITHOUT_FACE.name());
                liveness.setSelfieImageUrl(selfieImgURL);
                liveness.setLeftImageUrl(leftImgURL);
                liveness.setRightImageUrl(rightImgURL);
                this.storeLiveness(liveness);
            }
        } catch (HttpStatusCodeException e) {
            LogUtils.error("[RecognitionService] livenessWithoutFace HttpStatusCodeException", e.getResponseBodyAsString());
            this.storeLiveness(this.buildLivenessError(liveness, e.getStatusCode().name(), e.getStatusText()));
        } catch (IOException e) {
            LogUtils.error("[RecognitionService] livenessWithoutFace io-exception", e.getMessage());
            this.storeLiveness(this.buildLivenessError(liveness, Constants.APP_EXCEPTION_CODE, e.getMessage()));
        }
        return model;
    }
}
