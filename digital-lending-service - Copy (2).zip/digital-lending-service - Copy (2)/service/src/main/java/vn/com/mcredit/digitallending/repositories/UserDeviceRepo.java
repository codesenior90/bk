package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.UserDevice;

import javax.transaction.Transactional;

@Repository
public interface UserDeviceRepo extends JpaRepository<UserDevice, String> {
    @Query(value = "SELECT * FROM user_device u where u.username = :username and u.device_id = :deviceId order by u.last_updated desc limit 1", nativeQuery = true)
    UserDevice findLastUserDevice(String username, String deviceId);

    @Modifying
    @Transactional
    @Query(value = "UPDATE user_device SET status = 'UNVERIFIED' where username = :username  and status = 'VERIFIED'", nativeQuery = true)
    void updateUserDeviceStatus(String username);
}
