package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class CheckIdInternalDTO {
    @NotNullorEmpty(message = "Vui lòng cung cấp chuỗi qrcode")
    private String qr;
    @NotNullorEmpty(message = "Vui lòng cung cấp ocr id")
    private String ocrId;
}
