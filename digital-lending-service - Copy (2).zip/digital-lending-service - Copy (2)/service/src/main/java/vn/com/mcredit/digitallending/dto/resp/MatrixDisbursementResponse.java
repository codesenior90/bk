package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class MatrixDisbursementResponse {
    private String bankCode;
    private String disbursementType;
    private String disbursementModel;
}
