package vn.com.mcredit.digitallending.enums;

public enum ApplicationType {
    MINIAPP("MINIAPP");

    private String value;

    ApplicationType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
