package vn.com.mcredit.digitallending.dto;

import lombok.Data;

@Data
public class PreCheckResultDTO {
    private String result;
    private String caseNumber;
}
