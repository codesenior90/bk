package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class CheckAccountResponse {
    private String clientMessageId;
    private String data;
    private String returnCode;
    private String returnMes;
}
