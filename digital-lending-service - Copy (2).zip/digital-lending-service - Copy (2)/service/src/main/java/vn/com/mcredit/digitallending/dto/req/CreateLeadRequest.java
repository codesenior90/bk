package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

import java.math.BigInteger;

@Data
public class CreateLeadRequest {
    private String requestId;
    private String phoneNumber;
    private String telcoCode;
    private String scoreRange;
    private String nationalId;
    private String source;
    private String fullName;
    private String province;
    private String incomeLevel;
    private String other;
    private String refId;
    private String partner;
    private String campaignCode;
    private String dob;
    private String gender;
    private String address;
    private Integer cardType;
    private BigInteger loanAmount;
}
