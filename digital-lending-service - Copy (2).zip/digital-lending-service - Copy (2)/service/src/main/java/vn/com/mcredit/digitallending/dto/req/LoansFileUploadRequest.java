package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class LoansFileUploadRequest {
    private String loansProfileId;
    private String type;
    private String url;
    private String name;
    private String sourceUpload;
    private String fileType;
}
