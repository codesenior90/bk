package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HomeLendingResponse {
    private String bannerUrl;
    private String title;
    private String content;
    @JsonProperty("mainImageUrl")
    private String mainImageUrl;
    @JsonProperty("maxValueLendingTitle")
    private String maxValueLendingTitle;
    @JsonProperty("maxValueLending")
    private Integer maxValueLending;
    @JsonProperty("minValueVending")
    private Integer minValueVending;
    @JsonProperty("ratePerMonth")
    private Double ratePerMonth;
    @JsonProperty("monthLending")
    private Integer monthLending;
    @JsonProperty("conditions")
    private List<ConditionLendingResponse> conditions;
}
