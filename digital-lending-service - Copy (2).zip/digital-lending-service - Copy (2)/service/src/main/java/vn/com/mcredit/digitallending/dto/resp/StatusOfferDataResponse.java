package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatusOfferDataResponse {
    @JsonProperty("detailOffer")
    private String detailOffer;
    @JsonProperty("process")
    private String process;
    @JsonProperty("loanAmtMinusInsu")
    private Double loanAmtMinusInsu;
    @JsonProperty("loanAmount")
    private Integer loanAmount;
    @JsonProperty("approveAmount")
    private Double approveAmount;
    @JsonProperty("insuranceFee")
    private Double insuranceFee;
    @JsonProperty("insuranceRate")
    private Double insuranceRate;
    @JsonProperty("loanTenor")
    private BigInteger loanTenor;
    @JsonProperty("insuranceCompany")
    private String insuranceCompany;
    @JsonProperty("interestRate")
    private Double interestRate;
    @JsonProperty("loanMethod")
    private String loanMethod;
    @JsonProperty("campaignCode")
    private String campaignCode;
    @JsonProperty("campaignName")
    private String campaignName;
    @JsonProperty("offerId")
    private BigInteger offerId;
    @JsonProperty("expiredTime")
    private Date expiredTime;
    @JsonProperty("remainTime")
    private long remainTime;
    @JsonProperty("remainTimeUnit")
    private String remainTimeUnit;
    @JsonProperty("offerStatus")
    private String offerStatus;
    @JsonProperty("requestId")
    private String requestId;
    @JsonProperty("codeStatus")
    private List<CodeStatus> codeStatus;
}
