package vn.com.mcredit.digitallending.dto.req.contract;

import lombok.Data;

@Data
public class ContractDTO {
    private String username;
    private String citizenId;
    private String contractCode;
}
