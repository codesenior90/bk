package vn.com.mcredit.digitallending.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LogDTO {

    private Map<String, Object> headers = new HashMap<>();
    private Map<String, Object> message = new HashMap<>();
    private Object payload;

    @SerializedName("error-message")
    @JsonProperty("error-message")
    private String errorMes;

    @SerializedName("print-stack-trace")
    @JsonProperty("print-stack-trace")
    private String printStackTrace;

    @SerializedName("elapsed-time-in-milliseconds")
    @JsonProperty("elapsed-time-in-milliseconds")
    private String elapsedTimeInMilliseconds;

    @SerializedName("error")
    @JsonProperty("error")
    private Object responseError;

    @SerializedName("success")
    @JsonProperty("success")
    private Object responseSuccess;
}