package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class CheckOfferRequestDTO {
    private String idNumber;
    private String oldIdNumber;
    private String xsell;
    private Integer loanAmount;
    private String requestId;
}
