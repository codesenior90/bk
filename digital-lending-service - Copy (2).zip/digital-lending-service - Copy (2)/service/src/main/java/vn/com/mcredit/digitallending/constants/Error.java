package vn.com.mcredit.digitallending.constants;

import vn.com.mcredit.digitallending.utils.StringUtils;

import java.util.HashMap;

public enum Error {
    BAD_REQUEST("400", "Bad Request"),
    SYSTEM_ERROR("500", "Đã có lỗi xảy ra"),
    REDIS_CONNECTION_ERROR("REDIS_CONNECTION_ERROR", "Đã có lỗi xảy ra"),
    SUCCESS("200", "Success"),
    BAD_REQUEST_400_01("400.01", "Kiem tra gioi tinh: Khong thoa man dieu kien"),
    BAD_REQUEST_400_02("400.02", "Kiem tra logic nam sinh: Khong thoa man dieu kien"),
    BAD_REQUEST_400_03("400.03", "Kiem tra logic thang sinh: Khong thoa man dieu kien"),
    BAD_REQUEST_400_04("400.04", "Kiem tra logic ngay sinh: Khong thoa man dieu kien"),
    BAD_REQUEST_400_05("400.05", "Check logic năm hết hạn CCCD: Khong thoa man dieu kien"),
    BAD_REQUEST_400_06("400.06", "CCCD or CMDN khong dung dinh dang"),
    BAD_REQUEST_400_07("400.07", "OCR FAIL"),
    BAD_REQUEST_400_08("400.08", "Không phải CCCD!"),
    FAIL_ID_LOGIC("FAIL_ID_LOGIC", "CCCD/CMND không hợp lệ"),
    FAIL_ID_DUP("FAIL_ID_DUP", "CCCD/CMND không khớp Dup"),
    FAIL_ID_OFFLINE("FAIL_ID_OFFLINE", "CCCD/CMND không khớp offline"),
    FAIL_ID_TD_WATCHLIST("FAIL_ID_TDWATCHLIST", "CCCD/CMND thuộc watchlist từ nguồn thẩm định"),
    FAIL_ID_COMPARE("FAIL_ID_COMPARE","Xác thực không thành công. Thông tin trên CCCD hiện tại không khớp với thông tin đã đăng ký trước đó với Mcredit. Vui lòng xác thực lại."),
    FAIL_PRE_CHECK_BLACKLIST("FAIL_PRECHECK_BLACKLIST", "KH thuộc blacklist data"),
    FAIL_PRE_CHECK_LSTD("FAIL_PRECHECK_LSTD", "LSTD khách hàng không thỏa điều kiện vay"),
    FAIL_PRE_CHECK_DUP("FAIL_PRECHECK_DUP", "KH không thỏa điều kiện check Dup"),
    FAIL_PRE_CHECK_LIMIT("FAIL_PRECHECK_LIMIT", "KH không thỏa điều kiện hạn mức"),
    FAIL_IMAGE_DUP("FAIL_IMAGE_DUP", "Ảnh CCCD không khớp Dup"),
    FAIL_IMAGE_ID_INFO("FAIL_IMAGE_ID_INFO", "Trùng ảnh CCCD khác thông tin"),
    FAIL_IMAGE_BLACKLIST("FAIL_IMAGE_BLACKLIST", "Ảnh CCCD thuộc blacklist ảnh"),
    FAIL_PHONE_NUMBER_DUP("FAIL_PHONENUMBER_DUP", "SĐT khách hàng không khớp kho Dup"),
    FAIL_IMAGE_MB("FAIL_IMAGE_MB", "Ảnh CCCD không khớp dữ liệu bên ngoài"),
    FAIL_IMAGE_HTC("FAIL_IMAGE_HTC", "Ảnh CCCD không khớp dữ liệu bên ngoài"),
    FAIL_PHONE_NUMBER_OFFLINE("FAIL_PHONENUMBER_OFFLINE", "SĐT khách hàng không khớp kho offline"),
    FAIL_PHONE_NUMBER_TELCO("FAIL_PHONENUMBER_TELCO", "SĐT khách hàng không khớp kho telco"),
    FAIL_LSTD_CUS_PCB("FAIL_LSTD_CUS_PCB", "PCB khách hàng không thỏa điều kiện vay"),
    FAIL_LSTD_MAR_PCB("FAIL_LSTD_MAR_PCB", "LSTD người hôn phối không thỏa điều kiện vay"),
    FAIL_MAR_ID("FAIL_MAR_ID", "CCCD/CMND người hôn phối không hợp lệ"),
    FAIL_ACCOUNT_BANK("FAIL_ACCOUNTBANK", "Tài khoản giải ngân không hợp lệ"),
    FAIL_OTHER("FAIL_OTHER", "KH không thỏa điều kiện vay KHÁC"),
    FAIL_INCORRECT_INPUT("FAIL_INCORRECT_INPUT", "INPUT không hợp lệ (Thiếu input, sai định dạng…)"),
    FAIL_OCR_CCCD_CHIP("FAIL_OCR_CCCD_CHIP", "CCCD/CMND không hợp lệ"),
    FAIL_INCORRECT_CCCD_CHIP("FAIL_INCORRECT_CCCD_CHIP", "Không phải CCCD gắn chip"),
    FAIL_FACE_MATCHING("FAIL_FACE_MATCHING", "Lỗi so khớp ảnh khách hàng trong CCCD và ảnh chính diện."),
    FAIL_FACE_MATCHING_3WAY("FAIL_FACE_MATCHING_3WAY", "Lỗi so khớp ảnh trái, ảnh phải và ảnh chính diện của khách hàng."),
    FAIL_PROCESS_OCR("FAIL_PROCESS_OCR", "Có lỗi khi xử lý kết quả ocr"),
    FAIL_PROCESS_FACE_MATCHING("FAIL_PROCESS_FACE_MATCHING", "Có lỗi khi xử lý face matching"),
    FAIL_PROCESS_FACE_MATCHING_3WAY("FAIL_PROCESS_FACE_MATCHING_3WAY", "Có lỗi khi xử lý face matching 3way"),
    OCR_NOT_READY("OCR_NOT_READY", "Chưa thực hiện lấy thông tin!"),
    INFORMATION_OCR_INCORRECT("INFORMATION_OCR_INCORRECT", "Thông tin không khớp!"),
    CHECK_ID_INTERNAL_NOT_READY("CHECK_ID_INTERNAL_NOT_READY", "Chưa kiểm tra id nội bộ!"),
    CHECK_ID_INTERNAL_NOT_INCORRECT("CHECK_ID_INTERNAL_NOT_INCORRECT", "Có lỗi khi kiểm tra thông tin qr!"),
    CITIZEN_ID_ERROR("CITIZEN_ID_ERROR", "Số CMND/CCCD không hợp lệ. Vui lòng kiểm tra và thực hiện chụp lại. Trân trọng cảm ơn!"),
    FRONT_IMG_NULL("500044","Ảnh chứng minh thư hoặc căn cước công dân mặt trước không được để trống"),
    FRONT_IMG_INVALID("500045","Ảnh chứng minh thư hoặc căn cước công dân mặt trước không đúng định dạng"),
    BACK_IMG_NULL("500006","Ảnh chứng minh thư hoặc căn cước công dân mặt sau không được để trống"),
    BACK_IMG_INVALID("500047","Ảnh chứng minh thư hoặc căn cước công dân mặt sau không đúng định dạng"),
    SELFIE_IMG_INVALID("500049","Ảnh mặt chụp chân dung không đúng định dạng"),
    LEFT_IMG_NULL("500050","Ảnh mặt chụp quay trái không được để trống"),
    LEFT_IMG_INVALID("500051","Ảnh mặt chụp quay trái không đúng định dạng"),
    RIGHT_IMG_NULL("500052","Ảnh mặt chụp quay phải không được để trống"),
    RIGHT_IMG_INVALID("500053","Ảnh mặt chụp quay phải không đúng định dạng"),
    SELFIE_IMG_NULL("500048","Ảnh mặt chụp chân dung không được để trống"),
    CCCD_EKYC_IDENTIFIED("CCCD_EKYC_IDENTIFIED", "Mỗi CCCD chỉ được dùng 01 số điện thoại. Bạn đã dùng số điện thoại xxxxxxx%s để xác thực CCCD số xxxxxxxxx%s."),
    PHONE_EKYC_IDENTIFIED("PHONE_EKYC_IDENTIFIED", "Số điện thoại đã được định danh"),
    PHONE_EKYC_IDENTIFIED_AT_OTHER_SYSTEM("PHONE_EKYC_IDENTIFIED_AT_OTHER_SYSTEM", "Rất tiếc, bạn chưa thể vay lúc này. Mcredit sẽ hỗ trợ bạn trong thời gian tới. Bạn vui lòng quay lại sau nhé"),
    ERROR_RELATIVE_PHONE_NUMBER_SPOUSE("ERROR_RELATIVE_PHONE_NUMBER_SPOUSE", "Số điện thoại %s %skhông đúng định dạng"),
    ERROR_MIN_RELATIVE_REFERENCE_PERSON("ERROR_MIN_RELATIVE_REFERENCE_PERSON", "Ít nhất 1 người tham chiếu và 1 người thân."),
    ERROR_RELATIVES_PERSON("ERROR_RELATIVES_PERSON", "Số người thân không hợp lệ"),
    ERROR_MIN_RELATIVE_SPOUSE_PERSON("ERROR_MIN_RELATIVE_SPOUSE_PERSON", "Thông tin người hôn phối không được để trống"),
    ERROR_RELATIVE_PHONE_NUMBER_FORMAT("ERROR_RELATIVE_SPOUSE_PHONE_NUMBER_FORMAT", "Số điện thoại %s %skhông đúng định dạng."),
    ERROR_RELATIVE_ID_NUMBER_FORMAT("ERROR_RELATIVE_ID_NUMBER_FORMAT", "Số CCCD %s %skhông đúng định dạng."),
    ERROR_RELATIVE_INFO_EMPTY("ERROR_RELATIVE_INFO_EMPTY", "Thông tin người hôn phối không được để trống."),
    ERROR_RELATIVE_PHONE_DUPLICATE("ERROR_RELATIVE_PHONE_DUPLICATE", "Số điện thoại người tham chiếu/người hôn phối trùng nhau."),
    ERROR_RELATIVE_PHONE_DUPLICATE_WITH_USER("ERROR_RELATIVE_PHONE_DUPLICATE_WITH_USER", "Số điện thoại người tham chiếu/người hôn phối trùng nhau với số điện thoại khách hàng vay."),
    ERROR_RELATIVE_ID_NUMBER_DUPLICATE_WITH_USER("ERROR_RELATIVE_ID_NUMBER_DUPLICATE_WITH_USER", "Số CCCD người tham chiếu/người hôn phối trùng nhau với số CCCD khách hàng vay."),
    FAIL_LOCATION_TELCO("FAIL_LOCATION_TELCO", "KH không thỏa location telco"),
    ISSUE_DATE_INVALID_FORMAT("ISSUE_DATE_INVALID", "Ngày phát hành CCCD không hợp lệ"),
    EXPIRE_DATE_INVALID_FORMAT("EXPIRE_DATE_INVALID_FORMAT", "Ngày hết hạn CCCD không hợp lệ"),
    ID_NUMBER_INVALID_FORMAT("ID_NUMBER_INVALID_FORMAT", "Số CCCD không hợp lệ"),
    DOB_INVALID_FORMAT("DOB_INVALID_FORMAT", "Ngày sinh không hợp lệ"),
    DEVICE_VERIFICATION_ERROR("DEVICE_VERIFICATION_ERROR", "Khách hàng thay đổi thiết bị."),
    EXPIRE_DATE_LESS_ISSUE_DATE("EXPIRE_DATE_LESS_ISSUE_DATE", "Ngày hết hạn nhỏ hơn hoặc bằng ngày cấp."),
    GENDER_INVALID("GENDER_INVALID", "Giới tính không đúng (Nam|Nữ)"),
    DUPLICATE_METHOD("DUPLICATE_SUBMISSION", "Yêu cầu đang được xử lý"),
    MISS_DEVICE_ID("MISS_DEVICE_ID", "MISS_DEVICE_ID"),
    FAIL_DEVICEID("FAIL_DEVICEID", "Mỗi thiết bị chỉ đăng ký vay với 1 số điện thoại. Bạn đã đăng ký vay tiền trên thiết bị này với số: *xxxxxx%s*"),
    MISS_LEFT_IMG("MISS_LEFT_IMG", "Thiếu ảnh trái."),
    MISS_RIGHT_IMG("MISS_RIGHT_IMG", "Thiếu ảnh phải"),
    MISS_SELFIE_IMG("MISS_SELFIE_IMG", "Thiếu ảnh chính diện."),
    MISS_LEFT_IMG_URL("MISS_LEFT_IMG_URL", "Thiếu URL ảnh trái."),
    MISS_RIGHT_IMG_URL("MISS_RIGHT_IMG_URL", "Thiếu URL ảnh phải"),
    MISS_SELFIE_IMG_URL("MISS_SELFIE_IMG_URL", "Thiếu URL ảnh chính diện."),
    FAIL_VOICECAPCHA_OVER3TIMES("FAIL_VOICECAPCHA_OVER3TIMES", "Captcha được sử dụng quá 3 lần!"),
    FAIL_VOICE_CAPTCHA_SYSTEM("FAIL_VOICE_CAPTCHA_SYSTEM", ""),
    VOICE_CAPTCHA_INVALID("VOICE_CAPTCHA_INVALID", "Chuỗi captcha không đúng."),
    VOICE_CAPTCHA_NOT_MATCH("VOICE_CAPTCHA_NOT_MATCH", "Chuỗi captcha không khớp."),
    FAIL_CAPTCHA_EXPIRED("FAIL_CAPTCHA_EXPIRED", "Chuỗi captcha hết hạn."),
    ENCRYPT_DATA_ERROR("ENCRYPT_DATA_ERROR", "Dịch vụ tạm thời gián đoạn, bạn vui lòng thực hiện lại sau ít phút."),
    DECRYPT_DATA_ERROR("DECRYPT_DATA_ERROR", "Dịch vụ tạm thời gián đoạn, bạn vui lòng thực hiện lại sau ít phút."),
    ID_NUMBER_DO_NOT_MATCH_NFC("ID_NUMBER_DO_NOT_MATCH", "Số CCCD không trùng khớp NFC"),
    DEVICE_ID_IS_EMPTY("DEVICE_ID_IS_EMPTY", "Mã thiết bị không được để trống"),
    ACCOUNT_ERROR("ACCOUNT_ERROR", "Thông tin đăng nhập không đúng"),
    ACCOUNT_REGISTER_ERROR("ACCOUNT_REGISTER_ERROR", "Thông tin đăng ký không đúng"),
    RSA_NOTFOUND("RSA_NOTFOUND", "Không thể giải mã thông tin"),
    CUSTOMER_ADDRESS_INVALID("CUSTOMER_ADDRESS_INVALID", "Thông tin địa chỉ khách hàng không được để trống!"),
    CUSTOMER_ADDRESS_LIVE_MISS("CUSTOMER_ADDRESS_LIVE_MISS", "Thiếu thông tin địa chỉ tạm trú!"),
    CUSTOMER_ADDRESS_PERMANENT_MISS("CUSTOMER_ADDRESS_PERMANENT_MISS", "Thiếu thông tin địa chỉ thường trú!"),
    ERROR_RELATIVE_PHONE_THE_SAME_USER("ERROR_RELATIVE_PHONE_THE_SAME_USER", "SDT người tham chiếu | hôn phối trùng với SDT khách hàng"),
    ERROR_RELATIVE_PHONE_ARE_THE_SAME_USER("ERROR_RELATIVE_PHONE_ARE_THE_SAME_USER", "SDT người tham chiếu | hôn phối trùng nhau"),
    ACCOUNT_NUMBER_INVALID("ACCOUNT_NUMBER_INVALID", "Số tài khoản không hợp lệ"),
    ACCOUNT_NONE_LV3("ACCOUNT_NONE_LV3", "Trước khi nhận tiền về tài khoản, bạn cần đến điểm giao dịch của MB bank để xác nhận danh tính."),
    ERROR_CHECK_LV3("ERROR_CHECK_LV3", "Lỗi kiểm tra định danh tài khoản"),
    ERROR_CUST_PROCESSIONAL_INVALID("ERROR_CUST_PROCESSIONAL_INVALID", "Nghề nghiệp không đúng."),
    ERROR_MARITAL_STATUS_INVALID("ERROR_MARITAL_STATUS_INVALID", "Tình trạng hôn nhân không đúng."),
    ERROR_INCOME_RANGE_INVALID("ERROR_INCOME_RANGE_INVALID", "Khoảng thu nhập không đúng."),
    FAIL_ACCBANK_INVALID("FAIL_ACCBANK_INVALID", "Tài khoản giải ngân không active"),
    FAIL_ACCBANK_INFO("FAIL_ACCBANK_INFO", "Tài khoản giải ngân không khớp thông tin"),
    FAIL_ACCBANK_LEVEL3("FAIL_ACCBANK_LEVEL3", "KH không được định danh level 3"),
    FAIL_NFC_VERIFY("FAIL_NFC_VERIFY", "Xác thực NFC không thành công"),
    FAIL_FACE_IMAGE_NFC_VERIFY("FAIL_IMAGE_NFC_VERIFY", "Xác thực NFC không thành công"),
    ERROR_CASE_NUMBER("ERROR_CASE_NUMBER", "Case number không hợp lệ"),
    ERROR_PARTNER_CODE("ERROR_PARTNER_CODE", "Mã đối tác để trống hoặc không đúng"),
    PARTNER_CODE_IS_EMPTY("PARTNER_CODE_IS_EMPTY", "Mã đối tác không được để trống"),
    INVALID_DISBURSEMENT_DATA("INVALID_DISBURSEMENT_DATA", "Thông tin giải ngân không hợp lệ"),
    FAIL_VOICECAPCHA_INPUT("FAIL_VOICECAPCHA_INPUT", ""),
    FAIL_VOICECAPCHA_TOOLOUD("FAIL_VOICECAPCHA_TOOLOUD", ""),
    FAIL_VOICECAPCHA_TOOQUIET("FAIL_VOICECAPCHA_TOOQUIET", ""),
    FAIL_VOICECAPCHA_MULTI("FAIL_VOICECAPCHA_MULTI", ""),
    FAIL_CHECK_HAS_LOAN("FAIL_CHECK_HAS_LOAN", "KH đã có hạn mức trên MC."),
    FAIL_CHECK_AML("FAIL_CHECK_AML", "KH trùng blacklist AML"),
    FAIL_CHECK_AML_SCORE("FAIL_CHECK_AML_SCORE", "KH cần nhập thêm SĐT của cơ quan và địa chỉ của cơ quan.")
    ;
    private static HashMap<String, String> valueToTextMapping;

    private String code;
    private String message;

    Error(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public static String getStringValueFromKey(String code) {
        try {
            for (Error gender : Error.values()) {
                if (gender.getCode().equalsIgnoreCase(code)) {
                    return gender.getMessage();
                }
            }
            return StringUtils.EMPTY;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public String toString() {
        return code + ": " + message;
    }
}
