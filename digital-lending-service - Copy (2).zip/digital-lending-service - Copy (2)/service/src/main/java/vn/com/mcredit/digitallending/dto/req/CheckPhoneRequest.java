package vn.com.mcredit.digitallending.dto.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;
import vn.com.mcredit.digitallending.validator.Username;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CheckPhoneRequest {
    @NotNullorEmpty(message = "Vui lòng nhập số điện thoại.")
    @Username
    private String mobilePhone; // Số điện thoại
}
