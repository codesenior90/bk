package vn.com.mcredit.digitallending.enums;

public enum CardType {
    CCCD_CHIP("cccd_new"),
    CCCD_CHIP_TYPE("6"), //
    CCCD("1"), // cccd
    CMTND2("2"), // cmt12
    CMTND1("3"),// cmt09
    INVALID_CARD("-1")
    ;
    private String value;

    CardType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
