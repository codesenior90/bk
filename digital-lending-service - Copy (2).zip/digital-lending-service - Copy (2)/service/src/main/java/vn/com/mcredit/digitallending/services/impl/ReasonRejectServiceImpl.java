package vn.com.mcredit.digitallending.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.dto.resp.ReasonRejectResponse;
import vn.com.mcredit.digitallending.entity.ReasonReject;
import vn.com.mcredit.digitallending.repositories.ReasonRejectRepository;
import vn.com.mcredit.digitallending.services.ReasonRejectService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReasonRejectServiceImpl implements ReasonRejectService {

    @Autowired
    private ReasonRejectRepository reasonRejectRepository;


    @Override
    public List<ReasonRejectResponse> getAllByActiveAndType(boolean isActive, String type) {
        List<ReasonReject> data = reasonRejectRepository.getAllByActiveAndType(isActive, type);
        return data.stream().map(ReasonRejectResponse :: toResponseData).collect(Collectors.toList());
    }
}
