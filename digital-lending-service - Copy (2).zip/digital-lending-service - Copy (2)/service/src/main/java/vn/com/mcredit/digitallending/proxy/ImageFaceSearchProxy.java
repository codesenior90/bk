package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.resp.AddVectorResponse;
import vn.com.mcredit.digitallending.dto.resp.BlacklistCheckResponse;
import vn.com.mcredit.digitallending.dto.resp.FaceIdsCheckResponse;
import vn.com.mcredit.digitallending.dto.resp.IdFacesCheckResponse;

@Component
public class ImageFaceSearchProxy extends BaseProxy {
    @Value("${custom.properties.face-search-api-host}")
    protected String imageFaceSearchHost;
    public BlacklistCheckResponse blacklistCheck(Object body){
        String url = String.format("%s%s", imageFaceSearchHost, "/blacklist_search_vector");
        return this.post(url, initHeaderAppJson(), body, BlacklistCheckResponse.class);    }

    public IdFacesCheckResponse idFacesCheck(Object body){
        String url = String.format("%s%s", imageFaceSearchHost, "/id_faces_search_vector");
        return this.post(url, initHeaderAppJson(), body, IdFacesCheckResponse.class);
    }

    public FaceIdsCheckResponse faceIdsCheck(Object multiValueMap){
        String url = String.format("%s%s", imageFaceSearchHost, "/face_ids_search_vector");
        return this.post(url, initHeaderAppJson(), multiValueMap, FaceIdsCheckResponse.class);
    }
    public AddVectorResponse addVector(Object request){
        String url = String.format("%s%s", imageFaceSearchHost, "/addVector");
        return this.post(url, initHeaderAppJson(), request, AddVectorResponse.class);
    }
}
