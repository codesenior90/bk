package vn.com.mcredit.digitallending.services;

public interface SynchronizeService {
    void synchronizes();
}
