package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.Synchronize;

import java.util.List;

@Repository
public interface SynchronizeRepository  extends JpaRepository<Synchronize, String> {
    @Query(value = "SELECT * FROM synchronize s WHERE s.http_status_code in :status order by s.created_at ASC limit :limit", nativeQuery = true)
    List<Synchronize> findSynchronizeFailure(List<Integer> status, int limit);
}
