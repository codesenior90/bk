package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class LocationCheckResult {
    private LocationCheckDataResult province;
    private LocationCheckDataResult district;
    private LocationCheckDataResult ward;


}
