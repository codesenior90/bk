package vn.com.mcredit.digitallending.aop;

import com.google.common.net.InetAddresses;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import vn.com.mcredit.digitallending.constants.WebConstants;
import vn.com.mcredit.digitallending.exceptions.ForbiddenException;
import vn.com.mcredit.digitallending.helper.EnvironmentHelper;
import vn.com.mcredit.digitallending.utils.LogUtils;


import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

/**
 * chặn chỉ cho các request trong nội bộ các cluster
 */
@Aspect
@Configuration
@Order(0)
@SuppressWarnings("all")
public class InternalApiAspect {



    @Autowired
    private EnvironmentHelper environmentHelper;

    @Before("@annotation(vn.com.mcredit.digitallending.aop.InternalApi)")
    public void before(JoinPoint j) {
        // Nếu trường hợp là môi trường dev thì không cần phải bắt buộc gọi nội bộ giữa các service trên kubernate
        if(environmentHelper.isDev()){
            return;
        }
        try {
            HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes()))
                    .getRequest();
            var originalAddress = request.getHeader(WebConstants.Headers.X_ORIGIN_FORARDER_FOR);
            if (StringUtils.isNotBlank(originalAddress)) {
                String[] addressList = originalAddress.split(",");
                for (String address : addressList) {
                    String ip = StringUtils.substringBefore(address, ":");
                    if (!isPrivateV4Address(ip.trim()) && !isLocalAddress(ip.trim())) {
                        throw new ForbiddenException();
                    }
                }
            }
        } catch (Exception e) {
            LogUtils.error("Error check IP address ex = " + e.getMessage());
            throw new ForbiddenException();
        }

    }

    /**
     * check ip in range
     * 192.168.0.0 - 192.168.255.255 (192.168/16 prefix)
     * 172.16.0.0 - 172.31.255.255 (172.16/12 prefix)
     * 10.0.0.0 - 10.255.255.255 (10/8 prefix)
     */
    private static boolean isPrivateV4Address(String ip) {
        int address = InetAddresses.coerceToInteger(InetAddresses.forString(ip));
        return (((address >>> 24) & 0xFF) == 10)
                || ((((address >>> 24) & 0xFF) == 172) && ((address >>> 16) & 0xFF) >= 16 && ((address >>> 16) & 0xFF) <= 31)
                || ((((address >>> 24) & 0xFF) == 192) && (((address >>> 16) & 0xFF) == 168));
    }

    /**
     * 127.0.0.1
     * 0.0.0.0
     */
    private static boolean isLocalAddress(String ip) {
        return "127.0.0.1".equals(ip) || "0.0.0.0".equals(ip);
    }
}
