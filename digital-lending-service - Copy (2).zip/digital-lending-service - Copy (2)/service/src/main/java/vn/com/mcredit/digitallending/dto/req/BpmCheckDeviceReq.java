package vn.com.mcredit.digitallending.dto.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BpmCheckDeviceReq {
    private String deviceId;
    private String numberPhone;
    private String requestId;
}
