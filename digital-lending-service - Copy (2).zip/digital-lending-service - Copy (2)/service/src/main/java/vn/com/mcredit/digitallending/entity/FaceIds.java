package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "face_ids")
public class FaceIds {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "request_id") // Require: Request id
    private String requestId;

    @Column(name = "response_id") // Require: Response id
    private String responseId;

    @Column(name = "request_date") // Require: Thời điểm gửi request
    private String requestDate;

    @Column(name = "error_code") // Mã lỗi nghiệp vụ
    private String errorCode;

    @Column(name = "message", columnDefinition = "text") // lỗi nghiệp vụ
    private String message;
    @Column(name = "img_search_selfie_img_cut_off_threshold") // Ngưỡng cut-off trùng ảnh selfie
    private Float imgSearchSelfieImgCutOffThreshold;

    @Column(name = "img_search_id_img_cut_off_threshold") // Ngưỡng cut-off trùng ảnh ID
    private Float imgSearchIdImgCutOffThreshold;

    @Column(name = "image_search_by_image_check_detail", columnDefinition = "text") // Thông tin của khách hàng đã có trên BPM và kết quả check từng trường thông tin
    private String imageIdInfoDetails;

    @Column(name = "image_search_by_image_check_result") // Kết quả check
    private Boolean imageSearchByIdCheckResult;
    @Column(name = "username")
    private String username;
    @Column(name = "ocr_request_id")
    private String ocrRequestId;

    @Column(name = "error_message", columnDefinition = "text")
    private String errorMessage;

    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;
    @Column(name = "source_ekyc", length = 36)
    private String sourceEkyc;
}
