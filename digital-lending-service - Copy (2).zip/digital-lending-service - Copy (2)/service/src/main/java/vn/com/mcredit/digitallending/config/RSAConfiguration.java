package vn.com.mcredit.digitallending.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import vn.com.mcredit.digitallending.security.Aes;
import vn.com.mcredit.digitallending.security.RSADecryt;
import vn.com.mcredit.digitallending.security.RSAUtil;
import vn.com.mcredit.digitallending.utils.LogUtils;


import javax.annotation.PostConstruct;

@Configuration
public class RSAConfiguration {
    @Value("${custom.aes.secret-key}")
    protected String secretKey;    // aes secret key
    // RSA private key login afc
    @Value("${custom.rsa.auth-private-key}")
    private String loginPrivateKey; // RSA private key

    @Value("${custom.rsa.private-key}")
    private String privateKey; // RSA private key
    @Value("${custom.rsa.public-key}")
    private String publicKey; // RSA public key
    @PostConstruct
    private void initRSAConfig() {

        LogUtils.info("INIT AES VALUE!");
        Aes.init(secretKey);
        LogUtils.info("INIT RSAUtil VALUE!");
        RSAUtil.init(publicKey, privateKey);
        RSADecryt.getInstance().init(loginPrivateKey);
    }
}
