package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "synchronize")
public class Synchronize {

    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name = "request", columnDefinition = "text")
    private String request; // Dữ liệu cần đồng bộ sang afc

    @Column(name = "response", columnDefinition = "text")
    private String response;

    @Column(name = "http_status_text", columnDefinition = "text")
    private String httpStatusText;

    @Column(name = "http_status_code")
    private Integer httpStatusCode;

    @Column(name = "username")
    private String username;

    @Column(name = "count")
    private Integer count;
    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;
}
