package vn.com.mcredit.digitallending.services;

import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.dto.req.FaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.req.ekyc.NFCVerifyRequest;
import vn.com.mcredit.digitallending.dto.req.OcrForm;
import vn.com.mcredit.digitallending.dto.req.UpdateFaceMatchingDTO;


public interface EKycService {
    Object checkIdInternal(MultipartFile qrcodeImg, String qrcode, String requestId);
    Object checkIdInternalNFC(String data);
    Object ocr(OcrForm ocrForm);
    Object faceMatching(FaceMatchingDTO faceMatchingDTO);
    Object updateFaceMatching(UpdateFaceMatchingDTO faceMatchingDTO);
    Object nfcVerify(NFCVerifyRequest request);
    Object ocrV2(OcrForm ocrForm);
    Object checkIdInternalV2(MultipartFile qrcodeImg, String qrcode, String requestId);
    Object faceMatchingV2(FaceMatchingDTO dto);
    Object updateFaceMatchingV2(UpdateFaceMatchingDTO faceMatchingDTO);
}
