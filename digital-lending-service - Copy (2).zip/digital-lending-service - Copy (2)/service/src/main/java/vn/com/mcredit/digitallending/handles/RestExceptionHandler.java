package vn.com.mcredit.digitallending.handles;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.dto.resp.exception.ErrorModel;
import vn.com.mcredit.digitallending.dto.resp.exception.ExceptionData;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.exceptions.ForbiddenException;
import vn.com.mcredit.digitallending.exceptions.UnauthorizedException;
import vn.com.mcredit.digitallending.models.ExceptionDTO;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;
import vn.com.mcredit.digitallending.utils.Utils;
import java.util.ArrayList;
import java.util.List;


@RestControllerAdvice(basePackages = "vn.com.mcredit.digitallending")
@Order(Ordered.HIGHEST_PRECEDENCE)
@Component("RestExceptionHandler")
public class RestExceptionHandler extends Throwable {

    private static final long serialVersionUID = 1L;
    private static final String MESSAGE = Constants.EXCEPTION_MES;

    @ExceptionHandler(ApplicationException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ResponseBody
    @Order(value = Ordered.HIGHEST_PRECEDENCE)
    public ResponseEntity<Object> handleAllException(ApplicationException ex) {
        var mes = ex == null || StringUtils.isNullOrEmpty(ex.getMessage()) ? MESSAGE : ex.getMessage();
        String code = ex == null || StringUtils.isNullOrEmpty(ex.getCode()) ? null : ex.getCode();
        ExceptionDTO exceptionDTO =new ExceptionDTO();
        if(Utils.isJsonString(mes)){
            exceptionDTO.setAlerts(mes);
            exceptionDTO.setMessage(Error.BAD_REQUEST.getMessage());
        } else {
            exceptionDTO.setMessage(mes);
        }
        if (ex != null)
            exceptionDTO.setCount(ex.getCount());
        exceptionDTO.setCode(code);
        LogUtils.error("[RestExceptionHandler] handleAllException", exceptionDTO);
        return new ResponseEntity<>(exceptionDTO, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ResponseBody
    @Order(value = Ordered.HIGHEST_PRECEDENCE)
    public ResponseEntity<DigitalLendingResponse> handleBindException(MethodArgumentNotValidException ex) {
        String mes = Constants.HTTP_MESSAGE;
        String code = Constants.ERROR_400_CODE;
        List<ErrorModel> errorModels = new ArrayList<>();
        ErrorModel errorModel;
        for (ObjectError error : ex.getBindingResult().getAllErrors()) {
            errorModel = new ErrorModel();
            errorModel.setMessage(error.getDefaultMessage());
            errorModels.add(errorModel);
        }
        return new ResponseEntity<>(
                DigitalLendingResponse.builder().code(code).message(mes).data(errorModels).build(),
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(UnauthorizedException.class)
    @ResponseStatus(value = HttpStatus.UNAUTHORIZED)
    @ResponseBody
    @Order(value = Ordered.HIGHEST_PRECEDENCE)
    public ResponseEntity<ExceptionData> handleUnauthorizedException(UnauthorizedException ex) {
        var mes = ex == null || StringUtils.isNullOrEmpty(ex.getMessage()) ? MESSAGE : ex.getMessage();
        ExceptionData obj = ExceptionData.builder().message(mes).build();
        LogUtils.info("[RestExceptionHandler] handleUnauthorizedException: {}" , Utils.toJson(obj));
        return new ResponseEntity<>(obj, HttpStatus.UNAUTHORIZED);
    }
    @ExceptionHandler(ForbiddenException.class)
    @ResponseStatus(value = HttpStatus.FORBIDDEN)
    @ResponseBody
    @Order(value = Ordered.HIGHEST_PRECEDENCE)
    public ResponseEntity<ExceptionDTO> handleForbiddenException(ForbiddenException ex) {
        var mes = ex == null || StringUtils.isNullOrEmpty(ex.getMessage()) ? Constants.FORBIDDEN_MESSAGE : ex.getMessage();
        LogUtils.error("RestExceptionHandler::ForbiddenException: " + ex);
        String code;
        if (ex == null || StringUtils.isNullOrEmpty(ex.getCode())) {
            code = "403";
        } else {
            code = ex.getCode();
        }
        var obj = ExceptionDTO.builder().message(mes).code(code).build();
        return new ResponseEntity<>(obj, HttpStatus.FORBIDDEN);
    }
}
