package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "telco_location")
public class TelcoLocation {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name ="username", length = 16)
    private String username;

    @CreationTimestamp
    @Column(name = "created_at")
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name ="province")
    private String province;

    @Column(name ="district")
    private String district;

    @Column(name ="ward")
    private String ward;

    @Column(name ="ratio_3_months_province")
    private Float ratio3MonthsProvince;

    @Column(name ="ratio_range_3_months_province")
    private String ratioRange3MonthsProvince;

    @Column(name ="ratio_1_month_province")
    private Float ratio1MonthProvince;

    @Column(name ="ratio_range_1_month_province")
    private String ratioRange1MonthProvince;

    @Column(name ="ratio_3_months_district")
    private Float ratio3monthsDistrict;

    @Column(name ="ratio_range_3_months_district")
    private String ratioRange3MonthsDistrict;

    @Column(name ="ratio_1_month_district")
    private Float ratio1MonthDistrict;

    @Column(name ="ratio_range_1_month_district")
    private String ratioRange1MonthPDistrict;

    @Column(name ="ratio_3_months_ward")
    private Float ratio3monthsWard;

    @Column(name ="ratio_range_3_months_ward")
    private String ratioRange3MonthsWard;

    @Column(name ="ratio_1_month_ward")
    private Float ratio1MonthWard;

    @Column(name ="ratio_range_1_month_ward")
    private String ratioRange1MonthWard;

    @Column(name ="error_code", length = 50)
    private String errorCode;

    @Column(name ="message", columnDefinition = "text")
    private String message;

    @Column(name ="response_id", length = 36)
    private String responseId;

    @Column(name ="request_id", unique = true, length = 36)
    private String requestId;

    @Column(name ="dob", length = 36)
    private String dob;

    @Column(name = "status")
    private Boolean status;

}
