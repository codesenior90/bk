package vn.com.mcredit.digitallending.schedule;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import vn.com.mcredit.digitallending.services.LogService;

@Configuration
@EnableScheduling
@RequiredArgsConstructor
public class LogSchedule {
    private static final long TIMES_RETRY = 24 * 60 * 60 * 1000L;
    private final LogService logService;


    public void run(){
        logService.cleanup();
    }
}
