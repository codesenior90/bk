package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

import javax.validation.constraints.NotNull;

@Data
public class VoiceCaptchaDTO {
    @NotNull(message = "File không được để trống")
    private MultipartFile audio;
    @NotNullorEmpty(message = "Dãy số không được để trống")
    private String captcha;
    @NotNullorEmpty(message = "Mã yêu cầu không được để trống")
    private String requestId;
}
