package vn.com.mcredit.digitallending.dto.req.internal;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RegisterAccountRequest {

    private String username;

    private String fullName;

    private String password;

    private String email;

    private String deviceId;
    private String cardNumber;
    private String cardType;
    private String gender;
    private String introducedCode;
    private Boolean isAutoGeneratePassword;
    private String system;
    private String applicationType;
}
