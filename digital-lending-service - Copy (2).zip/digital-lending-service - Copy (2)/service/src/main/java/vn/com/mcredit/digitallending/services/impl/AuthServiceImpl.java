package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import net.minidev.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.SignDTO;
import vn.com.mcredit.digitallending.dto.UserProfileCreateDTO;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.internal.MiniAppHomePageResponse;
import vn.com.mcredit.digitallending.dto.resp.internal.MiniAppUserInfo;
import vn.com.mcredit.digitallending.entity.*;
import vn.com.mcredit.digitallending.enums.ApplicationType;
import vn.com.mcredit.digitallending.enums.EPartnerCode;
import vn.com.mcredit.digitallending.enums.SourceAppType;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.AfcProxy;
import vn.com.mcredit.digitallending.proxy.MiniAppProxy;
import vn.com.mcredit.digitallending.redis.services.TokenService;
import vn.com.mcredit.digitallending.repositories.CriteriaRepository;
import vn.com.mcredit.digitallending.repositories.PartnerUserInfoRepository;
import vn.com.mcredit.digitallending.repositories.UserDeviceRepo;
import vn.com.mcredit.digitallending.repositories.UserProfileProxy;
import vn.com.mcredit.digitallending.security.RSADecryt;
import vn.com.mcredit.digitallending.security.RSAUtil;
import vn.com.mcredit.digitallending.services.AfcService;
import vn.com.mcredit.digitallending.services.AuthService;
import vn.com.mcredit.digitallending.services.EkycModelService;
import vn.com.mcredit.digitallending.services.MiniAppService;
import vn.com.mcredit.digitallending.utils.*;

import java.util.*;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {
    @Value("${web-view.home-page-url}")
    private String homePageUrl;

    @Value("${web-view.expired-time}")
    private int expiredTime;
    private int webviewExpireTime = 30 * 60;
    private final AfcProxy afcProxy;

    @Autowired
    private TokenService tokenService;

    private final ModelMapper modelMapper;
    private final PartnerUserInfoRepository partnerUserInfoRepository;
    private final UserProfileProxy userProfileProxy;
    private final EkycModelService ekycModelService;

    private final UserDeviceRepo userDeviceRepo;
    private final MiniAppProxy miniAppProxy;
    private final AfcService afcService;

    private final CriteriaRepository criteriaRepository;

    private final MiniAppService miniAppService;
    @Override
    public Object register(UserProfileCreateDTO userProfileCreateDTO) {
        if (StringUtils.isBlank(userProfileCreateDTO.getDeviceId())) {
            throw new ApplicationException(Error.DEVICE_ID_IS_EMPTY.getCode(), Error.DEVICE_ID_IS_EMPTY.getMessage());
        }
        try {
            this.validateUsername(userProfileCreateDTO.getUsername(), Constants.REGISTER);
            AccessTokenDTO token = afcProxy.register(userProfileCreateDTO);

            if (token.getUserProfile() != null) {
                UserProfile userProfile = modelMapper.map(token.getUserProfile(), UserProfile.class);
                if (userProfile != null) {
                    userProfile.setCreatedDate(new Date());
                    userProfile.setModifiedDate(new Date());
                    userProfile.setPassword(PasswordUtils.encodMd5(userProfileCreateDTO.getPassword()));
                    userProfileProxy.save(userProfile);
                    this.insertUserDevice(userProfile.getUsername(), userProfileCreateDTO.getDeviceId());
                }
            }
            /* lưu token mới */
            tokenService.set(userProfileCreateDTO.getUsername(), token.getToken(), JWTUtils.getExpiredDate(token.getToken()));
            return DigitalLendingResponse.builder().status(Constants.SUCCESS_MESSAGE).data(token).code(Constants.SUCCESS_CODE).message(Constants.SUCCESS_MESSAGE).build();
        } catch (HttpStatusCodeException e){
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(Utils.transformMessage(e.getResponseBodyAsString(), Constants.USERNAME_EXISTED_ON_SYSTEM, Constants.INFORMATION_REGISTER_EXISTED)));
        }
    }

    @Override
    public DigitalLendingResponse login(LoginDTO dto) {
        LogUtils.info("[AuthService] login deviceId");
        if (StringUtils.isBlank(dto.getDeviceId())) {
            throw new ApplicationException(Error.DEVICE_ID_IS_EMPTY.getCode(), Error.DEVICE_ID_IS_EMPTY.getMessage());
        }
        this.validateUsername(dto.getUsername(), Constants.LOGIN);
        try {
            AccessTokenDTO token = afcProxy.login(dto);
            if (token != null && token.getUserProfile() != null) {
                this.updateProfile(dto.getUsername(), token, dto.getDeviceId());
                this.resetToken(dto.getUsername(), token.getToken());

            }

            return DigitalLendingResponse.builder().status(Constants.SUCCESS_MESSAGE).data(token).code(Constants.SUCCESS_CODE).message(Constants.SUCCESS_MESSAGE).build();
        } catch (HttpStatusCodeException e){
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(Utils.transformMessage(e.getResponseBodyAsString(), Constants.USERNAME_NOT_EXIST, Constants.UNAME_PW_INCORRECT)));
        } catch (Exception e){
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Utils.getMessageError(e.getMessage()));
        }
    }
    private UserProfile findByUsername(String username){
        Optional<UserProfile> optionalUserProfile = userProfileProxy.findByUsername(username);
        if (optionalUserProfile.isPresent())
            return optionalUserProfile.get();
        else return null;
    }
    private void updateProfile(String username, AccessTokenDTO token, String deviceId){
        if (token != null && token.getUserProfile() != null) {
            EkycModel ekycModel = ekycModelService.findEkycModelByUsername(username);
            if(deviceId != null) {
                if(ekycModel != null && (StringUtils.isBlank(ekycModel.getDeviceId()) || Boolean.TRUE.equals(token.getUserProfile().getIsVerifiedDevice()))) {
                    ekycModel.setDeviceId(deviceId);
                    ekycModelService.save(ekycModel);
                }
                this.upsertUserDevice(username, deviceId, ekycModel);
            }
            UserProfile userProfile = this.findByUsername(username);
            if (userProfile == null) {
                userProfile = modelMapper.map(token.getUserProfile(), UserProfile.class);
                userProfile.setCreatedDate(new Date());
            } else if (Boolean.TRUE.equals(token.getUserProfile().getIsEKYC()) &&
                    Boolean.FALSE.equals(userProfile.getIsEkyc())) {
                this.transformUserProfile(userProfile, token.getUserProfile());
            }
            userProfile.setModifiedDate(new Date());
            userProfileProxy.save(userProfile);
            if (ekycModel != null) {
                EkycData ekycData = modelMapper.map(ekycModel, EkycData.class);
                token.setEkycModel(ekycData);
            }

        }
    }
    private void transformUserProfile(UserProfile userProfile, UserProfileDTO userProfileDTO){
        userProfile.setFullName(userProfileDTO.getFullName());
        userProfile.setAddress(userProfileDTO.getAddress());
        userProfile.setUserType(userProfileDTO.getUserType());
        userProfile.setCardType(userProfileDTO.getCardType());
        userProfile.setAvatar(userProfileDTO.getAvatar());
        userProfile.setCardId(userProfileDTO.getCardId());
        userProfile.setEmail(userProfileDTO.getEmail());
        userProfile.setCardExpiredAt(userProfileDTO.getCardExpiredAt());
        userProfile.setCif(userProfileDTO.getCif());
        userProfile.setProvince(userProfileDTO.getProvince());
        userProfile.setCity(userProfileDTO.getCity());
        userProfile.setDistrict(userProfileDTO.getDistrict());
        userProfile.setCardIssuedAt(userProfileDTO.getCardIssuedAt());
        userProfile.setGender(userProfileDTO.getGender());
        userProfile.setDob(userProfileDTO.getDob());
        userProfile.setIsEkyc(userProfileDTO.getIsEKYC());
        userProfile.setIsMatching(userProfileDTO.getIsMatching());
    }
    private void resetToken(String username, String accessToken){
        /* xóa token cũ và lưu token mới */
        try {
            tokenService.delete(username);
            tokenService.set(username, accessToken, JWTUtils.getExpiredDate(accessToken));
        } catch (Exception e){
            throw new ApplicationException(Error.REDIS_CONNECTION_ERROR.getCode(), Error.REDIS_CONNECTION_ERROR.getMessage());
        }
    }
    @Override
    public Object loginV6(EncryptDTO encryptDTO) {
        try {
            AccessTokenDTO token = afcProxy.loginV6(encryptDTO);
            if (token != null && token.getUserProfile() != null) {
                String username = token.getUserProfile().getUsername();
                this.validateUsername(username, Constants.LOGIN);
                this.updateProfile(username, token, JWTUtils.getDeviceId());
                this.resetToken(username, token.getToken());
            }
            return DigitalLendingResponse.builder().status(Constants.SUCCESS_MESSAGE).data(token).code(Constants.SUCCESS_CODE).message(Constants.SUCCESS_MESSAGE).build();
        } catch (HttpStatusCodeException e){
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(Utils.transformMessage(e.getResponseBodyAsString(), Constants.USERNAME_NOT_EXIST, Constants.UNAME_PW_INCORRECT)));
        }
    }
    private PartnerUserInfo validateUsername(String username, String type){
        String partnerCode = JWTUtils.getPartnerCode();
        PartnerUserInfo partnerUserInfo = null;
        LogUtils.info("[AuthService] validateUsername partner", partnerCode);
        if (EPartnerCode.MB_BANK.value().equalsIgnoreCase(partnerCode)){
            String phone = tokenService.getWebviewData(username);
            LogUtils.info("[AuthService] validateUsername partner Username-Phone", username + "-" + phone);
            if (StringUtils.isBlank(phone)){
                throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
            }
            partnerUserInfo = partnerUserInfoRepository.findFirstByMobile(username);
            if (partnerUserInfo == null) {
                if (Constants.LOGIN.equalsIgnoreCase(type)){
                    throw new ApplicationException(Error.ACCOUNT_ERROR.getCode(), Error.ACCOUNT_ERROR.getMessage());
                } else if (Constants.REGISTER.equalsIgnoreCase(type)){
                    throw new ApplicationException(Error.ACCOUNT_REGISTER_ERROR.getCode(), Error.ACCOUNT_REGISTER_ERROR.getMessage());
                }
            } else {
                LogUtils.info("[AuthService] validateUsername partnerUserInfo Phone", partnerUserInfo.getMobile());
                if (!"IN_USE".equalsIgnoreCase(partnerUserInfo.getStatus())) {
                    partnerUserInfo.setStatus("IN_USE");
                    partnerUserInfoRepository.save(partnerUserInfo);
                }
            }
            LogUtils.info("[AuthService] validateUsername partner success");
        }
        return partnerUserInfo;
    }
    private UserDevice insertUserDevice(String username, String deviceId) {
        UserDevice userDevice = new UserDevice();
        userDevice.setDeviceId(deviceId);
        userDevice.setUsername(username);
        userDevice.setStatus(Constants.UNVERIFIED);
        return userDeviceRepo.save(userDevice);
    }

    private void upsertUserDevice(String username, String deviceId, EkycModel ekycModel) {
        LogUtils.info("[AuthService] upsertUserDevice username" + username + ", " + deviceId );
        UserDevice userDevice = userDeviceRepo.findLastUserDevice(username, deviceId);
        if(userDevice == null) {
           userDevice = new UserDevice();
           userDevice.setDeviceId(deviceId);
           userDevice.setUsername(username);
           if(ekycModel != null && deviceId.equalsIgnoreCase(ekycModel.getDeviceId())) userDevice.setStatus(Constants.VERIFIED);
           else  userDevice.setStatus(Constants.UNVERIFIED);
        }
        userDevice.setLastUpdated(new Date());
        userDeviceRepo.save(userDevice);
    }
    @Override
    public Object checkUrl(OpenWebviewRequest request){
        String sign = request.getSign();
        /**Lấy dữ liệu từ redis*/
        LogUtils.info("AuthService.checkUrl start...");
        String sessionDTO = tokenService.getWebview(sign);
        LogUtils.info("AuthService.checkUrl sessionDTO");
        if (StringUtils.isNullOrEmpty(sessionDTO)) {
            LogUtils.error("AuthService.checkUrl: UserSession not existed in redis");
            throw new ApplicationException(Error.ACCOUNT_ERROR.getCode(), Error.ACCOUNT_ERROR.getMessage());
        }
        SignDTO userLoginDTO = Utils.fromJson(sessionDTO, SignDTO.class);
        if (Objects.isNull(userLoginDTO)) {
            LogUtils.error("AuthService.checkUrl: UserSession parse error");
            throw new ApplicationException(Error.ACCOUNT_ERROR.getCode(), Error.ACCOUNT_ERROR.getMessage());
        }
        /**Giải mã chữ kí*/
        String data = RSAUtil.customDecrypt(sign);
        /**Check điều kiện*/
        if (StringUtils.isNullOrEmpty(data)) {
            LogUtils.error("AuthService.checkUrl: RSA sign error");
            throw new ApplicationException(Error.RSA_NOTFOUND.getCode(), Error.RSA_NOTFOUND.getMessage());
        }
        SignDTO signDTO = Utils.fromJson(data, SignDTO.class);
        LogUtils.info("AuthService.checkUrl:" + userLoginDTO.getCustomerCode(), signDTO.getCustomerCode());
        if (!userLoginDTO.getCustomerCode().equals(signDTO.getCustomerCode())) {
            LogUtils.error("AuthService.checkUrl: CustomerCode not match");
            throw new ApplicationException(Error.ACCOUNT_ERROR.getCode(), Error.ACCOUNT_ERROR.getMessage());
        }
        LogUtils.info("AuthService.checkUrl: TransactionId" + userLoginDTO.getTransactionId(), signDTO.getTransactionId());
        if (!userLoginDTO.getTransactionId().equals(signDTO.getTransactionId())) {
            LogUtils.error("AuthService.checkUrl: TransactionId not match");
            throw new ApplicationException(Error.ACCOUNT_ERROR.getCode(), Error.ACCOUNT_ERROR.getMessage());
        }
        tokenService.deleteWebview(sign);
        try {
            MiniAppUserInfo userInfo = miniAppProxy.getMiniAppUserInfo(signDTO.getCustomerCode());
            this.savePartnerUserInfo(userInfo);
            userInfo.setTransactionId(userLoginDTO.getTransactionId());
            LogUtils.info("[AuthService] checkUrl", userInfo.getMobile());
            tokenService.setWebviewData(userInfo.getMobile(), userInfo.getMobile(), Objects.requireNonNull(DateUtils.addSecond(new Date(), webviewExpireTime)));
            JSONObject resp = new JSONObject();
            resp.put("partner", userInfo.getPartner());
            resp.put("deviceId", userInfo.getExtras().getDeviceId());
            resp.put("mobile", userInfo.getMobile());
            if (userInfo.getExtras() != null)
                resp.put("cif", userInfo.getExtras().getCif());
            return DigitalLendingResponse.builder()
                    .code(Constants.SUCCESS_CODE)
                    .status(Constants.SUCCESS_MESSAGE)
                    .message(Constants.SUCCESS_MESSAGE)
                    .data(resp)
                    .build();
        } catch (HttpStatusCodeException e){
            LogUtils.error("[AuthService] checkUrl getMiniAppUserInfo error", e.getResponseBodyAsString());
            throw new ApplicationException(e.getStatusCode().name(), e.getResponseBodyAsString());
        }
    }

    private PartnerUserInfo buildPartnerUserInfo(MiniAppUserInfo userInfo){
        LogUtils.error("[AuthService] buildPartnerUserInfo");
        PartnerUserInfo partnerUserInfo = new PartnerUserInfo();
        partnerUserInfo.setSystem(userInfo.getSystem());
        partnerUserInfo.setMobile(userInfo.getMobile());
        partnerUserInfo.setEmail(userInfo.getEmail());
        partnerUserInfo.setDateOfBirth(userInfo.getDateOfBirth());
        partnerUserInfo.setCode(userInfo.getCode());
        partnerUserInfo.setName(userInfo.getName());
        partnerUserInfo.setStatus("NEW");
        partnerUserInfo.setCreatedBy(userInfo.getCreatedBy());
        partnerUserInfo.setPartner(JWTUtils.getPartnerCode());
        if (userInfo.getExtras() != null) {
            partnerUserInfo.setDeviceId(userInfo.getExtras().getDeviceId());
            partnerUserInfo.setAddress(userInfo.getExtras().getAddress());
            partnerUserInfo.setCif(userInfo.getExtras().getCif());
            partnerUserInfo.setFullnameVn(userInfo.getExtras().getFullnameVn());
            partnerUserInfo.setIdCardType(userInfo.getExtras().getIdCardType());
            partnerUserInfo.setIdCardNo(userInfo.getExtras().getIdCardNo());
            partnerUserInfo.setIdCardExpiryDate(userInfo.getExtras().getIdCardExpiryDate());
            partnerUserInfo.setIdCardIssuedDate(userInfo.getExtras().getIdCardIssuedDate());
            partnerUserInfo.setIdCardIssuedPlace(userInfo.getExtras().getIdCardIssuedPlace());
            partnerUserInfo.setAddress(userInfo.getExtras().getAddress());
            partnerUserInfo.setPermanentAddress(userInfo.getExtras().getPermanentAddress());
            partnerUserInfo.setGender(userInfo.getExtras().getGender());
            partnerUserInfo.setMaritalStatus(userInfo.getExtras().getMaritalStatus());
            partnerUserInfo.setNationality(userInfo.getExtras().getNationality());
        }
        return partnerUserInfo;
    }
    private void savePartnerUserInfo(MiniAppUserInfo userInfo){
        if (userInfo != null){
            LogUtils.error("[AuthService] savePartnerUserInfo");
            try {
                PartnerUserInfo partnerUserInfo = partnerUserInfoRepository.findFirstByMobile(userInfo.getMobile());
                if (partnerUserInfo == null) partnerUserInfo = this.buildPartnerUserInfo(userInfo);
                else partnerUserInfo.setStatus("NEW");
                partnerUserInfoRepository.save(partnerUserInfo);
            } catch (Exception e){
                LogUtils.error("[AuthService] savePartnerUserInfo error", e.getMessage());
            }
        }
    }
    @Override
    public MiniAppHomePageResponse generateTikTakPage(MiniAppHomePageRequest request) {
        LogUtils.info("[AuthService] generateTikTakPage request", request);
        SignDTO signDTO = SignDTO.builder()
            .transactionId(UUID.randomUUID().toString())
            .customerCode(request.getCustomerCode())
            .build();
        String sign = RSAUtil.customEncrypt(Utils.toJson(signDTO));
        String url = String.format("%s?sign=%s", homePageUrl, sign);
        MiniAppHomePageResponse response = MiniAppHomePageResponse.builder()
            .url(url)
            .build();
        if(tokenService.getWebview(sign) != null){
            tokenService.deleteWebview(sign);
        }
        tokenService.setWebview(sign, Utils.toJson(signDTO), Objects.requireNonNull(DateUtils.addSecond(new Date(), expiredTime)));
        return response;
    }
    @Override
    public Object loginV7(EncryptDTO encryptDTO) {
        if (!EPartnerCode.MB_BANK.value().equalsIgnoreCase(JWTUtils.getPartnerCode())){
            LogUtils.info("[AuthService] loginV7 no support partner", JWTUtils.getPartnerCode());
            throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
        }
            String decryptedString;
            try {
                decryptedString = RSADecryt.getInstance().decrypt(encryptDTO.getEncryt());
            } catch (Exception e){
                LogUtils.info("[AuthService] loginV7 decrypt error", e.getMessage());
                throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
            }
            PartnerUserInfo partnerUserInfo = null;
            LogUtils.info("[AuthService] loginV7 decrypt");
            LoginDTO dto = Utils.fromJson(decryptedString, LoginDTO.class);
            LogUtils.info("[AuthService] loginV7 decrypt", dto.getUsername());
            dto.setSystem(SourceAppType.DIGITAL_LENDING.getValue());
            dto.setApplicationType(ApplicationType.MINIAPP.getValue());
            partnerUserInfo = this.validateUsername(dto.getUsername(), Constants.LOGIN);
            AccessTokenV7DTO token = afcService.loginV7(dto);
            if (token != null && token.getAccessToken() != null) {
                this.resetToken(dto.getUsername(), token.getAccessToken());
                miniAppService.saveCustomerInfoMb(partnerUserInfo);
            }
            return DigitalLendingResponse.builder().status(Constants.SUCCESS_MESSAGE).data(token).code(Constants.SUCCESS_CODE).message(Constants.SUCCESS_MESSAGE).build();
    }
}
