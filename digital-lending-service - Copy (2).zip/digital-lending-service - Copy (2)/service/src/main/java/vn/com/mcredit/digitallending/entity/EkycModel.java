package vn.com.mcredit.digitallending.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ekyc_model")
public class EkycModel {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "username")
    private String username;
    @Column(name = "email")
    private String email;
    @Column(name = "gender")
    private String gender;
    @Column(name = "id_number", unique = true)
    private String idNumber;
    @Column(name = "id_number_old")
    private String idNumberOld;
    @Column(name = "object_id")
    private String objectId;
    @Column(name = "card_type")
    private String cardType;
    @Column(name = "front_image_ecm_url")
    private String frontImageEcmURL;
    @Column(name = "back_image_ecm_url")
    private String backImageEcmURL;
    @Column(name = "front_image_url")
    private String frontImageURL;
    @Column(name = "back_image_url")
    private String backImageURL;
    @Column(name = "selfie_image_url")
    private String selfieImageURL;
    @Column(name = "left_image_url")
    private String leftImageURL;// link ảnh mặt trái
    @Column(name = "right_image_url")
    private String rightImageURL;// link ảnh mặt phải
    @Column(name = "selfie_image_ecm_url")
    private String selfieImageEcmURL;// link ảnh mặt selfie
    @Column(name = "status")
    private String status;
    @Column(name = "system")
    private String system;
    @Column(name = "is_ekyc")
    private Boolean isEkyc;
    @Column(name = "name")
    private String name;
    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;
    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;
    @Column(name = "address")
    private String address;

    @Column(name = "address_correction")
    private String addressCorrection;
    @Column(name = "nationality")
    private String nationality;
    @Column(name = "home_town")
    private String homeTown;

    @Column(name = "hometown_correction")
    private String hometownCorrection;

    @Column(name = "issued_date")
    private String issuedDate;

    @Column(name = "dob")
    private String dob;

    @Column(name = "expiry_date")
    private String expiryDate;

    @Column(name = "province")
    private String province;

    @Column(name = "district")
    private String district;

    @Column(name = "city")
    private String city;

    @Column(name = "qr_code")
    private String qrCode;

    @Column(name = "qr_code_image_url", columnDefinition = "text")
    private String qrCodeImageURL;

    @Column(name = "internal_id_c3")
    private String internalIdC3;

    @Column(name = "offline_id_c4")
    private String offlineIdC4;

    @Column(name = "image_search_one_id_multi_face_c5")
    private String imageSearchOneIdMultiFaceC5;

    @Column(name = "image_search_one_id_multi_face_c62")
    private String imageSearchOneFaceMultiIdC62;

    @Column(name = "black_list_check")
    private String blackListCheck;

    @Column(name = "fraud_checks", columnDefinition = "text")
    private String fraudChecks;

    @Column(name = "device_id", length = 36)
    private String deviceId;

    @Column(name = "captcha", length = 10)
    private String captcha;

    @Column(name = "voice_captcha_url")
    private String voiceCaptchaURL;

    @Column(name = "voice_captcha_ecm_url")
    private String voiceCaptchaEcmURL;

    @Column(name = "ekyc_code", length = 36)
    private String ekycCode;
}
