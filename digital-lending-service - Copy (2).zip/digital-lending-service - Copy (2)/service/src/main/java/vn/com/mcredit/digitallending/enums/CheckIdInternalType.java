package vn.com.mcredit.digitallending.enums;

public enum CheckIdInternalType {
    SCAN_QRCODE,
    NFC
}
