package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DocValidateBodyResponse {
    @JsonProperty("age_logic_check")
    private boolean ageLogicCheck;
    @JsonProperty("age_logic_check_reason")
    private String ageLogicCheckReason;
    @JsonProperty("dob_logic_check")
    private boolean dobLogicCheck;
    @JsonProperty("dob_logic_check_reason")
    private String dobLogicCheckReason;
    @JsonProperty("expire_date_logic_check")
    private boolean  expireDateLogicCheck;
    @JsonProperty("expire_date_logic_check_reason")
    private String expireDateLogicCheckReason;
    @JsonProperty("gender_logic_check")
    private boolean genderLogicCheck;
    @JsonProperty("gender_logic_check_reason")
    private String genderLogicCheckReason;
    @JsonProperty("new_id_number_length_check")
    private boolean newIdNumberLengthCheck;
    @JsonProperty("new_id_number_length_check_reason")
    private String newIdNumberLengthCheckReason;
    @JsonProperty("old_id_number_length_check")
    private boolean oldIdNumberLengthCheck;
    @JsonProperty("old_id_number_length_check_reason")
    private String oldIdNumberLengthCheckReason;
    @JsonProperty("id_number_logic_check")
    private String idNumberLogicCheck;
    @JsonProperty("id_number_logic_check_reason")
    private String idNumberLogicCheckReason;
    @JsonProperty("id_number_format_validate")
    private String idNumberFormatValidate;
    @JsonProperty("id_number_format_validate_reason")
    private String idNumberFormatValidateReason;
    @JsonProperty("name_character_check")
    private String nameCharacterCheck;
    @JsonProperty("name_character_check_reason")
    private String nameCharacterCheckReason;
    @JsonProperty("mrz_checksum_check")
    private String mrzChecksumCheck;
    @JsonProperty("mrz_checksum_reason")
    private String mrzChecksumReason;
    @JsonProperty("3_components_check")
    private ComponentCheck componentCheck;
}
