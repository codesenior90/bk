package vn.com.mcredit.digitallending.dto.resp.aws_auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ResponseMetadata{
    @JsonProperty("RequestId")
    public String requestId;
}
