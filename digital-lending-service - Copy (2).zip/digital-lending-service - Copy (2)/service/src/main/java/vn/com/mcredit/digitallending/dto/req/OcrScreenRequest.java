package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.File;

@Data
public class OcrScreenRequest {
    @JsonProperty("image")
    private File file;
}
