package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FaceMatch3WayResponse {
    @JsonProperty("img1_angle")
    private Float img1Angle; // Góc quay của ảnh thứ nhất để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("Img2_angle")
    private Float img2Angle; // Góc quay của ảnh thứ hai để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("Img3_angle")
    private Float img3Angle; // Góc quay của ảnh thứ ba để khuôn mặt trong ảnh về dạng thẳng đứng
    @JsonProperty("s12")
    private Float s12; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ nhất và ảnh thứ hai
    @JsonProperty("s23")
    private Float s23; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ hai và ảnh thứ ba
    @JsonProperty("s31")
    private Float s31; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ ba và ảnh thứ nhất
    @JsonProperty("detection_time")
    private Float detectionTime; // Thời gian xác định khuôn mặt trong ảnh
    @JsonProperty("embedding_time")
    private Float embeddingTime; // Thời gian chuyển các đặc trưng trên khuôn mặt sang vector
    @JsonProperty("response_id")
    private String responseId; // Id của response trả về
    @JsonProperty("process_id")
    private String processId; // Id của request gửi lên
    @JsonProperty("error")
    private String error;
    @JsonProperty("status")
    private boolean status;
    @JsonProperty("right_image_url")
    private String rightImageURL;
    @JsonProperty("selfie_image_url")
    private String selfieImageURL;
    @JsonProperty("left_image_url")
    private String leftImageURL;
}
