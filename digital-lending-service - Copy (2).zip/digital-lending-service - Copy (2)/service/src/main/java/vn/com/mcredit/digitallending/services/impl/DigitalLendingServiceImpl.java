package vn.com.mcredit.digitallending.services.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.req.CheckPhoneRequest;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.customer.CustomerInfo;
import vn.com.mcredit.digitallending.dto.resp.customer.CustomerInfoResponse;
import vn.com.mcredit.digitallending.dto.resp.customer.CustomerResult;
import vn.com.mcredit.digitallending.dto.resp.internal.RegisterAccountResponse;
import vn.com.mcredit.digitallending.dto.req.internal.RegisterAccountRequest;
import vn.com.mcredit.digitallending.entity.*;
import vn.com.mcredit.digitallending.enums.*;
import vn.com.mcredit.digitallending.enums.LoanState;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.AfcProxy;
import vn.com.mcredit.digitallending.redis.services.TokenService;
import vn.com.mcredit.digitallending.repositories.*;
import vn.com.mcredit.digitallending.services.*;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.util.*;

@Service
public class DigitalLendingServiceImpl implements DigitalLendingService {
    @Qualifier("mapper")
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private LoanService loanService;
    @Autowired
    private AfcService afcService;
    @Autowired
    private HomeLendingService homeLendingService;
    @Autowired
    private EkycModelRepository ekycModelRepository;

    @Autowired
    private CreateLoanRepository createLoanRepository;

    @Autowired
    private PreOfferRepository preOfferRepository;
    @Autowired
    private AfcProxy afcProxy;

    @Value("${custom.properties.enable-nfc}")
    private boolean enableNfc;

    @Autowired
    private PartnerUserInfoRepository partnerUserInfoRepository;
    @Autowired
    private TokenService tokenService;

    @Autowired
    private MiniAppService miniAppService;
    @Override
    public DigitalLendingResponse checkPhone(CheckPhoneRequest data) {

        CustomerResult customerResult = new CustomerResult();
        boolean hasLoan = this.checkLoanByPhone(data);
        CheckAccountRegisterResponse checkAccountRegisterResponse = this.checkAccountByPhone(data);
        if(checkAccountRegisterResponse != null){
            if(checkAccountRegisterResponse.getUserAccount() != null) {
                customerResult.setName(checkAccountRegisterResponse.getUserAccount().getFullName());
            }
            customerResult.setHasAccountApp(checkAccountRegisterResponse.getIsExisted());
        }
        customerResult.setHasLoan(hasLoan);

        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        digitalLendingResponse.setData(customerResult);
        digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
        digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
        return digitalLendingResponse;
    }

    private boolean checkLoanByPhone(CheckPhoneRequest checkPhoneRequest){
        try {
            Map<String, String> requestParams = new HashMap<>();
            requestParams.put("mobilePhone", checkPhoneRequest.getMobilePhone());
            CustomerInfoResponse customerInfoResponse = loanService.getCustomerInfo(requestParams);
            if (customerInfoResponse != null && customerInfoResponse.getResult() != null){
                List<CustomerInfo> customerInfos = customerInfoResponse.getResult();

                for (CustomerInfo customerInfo: customerInfos){
                    LogUtils.info("[DigitalLendingServiceImpl] get customerInfoResponse success, customerInfo");
                    if ((Constants.CREDIT_OPEN.equalsIgnoreCase(customerInfo.getStatus())
                            || Constants.CREDIT_BACKDATE.equalsIgnoreCase(customerInfo.getStatus()))
                            && Constants.CREDIT_RL.equalsIgnoreCase(customerInfo.getCategory())){
                        return true;
                    }
                }
            }
        } catch (HttpStatusCodeException e) {
            return handleExceptionCheckLoanByPhone(e);
        }
        return false;
    }
    private CheckAccountRegisterResponse checkAccountByPhone(CheckPhoneRequest checkPhoneRequest){

        return afcService.checkAccountRegisterByPhone(checkPhoneRequest.getMobilePhone());
    }
    private boolean handleExceptionCheckLoanByPhone(HttpStatusCodeException e){
        LogUtils.error("[DigitalLendingService] handleExceptionCheckLoanByPhone code/message", e.getStatusCode() + e.getResponseBodyAsString());
        String mes = e.getResponseBodyAsString();
        if (Utils.isJsonString(mes)){
            CustomerInfoErrorResponse responseBody = parseCustomerInfoError(mes);
            LogUtils.error("[DigitalLendingService] handleExceptionCheckLoanByPhone result", responseBody);
            if (responseBody != null && responseBody.getResult() != null){
                return false;
            }
        }
        throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(mes));
    }
    private CustomerInfoErrorResponse parseCustomerInfoError(String message){
        try{
            return new Gson().fromJson(message , CustomerInfoErrorResponse.class);
        }catch (Exception e){
            LogUtils.error("[DigitalLendingServiceImpl] getCustomerInfoError");
        }
        return null;
    }
    @Override
    public DigitalLendingResponse getHomeLendingInfo() {
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
        digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
        digitalLendingResponse.setMessage("Show message loi khi status = 2");
        HomeLending homeLending = homeLendingService.getHomeLending(Constants.HOME_LENDING_PAGE_CONFIG);
        HomeLendingResponse homeLendingResponse = new HomeLendingResponse();
        if (homeLending != null) {
            modelMapper.map(homeLending, homeLendingResponse);
        } else {
            homeLendingResponse = getHomeLendingDefault();
        }
        digitalLendingResponse.setData(homeLendingResponse);
        return digitalLendingResponse;
    }
    private HomeLendingResponse getHomeLendingDefault(){
        List<ConditionLendingResponse> conditionLendingResponses = new ArrayList<>();
        HomeLendingResponse homeLendingResponse = new HomeLendingResponse();
        homeLendingResponse.setBannerUrl("https://prod-external-channel-s3-mcredit-website.s3.ap-southeast-1.amazonaws.com/132835212869708617_Banner%20vay%20tr%E1%BA%A3%20g%C3%B3p.png");
        homeLendingResponse.setMonthLending(36);
        homeLendingResponse.setTitle("VAY SIÊU TỐC");
        homeLendingResponse.setContent("Cần vay liền nhận liền sau 5 phút");
        homeLendingResponse.setMainImageUrl("https://prod-external-channel-s3-mcredit-website.s3.ap-southeast-1.amazonaws.com/132834451531084876_chrome_CpUQcG9OuJ.jpg");
        homeLendingResponse.setMaxValueLendingTitle("Mức vay tối đa lên đến");
        homeLendingResponse.setMaxValueLending(15000000);
        homeLendingResponse.setMinValueVending(5000000);
        homeLendingResponse.setRatePerMonth(0.08);
        ConditionLendingResponse conditionLendingResponse = new ConditionLendingResponse();
        conditionLendingResponse.setContent("Chỉ xác minh bằng CCCD mới (có gắn chíp)");
        conditionLendingResponse.setTitle("Vay không thế chấp");
        String icon = "https://prod-external-channel-s3-mcredit-website.s3.ap-southeast-1.amazonaws.com/132834451530731865_chrome_s9skfPtTQt.jpg";
        conditionLendingResponse.setIcon(icon);
        conditionLendingResponses.add(conditionLendingResponse);
        conditionLendingResponse = new ConditionLendingResponse();
        conditionLendingResponse.setContent("Chỉ từ 12k/ngày (tương đương 1 ổ bánh mì)");
        conditionLendingResponse.setTitle("Trả góp");
        conditionLendingResponse.setIcon(icon);
        conditionLendingResponses.add(conditionLendingResponse);
        conditionLendingResponse = new ConditionLendingResponse();
        conditionLendingResponse.setContent("Khách cho khách hàng chưa có hợp đồng vay hạn mức");
        conditionLendingResponse.setTitle("Đối tượng áp dụng");
        conditionLendingResponse.setIcon(icon);
        conditionLendingResponses.add(conditionLendingResponse);
        homeLendingResponse.setConditions(conditionLendingResponses);
        return homeLendingResponse;
    }

    @Override
    public DigitalLendingResponse getSummary(String system, String deviceId) {
        String username = JWTUtils.getUsername();
        LogUtils.info("[DigitalLendingService] getSummary", deviceId);
        return processDigitalLendingSystem(system, username, deviceId);
    }

    private DigitalLendingResponse processDigitalLendingSystem(String system, String username, String deviceId) {
        try {
            UserSummaryResponse summaryResponse = new UserSummaryResponse();
            summaryResponse.setNfc(enableNfc);
            this.checkIsEkyc(system, summaryResponse, username, deviceId);
            if(Boolean.TRUE.equals(summaryResponse.isEkyc())) {
                this.getStep(username, summaryResponse);
            }
            DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
            digitalLendingResponse.setData(summaryResponse);
            digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
            digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
            return digitalLendingResponse;
        } catch (Exception e){
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EXCEPTION_MES);
        }
    }

    private void getStep(String username, UserSummaryResponse summaryResponse) {
        CreateLoan createLoan = createLoanRepository.getCreateLoanByName(username);
        if (createLoan != null && this.isValidLoanStatus(createLoan.getStatus())){
            // trả trạng thái của create case
            summaryResponse.setStep(createLoan.getStatus());
            summaryResponse.setPartnerCode(createLoan.getPartnerCode());
        } else {
            PreOffer preOffer = preOfferRepository.getPreOfferByUserName(username);
            if (preOffer != null && this.isValidOfferStatus(preOffer.getStatus())) {
                // trả về trạng thái của pre-offer
                summaryResponse.setStep(preOffer.getStatus());
                summaryResponse.setPartnerCode(preOffer.getPartnerCode());
            }
        }
    }

    private boolean isValidLoanStatus(String status) {
        List<String> validStatus = List.of(LoanState.LOAN_PROCESSING.getValue(), LoanState.LOAN_PASSED.getValue(), LoanState.LOAN_FAILED.getValue(),
                LoanState.SIGN_COMPLETED.getValue());
        return validStatus.contains(status);
    }

    private boolean isValidOfferStatus(String status) {
        List<String> validStatus = List.of(OfferState.OFFER_PROCESSING.getValue(), OfferState.OFFER_PASSED.getValue(), OfferState.OFFER_FAILED.getValue(),
                OfferState.OFFER_TIMEOUT.getValue(), OfferState.OFFER_REJECT.getValue());
        return validStatus.contains(status);
    }

    private void checkIsEkyc(String system, UserSummaryResponse summaryResponse, String username, String deviceId){
        LogUtils.info("[DigitalLendingService] getSummary system", system);
        DeviceVerificationResponse deviceVerificationResponse = getDeviceVerificationResponse(deviceId);
        EkycModel ekycModel = ekycModelRepository.findByUsername(username);
        summaryResponse.setHasLoan(this.checkLoanByPhone(new CheckPhoneRequest(username)));
        if (ekycModel != null) {
            summaryResponse.setEkyc(true);
            EkycData ekycData = modelMapper.map(ekycModel, EkycData.class);
            summaryResponse.setUser(ekycData);
            summaryResponse.setSystem(SourceAppType.DIGITAL_LENDING.getValue());
            if(Boolean.TRUE.equals(deviceVerificationResponse.isStatus())) summaryResponse.setProcessEkyc(ProcessTypeEnum.IDENTIFIED_DL_EKYC.getValue());
            else summaryResponse.setProcessEkyc(ProcessTypeEnum.IDENTIFIED_DL_EKYC_CHANGE_DEVICE.getValue());
        } else {
            EkycDetailResponse ekycDetailResponse = afcService.getEkycDetail(username);
            LogUtils.info("[DigitalLendingService] getSummary ekycDetailResponse");
            summaryResponse.setUser(ekycDetailResponse);
            summaryResponse.setEkyc(false);
            if(ekycDetailResponse != null) {
                summaryResponse.setSystem(ekycDetailResponse.getOriginSystem());
                summaryResponse.setProcessEkyc(this.getProcessEkyc(ekycDetailResponse, deviceVerificationResponse.isStatus()));
            }else {
                summaryResponse.setProcessEkyc(ProcessTypeEnum.NONE_EKYC.getValue());
            }
        }
    }

    private DeviceVerificationResponse getDeviceVerificationResponse(String deviceId) {
        if (StringUtils.isNotBlank(deviceId)) {
            try {
                Map<String, String> requestParam = new HashMap<>();
                requestParam.put("username", JWTUtils.getUsername());
                requestParam.put("deviceId", deviceId);
                DeviceVerificationResponse deviceVerificationResponse = afcProxy.getDeviceVerification(requestParam);
                if (deviceVerificationResponse == null) {
                    LogUtils.info("[DigitalLendingServiceImpl] checkIsEkyc deviceVerificationResponse is null");
                    deviceVerificationResponse = DeviceVerificationResponse.builder().status(Boolean.FALSE).build();
                }
                return deviceVerificationResponse;
            } catch (Exception e) {
                throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.APP_EXCEPTION_MESSAGE);
            }
        } else { // Cần remove sau khi app lên app-store
            return DeviceVerificationResponse.builder().status(Boolean.TRUE).build();
        }
    }

    @Override
    public UserInfoDTO getUserInfo(){
        String username = JWTUtils.getUsername();
        EkycModel ekycModel = ekycModelRepository.findByUsername(username);
        UserInfoDTO userInfoDTO = new UserInfoDTO();
        if (ekycModel != null){
            userInfoDTO = modelMapper.map(ekycModel, UserInfoDTO.class);
        }
        return userInfoDTO;
    }

    private int getProcessEkyc(EkycDetailResponse ekycDetailResponse, boolean deviceStatus) {
        if(EkycStatus.VERIFIED.getValue().equals(ekycDetailResponse.getStatus())) {
            if(StringUtils.isNullOrEmpty(ekycDetailResponse.getSelfieImageURL())
                    || StringUtils.isNullOrEmpty(ekycDetailResponse.getLeftImageURL())
                    || StringUtils.isNullOrEmpty(ekycDetailResponse.getRightImageURL()) ) {
               return ProcessTypeEnum.MISS_FACE3WAY.getValue();
            }
            if (Boolean.TRUE.equals(deviceStatus)) return ProcessTypeEnum.EKYC_NOT_DL_FULL.getValue();
            else return ProcessTypeEnum.EKYC_NOT_DL_FULL_CHANGE_DEVICE.getValue();
        }
        return ProcessTypeEnum.NONE_EKYC.getValue();
    }

    private PartnerUserInfo getUserInfoByPhone(String mobilePhone){
        String partnerCode = JWTUtils.getPartnerCode();
        if (EPartnerCode.MB_BANK.value().equalsIgnoreCase(partnerCode)){
            String phone = tokenService.getWebviewData(mobilePhone);
            LogUtils.info("[DigitalLendingService] getUserInfoByPhone Username-Phone", mobilePhone + "-" + phone);
            if (StringUtils.isBlank(phone)){
                throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
            }
            PartnerUserInfo partnerUserInfo = partnerUserInfoRepository.findFirstByMobile(mobilePhone);
            if (partnerUserInfo == null) {
                throw new ApplicationException(Error.ACCOUNT_ERROR.getCode(), Error.ACCOUNT_ERROR.getMessage());
            } else {
                LogUtils.info("[DigitalLendingService] getUserInfoByPhone Phone", partnerUserInfo.getMobile());
                if (!"IN_USE".equalsIgnoreCase(partnerUserInfo.getStatus())) {
                    partnerUserInfo.setStatus("IN_USE");
                    partnerUserInfo = partnerUserInfoRepository.save(partnerUserInfo);
                }
            }
            LogUtils.info("[DigitalLendingService] getUserInfoByPhone success");
            return partnerUserInfo;
        } else {
            LogUtils.info("[DigitalLendingService] getUserInfoByPhone false: not from mini-app");
            throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
        }
    }

    @Override
    public DigitalLendingResponse checkPhoneTiktak(CheckPhoneRequest checkPhoneRequest) {
        PartnerUserInfo userInfo = this.getUserInfoByPhone(checkPhoneRequest.getMobilePhone());
        CustomerResult customerResult = new CustomerResult();
        // Kiểm tra hạn mức
        boolean hasLoan = this.checkLoanByPhone(checkPhoneRequest);
        customerResult.setHasLoan(hasLoan);
        if (hasLoan) {
            return DigitalLendingResponse.builder()
                    .data(customerResult)
                    .code(Constants.SUCCESS_CODE)
                    .message(Constants.SUCCESS_MESSAGE)
                    .status(Constants.SUCCESS_MESSAGE)
                    .build();
        }
        // kiểm tra SDT đã được đăng ký ở MC
        CheckAccountRegisterResponse checkAccount = this.checkAccountByPhone(checkPhoneRequest);
        if(checkAccount != null) {
            customerResult.setHasAccountApp(checkAccount.getIsExisted());
            if (Boolean.FALSE.equals(checkAccount.getIsExisted())){
                // Tự động tạo tài khoản
                RegisterAccountRequest registerAccountRequest = RegisterAccountRequest.builder()
                        .username(checkPhoneRequest.getMobilePhone())
                        .fullName(userInfo.getName())
                        .email(userInfo.getEmail())
                        .gender(userInfo.getGender())
                        .cardNumber(userInfo.getIdCardNo())
                        .cardType(userInfo.getIdCardType())
                        .deviceId(userInfo.getDeviceId())
                        .isAutoGeneratePassword(true)
                        .system(SourceAppType.DIGITAL_LENDING.getValue())
                        .applicationType(ApplicationType.MINIAPP.getValue())
                        .build();
                RegisterAccountResponse token = this.autoRegisterAccount(registerAccountRequest);
                if (token != null) {
                    /* lưu token mới */
                    customerResult.setToken(token.getAccessToken());
                    tokenService.set(checkPhoneRequest.getMobilePhone(), token.getAccessToken(), JWTUtils.getExpiredDate(token.getAccessToken()));
                    customerResult.setName(registerAccountRequest.getFullName());
                    // lưu lại thông tin người dùng nhận từ phía MB
                    miniAppService.saveCustomerInfoMb(userInfo);
                } else {
                    throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
                }
            } else if(checkAccount.getUserAccount() != null) {
                customerResult.setName(checkAccount.getUserAccount().getFullName());
            }
            return DigitalLendingResponse.builder()
                    .data(customerResult)
                    .code(Constants.SUCCESS_CODE)
                    .message(Constants.SUCCESS_MESSAGE)
                    .status(Constants.SUCCESS_MESSAGE)
                    .build();
        } else {
            throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
        }
    }

    /**
     * Tạo tài khoản tự động (Tích hợp api tạo tài khoản tự động với AFC)
     * @param registerAccountRequest
     * @return
     */
    private RegisterAccountResponse autoRegisterAccount(RegisterAccountRequest registerAccountRequest){
        try {
            return afcProxy.register(registerAccountRequest);
        } catch (HttpStatusCodeException e){
            LogUtils.info("[DigitalLendingService] autoRegisterAccount HttpStatusCodeException", e.getResponseBodyAsString());
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), Utils.getMessageError(e.getResponseBodyAsString()));
        }
    }
}
