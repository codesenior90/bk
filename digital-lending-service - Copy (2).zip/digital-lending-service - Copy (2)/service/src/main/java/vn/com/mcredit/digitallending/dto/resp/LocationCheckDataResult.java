package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class LocationCheckDataResult {
    private String name;

    @JsonProperty("ratio_3_months")
    private Float ratio3Months;

    @JsonProperty("ratio_range_3_months")
    private String ratioRange3Months;

    @JsonProperty("ratio_1_month")
    private Float ratio1Month;

    @JsonProperty("ratio_range_1_month")
    private String ratioRange1Month;
}
