package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class CustomerAddressRequest {
    @JsonProperty("type")
    private String type;
    @JsonProperty("address")
    private String address;
    @JsonProperty("apartmentNumber")
    @NotNullorEmpty(message = "Vui lòng cung cấp số nhà")
    private String apartmentNumber;
    @JsonProperty("province")
    @NotNullorEmpty(message = "Vui lòng cung cấp mã tỉnh thành")
    private String province;
    @JsonProperty("district")
    @NotNullorEmpty(message = "Vui lòng cung cấp mã quận huyện")
    private String district;
    @JsonProperty("ward")
    @NotNullorEmpty(message = "Vui lòng cung cấp mã quận huyện")
    private String ward;
    @JsonProperty("provinceName")
    @NotNullorEmpty(message = "Vui lòng cung cấp tên tỉnh thành")
    private String provinceName;
    @JsonProperty("districtName")
    @NotNullorEmpty(message = "Vui lòng cung cấp tên quận huyện")
    private String districtName;
    @JsonProperty("wardName")
    @NotNullorEmpty(message = "Vui lòng cung tên phường xã")
    private String wardName;
    @JsonProperty("accommodationType")
    @NotNullorEmpty(message = "Vui lòng cung cấp loại địa chỉ")
    private String accommodationType;
}
