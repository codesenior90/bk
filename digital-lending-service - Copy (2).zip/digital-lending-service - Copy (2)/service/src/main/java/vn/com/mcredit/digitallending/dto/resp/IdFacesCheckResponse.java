package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class IdFacesCheckResponse {
    @JsonProperty("request_id") // Require: Request id
    private String requestId;

    @JsonProperty("response_id") // Require: Response id
    private String responseId;

    @JsonProperty("request_date") // Require: Thời điểm gửi request
    private String requestDate;

    @JsonProperty("error_code") // Mã lỗi nghiệp vụ
    private String errorCode;

    @JsonProperty("img_search_selfie_img_cut_off_threshold") // Ngưỡng cut-off trùng ảnh selfie
    private Float imgSearchSelfieImgCutOffThreshold;

    @JsonProperty("img_search_id_img_cut_off_threshold") // Ngưỡng cut-off trùng ảnh ID
    private Float imgSearchIdImgCutOffThreshold;

    @JsonProperty("image_search_by_id_check_detail") // Thông tin url + score các ảnh trùng với mà có ID trùng với ID của ảnh đầu vào
    private List<ImageSearchByIdCheckDetail> imageSearchByIdCheckDetails;

    @JsonProperty("image_search_by_id_check_result") // Kết quả check
    private Boolean imageSearchByIdCheckResult;

    @JsonProperty("message") // lỗi nghiệp vụ
    private String message;
}
