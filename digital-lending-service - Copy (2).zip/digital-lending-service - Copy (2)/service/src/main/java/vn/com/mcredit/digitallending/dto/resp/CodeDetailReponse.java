package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class CodeDetailReponse {
    private String codeSumary;
    private String codeItSumary;
    private String codeDetail;

}
