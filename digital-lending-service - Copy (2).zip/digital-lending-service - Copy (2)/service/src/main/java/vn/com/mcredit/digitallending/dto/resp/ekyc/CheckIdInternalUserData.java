package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

@Data
public class CheckIdInternalUserData {
    private String gender; // Giới tính

    private String idNumber; // Số CCCD CHIP

    private String idNumberOld; // Số CMND|CCCD cũ

    private String name; // Họ và tên

    private String address; // Địa chỉ sinh sống

    private String nationality; // Quốc gia

    private String homeTown; // Nguyên quán

    private String issuedDate; // Ngày phát hành

    private String dob; // Ngày sinh

    private String expiryDate; // Ngày hết hạn

    private String religion; // Tôn giáo

    private String ethnic; // Dân tộc

    private String personalIdentification;
}
