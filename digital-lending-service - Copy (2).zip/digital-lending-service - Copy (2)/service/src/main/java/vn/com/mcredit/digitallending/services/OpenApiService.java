package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.resp.BankListResponse;

public interface OpenApiService {
    BankListResponse getBanks();
}
