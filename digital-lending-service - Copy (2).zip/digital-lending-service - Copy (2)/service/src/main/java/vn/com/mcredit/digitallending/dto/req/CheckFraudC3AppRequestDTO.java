package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class CheckFraudC3AppRequestDTO {
    @NotNullorEmpty(message = "Ngày Sinh không được để trống")
    @JsonProperty("brithday")
    private String birthDay;
    @NotNullorEmpty(message = "Tên không được để trống")
    private String fullName;
    private String numberExtraId; // CMND
    @NotNullorEmpty(message = "CCCD không được để trống")
    private String numberId; // CCCD
    @JsonProperty("requestId")
    private String requestId;
    private String phoneNumber;
}
