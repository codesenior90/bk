package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import vn.com.mcredit.digitallending.dto.req.OcrScreenRequest;
import vn.com.mcredit.digitallending.dto.req.FaceMatch4WayRequest;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.ekyc.VoiceCaptchaCheckResponse;

@Component
public class EkycProxy extends BaseProxy {
    @Value("${custom.properties.check-id-api-host}")
    protected String checkIdApiHost;
    @Value("${custom.properties.face-matching-api-host}")
    protected String faceApiMatchingHost;
    @Value("${custom.properties.ocr-api-host}")
    protected String ocrApiHost;
    @Value("${custom.properties.voice-captcha-service-host}")
    protected String voiceCaptchaApiHost;
    // API này có chức năng phát hiện giấy tờ tuỳ thân (mặt trước, mặt sau) có chụp trên màn hình thiết bị thứ ba hay không.
    public OcrScreenResponse ocrScreen(OcrScreenRequest ocrScreenRequest) {
        String url = String.format("%s%s", ocrApiHost, "/screen");
        return this.post(url, initHeaderFormData2(), ocrScreenRequest, OcrScreenResponse.class);
    }

    /*** API có chức năng nhận đầu vào là 3 ảnh (ảnh chụp chân dung và ảnh quay phải, quay trái của khách hang), trả về các thông tin trong quá trình xử lý ảnh và xác suất trùng khớp các khuôn mặt có trong 3 ảnh được truyền vào với nhau theo từng cặp
     *
     * @param object
     * @return
     */

    public FaceMatch3WayResponse faceMatch3way(Object object) {
        String url = String.format("%s%s", faceApiMatchingHost, "/face_match_3way");
        return this.post(url, initHeaderMultipartFormData(), object, FaceMatch3WayResponse.class);
    }
    // API có chức năng nhận đầu vào là 4 ảnh (ảnh chụp chân dung thẳng mặt và ảnh quay phải, quay trái, ảnh chụp chứng minh thư của khách hàng), trả về các thông tin trong quá trình xử lý ảnh và xác suất trùng khớp các khuôn mặt của ảnh chụp chân dung thẳng mặt và các ảnh còn lại.
    public FaceMatch4WayResponse faceMatch4way(FaceMatch4WayRequest object) {
        String url = String.format("%s%s", faceApiMatchingHost, "/face_match_4way");
        return this.post(url, initHeaderMultipartFormData(), object, FaceMatch4WayResponse.class);
    }
    // API có chức năng nhận đầu vào là 2 ảnh gồm ảnh chân dung và ảnh giấy tờ tùy thân mặt trước của khách hàng, trả về các thông tin trong quá trình xử lý ảnh và xác suất trùng khớp khuôn mặt có trong 2 ảnh được truyền vào
    public FaceMatchRawResponse eKyc(Object object) {
        String url = String.format("%s%s", faceApiMatchingHost, "/face_match_raw");
        return this.post(url, initHeaderMultipartFormData(), object, FaceMatchRawResponse.class);
    }

    public VoiceCaptchaCheckResponse voiceCaptchaCheck(Object body){
        String url = String.format("%s%s", voiceCaptchaApiHost, "/voice_captcha");
        return this.post(url, initHeaderMultipartFormData(), body, VoiceCaptchaCheckResponse.class);

    }
}
