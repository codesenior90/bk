package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class QueryMBAccountStatus {
    private String accountStatus;
    private String accountName;
    private String idCardNumber;
    private String branchCode;
    private String branchName;
    private String branchMnemonic;
    private String message;
}
