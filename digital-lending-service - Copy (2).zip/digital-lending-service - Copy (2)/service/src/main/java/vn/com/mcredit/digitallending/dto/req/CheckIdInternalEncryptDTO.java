package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class CheckIdInternalEncryptDTO {
    private String data;
}
