package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.resp.DocValidateResponse;

@Component
public class FraudCheckProxy extends BaseProxy{
    @Value("${custom.properties.check-id-api-host}")
    protected String checkIdApiHost;
    public DocValidateResponse validateDoc(Object docValidateDto) {
        String url = String.format("%s%s", checkIdApiHost, "/doc_validate");
        return this.post(url, initHeaderAppJson(), docValidateDto, DocValidateResponse.class);
    }
}
