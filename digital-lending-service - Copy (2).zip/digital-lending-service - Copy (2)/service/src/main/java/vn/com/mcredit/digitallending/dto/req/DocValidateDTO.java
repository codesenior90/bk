package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.mcredit.digitallending.dto.resp.OcrResultResponse;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DocValidateDTO extends OcrResultResponse{
    @SerializedName("request_id")
    @JsonProperty("request_id")
    private String requestId;
    private String qr;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String nfc;

}
