package vn.com.mcredit.digitallending.enums;


public enum SourceAppType {
    AFC("AFC"),
    DIGITAL_LENDING("DIGITAL_LENDING"),
    DL_MBBANK("DL_MBBANK"),
    DL_WEB("DL_WEB"),

    OTHER("OTHER");

    private String value;

    SourceAppType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
