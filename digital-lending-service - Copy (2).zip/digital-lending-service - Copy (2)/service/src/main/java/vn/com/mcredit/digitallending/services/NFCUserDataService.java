package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.NFCFailRequest;

public interface NFCUserDataService {
    void saveFailData(NFCFailRequest nfcFailRequest);
}
