package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class MbAccountDTO {
    private String customerName;
    private String accountNumber;
}
