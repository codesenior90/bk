package vn.com.mcredit.digitallending.handles;

import vn.com.mcredit.digitallending.constants.Error;

public class BusinessException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private String code;
    private String message;

    public BusinessException(Error error) {
        super();
        this.code = error.getCode();
        this.message = error.getMessage();
    }
    public BusinessException(String code, String message) {
        super();

        this.code = code;
        this.message = message;
    }
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}

