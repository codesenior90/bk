package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.entity.*;
import vn.com.mcredit.digitallending.enums.ProcessTypeEnum;
import vn.com.mcredit.digitallending.enums.SourceEKYC;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.EkycProxy;
import vn.com.mcredit.digitallending.proxy.ImageFaceSearchProxy;
import vn.com.mcredit.digitallending.repositories.*;
import vn.com.mcredit.digitallending.services.AwsS3Service;
import vn.com.mcredit.digitallending.services.ImageSearchService;
import vn.com.mcredit.digitallending.utils.DateUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;


@Service
@RequiredArgsConstructor
public class ImageSearchServiceImpl implements ImageSearchService {
    private final AwsS3Service awsS3Service;
    private final ImageFaceSearchProxy imageFaceSearchProxy;
    private final FaceMatchRawRepository faceMatchRawRepository;
    private final FaceMatching3WayRepository faceMatching3WayRepository;
    private final IdsFaceRepository idsFaceRepository;
    private final BlacklistRepository blacklistRepository;
    private final FaceIdsRepository faceIdsRepository;
    private final EkycProxy ekycProxy;
    private final ModelMapper modelMapper;
    @Value("${custom.properties.aws-s3-folder-task-name}")
    private String folderTaskName;
    @Override
    public FaceMatchRawResponse faceMatchRaw(Ocr ocr, MultipartFile frontImg, FaceMatchingDTO faceMatchingDTO, String username){
        try {
            FaceMatchRawResponse faceMatchRawResponse = ekycProxy.eKyc(this.buildFaceMatchingRequest(frontImg ,faceMatchingDTO.getSelfieImg()));
            this.saveFaceMatchRaw(faceMatchRawResponse, null, ocr.getRequestId(), username);
            return faceMatchRawResponse;
        } catch (HttpStatusCodeException statusCodeException){
            this.saveFaceMatchRaw(null, statusCodeException.getResponseBodyAsString(), ocr.getRequestId(), username);
            return null;
        } catch (IOException e) {
            this.saveFaceMatchRaw(null, e.getMessage(), ocr.getRequestId(), username);
            return null;
        }
    }

    private void saveFaceMatchRaw(FaceMatchRawResponse faceMatchRawResponse, String error, String ocrRequestId, String username){
        try{
            FaceMatchRaw faceMatchRaw;
            if (faceMatchRawResponse != null) {
                LogUtils.info("faceMatchRaw response");
                faceMatchRaw = modelMapper.map(faceMatchRawResponse, FaceMatchRaw.class);
            } else {
                faceMatchRaw = new FaceMatchRaw();
                faceMatchRaw.setError(error);
                faceMatchRaw.setStatus(false);
            }
            faceMatchRaw.setUsername(username);
            faceMatchRaw.setOcrRequestId(ocrRequestId);
            faceMatchRaw.setCreatedAt(new Date());
            faceMatchRaw.setUpdatedAt(new Date());
            faceMatchRaw.setSourceEkyc(SourceEKYC.OTHER.getValue());
            LogUtils.info("faceMatchRaw response");
            faceMatchRawRepository.save(faceMatchRaw);
        } catch (Exception e){
            LogUtils.error("faceMatchRaw error", e.getMessage());
        }
    }
    @Override
    public BlacklistCheckResponse checkBlacklist(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber, Map<String, Object> map, String username){
        try {
            var body = this.buildBlacklistCheckRequest(ocr,idVector, selfieVector, cccdNumber, cmndoNumber);
            BlacklistCheckResponse blacklistCheckResponse = imageFaceSearchProxy.blacklistCheck(body);
            this.handleBlacklistSuccess(blacklistCheckResponse, map);
            this.saveBlacklist(blacklistCheckResponse, null, null, ocr.getRequestId(), username);
            return blacklistCheckResponse;
        } catch (HttpStatusCodeException e){
            LogUtils.error("[ImageSearchService] checkBlacklist exception", e.getMessage());
            this.saveBlacklist(null, e.getStatusCode().name(), e.getResponseBodyAsString(), ocr.getRequestId(), username);
            this.handleCheckFaceSearchFailure(e, map, Constants.CHECK_BLACKLIST_RESPONSE);
            return null;
        }
    }
    private void saveBlacklist(BlacklistCheckResponse blacklistCheckResponse, String errorCode, String errorMessage, String ocrRequestId, String username){
        try{
            Blacklist blacklist;
            LogUtils.info("[ImageSearchService] saveBlacklist");
            if (blacklistCheckResponse != null){
                blacklist = modelMapper.map(blacklistCheckResponse, Blacklist.class);
                if (blacklistCheckResponse.getBlacklistCheckDetails() != null){
                    blacklist.setBlacklistCheckDetails(Utils.toJson(blacklistCheckResponse.getBlacklistCheckDetails()));
                }
                blacklist.setErrorMessage(blacklistCheckResponse.getMessage());
            } else {
                blacklist = new Blacklist();
                blacklist.setErrorCode(errorCode);
                blacklist.setErrorMessage(errorMessage);
            }
            blacklist.setUsername(username);
            blacklist.setOcrRequestId(ocrRequestId);
            blacklist.setCreatedAt(new Date());
            blacklist.setUpdatedAt(new Date());
            blacklist.setSourceEkyc(SourceEKYC.OTHER.getValue());
            LogUtils.info("[ImageSearchService] saveBlacklist");
            blacklistRepository.save(blacklist);
        } catch (Exception e){
            LogUtils.error("faceMatchRaw error", e.getMessage());
        }
    }
    // handle blacklist_check's response
    private void handleBlacklistSuccess(BlacklistCheckResponse blacklistCheckResponse, Map<String, Object> map){
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        if (blacklistCheckResponse.isBlacklistCheckResult()){
            digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
            digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
        } else {
            digitalLendingResponse.setStatus(Constants.FAILED_MESSAGE);
            digitalLendingResponse.setCode(blacklistCheckResponse.getErrorCode());
        }
        map.put(Constants.CHECK_BLACKLIST_RESPONSE, digitalLendingResponse);
    }

    // Call api C6.1 face_ids_check
    @Override
    public FaceIdsCheckResponse checkFaceIds(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber, Map<String, Object> map, String username){
        try{
            var body = this.buildCheckFaceIdsRequest(ocr,idVector, selfieVector, cccdNumber, cmndoNumber);
            FaceIdsCheckResponse faceIdsCheckResponse = imageFaceSearchProxy.faceIdsCheck(body);
            this.handleCheckFaceIdsSuccess(faceIdsCheckResponse, map);
            this.saveCheckFaceIds(faceIdsCheckResponse, null, null, ocr.getRequestId(), username);
            return faceIdsCheckResponse;
        } catch (HttpStatusCodeException e){
            LogUtils.error("[ImageSearchService] checkFaceIds HttpStatusCodeException");
            this.saveCheckFaceIds(null, e.getStatusCode().name(), e.getResponseBodyAsString(), ocr.getRequestId(), username);
            this.handleCheckFaceSearchFailure(e, map, Constants.CHECK_FACE_IDS_RESPONSE);
            return null;
        } catch (Exception e){
            LogUtils.error("[ImageSearchService] checkFaceIds", e.getMessage());
            return null;
        }
    }
    // handle face_ids_check's response
    private void handleCheckFaceIdsSuccess(FaceIdsCheckResponse faceIdsCheckResponse, Map<String, Object> map){
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        if (Boolean.TRUE.equals(faceIdsCheckResponse.getImageSearchByIdCheckResult())) {
            digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
            digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
        } else {
            digitalLendingResponse.setStatus(Constants.FAILED_MESSAGE);
            digitalLendingResponse.setCode(faceIdsCheckResponse.getErrorCode());
        }
        map.put(Constants.CHECK_FACE_IDS_RESPONSE, digitalLendingResponse);
    }
    private void saveCheckFaceIds(FaceIdsCheckResponse faceIdsCheckResponse, String errorCode, String errorMessage, String ocrRequestId, String username){
        try{
            LogUtils.info("[ImageSearchService] saveCheckFaceIds faceIdsCheckResponse");
            FaceIds faceIds;
            if (faceIdsCheckResponse != null){
                faceIds = modelMapper.map(faceIdsCheckResponse, FaceIds.class);
                if (faceIdsCheckResponse.getImageIdInfoDetails() != null){
                    faceIds.setImageIdInfoDetails(Utils.toJson(faceIdsCheckResponse.getImageIdInfoDetails()));
                }
            } else {
                faceIds = new FaceIds();
                faceIds.setErrorCode(errorCode);
                faceIds.setErrorMessage(errorMessage);
            }
            faceIds.setUsername(username);
            faceIds.setOcrRequestId(ocrRequestId);
            faceIds.setCreatedAt(new Date());
            faceIds.setUpdatedAt(new Date());
            faceIds.setSourceEkyc(SourceEKYC.OTHER.getValue());
            LogUtils.info("[ImageSearchService] saveCheckFaceIds");
            faceIdsRepository.save(faceIds);
        } catch (Exception e){
            LogUtils.error("saveCheckFaceIds error", e.getMessage());
        }
    }
    // Call api C6.1 face_ids_check
    @Override
    public IdFacesCheckResponse checkIdsFace(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber, Map<String, Object> map, String username){
        try{
            var body = this.buildCheckIdsFaceRequest(ocr,idVector, selfieVector, cccdNumber, cmndoNumber);
            IdFacesCheckResponse idFacesCheckResponse = imageFaceSearchProxy.idFacesCheck(body);
            this.handleCheckIdsFaceSuccess(idFacesCheckResponse, map);
            this.saveCheckIdsFace(idFacesCheckResponse, null, null, ocr.getRequestId(), username);
            return idFacesCheckResponse;
        } catch (HttpStatusCodeException e){
            LogUtils.error("[ImageSearchService] checkIdsFace exception", e.getMessage());
            this.handleCheckFaceSearchFailure(e, map, Constants.CHECK_IDS_FACE_RESPONSE);
            this.saveCheckIdsFace(null, e.getStatusCode().name(), e.getResponseBodyAsString(), ocr.getRequestId(), username);
            return null;
        }
    }
    // handle face_ids_check's response
    private void handleCheckIdsFaceSuccess(IdFacesCheckResponse idFacesCheckResponse, Map<String, Object> map){
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        if (Boolean.TRUE.equals(idFacesCheckResponse.getImageSearchByIdCheckResult())) {
            digitalLendingResponse.setStatus(Constants.SUCCESS_MESSAGE);
            digitalLendingResponse.setCode(Constants.SUCCESS_CODE);
        } else {
            digitalLendingResponse.setStatus(Constants.FAILED_MESSAGE);
            digitalLendingResponse.setCode(idFacesCheckResponse.getErrorCode());
        }
        map.put(Constants.CHECK_IDS_FACE_RESPONSE, digitalLendingResponse);
    }
    private void saveCheckIdsFace(IdFacesCheckResponse idFacesCheckResponse, String errorCode, String errorMessage, String ocrRequestId, String username){
        try{

            LogUtils.info("[ImageSearchService] saveCheckIdsFace idFacesCheckResponse");
            IdsFace idsFace;
            if (idFacesCheckResponse != null){
                LogUtils.info("[ImageSearchService] saveCheckIdsFace idFacesCheckResponse", idFacesCheckResponse.getMessage());
                idsFace = modelMapper.map(idFacesCheckResponse, IdsFace.class);
                idsFace.setErrorMessage(idFacesCheckResponse.getMessage());
                if (idFacesCheckResponse.getImageSearchByIdCheckDetails() != null){
                    idsFace.setImageSearchByIdCheckDetails(Utils.toJson(idFacesCheckResponse.getImageSearchByIdCheckDetails()));
                }
            } else {
                idsFace = new IdsFace();
                idsFace.setErrorCode(errorCode);
                idsFace.setErrorMessage(errorMessage);
            }
            idsFace.setUsername(username);
            idsFace.setOcrRequestId(ocrRequestId);
            idsFace.setCreatedAt(new Date());
            idsFace.setUpdatedAt(new Date());
            idsFace.setSourceEkyc(SourceEKYC.OTHER.getValue());
            LogUtils.info("[ImageSearchService] saveCheckIdsFace");
            idsFaceRepository.save(idsFace);
        } catch (Exception e){
            LogUtils.error("saveCheckIdsFace error", e.getMessage());
        }
    }
    private void handleCheckFaceSearchFailure(HttpStatusCodeException httpStatusCodeException, Map<String, Object> map, String key){
        try {
            DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
            digitalLendingResponse.setMessage(httpStatusCodeException.getResponseBodyAsString());
            digitalLendingResponse.setStatus(Constants.FAILED_MESSAGE);
            digitalLendingResponse.setCode(Constants.ERROR_400_CODE);
            map.put(key, digitalLendingResponse);
        } catch (Exception e){
            LogUtils.error("[ImageSearchService] handleCheckFaceSearchFailure",e.getMessage());
        }
    }
    public BlacklistCheckRequest buildBlacklistCheckRequest(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber){
        BlacklistCheckRequest blacklistCheckRequest = new BlacklistCheckRequest();
        blacklistCheckRequest.setRequestId(UUID.randomUUID().toString());
        blacklistCheckRequest.setRequestDate(DateUtils.dateTimeNow(DateUtils.DATE_TIME_FORMAT_VI_OUTPUT));
        blacklistCheckRequest.setDob(ocr.getDob());
        blacklistCheckRequest.setName(ocr.getName());
        blacklistCheckRequest.setIdImageVector(idVector);
        blacklistCheckRequest.setSelfieImageVector(selfieVector);
        blacklistCheckRequest.setCccdNumber(cccdNumber);
        if (!StringUtils.isNullOrEmpty(cmndoNumber))
            blacklistCheckRequest.setCmndoNumber(cmndoNumber);
        return blacklistCheckRequest;
    }
    public CheckFaceIdsRequest buildCheckFaceIdsRequest(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber){
        CheckFaceIdsRequest checkFaceIdsRequest = new CheckFaceIdsRequest();
        checkFaceIdsRequest.setRequestId(UUID.randomUUID().toString());
        checkFaceIdsRequest.setRequestDate(DateUtils.dateTimeNow(DateUtils.DATE_TIME_FORMAT_VI_OUTPUT));
        checkFaceIdsRequest.setDob(ocr.getDob());
        checkFaceIdsRequest.setName(ocr.getName());
        checkFaceIdsRequest.setIdImageVector(idVector);
        checkFaceIdsRequest.setSelfieImageVector(selfieVector);
        checkFaceIdsRequest.setCccdNumber(cccdNumber);
        if (!StringUtils.isNullOrEmpty(cmndoNumber))
            checkFaceIdsRequest.setCmndoNumber(cmndoNumber);
        return checkFaceIdsRequest;
    }
    public CheckIdsFaceRequest buildCheckIdsFaceRequest(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber){
        CheckIdsFaceRequest checkIdsFaceRequest = new CheckIdsFaceRequest();
        checkIdsFaceRequest.setRequestId(UUID.randomUUID().toString());
        checkIdsFaceRequest.setRequestDate(DateUtils.dateTimeNow(DateUtils.DATE_TIME_FORMAT_VI_OUTPUT));
        checkIdsFaceRequest.setDob(ocr.getDob());
        checkIdsFaceRequest.setName(ocr.getName());
        checkIdsFaceRequest.setIdImageVector(idVector);
        checkIdsFaceRequest.setSelfieImageVector(selfieVector);
        checkIdsFaceRequest.setCccdNumber(cccdNumber);
        if (!StringUtils.isNullOrEmpty(cmndoNumber))
            checkIdsFaceRequest.setCmndoNumber(cmndoNumber);
        return checkIdsFaceRequest;
    }
    private MultiValueMap<String, Object> buildFaceMatchingRequest(MultipartFile frontImg, MultipartFile selfieImg) throws IOException {
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        Utils.addMapImage(body, Constants.FACE_RAW_IMG1, frontImg);
        Utils.addMapImage(body, Constants.FACE_RAW_IMG2, selfieImg);
        return body;
    }

    private MultiValueMap<String, Object> buildFaceMatch3WayRequest(MultipartFile left, MultipartFile right, MultipartFile selfie) throws IOException {
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        Utils.addMapImage(body, Constants.FACE_RAW_IMG1, right);
        Utils.addMapImage(body, Constants.FACE_RAW_IMG2, left);
        Utils.addMapImage(body, Constants.FACE_RAW_IMG3, selfie);
        return body;
    }
    @Override
    public FaceMatch3WayResponse faceMatch3Way(FaceMatchingDTO faceMatchingDTO, String ocrRequestId, String username, String idNumber, Integer processType) {
        try {

            FaceMatch3WayResponse faceMatch3WayResponse = ekycProxy.faceMatch3way(this.buildFaceMatch3WayRequest(faceMatchingDTO.getLeftImg(), faceMatchingDTO.getRightImg(), faceMatchingDTO.getSelfieImg()));
            String rightImgUrl;
            String leftImgUrl;
            String selfieImgUrl;
            if(ProcessTypeEnum.EKYC_NOT_DL_FULL.getValue().equals(processType)) {
                rightImgUrl = faceMatchingDTO.getRightImgURL();
                leftImgUrl = faceMatchingDTO.getLeftImgURL();
                selfieImgUrl = faceMatchingDTO.getSelfieImgURL();
            } else {
                String filePath = Utils.generateFilePathOnS3(folderTaskName, username, idNumber);
                rightImgUrl = awsS3Service.upload(faceMatchingDTO.getRightImg(), filePath + Constants.PREFIX_RIGHT);
                leftImgUrl = awsS3Service.upload(faceMatchingDTO.getLeftImg(), filePath + Constants.PREFIX_LEFT);
                selfieImgUrl = awsS3Service.upload(faceMatchingDTO.getSelfieImg(), filePath + Constants.PREFIX_SELFIE);
            }
            if (faceMatch3WayResponse != null) {
                faceMatch3WayResponse.setSelfieImageURL(selfieImgUrl);
                faceMatch3WayResponse.setRightImageURL(rightImgUrl);
                faceMatch3WayResponse.setLeftImageURL(leftImgUrl);
                this.saveFaceMatch3Way(faceMatch3WayResponse, null, ocrRequestId, username, null);
            }

            return faceMatch3WayResponse;
        } catch (HttpStatusCodeException statusCodeException){
            this.saveFaceMatch3Way(null, statusCodeException.getResponseBodyAsString(), ocrRequestId, username, null);
            return null;
        } catch (IOException e) {
            this.saveFaceMatch3Way(null, e.getMessage(), ocrRequestId, username, null);
            return null;
        }
    }

    @Override
    public FaceMatchRawResponse faceMatchRaw(MultipartFile frontImg, MultipartFile selfieImg, String username) {
        try {
            FaceMatchRawResponse faceMatchRawResponse =  ekycProxy.eKyc(this.buildFaceMatchingRequest(frontImg ,selfieImg));
            LogUtils.info("[ImageSearchService] faceMatchRaw updateFaceMatching result");
            this.saveFaceMatchRaw(faceMatchRawResponse, null, UUID.randomUUID().toString(), username);
            return faceMatchRawResponse;
        } catch (HttpStatusCodeException statusCodeException){
            this.saveFaceMatchRaw(null, statusCodeException.getResponseBodyAsString(), UUID.randomUUID().toString(), username);
            return null;
        } catch (IOException e) {
            this.saveFaceMatchRaw(null, e.getMessage(), UUID.randomUUID().toString(), username);
            return null;
        }
    }

    @Override
    public FaceMatch3WayResponse faceMatch3Way(UpdateFaceMatchingDTO faceMatchingDTO, String username, String idNumber) {
        try {
            FaceMatch3WayResponse faceMatch3WayResponse = ekycProxy.faceMatch3way(this.buildFaceMatch3WayRequest(faceMatchingDTO.getLeftImg(), faceMatchingDTO.getRightImg(), faceMatchingDTO.getSelfieImg()));
            LogUtils.info("[ImageSearchService] faceMatch3Way updateFaceMatching result");
            String filePath = Utils.generateFilePathOnS3(folderTaskName, username, idNumber);
            String rightImgUrl = awsS3Service.upload(faceMatchingDTO.getRightImg(), filePath + Constants.PREFIX_RIGHT);
            String leftImgUrl = awsS3Service.upload(faceMatchingDTO.getLeftImg(), filePath + Constants.PREFIX_LEFT);
            String selfieImgUrl = awsS3Service.upload(faceMatchingDTO.getSelfieImg(), filePath + Constants.PREFIX_SELFIE);
            faceMatch3WayResponse.setSelfieImageURL(selfieImgUrl);
            faceMatch3WayResponse.setLeftImageURL(leftImgUrl);
            faceMatch3WayResponse.setRightImageURL(rightImgUrl);
            this.saveFaceMatch3Way(faceMatch3WayResponse, null, UUID.randomUUID().toString(), username, null);
            return faceMatch3WayResponse;
        } catch (HttpStatusCodeException statusCodeException){
            this.saveFaceMatch3Way(null, statusCodeException.getResponseBodyAsString(), UUID.randomUUID().toString(), username, null);
            return null;
        } catch (IOException e) {
            this.saveFaceMatch3Way(null, e.getMessage(), UUID.randomUUID().toString(), username, null);
            return null;
        }
    }

    private void saveFaceMatch3Way(FaceMatch3WayResponse faceMatch3WayResponse, String error, String ocrRequestId, String username, String deviceId){
        try {
            LogUtils.info("saveFaceMatch3Way response");
            FaceMatching3Way faceMatching3Way;
            if (faceMatch3WayResponse != null) {
                LogUtils.info("saveFaceMatch3Way response");
                faceMatching3Way = modelMapper.map(faceMatch3WayResponse, FaceMatching3Way.class);
                faceMatching3Way.setStatus(true);
            } else {
                faceMatching3Way = new FaceMatching3Way();
                faceMatching3Way.setError(error);
                faceMatching3Way.setStatus(false);
            }
            faceMatching3Way.setUsername(username);
            faceMatching3Way.setOcrRequestId(ocrRequestId);
            faceMatching3Way.setCreatedAt(new Date());
            faceMatching3Way.setUpdatedAt(new Date());
            faceMatching3Way.setSourceEkyc(SourceEKYC.OTHER.getValue());
            faceMatching3Way.setDeviceId(deviceId);
            LogUtils.info("saveFaceMatch3Way faceMatching3Way", faceMatching3Way.getError());
            faceMatching3WayRepository.save(faceMatching3Way);
        } catch (Exception e){
            LogUtils.error("saveFaceMatch3Way error", e.getMessage());
        }
    }
    @Override
    public AddVectorRequest buildAddVectorRequest(String db, String vec, String uid){
        return AddVectorRequest.builder()
                .requestId(UUID.randomUUID().toString())
                .requestDate(DateUtils.dateTimeNow(DateUtils.DATE_TIME_FORMAT_VI_OUTPUT))
                .db(db).vec(vec).uid(uid)
                .build();
    }

    @Override
    public AddVectorResponse addVector(AddVectorRequest request){
        AddVectorResponse response = null;
        try {
            response = imageFaceSearchProxy.addVector(request);
            this.handleAddVector(response, null);
            return response;
        } catch (HttpStatusCodeException e){
            this.handleAddVector(null, e);
            LogUtils.error("[ImageSearchService] add vector exception", e.getResponseBodyAsString());
        }
        return response;
    }

    private void handleAddVector(AddVectorResponse response, HttpStatusCodeException e) {
        if (response != null)
            LogUtils.info("[ImageSearchService] handleAddVector response", response);
        if (e != null)
            LogUtils.info("[ImageSearchService] handleAddVector e", e);
    }
    @Override
    public Map<String, Object> checkFaceSearch(FaceSearchRequest request, String username, String ocrRequestId){
        BlacklistCheckResponse blacklist;
        FaceIdsCheckResponse faceIds;
        IdFacesCheckResponse idFaces;
        try {
            // Kiểm tra blacklist
            CompletableFuture<BlacklistCheckResponse> blacklistCheckResCF = CompletableFuture.supplyAsync(()->this.checkBlacklist(request, username, ocrRequestId));
            // kiểm tra 1 mặt nhiều Id (1 user dùng nhiều cccd)
            CompletableFuture<FaceIdsCheckResponse> faceIdsCheckResCF = CompletableFuture.supplyAsync(()->this.checkFaceIds(request, username, ocrRequestId));
            // kiểm tra 1 id (cccd) sử dụng cho nhiều mặt
            CompletableFuture<IdFacesCheckResponse> idFacesCheckResCF = CompletableFuture.supplyAsync(()->this.checkIdsFace(request, username, ocrRequestId));
            // Chạy bất đồng bộ
            CompletableFuture.allOf(blacklistCheckResCF, faceIdsCheckResCF, idFacesCheckResCF);

            blacklist = modelMapper.map(blacklistCheckResCF.get(), BlacklistCheckResponse.class);
            faceIds = modelMapper.map(faceIdsCheckResCF.get(), FaceIdsCheckResponse.class);
            idFaces = modelMapper.map(idFacesCheckResCF.get(), IdFacesCheckResponse.class);
        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            LogUtils.info("[EKycService] faceMatching check blacklist, faceIds, IdFaces InterruptedException|ExecutionException", e.getMessage());
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, Constants.EKYC_IDENTIFIED_UN_SUCCESS);
        }
        if (blacklist == null || faceIds == null || idFaces == null){
            throw new ApplicationException(Error.SYSTEM_ERROR.getCode(),Error.SYSTEM_ERROR.getMessage());
        }
        if(Boolean.FALSE.equals(blacklist.isBlacklistCheckResult())){
            throw new ApplicationException(blacklist.getErrorCode(), blacklist.getMessage());
        }
        if(Boolean.FALSE.equals(faceIds.getImageSearchByIdCheckResult())){
            throw new ApplicationException(faceIds.getErrorCode(), faceIds.getMessage());
        }
        if(Boolean.FALSE.equals(idFaces.getImageSearchByIdCheckResult())){
            throw new ApplicationException(idFaces.getErrorCode(), idFaces.getMessage());
        }
        Map<String, Object> map = new HashMap<>();
        map.put(Constants.CHECK_BLACKLIST_RESPONSE, blacklist);
        map.put(Constants.CHECK_FACE_IDS_RESPONSE, faceIds);
        map.put(Constants.CHECK_IDS_FACE_RESPONSE, idFaces);
        return map;
    }
    // FaceSearchRequest hiện tại dùng chung cho blacklist, id-faces, face-ids
    @Override
    public FaceSearchRequest buildFaceSearchRequest(String idNumber, String idNumberOld, String name, String dob, String idNumberVector, String selfieVector){
        FaceSearchRequest req = new FaceSearchRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setRequestDate(DateUtils.dateTimeNow(DateUtils.DATE_TIME_FORMAT_VI_OUTPUT));
        req.setDob(dob);
        req.setName(name);
        req.setIdImageVector(idNumberVector);
        req.setSelfieImageVector(selfieVector);
        req.setCccdNumber(idNumber);
        if (!StringUtils.isNullOrEmpty(idNumberOld))
            req.setCmndoNumber(idNumberOld);
        return req;

    }
    public BlacklistCheckResponse checkBlacklist(FaceSearchRequest request, String username, String ocrRequestId){
        BlacklistCheckResponse blacklistCheckResponse;
        try {
            LogUtils.info("[EKycService] checkBlacklist");
            blacklistCheckResponse = imageFaceSearchProxy.blacklistCheck(request);
            this.saveBlacklist(blacklistCheckResponse, null, null, ocrRequestId, username);
        } catch (HttpStatusCodeException e){
            LogUtils.info("[EKycService] checkBlacklist failure", e.getResponseBodyAsString());
            blacklistCheckResponse = new BlacklistCheckResponse();
            blacklistCheckResponse.setErrorCode(e.getStatusCode().name());
            blacklistCheckResponse.setMessage(e.getStatusText());
            this.saveBlacklist(null, e.getStatusCode().name(), e.getResponseBodyAsString(), ocrRequestId, username);
        }
        return blacklistCheckResponse;
    }

    public FaceIdsCheckResponse checkFaceIds(FaceSearchRequest request, String username, String ocrRequestId){
        FaceIdsCheckResponse faceIdsCheckResponse;
        try {
            LogUtils.info("[EKycService] checkFaceIds");
            faceIdsCheckResponse = imageFaceSearchProxy.faceIdsCheck(request);
            this.saveCheckFaceIds(faceIdsCheckResponse, null, null, ocrRequestId, username);
        } catch (HttpStatusCodeException e){
            LogUtils.info("[EKycService] checkFaceIds failure", e.getResponseBodyAsString());
            faceIdsCheckResponse = new FaceIdsCheckResponse();
            faceIdsCheckResponse.setErrorCode(e.getStatusCode().name());
            faceIdsCheckResponse.setMessage(e.getStatusText());
            this.saveCheckFaceIds(null, e.getStatusCode().name(), e.getResponseBodyAsString(), ocrRequestId, username);
        }
        return faceIdsCheckResponse;
    }

    public IdFacesCheckResponse checkIdsFace(FaceSearchRequest request, String username, String ocrRequestId){
        IdFacesCheckResponse idFacesCheckResponse;
        try {
            LogUtils.info("[EKycService] checkIdsFace");
            idFacesCheckResponse = imageFaceSearchProxy.idFacesCheck(request);
            this.saveCheckIdsFace(idFacesCheckResponse, null, null, ocrRequestId, username);
        } catch (HttpStatusCodeException e){
            LogUtils.info("[EKycService] checkIdsFace failure", e.getResponseBodyAsString());
            idFacesCheckResponse = new IdFacesCheckResponse();
            idFacesCheckResponse.setErrorCode(e.getStatusCode().name());
            idFacesCheckResponse.setMessage(e.getStatusText());
            this.saveCheckIdsFace(null, e.getStatusCode().name(), e.getResponseBodyAsString(), ocrRequestId, username);
        }
        return idFacesCheckResponse;
    }
}