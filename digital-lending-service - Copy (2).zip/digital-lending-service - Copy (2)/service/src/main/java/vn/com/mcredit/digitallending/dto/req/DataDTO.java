package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class DataDTO {
    private String identity;
    private String dateOfBirth;
    private String expireDate;
    private String createdDate;
    private String gender;
}
