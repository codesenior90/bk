package vn.com.mcredit.digitallending.dto.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeviceVerificationResponse {
    private String createdAt;
    private String updatedAt;
    private String username;
    private String deviceId;
    private String verifiedAt;
    private boolean status;
}
