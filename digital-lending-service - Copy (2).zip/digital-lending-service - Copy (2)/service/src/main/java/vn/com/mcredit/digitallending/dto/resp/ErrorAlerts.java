package vn.com.mcredit.digitallending.dto.resp;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ErrorAlerts {
    @SerializedName("message")
    private String message;
    @SerializedName("code")
    private String code;
    @SerializedName("details")
    private String details;
}
