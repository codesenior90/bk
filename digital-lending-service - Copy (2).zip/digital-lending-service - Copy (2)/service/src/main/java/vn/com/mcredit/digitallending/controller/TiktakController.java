package vn.com.mcredit.digitallending.controller;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.com.mcredit.digitallending.dto.req.CheckPhoneRequest;
import vn.com.mcredit.digitallending.services.DigitalLendingService;

import javax.validation.Valid;

@RequiredArgsConstructor
@RequestMapping("")
@RestController
public class TiktakController {
    private final DigitalLendingService digitalLendingService;
    @Operation(summary = "Kiểm tra hạn mức và đã đăng ký tài khoản trên MC")
    @PostMapping(value = "/tiktak/check-phone", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> checkPhoneTiktak(@Valid @RequestBody CheckPhoneRequest checkPhoneRequest) {
        return ResponseEntity.status(HttpStatus.OK).body(digitalLendingService.checkPhoneTiktak(checkPhoneRequest));
    }
}
