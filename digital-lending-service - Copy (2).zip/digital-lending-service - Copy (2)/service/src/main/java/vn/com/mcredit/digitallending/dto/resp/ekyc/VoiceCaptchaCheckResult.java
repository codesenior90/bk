package vn.com.mcredit.digitallending.dto.resp.ekyc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude
public class VoiceCaptchaCheckResult {
    @JsonProperty("is_match")
    private Boolean match;
    private String captcha;
    private String text;
    @JsonProperty("audio_quality")
    private String audioQuality;

}
