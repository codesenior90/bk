package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.EkycModel;

@Repository
public interface EkycModelRepository extends JpaRepository<EkycModel, String> {
    Boolean existsByUsername(String username);
    boolean existsByIdNumber(String idNumber);
    EkycModel findByIdNumber(String idNumber);
    EkycModel findByUsername(String username);
}
