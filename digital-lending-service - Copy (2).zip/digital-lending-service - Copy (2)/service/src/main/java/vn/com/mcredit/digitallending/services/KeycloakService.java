package vn.com.mcredit.digitallending.services;

public interface KeycloakService {
    String issueDocumentLibraryToken();
}
