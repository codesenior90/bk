package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import vn.com.mcredit.digitallending.enums.SourceAppType;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;


@Data
public class PreCheckRequestDTO {
    private String fullName;
    private String idNumber;
    private String oldIdNumber;
    @NotNullorEmpty(message = "RequestId không được để trống!")
    private String requestId;
    @NotNullorEmpty(message = "referId không được để trống!")
    private String referId;
    private String xsell;
    private Double loanAmount;
    private String system = SourceAppType.DIGITAL_LENDING.getValue();
}
