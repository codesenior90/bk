package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.resp.ReasonRejectResponse;

import java.util.List;

public interface ReasonRejectService {
    List<ReasonRejectResponse> getAllByActiveAndType(boolean isActive, String type);
}
