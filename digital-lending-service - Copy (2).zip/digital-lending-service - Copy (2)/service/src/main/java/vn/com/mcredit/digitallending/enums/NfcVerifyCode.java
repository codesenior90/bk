package vn.com.mcredit.digitallending.enums;

public enum NfcVerifyCode {
    NOTVERIFRIED("NotVerified"),
    UNAUTHORIZED("Unauthorized"),
    ;

    private final String value;

    NfcVerifyCode(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
