package vn.com.mcredit.digitallending.dto.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RawUserDataDTO {

    private String gender; // Giới tính

    private String idNumber; // Số CCCD CHIP

    private String idNumberOld; // Số CMND|CCCD cũ

    private String name; // Họ và tên

    private String address; // Địa chỉ sinh sống

    private String nationality; // Quốc gia

    private String homeTown; // Nguyên quán

    private String issuedDate; // Ngày phát hành

    private String dob; // Ngày sinh

    private String expiryDate; // Ngày hết hạn

    private String religion; // Tôn giáo

    private String ethnic; // Dân tộc

    private String personalIdentification; // Đặc điểm nhận dạng

    private String faceImageUrl; // url ảnh khuôn mặt trên giấy tờ quét bằng công nghệ NFC

    private String fatherName; // Tên bố

    private String motherName; // Tên mẹ

    private String scoreAccuracy; // Điểm chấm

}
