package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class OcrResult {
    private OcrScore score;
}
