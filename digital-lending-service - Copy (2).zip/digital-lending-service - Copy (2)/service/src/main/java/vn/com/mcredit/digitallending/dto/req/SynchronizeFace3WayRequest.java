package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.Data;

import java.lang.annotation.Annotation;

@Data
public class SynchronizeFace3WayRequest implements SerializedName {
    @JsonProperty("detection_time")
    private Float detectionTime;

    @JsonProperty("embedding_time")
    private Float embeddingTime;

    @JsonProperty("pass")
    private Boolean pass;

    @JsonProperty("s12")
    private Float s12;

    @JsonProperty("s23")
    private Float s23;

    @JsonProperty("s31")
    private Float s31;

    @JsonProperty("error")
    private String error;

    @Override
    public String value() {
        return null;
    }

    @Override
    public String[] alternate() {
        return new String[0];
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return null;
    }
}
