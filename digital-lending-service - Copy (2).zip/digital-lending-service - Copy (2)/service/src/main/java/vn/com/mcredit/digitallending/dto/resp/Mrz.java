package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Mrz {

    @JsonProperty("nationality")
    private String nationality;

    @JsonProperty("id_number")
    private String idNumber;

    @JsonProperty("dob")
    private String dob;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("expire_date")
    private String expireDate;

    @JsonProperty("dob_checksum")
    private boolean dobChecksum;

    @JsonProperty("id9_checksum")
    private String id9Checksum;


    @JsonProperty("id_9_number")
    private String idN9Number;

    @JsonProperty("id12_checksum")
    private Boolean id12Checksum;

    @JsonProperty("expire_date_checksum")
    private boolean expireDateChecksum;

    @JsonProperty("name")
    private String name;
}
