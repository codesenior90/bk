package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.Data;

import java.lang.annotation.Annotation;

@Data
public class UserSummaryResponse implements SerializedName{

    @JsonProperty("isEkyc")
    private boolean ekyc;
    private String step;
    private String system;
    private Object user;
    private Boolean hasLoan;
    private Integer processEkyc;
    private boolean nfc;
    private String partnerCode;
    @Override
    public String value() {
        return null;
    }

    @Override
    public String[] alternate() {
        return new String[0];
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return null;
    }
}
