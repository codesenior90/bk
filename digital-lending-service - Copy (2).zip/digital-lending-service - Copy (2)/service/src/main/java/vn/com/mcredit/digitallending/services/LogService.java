package vn.com.mcredit.digitallending.services;

public interface LogService {
    void cleanup();
}
