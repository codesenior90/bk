package vn.com.mcredit.digitallending.proxy;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.Utils;


@Component
public class BPMProxy extends BaseProxy {

    @Value("${custom.properties.bpm-digital-api-host}")
    protected String bpmDigitalApiHost;
    public CheckDupMcResponse checkDupMc(Object dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/check-dup-mc");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, CheckDupMcResponse.class);
    }
    public PreCheckResponse preCheck(PreCheckRequestDTO preCheckRequestDTO){
        String url = String.format("%s%s?%s", bpmDigitalApiHost, "/pre-check", Utils.getRequestString(preCheckRequestDTO));
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), preCheckRequestDTO, PreCheckResponse.class);
    }

    public RejectOfferResponse rejectOffer(Object dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/reject-offer");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, RejectOfferResponse.class);
    }

    public PreOfferResponse preOffer(Object dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/pre-offer");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, PreOfferResponse.class);
    }
    public CompleteCaseResponse completeCase(CompleteCaseDTO dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/complete-case");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, CompleteCaseResponse.class);
    }
    public CustomerResponseInfo customerCheckInfo(CustomerRequestDTO dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/customer/checkinfo");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, CustomerResponseInfo.class);
    }
    public CheckAccountResponse checkMBAccount(MbAccountDTO dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/check-mb-account");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, CheckAccountResponse.class);
    }
    public MBAccountQueryRes getMBAccountInfo(MBAccountQueryReq dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/get-mb-account-info");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, MBAccountQueryRes.class);
    }
    public SearchOptionData[] searchOption(OptionDTO dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/search-option");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, SearchOptionData[].class);
    }

    public MatrixResponse disbursement(MatrixDisbursementRequest request){
        String url = String.format("%s%s", bpmDigitalApiHost, "/decision/disbursement/matrix");
        return  this.post(url, initHeaderAppJson(JWTUtils.getUsername()), request, MatrixResponse.class);
    }

    public CheckAccountDisbursementResponse checkAccountDisbursement(CheckAccountDisbursementRequestDTO request){
        String url = String.format("%s%s", bpmDigitalApiHost, "/check-account-disbursement");
        return  this.post(url, initHeaderAppJson(JWTUtils.getUsername()), request, CheckAccountDisbursementResponse.class);
    }

    public BpmCheckDeviceResponse bpmCheckDeviceId(BpmCheckDeviceReq request) {
        String url = String.format("%s%s", bpmDigitalApiHost, "/check-device-id");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), request, BpmCheckDeviceResponse.class);
    }

    public BpmCheckLoanDeviceResp checkLoanDevice(BpmCheckLoanDeviceReq request) {
        String url = String.format("%s%s", bpmDigitalApiHost, "/check-loan-device");
        return  this.post(url, initHeaderAppJson(JWTUtils.getUsername()), request, BpmCheckLoanDeviceResp.class);
    }

    public BpmBaseResponse updateLoanRequest(UpdateLoanRequestDTO request) {
        String url = String.format("%s%s", bpmDigitalApiHost, "/loans-profile-service/loans-request");
        return  this.post(url, initHeaderAppJson(JWTUtils.getUsername()), request, BpmBaseResponse.class);
    }

    public CheckAMLResponse checkAML(Object dto){
        String url = String.format("%s%s", bpmDigitalApiHost, "/check-aml");
        return this.post(url, initHeaderAppJson(JWTUtils.getUsername()), dto, CheckAMLResponse.class);
    }

}
