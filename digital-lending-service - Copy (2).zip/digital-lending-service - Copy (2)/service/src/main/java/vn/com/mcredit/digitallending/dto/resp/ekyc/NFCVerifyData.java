package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

@Data
public class NFCVerifyData {
    private String mrz;
    private String faceImage;
    private String cardNumber;
    private String dateOfBirth;
    private String issueDate;
    private String previousNumber;
    private String name;
    private String sex;
    private String nationality;
    private String nation;
    private String religion;
    private String hometown;
    private String address;
    private String character;
    private String expiredDate;
    private String fatherName;
    private String motherName;
    private String partnerName;
}
