package vn.com.mcredit.digitallending.logging;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.enums.TransactionKeeperEnum;

import javax.servlet.http.HttpServletRequest;

@Component
public class TransactionKeeper {

	@Autowired
	HttpServletRequest httpServletRequest;

	public String getSourceSystem() {
		return getAttribute(TransactionKeeperEnum.SOURCE_SYSTEM);
	}

	public String getServiceMessageId() {
		return getAttribute(TransactionKeeperEnum.SERVICE_MESSAGE_ID);
	}

	public String getTransactionId() {
		return getAttribute(TransactionKeeperEnum.TRANSACTION_ID);
	}

	public String getJWT() {
		return getAttribute(TransactionKeeperEnum.JWT);
	}

	public String getLogInfo() {
		return getAttribute(TransactionKeeperEnum.LOG_INFO);
	}

	private String getAttribute(TransactionKeeperEnum key) {
		try {
			return (String) httpServletRequest.getAttribute(key.value());
		} catch (Exception e) {
			return StringUtils.EMPTY;
		}
	}
}
