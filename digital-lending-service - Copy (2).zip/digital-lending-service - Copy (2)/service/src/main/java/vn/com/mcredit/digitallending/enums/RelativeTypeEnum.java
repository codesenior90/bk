package vn.com.mcredit.digitallending.enums;

public enum RelativeTypeEnum {
    SPOUSE("người hôn phối"),
    REFERENCE_PERSON("người tham chiếu"),
    RELATIVES("người thân"),
    ;

    private String value;

    RelativeTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
