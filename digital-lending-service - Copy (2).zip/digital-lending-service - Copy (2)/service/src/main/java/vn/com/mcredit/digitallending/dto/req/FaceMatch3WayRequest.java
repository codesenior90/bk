package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.File;

@Data
public class FaceMatch3WayRequest {
    @JsonProperty("process_id") // Require: Id của request gửi lên
    private String processId;
    @JsonProperty("img1")
    private File img1; // Require: Ảnh khách hàng quay phải
    @JsonProperty("img2")
    private File img2; // Require: Ảnh khách hàng chụp chính diện
    @JsonProperty("img3")
    private File img3; // Require: Ảnh khách hàng quay trái
}
