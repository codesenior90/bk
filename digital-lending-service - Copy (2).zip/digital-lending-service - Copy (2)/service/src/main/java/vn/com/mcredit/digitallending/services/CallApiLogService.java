package vn.com.mcredit.digitallending.services;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import vn.com.mcredit.digitallending.dto.LogDTO;
import vn.com.mcredit.digitallending.dto.req.CallLogRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface CallApiLogService {
    Object getLog(CallLogRequest request);
    void saveLog(Object body, HttpServletRequest request, HttpServletResponse httpServletResponse, LogDTO logInfo);
    void saveLog(Object body, HttpRequest request, ClientHttpResponse response);
}
