package vn.com.mcredit.digitallending.dto.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerCheckInfo {
    private String customerSector;
    private Boolean phoneNumber;
    private Boolean customerName;
    private Boolean account;
    private Boolean embStatus;
    private Boolean ewallet;
}