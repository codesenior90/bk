package vn.com.mcredit.digitallending.dto.resp.ekyc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude
public class VoiceCaptchaCheckResponse {
    private Boolean status;

    @JsonProperty("error_code")
    private String errorCode;

    @JsonProperty("error_mess")
    private String errorMessage;

    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("response_id")
    private String responseId;

    private VoiceCaptchaCheckResult result;
}
