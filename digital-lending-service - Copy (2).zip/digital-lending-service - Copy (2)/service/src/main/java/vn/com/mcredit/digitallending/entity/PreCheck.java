package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pre_check")
public class PreCheck {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "idNumber")
    private String idNumber;
    @Column(name = "oldIdNumber")
    private String oldIdNumber;
    @Column(name = "xsell")
    private String xsell;
    @Column(name = "loanAmount")
    private Integer loanAmount;
    @Column(name = "requestId")
    private String requestId;
    @Column(name = "userName")
    private String userName;
    @Column(name = "createdBy")
    private String createdBy;
    @Column(name = "updatedBy")
    private String updatedBy;
    @Column(name = "updatedDate")
    private Date updatedDate;
    @Column(name = "createdDate")
    private Date createdDate;
    @Column(name = "status",length = 30)
    private String status;
    @Column(name = "partner_code",length = 25)
    private String partnerCode;
    @Column(name = "errorCode")
    private String errorCode;
    @Column(name = "message")
    private String message;
    @Column(name = "referId")
    private String referId;
    @Column(name = "case_number")
    private String caseNumber;
}
