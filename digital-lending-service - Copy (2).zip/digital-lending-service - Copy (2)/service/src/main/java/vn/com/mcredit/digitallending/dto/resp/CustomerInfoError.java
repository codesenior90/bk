package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class CustomerInfoError {
    private String returnCode;
    private String returnMes;
}
