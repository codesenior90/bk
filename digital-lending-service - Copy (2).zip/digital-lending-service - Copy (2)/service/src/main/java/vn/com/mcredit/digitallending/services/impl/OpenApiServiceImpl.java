package vn.com.mcredit.digitallending.services.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.dto.resp.BankListResponse;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.proxy.OpenApiProxy;
import vn.com.mcredit.digitallending.services.OpenApiService;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.Utils;

@Service
@RequiredArgsConstructor
public class OpenApiServiceImpl implements OpenApiService {
    private final OpenApiProxy proxy;
    @Override
    public BankListResponse getBanks() {
        try {
            LogUtils.info("OpenApiService getBanks");
            BankListResponse banks = proxy.getBanks();
            banks.setCode(Constants.SUCCESS_CODE);
            banks.setStatus(Constants.SUCCESS_MESSAGE);
            return banks;
        } catch (HttpStatusCodeException statusCodeException){
            LogUtils.info("OpenApiService getBanks HttpStatusCodeException", statusCodeException.getResponseBodyAsString());
            throw new ApplicationException(String.valueOf(statusCodeException.getStatusCode().value()), Utils.getMessageError(statusCodeException.getResponseBodyAsString()));
        } catch (Exception e){
            LogUtils.info("OpenApiService getBanks Exception", e.getMessage());
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, e.getMessage());
        }
    }
}
