package vn.com.mcredit.digitallending.services;

public interface SupportService {
    String preventDuplicateMethod(String username);
}
