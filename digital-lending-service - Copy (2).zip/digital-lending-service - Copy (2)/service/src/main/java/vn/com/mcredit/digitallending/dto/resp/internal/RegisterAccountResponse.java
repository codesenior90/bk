package vn.com.mcredit.digitallending.dto.resp.internal;

import lombok.Data;

@Data

public class RegisterAccountResponse {
    private String accessToken;
    private String expiresIn;
    private String tokenType;
    private String username;
    private String fullName;
    private String system;
    private String applicationType;
}
