package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class SearchOptionResponse {
    @JsonProperty("data")
    private List<SearchOptionData> data;
}
