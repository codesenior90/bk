package vn.com.mcredit.digitallending.aop;


import java.lang.annotation.*;
import java.util.concurrent.TimeUnit;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface PreventDuplicateMethod {

	String prefix() default "";

	int expire() default 5;

	TimeUnit timeUnit() default TimeUnit.SECONDS;

	String delimiter() default ":";

}
