package vn.com.mcredit.digitallending.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MatchingData {
    private String errorCode;
    private UserData data;
    private UserData oldData;
}
