package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import vn.com.mcredit.digitallending.entity.ReasonReject;

@Data
@AllArgsConstructor
public class ReasonRejectResponse {
    @JsonProperty("reasonCode")
    private String reasonCode;
    @JsonProperty("reasonMessage")
    private String reasonMessage;
    @JsonProperty("isFreeText")
    private boolean isFreeText;

    public static ReasonRejectResponse toResponseData(ReasonReject reasonReject) {
        return new ReasonRejectResponse(reasonReject.getReasonCode(), reasonReject.getReasonMessage(), reasonReject.isFreeText());
    }
}
