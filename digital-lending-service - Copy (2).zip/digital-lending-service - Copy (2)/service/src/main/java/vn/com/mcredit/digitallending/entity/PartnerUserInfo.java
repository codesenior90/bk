package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "partner_user_info")
public class PartnerUserInfo {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "system", length = 25)
    private String system;
    @Column(name = "mobile", length = 15)
    private String mobile;
    @Column(name = "email", length = 100)
    private String email;
    @Column(name = "date_of_birth", length = 10)
    private String dateOfBirth;
    @Column(name = "code", length = 36)
    private String code;
    @Column(name = "name", length = 50)
    private String name;
    @Column(name = "created_by", length = 50)
    private String createdBy;
    @Column(name = "status", length = 50)
    private String status;
    @Column(name = "cif", length = 36)
    private String cif;
    @Column(name = "full_name", length = 100)
    private String fullnameVn;
    @Column(name = "id_card_type", length = 50)
    private String idCardType;
    @Column(name = "id_card_no", length = 36)
    private String idCardNo;
    @Column(name = "id_card_issued_date", length = 10)
    private String idCardIssuedDate;
    @Column(name = "id_card_issued_place")
    private String idCardIssuedPlace;
    @Column(name = "id_card_expiry_date", length = 10)
    private String idCardExpiryDate;
    @Column(name = "gender", length = 20)
    private String gender;
    @Column(name = "address")
    private String address;
    @Column(name = "permanent_address")
    private String permanentAddress;
    @Column(name = "marital_status", length = 50)
    private String maritalStatus;
    @Column(name = "nationality", length = 50)
    private String nationality;
    @Column(name = "account_list", columnDefinition = "text")
    private String accountList;
    @Column(name = "account_default", length = 36)
    private String accountDefault;
    @Column(name = "sector")
    private String sector;
    @Column(name = "device_id", length = 36)
    private String deviceId;
    @Column(name = "partner", length = 25)
    private String partner;
    @CreationTimestamp
    @Column(name = "created_at")
    private Date createdAt;
    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updatedAt;

}
