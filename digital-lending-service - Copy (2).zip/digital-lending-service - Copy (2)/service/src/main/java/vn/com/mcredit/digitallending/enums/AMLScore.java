package vn.com.mcredit.digitallending.enums;

public enum AMLScore {
    L("L"),
	M("M"),
	H("H");

    private String value;

    AMLScore(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
