package vn.com.mcredit.digitallending.schedule;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import vn.com.mcredit.digitallending.services.SynchronizeService;

@Configuration
@EnableScheduling
@RequiredArgsConstructor
public class SynchronizeSchedule {
    private static final long TIMES_RETRY = 1000 * 60L * 30;
    private final SynchronizeService synchronizeService;
    @Scheduled(fixedRate = TIMES_RETRY)
    public void run(){
        synchronizeService.synchronizes();
    }
}
