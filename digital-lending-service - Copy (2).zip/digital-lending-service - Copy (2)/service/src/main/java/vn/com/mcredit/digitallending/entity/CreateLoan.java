package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import java.math.BigInteger;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "create_loan")
public class CreateLoan {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;
    @Column(name = "idNumber")
    private String idNumber;
    @Column(name = "request_id")
    private String requestId;
    @Column(name = "offer_id")
    private BigInteger offerId;
    @Column(name = "customer_request", columnDefinition = "text")
    private String customerRequest;
    @Column(name = "customer_address", columnDefinition = "text")
    private String customerAddress;
    @Column(name = "customer_relative", columnDefinition = "text")
    private String customerRelatives;
    @Column(name = "identity_paper", columnDefinition = "text")
    private String identityPaper;
    @Column(name = "loan_file_upload", columnDefinition = "text")
    private String loansFileUpload;
    @Column(name = "notification_request", columnDefinition = "text")
    private String notificationRequest;
    @Column(name = "notification_response", columnDefinition = "text")
    private String notificationResponse;
    @Column(name = "userName")
    private String userName;
    @Column(name = "createdBy")
    private String createdBy;
    @Column(name = "updatedBy")
    private String updatedBy;
    @Column(name = "updatedDate")
    private Date updatedDate;
    @Column(name = "createdDate")
    private Date createdDate;
    @Column(name = "status", length = 30)
    private String status;
    @Column(name = "reason")
    private String reason;
    @Column(name = "contract_number")
    private String contractNumber;

    @Column(name  = "sign_date")
    private String signDate;
    @Column(name  = "case_number")
    private String caseNumber;

    @Column(name = "user_sign")
    private String userSign;

    @Column(name = "complete_date")
    private String completeDate;

    @Column(name  = "complete_user")
    private String completeUser;

    @Column(name = "contract_status", length = 30)
    private String contractStatus;

    @Column(name = "refer_id")
    private String referId; // request_id ở bước check dup mc
    @Column(name = "telco_location_request_id")
    private String telcoLocationRequestId; // đối với khách hàng sim không chính chủ (c10.2 là Y)

    @Column(name = "partner_code", length = 25)
    private String partnerCode; // Dùng để trace khách hàng lên case từ đâu (Mini-app, web, app mcredit ...)
}
