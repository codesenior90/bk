package vn.com.mcredit.digitallending.services;

import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.enums.DocumentType;

import java.io.IOException;

public interface EcmService {
    String upload(Object body);
    String upload(String idNumber, DocumentType documentType, MultipartFile file) throws IOException;
    String upload(String idNumber, DocumentType documentType, String url, String fileName) throws IOException;
}
