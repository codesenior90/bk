package vn.com.mcredit.digitallending.enums;

import java.util.Arrays;

public enum CustomerAddressType {
    ADDRESS_LIVE("Địa trỉ tạm trú"),
    ADDRESS_PERMANENT("Địa chỉ thường trú");

    private String value;

    CustomerAddressType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static boolean validateAddressType(String addressType) {
        return Arrays.stream(CustomerAddressType.values()).anyMatch(p->p.name().equalsIgnoreCase(addressType));
    }
}
