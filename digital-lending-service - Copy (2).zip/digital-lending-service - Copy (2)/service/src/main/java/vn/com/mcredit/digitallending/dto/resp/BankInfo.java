package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class BankInfo {
    private String bankName; // Tên Ngân hàng
    private String bankCode; // Code ngân hàng
    private String details; // Chi tiết
    private String shortName; // Tên viết tắt
    private String smlCode; // SML Code
    private String regex; // regex
    private String transferType; // Loại hình chuyển tiền(nội bộ/liên ngân hàng)
    private String bankIcon; // Logo link
}
