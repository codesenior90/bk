package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OcrResponse {

  // Todo

  @JsonProperty("id_number_old")
  private String idNumberOld;

  @JsonProperty("request_id")
  private String requestId;
  @JsonProperty("id_type")
  private String idType;

  @JsonProperty("id_name")
  private String idName;

  @JsonProperty("status")
  private boolean status;

  @JsonProperty("front_screen_score")
  private String frontScreenScore;

  @JsonProperty("back_screen_score")
  private String backScreenScore;

  @JsonProperty("front_blur_score")
  private String frontBlurScore;

  @JsonProperty("back_blur_score")
  private String backBlurScore;

  @JsonProperty("error")
  private String error;

  @JsonProperty("result")
  private OcrResultResponse result;
}
