package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PreOfferDataResponse {
    @JsonProperty("requestId")
    private String requestId;

    @JsonProperty("status")
    private String status;

    @JsonProperty("firstPaymentDate")
    private String firstPaymentDate;

    @JsonProperty("monthlyPaymentAmount")
    private Double monthlyPaymentAmount;

    @JsonProperty("loanAmtMinusInsu")
    private Double loanAmtMinusInsu;

    @JsonProperty("loanAmount")
    private Double loanAmount;

    @JsonProperty("insuranceFee")
    private Double insuranceFee;

    @JsonProperty("insuranceRate")
    private Double insuranceRate;

    @JsonProperty("loanTenor")
    private Integer loanTenor;

    @JsonProperty("recurringPaymentRate")
    private String recurringPaymentRate;

    @JsonProperty("insuranceCompany")
    private String insuranceCompany;

    @JsonProperty("interestRate")
    private String interestRate;

    @JsonProperty("loanMethod")
    private String loanMethod;

    @JsonProperty("campaignCode")
    private String campaignCode;

    @JsonProperty("campaignCode")
    private String campaignName;
}
