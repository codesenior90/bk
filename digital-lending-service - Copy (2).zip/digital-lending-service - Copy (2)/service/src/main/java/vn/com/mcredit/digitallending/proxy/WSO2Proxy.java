package vn.com.mcredit.digitallending.proxy;

import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import vn.com.mcredit.digitallending.dto.resp.WSO2TokenDTO;
import vn.com.mcredit.digitallending.utils.LogUtils;

@Component
public class WSO2Proxy extends BaseProxy {

    public WSO2TokenDTO authorize() {
        LogUtils.info(" WSO2TokenDTO-authorize url : " + apiManagerHost + "/token");
        MultiValueMap<String, String> map= new LinkedMultiValueMap<>();
        map.add("grant_type", "client_credentials");
        map.add("client_secret", amClientSecret);
        map.add("client_id", amClientKey);
        return this.postAppFormUrl(amClientKey, amClientSecret, apiManagerHost + "/token",
                initHeaderAppFormUrl(),WSO2TokenDTO.class);
    }


}
