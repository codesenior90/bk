package vn.com.mcredit.digitallending.middleware;

import org.slf4j.Logger;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import vn.com.mcredit.digitallending.enums.TransactionKeeperEnum;
import vn.com.mcredit.digitallending.factory.LoggingFactory;
import vn.com.mcredit.digitallending.logging.Logging;
import vn.com.mcredit.digitallending.logging.TransactionKeeper;
import vn.com.mcredit.digitallending.services.CallApiLogService;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static net.logstash.logback.argument.StructuredArguments.keyValue;

@Component
public class RestTemplateInterceptor implements ClientHttpRequestInterceptor {
	private static final Logger log = LoggingFactory.getLogger(RestTemplateInterceptor.class);
	public static final String HEADERS = "headers";
	private TransactionKeeper tk;
	private Logging l;

	private CallApiLogService callApiLogService;
	public RestTemplateInterceptor(TransactionKeeper tk, Logging l, CallApiLogService callApiLogService) {
		this.tk = tk;
		this.l = l;
		this.callApiLogService = callApiLogService;
	}

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {

		logRequest(request, body);
		ClientHttpResponse response = null;
		try {
			response = execution.execute(request, body);
		} catch (Exception e) {
			LogUtils.error("RestTemplateInterceptor.intercept", e.getMessage());
		}
		logResponse(request, body, response);
		return response;
	}

	private void logRequest(HttpRequest request, byte[] body) {
		if (request != null) {
			try {
				l.info("logRequest");
				request.getHeaders().add(TransactionKeeperEnum.SERVICE_MESSAGE_ID.value(), tk.getServiceMessageId());
				request.getHeaders().add(TransactionKeeperEnum.TRANSACTION_ID.value(), tk.getTransactionId());
				request.getHeaders().add(TransactionKeeperEnum.JWT.value(), tk.getJWT());
				request.getHeaders().add(TransactionKeeperEnum.SOURCE_SYSTEM.value(), tk.getSourceSystem());
				Map<String, Object> map = new LinkedHashMap<>();
				map.put("type", "request");
				map.put("method", request.getMethodValue());
				map.put("uri", request.getURI());
				log.info("{} Headers = {} ", map, keyValue(HEADERS, request.getHeaders()));

			} catch (Exception e) {
				LogUtils.error("RestTemplateInterceptor.logRequest", e.getMessage());
			}

		}
	}

	private void logResponse(HttpRequest request, byte[] body, ClientHttpResponse response) {
		if (response != null) {
			try {
				response.getHeaders().add(TransactionKeeperEnum.SERVICE_MESSAGE_ID.value(), tk.getServiceMessageId());
				response.getHeaders().add(TransactionKeeperEnum.TRANSACTION_ID.value(), tk.getTransactionId());
				response.getHeaders().add(TransactionKeeperEnum.JWT.value(), tk.getJWT());
				response.getHeaders().add(TransactionKeeperEnum.SOURCE_SYSTEM.value(), tk.getSourceSystem());
				Map<String, Object> map = new LinkedHashMap<>();
				map.put("type", "response");
				map.put("status", response.getStatusCode());
				map.put("statusText", response.getStatusText());
				map.put("method", request.getMethodValue());
				map.put("uri", request.getURI());
				String payload = "";
				if (body != null && !Utils.apiContainSensitiveData(request.getURI().toString())){
					payload = new String(body, StandardCharsets.UTF_8);
        		}
        		if (!request.getURI().toString().contains("/api/v1/log")) {
          			this.saveLog(payload, request, response);
				}
			} catch (Exception e) {
				LogUtils.error("RestTemplateInterceptor.logResponse", e.getMessage());
			}

		}
	}
	private void saveLog(Object body, HttpRequest request, ClientHttpResponse response){
		callApiLogService.saveLog(body, request, response);
	}
}