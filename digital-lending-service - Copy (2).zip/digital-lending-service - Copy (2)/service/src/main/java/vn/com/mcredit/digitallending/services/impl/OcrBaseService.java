package vn.com.mcredit.digitallending.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.req.OcrForm;
import vn.com.mcredit.digitallending.dto.resp.OcrResponse;
import vn.com.mcredit.digitallending.entity.Ocr;
import vn.com.mcredit.digitallending.enums.CardType;
import vn.com.mcredit.digitallending.enums.ProcessTypeEnum;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.repositories.OcrRepository;
import vn.com.mcredit.digitallending.services.AfcService;
import vn.com.mcredit.digitallending.services.AwsS3Service;
import vn.com.mcredit.digitallending.services.MCPortalService;
import vn.com.mcredit.digitallending.utils.DateUtils;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.io.IOException;
import java.util.Date;

@Service
public class OcrBaseService {
    public static final String FRONT = "front";
    public static final String BACK = "back";
    public static final String SELFIE = "selfie";
    public static final String LEFT = "left";
    public static final String RIGHT = "right";

    @Autowired
    protected AfcService afcService;
    @Value("${custom.properties.cutoff-screen}")
    private Float cutoffScreen;
    @Value("${custom.properties.aws-s3-folder-task-name}")
    private String folderTaskName;

    @Autowired
    protected MCPortalService mcPortalService;
    @Autowired
    private AwsS3Service awsS3Service;
    @Autowired
    protected OcrRepository ocrRepository;
    /**
     * Tạo request Body ocr
     * @param form
     * @return
     * @throws IOException
     */
    protected MultiValueMap<String, Object> buildOcrRequest(OcrForm form) throws IOException {
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        Utils.addMapImage(body, FRONT, form.getFrontImg());
        Utils.addMapImage(body, BACK, form.getBackImg());
        return body;
    }

    protected void validateInformationOcr(Ocr ocr, String idNumber, String gender, String dob, String issueDate, String expireDate){
        // Kiểm tra định dạng sô CCCD Chip
        LogUtils.error("[OcrService] validateInformationOcr idNumber", idNumber);
        if(!Utils.isCccd(idNumber)){
            this.updateOcrError(ocr, Error.ID_NUMBER_INVALID_FORMAT.getCode(), Error.ID_NUMBER_INVALID_FORMAT.getMessage());
            throw new ApplicationException(Error.ID_NUMBER_INVALID_FORMAT.getCode(), Error.ID_NUMBER_INVALID_FORMAT.getMessage());
        }
        this.validateDateFormat(ocr, dob, issueDate, expireDate);
        // Kiểm tra ngày hết hạn với ngày cấp CCCD
        var resultCompare = DateUtils.compareTo(expireDate, issueDate, DateUtils.F_DDMMYYYY);
        if (resultCompare == null || resultCompare <= 0){
            this.updateOcrError(ocr, Error.EXPIRE_DATE_LESS_ISSUE_DATE.getCode(), Error.EXPIRE_DATE_LESS_ISSUE_DATE.getMessage());
            throw new ApplicationException(Error.EXPIRE_DATE_LESS_ISSUE_DATE.getCode(), Error.EXPIRE_DATE_LESS_ISSUE_DATE.getMessage());
        }
        // Kiểm tra giới tính Nam|Nữ
        if (!(Constants.MALE.equalsIgnoreCase(gender) || Constants.FEMALE.equalsIgnoreCase(gender))){
            this.updateOcrError(ocr, Error.GENDER_INVALID.getCode(), Error.GENDER_INVALID.getMessage());
            throw new ApplicationException(Error.GENDER_INVALID.getCode(), Error.GENDER_INVALID.getMessage());
        }
    }

    protected void validateDateFormat(Ocr ocr, String dob, String issueDate, String expireDate) {
        // Kiểm tra định dạng ngày sinh
        boolean dobValid = DateUtils.isValid(dob, DateUtils.F_DDMMYYYY);
        LogUtils.error("[OcrService] validateInformationOcr dob", dob);
        if(!dobValid){
            this.updateOcrError(ocr, Error.DOB_INVALID_FORMAT.getCode(), Error.DOB_INVALID_FORMAT.getMessage());
            throw new ApplicationException(Error.DOB_INVALID_FORMAT.getCode(), Error.DOB_INVALID_FORMAT.getMessage());
        }
        // Kiểm tra định dạng ngày cấp
        LogUtils.error("[OcrService] validateInformationOcr issueDateValid", issueDate);
        boolean issueDateValid = DateUtils.isValid(issueDate, DateUtils.F_DDMMYYYY);
        if (!issueDateValid){
            this.updateOcrError(ocr, Error.ISSUE_DATE_INVALID_FORMAT.getCode(), Error.ISSUE_DATE_INVALID_FORMAT.getMessage());
            throw new ApplicationException(Error.ISSUE_DATE_INVALID_FORMAT.getCode(), Error.ISSUE_DATE_INVALID_FORMAT.getMessage());
        }
        // Kiểm tra định dạng ngày hết hạn
        LogUtils.error("[OcrService] validateInformationOcr expiredDateValid", expireDate);
        boolean expireDateValid = DateUtils.isValid(expireDate, DateUtils.F_DDMMYYYY);
        if (!expireDateValid){
            this.updateOcrError(ocr, Error.EXPIRE_DATE_INVALID_FORMAT.getCode(), Error.EXPIRE_DATE_INVALID_FORMAT.getMessage());
            throw new ApplicationException(Error.EXPIRE_DATE_INVALID_FORMAT.getCode(), Error.EXPIRE_DATE_INVALID_FORMAT.getMessage());
        }
    }
    protected boolean verifyOcrCutOff(Float frontScreenScore, Float backScreenScore) {
        if (frontScreenScore == null || backScreenScore == null) return false;
        LogUtils.info("[OcrService] verifyOcrResult backScreenScore", backScreenScore);
        LogUtils.info("[OcrService] verifyOcrResult frontScreenScore", frontScreenScore);
        return backScreenScore <= cutoffScreen && frontScreenScore <= cutoffScreen;
    }
    protected void verifyCCCDChip(Ocr ocr, String idName, String idNumber, String name, String gender, String address){
        String username = JWTUtils.getUsername();
        if (!CardType.CCCD_CHIP.getValue().equalsIgnoreCase(idName)){
            if(!CardType.INVALID_CARD.getValue().equalsIgnoreCase(idNumber)) {
                mcPortalService.sendLeadToMcPortal(idNumber, name, gender, address, username, JWTUtils.getPartnerCode());
            }
            this.updateOcrError(ocr, Error.FAIL_INCORRECT_CCCD_CHIP.getCode(), Error.FAIL_INCORRECT_CCCD_CHIP.getMessage());
            throw new ApplicationException(Error.FAIL_INCORRECT_CCCD_CHIP.getCode(), Error.FAIL_INCORRECT_CCCD_CHIP.getMessage());
        }
    }


    protected void verifyCCCDChip(Ocr ocr, OcrResponse ocrResponse){
        if (!ocrResponse.isStatus()
                || !CardType.CCCD_CHIP_TYPE.getValue().equalsIgnoreCase(ocrResponse.getIdType())){
            if(!CardType.INVALID_CARD.getValue().equalsIgnoreCase(ocrResponse.getIdType()) && ocrResponse.getResult() != null ) {
                mcPortalService.sendLeadToMcPortal(ocrResponse.getResult(), JWTUtils.getUsername(),JWTUtils.getPartnerCode());
            }
            this.updateOcrError(ocr, Error.FAIL_INCORRECT_CCCD_CHIP.getCode(), Error.FAIL_INCORRECT_CCCD_CHIP.getMessage());
            throw new ApplicationException(Error.FAIL_INCORRECT_CCCD_CHIP.getCode(), Error.FAIL_INCORRECT_CCCD_CHIP.getMessage());
        }
    }
    protected void upload(MultipartFile front, MultipartFile back, String username, String idNumber, Ocr ocr){
        try {
            String filePath;
            if (idNumber != null){
                filePath = Utils.generateFilePathOnS3(folderTaskName, username, idNumber);
            } else {
                filePath = Utils.generateFilePathOnS3(folderTaskName, username, null);
            }
            String frontUrl = awsS3Service.upload(front, filePath + Constants.PREFIX_FRONT);
            ocr.setFrontImageURL(frontUrl);
            String backUrl = awsS3Service.upload(back, filePath + Constants.PREFIX_BACK);
            ocr.setBackImageURL(backUrl);
        } catch (Exception e){
            LogUtils.error("upload file to s3 fail", e.getMessage());
        }
    }
    protected void updateOcrError(Ocr ocr, String errorCode, String errorMessage){
        try {
            if (ocr != null) {
                ocr.setPass(false);
                ocr.setError(errorCode);
                ocr.setErrorMessage(errorMessage);
                ocr.setUpdatedAt(new Date());
                ocrRepository.save(ocr);
            }
        } catch (Exception e){
            LogUtils.info("[OcrService] updateOcrError");
        }
    }
    protected void verifyIdentifyNumber(Ocr ocr, String idNumber, Integer processEkyc){
        if(ProcessTypeEnum.NONE_EKYC.getValue().equals(processEkyc)) {
            ApplicationException exception = afcService.verifyIdentifyNumber(idNumber);
            if (exception != null) {
                this.updateOcrError(ocr, exception.getCode(), exception.getMessage());
                throw exception;
            }

        }
    }
}
