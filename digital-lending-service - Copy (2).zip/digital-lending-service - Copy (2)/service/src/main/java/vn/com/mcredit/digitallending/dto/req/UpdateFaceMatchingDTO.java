package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

import javax.validation.constraints.NotNull;

@Data
public class UpdateFaceMatchingDTO {
    private MultipartFile frontImg;
    @NotNull(message = "Ảnh mặt trái không được để trống")
    private MultipartFile leftImg;
    @NotNull(message = "Ảnh mặt phải không được để trống")
    private MultipartFile rightImg;
    @NotNull(message = "Ảnh mặt trước không được để trống")
    private MultipartFile selfieImg;
    @NotNullorEmpty(message = "Hệ thống không được để trống")
    private String system;
    @NotNullorEmpty(message = "Mã thiết bị không được để trống")
    private String deviceId;
}
