package vn.com.mcredit.digitallending.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.com.mcredit.digitallending.aop.Secured;
import vn.com.mcredit.digitallending.dto.req.TelcoLocationRequest;
import vn.com.mcredit.digitallending.enums.SystemNameEnum;
import vn.com.mcredit.digitallending.services.TelcoService;

@RequiredArgsConstructor
@RequestMapping("/api/telco/v1")
@RestController
public class TelcoController {

    private final TelcoService service;

    @PostMapping("/telco-check")
    @Secured(system = SystemNameEnum.MOBILE_DIGITAL_LENDING)
    public ResponseEntity<Object> telcoCheck(@RequestBody TelcoLocationRequest request) {
        return ResponseEntity.status(HttpStatus.OK).body(service.telcoLocationCheck(request));
    }

}
