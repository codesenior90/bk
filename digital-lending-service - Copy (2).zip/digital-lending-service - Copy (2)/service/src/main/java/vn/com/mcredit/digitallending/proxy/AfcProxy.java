package vn.com.mcredit.digitallending.proxy;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.UserProfileCreateDTO;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.internal.RegisterAccountResponse;
import vn.com.mcredit.digitallending.dto.req.internal.RegisterAccountRequest;
import vn.com.mcredit.digitallending.utils.JWTUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.util.Map;


@Component
public class AfcProxy extends BaseProxy {
    @Value("${custom.properties.m4c-api-host}")
    private String m4cAfcHost;

    @Value("${custom.properties.m4c-auth-api-host}")
    private String m4cAuthHost;

    @Value("${custom.properties.m4c-loan-api-host}")
    private String m4cLoanHost;
    @Value("${custom.properties.m4c-contract-api-host}")
    private String m4cContractHost;
    @Value("${custom.properties.m4c-notify-api-host}")
    private String m4cNotifyHost;

    // User-Profile-Service
    public CheckAccountRegisterResponse checkUserAccount(String phone) {
        String url = String.format("%s%s%s", m4cAfcHost, "internal/m4c/user/v1/check-user-account/", phone);
        return this.get(url, initHeaderAppJson(), CheckAccountRegisterResponse.class);
    }

    public IdentityPresentResponse checkIdentityPresent(String identity) {
        String url = String.format("%s%s%s", m4cAfcHost, "internal/m4c/user/v1/check-identity/", identity);
        return this.get(url, initHeader(), IdentityPresentResponse.class);
    }

    public byte[] viewEcontractTransaction(Object dto) {
        String url = String.format("%s%s", m4cContractHost, "econtract-transaction/v1/view");
        return this.post(url, initHeader(JWTUtils.getToken()), dto, byte[].class);
    }

    public Object sendOtp(Object dto) {
        String url = String.format("%s%s", m4cAfcHost, "admin/v1/otp/send");
        return this.post(url, initHeaderAppJson(), dto, Object.class);
    }

    public Object verifyPhoneOtp(Object dto) {
        String url = String.format("%s%s", m4cAfcHost, "admin/v1/otp/verify");
        return this.post(url, initHeaderAppJson(), dto, Object.class);
    }

    public AccessTokenDTO register(UserProfileCreateDTO dto) {
        String url = String.format("%s%s", m4cAfcHost, "admin/v1/register");
        return this.post(url, initHeaderAppJson(), dto, AccessTokenDTO.class);
    }

    // Authentication-Service
    public AccessTokenDTO login(LoginDTO loginDTO) {
        String url = String.format("%s%s", m4cAuthHost, "authentication/mobile-4-customers/v2/login");
        return this.post(url, initHeaderAppJson(), loginDTO, AccessTokenDTO.class);
    }

    public AccessTokenDTO loginV6(EncryptDTO encryptDTO) {
        String url = String.format("%s%s", m4cAuthHost, "authentication/mobile-4-customers/v6/login");
        return this.post(url, initHeaderAppJson(), encryptDTO, AccessTokenDTO.class);
    }

    // Ekyc-Loan-Service
    public SynchronizeEkycResponse synchronize(SynchronizeEkycRequest body, String token) {
        String url = String.format("%s%s", m4cLoanHost, "internal/ekyc/v1/synchronize");
        return this.post(url, initHeader(token), body, SynchronizeEkycResponse.class);
    }

    public EkycDetailResponse getEkycDetail(String username) {
        String url = String.format("%s%s?username=%s", m4cLoanHost, "internal/ekyc/v1/detail", username);
        return this.get(url, initHeaderAppJson(), EkycDetailResponse.class);
    }

    public CheckDeviceResponse checkDevice(CheckDeviceRequest request) {
        String url = String.format("%s%s", m4cLoanHost, "internal/ekyc/v1/check-device");
        return this.post(url, initHeaderAppJson(), request, CheckDeviceResponse.class);
    }
    public DeviceVerificationResponse getDeviceVerification(Map<String, String> requestParams) {
        String url = String.format("%s%s?%s", m4cAfcHost, "internal/m4c/user/v1/device-verification", Utils.parseRequestParams(requestParams));
        return this.get(url, initHeaderAppJson(), DeviceVerificationResponse.class);
    }

    public Object pushUserNotify(AfcNotifyRequest request) {
        String url = String.format("%s%s", m4cNotifyHost, "v1/push-notification-action");
        return this.post(url, initHeaderAppJson(), request, Object.class);
    }

    // https://dudu-uat.mcredit.com.vn/user-profile-service/internal/m4c/user/v1/register
    public RegisterAccountResponse register(RegisterAccountRequest body) {
        String url = String.format("%s%s", m4cAfcHost, "internal/m4c/user/v1/register");
        return this.post(url, initHeaderAppJson(), body, RegisterAccountResponse.class);
    }
    // Authentication-Service
    public AccessTokenV7DTO loginV7(LoginDTO loginDTO) {
        String url = String.format("%s%s", m4cAuthHost, "authentication/mobile-4-customers/internal/v1/login");
        return this.post(url, initHeaderAppJson(), loginDTO, AccessTokenV7DTO.class);
    }
}
