package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class QueryMBAccountStatusRequest {
    private String accountNumber;
}
