package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.persistence.JoinColumn;
import javax.persistence.FetchType;
import javax.persistence.CascadeType;
import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "home_lending")
public class HomeLending {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 32)
    private String id;
    @Column(name = "banner_url")
    private String bannerUrl;
    @Column(name = "title")
    private String title;
    @Column(name = "content")
    private String content;
    @Column(name = "main_image_url")
    private String mainImageUrl;
    @Column(name = "max_value_lending_title")
    private String maxValueLendingTitle;
    @Column(name = "max_value_lending")
    private Integer maxValueLending;
    @Column(name = "min_value_vending")
    private Integer minValueVending;
    @Column(name = "rate_per_month")
    private Double ratePerMonth;
    @Column(name = "month_lending")
    private Integer monthLending;
    @OneToMany(fetch = FetchType.EAGER, cascade= CascadeType.ALL)
    @JoinColumn(name = "home_lending_id")
    private List<ConditionLending> conditions;
}
