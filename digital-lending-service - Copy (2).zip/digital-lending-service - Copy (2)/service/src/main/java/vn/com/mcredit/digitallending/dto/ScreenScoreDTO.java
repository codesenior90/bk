package vn.com.mcredit.digitallending.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.lang.annotation.Annotation;
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ScreenScoreDTO implements SerializedName {
    @JsonProperty("screen_detection_score")
    private String screenDetectionScore;
    @JsonProperty("screen_detection_result")
    private String screenDetectionResult;

    @Override
    public String value() {
        return null;
    }

    @Override
    public String[] alternate() {
        return new String[0];
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return null;
    }
}
