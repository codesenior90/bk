package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class LocationRequest {
    private Double latitude;
    private Double longitude;
    private Float wardRatio3Months;
    private String wardRatioRange3Months;
    private Float wardRatio1Month;
    private String wardRatioRange1Month;
    private String wardName;
    private String provinceName;
    private String districtName;
}
