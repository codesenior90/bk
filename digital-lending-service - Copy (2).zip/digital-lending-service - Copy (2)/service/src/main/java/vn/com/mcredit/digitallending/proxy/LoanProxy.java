package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.resp.customer.CustomerInfoResponse;
import vn.com.mcredit.digitallending.redis.services.WSO2TokenService;
import vn.com.mcredit.digitallending.utils.Utils;

import java.util.Map;
@Component
public class LoanProxy extends BaseProxy {
    @Autowired
    public WSO2TokenService wso2TokenService;
    public CustomerInfoResponse getCustomerCreditInfo(Map<String, String> requestParams) {
        String url = String.format("%s%s?%s", apiManagerHost, "/loan/v1.0/eContract/credit", Utils.parseRequestParams(requestParams));
        return this.get(url, initHeader(wso2TokenService.get()), CustomerInfoResponse.class);
    }
}
