package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

@Data
public class NFCVerifyResponse {
    private Integer accuracy;
    private String transID;
    private boolean success;
    private NFCVerifyData data;
    private String expiredTimeResponse;
}
