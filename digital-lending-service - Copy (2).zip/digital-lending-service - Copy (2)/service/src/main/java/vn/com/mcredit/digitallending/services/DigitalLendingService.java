package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.CheckPhoneRequest;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.dto.resp.UserInfoDTO;

public interface DigitalLendingService {
    DigitalLendingResponse checkPhone(CheckPhoneRequest checkPhoneRequest);
    DigitalLendingResponse checkPhoneTiktak(CheckPhoneRequest checkPhoneRequest);
    DigitalLendingResponse getHomeLendingInfo();
    DigitalLendingResponse getSummary(String system, String deviceId);
    UserInfoDTO getUserInfo();
}
