package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class CheckIdInternalNFCReq {
    @NotNull(message = "Dữ liệu NFC không được để trống")
    private String data;
}
