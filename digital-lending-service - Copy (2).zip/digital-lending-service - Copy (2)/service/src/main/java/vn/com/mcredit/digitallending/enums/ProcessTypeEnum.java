package vn.com.mcredit.digitallending.enums;

import java.util.Arrays;

public enum ProcessTypeEnum {
    NONE_EKYC(0),
    MISS_FACE3WAY(1),
    EKYC_NOT_DL_FULL(2),
    IDENTIFIED_DL_EKYC(3),
    EKYC_NOT_DL_FULL_CHANGE_DEVICE(4),
    IDENTIFIED_DL_EKYC_CHANGE_DEVICE(5),
    ;

    private Integer value;

    ProcessTypeEnum(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }

    public static boolean checkExist(Integer processType) {
        return Arrays.stream(ProcessTypeEnum.values()).anyMatch(p->p.value.equals(processType));
    }
}
