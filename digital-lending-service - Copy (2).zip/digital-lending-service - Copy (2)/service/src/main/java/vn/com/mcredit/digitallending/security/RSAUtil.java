package vn.com.mcredit.digitallending.security;

import vn.com.mcredit.digitallending.utils.LogUtils;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class RSAUtil {

    private static final String CRYPTO_METHOD = "RSA";
    private static final String CYPHER = "RSA/ECB/PKCS1Padding";
    private static final int CRYPTO_BITS = 2048;
    private static String privateKey;
    private static String publicKey;
    private RSAUtil(){

    }
    public static void init(String privateKeyText) {
        privateKey = privateKeyText;
    }

    public static void init(String publicKeyText, String privateKeyText) {
        publicKey = publicKeyText;
        privateKey = privateKeyText;
    }
    public static String customEncrypt(String dataToEncrypt) {
        try {
            return encrypted(dataToEncrypt, publicKey);
        } catch (Exception e) {
            LogUtils.error("Error encrypt data", e.getMessage());
        }
        return null;
    }
    public static String customDecrypt(String dataToDecrypt) {
        try {
            return decrypt(dataToDecrypt);
        } catch (Exception e) {
            LogUtils.error("Error decrypt data:", e.getMessage());
        }
        return null;
    }
    public static KeyPair getKeyPair() {
        KeyPair kp = null;
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(CRYPTO_METHOD);
            kpg.initialize(CRYPTO_BITS);
            kp = kpg.generateKeyPair();
        } catch (Exception e) {
            LogUtils.error("[RSAUtil] getKeyPair error", e.getMessage());
        }
        return kp;
    }

    public static PublicKey getPublicKey(String base64PublicKey){
        PublicKey publicKey = null;
        try{
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(org.bouncycastle.util.encoders.Base64.decode(base64PublicKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance(CRYPTO_METHOD);
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            LogUtils.error("[RSAUtil] getPublicKey error", e.getMessage());
        }
        return publicKey;
    }

    public static PrivateKey getPrivateKey(String base64PrivateKey){
        PrivateKey privateKey = null;
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(org.bouncycastle.util.encoders.Base64.decode(base64PrivateKey.getBytes()));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance(CRYPTO_METHOD);
        } catch (NoSuchAlgorithmException e) {
            LogUtils.error("[RSAUtil] getPrivateKey NoSuchAlgorithmException error", e.getMessage());
        }
        try {
            if (keyFactory != null)
                privateKey = keyFactory.generatePrivate(keySpec);
        } catch (InvalidKeySpecException e) {
            LogUtils.error("[RSAUtil] getPrivateKey InvalidKeySpecException error", e.getMessage());
        }
        return privateKey;
    }
    @SuppressWarnings("java:S5542")
    public static byte[] encrypt(String data, String publicKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance(CYPHER);
        cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
        return cipher.doFinal(data.getBytes());
    }
    @SuppressWarnings("java:S5542")
    public static byte[] encrypt(String data) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance(CYPHER);
        cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
        return cipher.doFinal(data.getBytes());
    }
    @SuppressWarnings("java:S5542")
    public static String encrypted(String data, String publicKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(CYPHER);
        cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
        byte[] encryptedBytes = cipher.doFinal(data.getBytes());
        return new String(Base64.getEncoder().encode(encryptedBytes));
    }
    @SuppressWarnings("java:S5542")
    public static String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Cipher cipher = Cipher.getInstance(CYPHER);
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return new String(cipher.doFinal(data));
    }
    @SuppressWarnings("java:S5542")
    public static String decrypt(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        return decrypt(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(base64PrivateKey));
    }
    @SuppressWarnings("java:S5542")
    public static String decrypt(String data) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        return decrypt(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(privateKey));
    }

}