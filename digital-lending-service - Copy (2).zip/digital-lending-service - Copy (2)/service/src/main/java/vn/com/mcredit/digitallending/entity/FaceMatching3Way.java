package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "face_matching_3way")
public class FaceMatching3Way {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name = "img1_angle")
    private Float img1Angle; // Góc quay của ảnh thứ nhất để khuôn mặt trong ảnh về dạng thẳng đứng
    @Column(name = "Img2_angle")
    private Float img2Angle; // Góc quay của ảnh thứ hai để khuôn mặt trong ảnh về dạng thẳng đứng
    @Column(name = "Img3_angle")
    private Float img3Angle; // Góc quay của ảnh thứ ba để khuôn mặt trong ảnh về dạng thẳng đứng
    @Column(name = "s12")
    private Float s12; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ nhất và ảnh thứ hai
    @Column(name = "s23")
    private Float s23; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ hai và ảnh thứ ba
    @Column(name = "s31")
    private Float s31; // Xác xuất trùng khớp giữa khuôn mặt ở ảnh thứ ba và ảnh thứ nhất
    @Column(name = "detection_time")
    private Float detectionTime; // Thời gian xác định khuôn mặt trong ảnh
    @Column(name = "embedding_time")
    private Float embeddingTime; // Thời gian chuyển các đặc trưng trên khuôn mặt sang vector
    @Column(name = "response_id")
    private String responseId; // Id của response trả về
    @Column(name = "process_id")
    private String processId; // Id của request gửi lên

    @CreatedDate
    @Column(name = "created_at")
    private Date createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Date updatedAt;
    @Column(name = "username")
    private String username;

    @Column(name = "right_image_url")
    private String rightImageURL;
    @Column(name = "selfie_image_url")
    private String selfieImageURL;
    @Column(name = "left_image_url")
    private String leftImageURL;

    @Column(name = "error", columnDefinition = "text")
    private String error;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "ocr_request_id")
    private String ocrRequestId;

    @Column(name = "source_ekyc", length = 36)
    private String sourceEkyc;
    @Column(name = "device_id", length = 36)
    private String deviceId;
}
