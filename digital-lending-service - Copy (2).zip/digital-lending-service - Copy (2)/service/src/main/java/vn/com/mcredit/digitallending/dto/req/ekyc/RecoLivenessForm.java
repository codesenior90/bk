package vn.com.mcredit.digitallending.dto.req.ekyc;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class RecoLivenessForm extends BaseRecognitionForm {
    private MultipartFile left;
    private MultipartFile right;
    private MultipartFile selfie;
}
