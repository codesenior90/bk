package vn.com.mcredit.digitallending.enums;

public enum LoanState {
    LOAN_PROCESSING("loan_processing"),
    LOAN_PASSED("loan_passed"),
    LOAN_FAILED("loan_failed"),
    LOAN_TIMEOUT("loan_timeout"),
    LOAN_REJECT("loan_reject"),
    LOAN_COMPLETED("loan_completed"),
    SIGN_COMPLETED("DONE"),
    CREATE_CASE_REJECT("create_case_reject");

    private String value;

    LoanState(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
