package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.math.BigInteger;
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetOfferRequestDTO {
    @JsonProperty("loanAmtMinusInsu")
    @Max(value = 15000000,message = "Khoản vay phải thấp hơn 15.000.000 triệu")
    @Min(value = 5000000, message = "Khoản vay phải cao hơn 5.000.000 triệu")
    private BigInteger loanAmtMinusInsu;
    @JsonProperty("loanPurpose")
    @NotNullorEmpty(message = "Vui lòng cung cấp mục đích vay")
    private String loanPurpose;
    @JsonProperty("loanTenor")
    @Max(value = 36)
    @Min(value = 12)
    private BigInteger loanTenor;
    @JsonProperty("hasInsurance")
    @NotNullorEmpty(message = "Vui lòng cung cấp có tham gia bảo hiểm không")
    private String hasInsurance;
    private String requestId;
}
