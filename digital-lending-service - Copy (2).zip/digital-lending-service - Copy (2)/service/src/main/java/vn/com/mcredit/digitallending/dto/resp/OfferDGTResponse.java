package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;


@Data
public class OfferDGTResponse {
    private String topic;
    private String contentType;
    private String caseNumber;
    private String requestId;
    private String contractNumber;
    private String status;
    private String sourceCreate;
    private OfferDGTDetailResponse message;
    private String system;
    private String reasonLogDTOS;
}
