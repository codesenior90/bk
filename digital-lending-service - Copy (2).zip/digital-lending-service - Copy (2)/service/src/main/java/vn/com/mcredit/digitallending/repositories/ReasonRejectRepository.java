package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.ReasonReject;

import java.util.List;

@Repository
public interface ReasonRejectRepository extends JpaRepository<ReasonReject, String> {
    @Query(value = "SELECT * FROM REASON_REJECT r WHERE r.IS_ACTIVE = :isActive and r.TYPE = :type order by r.REASON_CODE", nativeQuery = true)
    List<ReasonReject> getAllByActiveAndType(boolean isActive, String type);

    boolean existsByReasonCode(String reasonCode);
}
