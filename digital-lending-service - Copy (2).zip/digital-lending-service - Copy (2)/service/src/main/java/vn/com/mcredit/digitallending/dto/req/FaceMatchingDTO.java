package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;
@Data
public class FaceMatchingDTO {
    private MultipartFile frontImg;
    private MultipartFile backImg;
    private MultipartFile leftImg;
    private MultipartFile rightImg;
    private MultipartFile selfieImg;
    private String email;
    private String requestId;
    private String selfieImgURL;
    private String leftImgURL;
    private String rightImgURL;
    private Integer processEkyc;
    private String captcha;
}
