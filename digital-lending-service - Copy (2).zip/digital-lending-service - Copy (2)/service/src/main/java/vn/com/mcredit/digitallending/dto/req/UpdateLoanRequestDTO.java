package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class UpdateLoanRequestDTO {
    private String requestId;
    private String idNumber;
    private String idNumberOld;
    private String fullName;
    private String custDob;
    private Integer loanAmtMinusInsu;
    private Integer loanTenor;
    private Integer age;
    private String channel;
    private String sex;
    private String city;
    private String score;
    private String customerGroup;
    private String hasInsurance;
    private String insuranceCompany;
    private String loanPurpose;
    private String loanPurposeDetail;
    private String referId;
    private Integer loansProfileId;
    private Integer loansOfferId;
    private String reasonReject;
    private String reasonRejectDetail;
    private String createdBy;
    private String createdDate;
    private String updateBy;
    private String updateDate;
    private String offlineId;
    private String appUid;
    private String status;

}
