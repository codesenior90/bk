package vn.com.mcredit.digitallending.dto.req.ekyc;

import lombok.Data;

@Data
public class BaseRecognitionForm {
    private String ocrCode;
    private String username;
    private String system;
    private String ipAddress;
    private Integer processEkyc;
}
