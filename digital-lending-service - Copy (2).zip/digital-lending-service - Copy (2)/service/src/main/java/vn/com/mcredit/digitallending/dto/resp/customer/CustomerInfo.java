package vn.com.mcredit.digitallending.dto.resp.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class CustomerInfo {
    private String repaymentPeriod;
    private String typeOfLoan;
    private String signDate;
    private String limitExpDate;
    private String limitOnlineDate;
    private String lastUpdated;
    private String tenor;
    private String limitHoldDate;
    private String dateCancel;
    private String identityNumber;
    private String maturityDate;
    private String loanStatus;
    private String dpd;
    private String hasinsurrance;
    private String totalOverdueAmount;
    private String outstandingBalance;
    private String insuranceFlag;
    private String interestRate;
    private String product;
    private String nextPaymentDate;
    private String contractNumber;
    private String limitID;
    private String valueDate;
    private String customerName;
    private String limitWorkingAmt;
    private String totalAmount;
    private String mobilePhone;
    private String originalAmount;
    private String disbursementChannel;
    private String dateClose;
    private String limitAmount;
    private String nextPayment;
    private String category;
    private String nextPaymentAmount;
    private String status;
}
