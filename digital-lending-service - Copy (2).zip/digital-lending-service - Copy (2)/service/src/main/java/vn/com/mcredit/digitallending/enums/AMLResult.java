package vn.com.mcredit.digitallending.enums;

public enum AMLResult {
    PASS("PASS"),
	FAIL("FAIL");

    private String value;

    AMLResult(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
