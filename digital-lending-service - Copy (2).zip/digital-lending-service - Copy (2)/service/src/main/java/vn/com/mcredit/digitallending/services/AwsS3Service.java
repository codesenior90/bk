package vn.com.mcredit.digitallending.services;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

public interface AwsS3Service   {
    String upload(MultipartFile multipartFile, String name);
    String upload(MultipartFile multipartFile, String name, String extension);
    String uploadVoice(MultipartFile multipartFile, String name);
    String upload(File file, String name) throws IOException;
    String upload(File file, String name, String extension) throws IOException;

    String uploadVoice(File file, String name) throws IOException;
    MultipartFile dowload2S3bucketWithName(String keyImage, String name);
    String upload(String base64Data, String preFix);
}
