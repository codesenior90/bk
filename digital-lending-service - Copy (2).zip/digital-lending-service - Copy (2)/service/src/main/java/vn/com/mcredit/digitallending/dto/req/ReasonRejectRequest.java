package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class ReasonRejectRequest {
    @JsonProperty("type")
    @NotNullorEmpty
    private String type;
}
