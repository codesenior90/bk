package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

@Data
public class OcrForm {
    @NotNull(message = "Vui lòng chọn mặt trước CCCD")
    MultipartFile frontImg;
    @NotNull(message = "Vui lòng chọn mặt sau CCCD")
    MultipartFile backImg;
    Integer processEkyc;
}
