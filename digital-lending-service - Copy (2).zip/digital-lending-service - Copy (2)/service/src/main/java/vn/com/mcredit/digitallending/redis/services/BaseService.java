package vn.com.mcredit.digitallending.redis.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component("baseService")
public class BaseService {

  @SuppressWarnings("rawtypes")
  @Autowired
  protected RedisTemplate redisTemplate;

  @SuppressWarnings("unchecked")
  public void set(String key, String token) {
    redisTemplate.opsForValue().set(key, token);
  }

  @SuppressWarnings("unchecked")
  public void set(String key, String token, long timeoutInMinute) {
    redisTemplate.opsForValue().set(key, token, timeoutInMinute, TimeUnit.SECONDS);
  }

  @SuppressWarnings("unchecked")
  public void set(String key, String token, long timeout, TimeUnit timeUnit) {
    redisTemplate.opsForValue().set(key, token, timeout, timeUnit);
  }

  public String get(String key) {
    return (String) redisTemplate.opsForValue().get(key);
  }
}
