package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

import java.util.List;

@Data
public class CompleteCaseDTO {
    private String loansProfileId;
    private List<LoansFileUploadRequest> fileUploadDTOS;
}
