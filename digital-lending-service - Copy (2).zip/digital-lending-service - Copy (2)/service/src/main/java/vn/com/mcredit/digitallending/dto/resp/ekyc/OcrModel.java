package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;
import vn.com.mcredit.digitallending.dto.resp.Mrz;

@Data
public class OcrModel {
    private String address;
    private String addressCorrection;
    private String addressCorrectionProb;
    private String addressProb;
    private String dob;
    private String dobProb;
    private String expireDate;
    private String expireDateProb;
    private String gender;
    private String genderProb;
    private String hometown;
    private String hometownCorrection;
    private String hometownCorrectionProb;
    private String hometownProb;
    private String idNumber;
    private String idNumberProb;
    private String issueDate;
    private String issueDateProb;
    private String name;
    private String nameProb;
    private String nationality;
    private String nationalityProb;

    private Mrz mrz;
}
