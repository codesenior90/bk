package vn.com.mcredit.digitallending.services.impl;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import org.apache.commons.io.FileUtils;
import org.apache.http.entity.ContentType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.services.AwsS3Service;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;

import javax.annotation.PostConstruct;
import java.io.*;
import java.nio.file.Files;
import java.util.Base64;
import java.util.UUID;

@Component
public class AwsS3ServiceImpl implements AwsS3Service {
    private AmazonS3 amazonS3;
    private AmazonS3 amazonS3Voice;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    @Value("${aws.s3.accessKey}")
    private String accessKey;

    @Value("${aws.s3.secretKey}")
    private String secretKey;

    @Value("${aws.s3-voice.bucket-name}")
    private String voiceBucketName;

    @Value("${aws.s3-voice.accessKey}")
    private String voiceAccessKey;

    @Value("${aws.s3-voice.secretKey}")
    private String voiceSecretKey;

    @PostConstruct
    private void initializeAmazone() {
        String region = "ap-southeast-1";
        AWSCredentials credentials = new BasicAWSCredentials(this.accessKey, this.secretKey);
        this.amazonS3 = AmazonS3ClientBuilder.standard().withRegion(region)
                .withCredentials(new AWSStaticCredentialsProvider(credentials)).build();
    }

    public String upload(MultipartFile multipartFile, String preFix) {
        return this.upload(amazonS3, bucketName, multipartFile, preFix);
    }
    public String upload(MultipartFile multipartFile, String preFix, String extension) {
        return this.upload(amazonS3, bucketName, multipartFile, preFix, extension);
    }
    public String uploadVoice(MultipartFile multipartFile, String preFix) {
        return this.upload(amazonS3Voice, voiceBucketName, multipartFile, preFix);
    }
    private String upload(AmazonS3 amazonS3, String bucketName, MultipartFile multipartFile, String preFix) {

        File file = null;
        var url = StringUtils.EMPTY;

        try {
            file = convert2File(multipartFile);
            url = upload2S3bucket(amazonS3, bucketName, this.generateFileName(preFix), file);
        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] upload", e.getMessage());
        } finally {
            if (file != null)
                try {
                    Files.deleteIfExists(file.toPath());
                } catch (IOException ex){
                    LogUtils.error("[AwsS3Service] upload:IOException", ex.getMessage());
                }
        }

        return url;
    }
    private String upload(AmazonS3 amazonS3, String bucketName, MultipartFile multipartFile, String preFix, String extension) {

        File file = null;
        var url = StringUtils.EMPTY;

        try {
            file = convert2File(multipartFile);
            url = upload2S3bucket(amazonS3, bucketName, this.generateFileName(preFix, extension), file);
        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] upload", e.getMessage());
        } finally {
            if (file != null)
                try {
                    Files.deleteIfExists(file.toPath());
                } catch (IOException ex){
                    LogUtils.error("[AwsS3Service] upload:IOException", ex.getMessage());
                }
        }

        return url;
    }
    private String generateFileName(String preFix){
        return preFix + UUID.randomUUID() + ".jpg";
    }
    private String generateFileName(String preFix, String extension){
        return String.format("%s%s.%s",preFix, UUID.randomUUID(), extension);
    }
    public String upload(File file, String preFix) throws IOException {
        return this.upload(amazonS3, bucketName, file, preFix);
    }
    public String upload(File file, String preFix, String extension) throws IOException {
        return this.upload(amazonS3, bucketName, file, preFix, extension);
    }
    public String uploadVoice(File file, String prefix) throws IOException {
        return this.upload(amazonS3Voice, voiceBucketName, file, prefix);
    }
    private String upload(AmazonS3 amazonS3, String bucketName, File file, String preFix) throws IOException {

        var url = StringUtils.EMPTY;
        try {
            url = upload2S3bucket(amazonS3, bucketName, this.generateFileName(preFix), file);
        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] upload Exception", e.getMessage());
        } finally {
            if (file != null)
                Files.deleteIfExists(file.toPath());
        }

        return url;
    }
    private String upload(AmazonS3 amazonS3, String bucketName, File file, String preFix, String extension) throws IOException {

        var url = StringUtils.EMPTY;
        try {
            url = upload2S3bucket(amazonS3, bucketName, this.generateFileName(preFix, extension), file);
        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] upload Exception", e.getMessage());
        } finally {
            if (file != null)
                Files.deleteIfExists(file.toPath());
        }

        return url;
    }
    private String upload2S3bucket(AmazonS3 amazonS3, String bucketName, String fileName, File file) {
        try {
            amazonS3.putObject(new PutObjectRequest(bucketName, fileName, file));
            return getUrl(amazonS3, bucketName, fileName);
        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] upload2S3bucket Exception", e.getMessage());
            throw e;
        }
    }

    private String getUrl(AmazonS3 amazonS3, String bucketName, String fileName) {
        var req = new ListObjectsV2Request().withBucketName(bucketName).withPrefix(fileName);
        var result = amazonS3.listObjectsV2(req);
        String key = "";
        if (!result.getObjectSummaries().isEmpty()) {
            key = result.getObjectSummaries().get(0).getKey();
        }
        return amazonS3.getUrl(bucketName, key).toString();
    }
    public String upload(String base64Data, String preFix) {
        return this.upload2S3bucket(amazonS3, bucketName, base64Data, this.generateFileName(preFix));
    }
    private String upload2S3bucket(AmazonS3 amazonS3, String bucketName, String base64Data, String fileName) {
        try {
            byte[] bI = Base64.getDecoder().decode(base64Data);
            InputStream fis = new ByteArrayInputStream(bI);
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(bI.length);
            metadata.setContentType("image/jpg");
            metadata.setCacheControl("public, max-age=31536000");
            amazonS3.putObject(bucketName, fileName, fis, metadata);
            return getUrl(amazonS3, bucketName, fileName);
        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] upload2S3bucket Exception", e.getMessage());
            return "";
        }
    }
    private File convert2File(MultipartFile file) throws IOException {
        FileOutputStream fos = null;
        File convFile = null;
        try {
            if (file.getOriginalFilename() != null){
                convFile = new File(file.getOriginalFilename());
                fos = new FileOutputStream(convFile);
                fos.write(file.getBytes());
            }
        } catch (Exception e) {
            LogUtils.info("[AwsS3Service] convert2File Exception", e.getMessage());
        }
        if (fos != null)
            fos.close();
        return convFile;
    }
    public MultipartFile dowload2S3bucketWithName(String keyImage, String name){
        try {
            S3Object s3object = amazonS3.getObject(bucketName, keyImage);
            S3ObjectInputStream inputStream = s3object.getObjectContent();
            return new MockMultipartFile(name, name,
                    ContentType.APPLICATION_OCTET_STREAM.toString(), inputStream);
        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] download2S3bucketWithName", e.getMessage());
        }
        return null;
    }

    public MultipartFile download2S3bucket(String keyImage,String target){
        File file = null;
        try {
            S3Object s3object = amazonS3.getObject(bucketName, keyImage);
            S3ObjectInputStream inputStream = s3object.getObjectContent();
            file = new File(target);
            FileUtils.copyInputStreamToFile(inputStream, file);
            return new MockMultipartFile(file.getName(), file.getName(),
                    ContentType.APPLICATION_OCTET_STREAM.toString(), inputStream);

        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] download2S3bucket Exception", e.getMessage());
        }
        return null;
    }

    public void cleanFile(File file) {
        try {
            Files.delete(file.toPath());
        }catch (Exception e){
            LogUtils.error("[AwsS3Service] error cleanFile:" +e.getMessage());
        }
    }

    MultipartFile download2S3bucketPNG(String keyImage, String name) {
        try {
            S3Object s3object = amazonS3.getObject(bucketName, keyImage);
            S3ObjectInputStream inputStream = s3object.getObjectContent();
            return new MockMultipartFile(name, name,
                    ContentType.IMAGE_PNG.toString(), inputStream);
        } catch (Exception e) {
            LogUtils.error("[AwsS3Service] download2S3bucketPNG", e.getMessage());
        }
        return null;
    }
}
