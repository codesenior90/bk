package vn.com.mcredit.digitallending.dto.req;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CheckLeadRequest {
    private String requestId; // Request Id tự sinh theo từng request
    private String phoneNumber; // Số điện thoại khách hàng
    private String nationalId; // Số cmnd/cccd
    private String partner; // Mã đối tác
}
