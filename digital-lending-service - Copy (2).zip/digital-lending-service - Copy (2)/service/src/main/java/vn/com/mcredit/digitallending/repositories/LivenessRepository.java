package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.Liveness;

@Repository
public interface LivenessRepository extends JpaRepository<Liveness, String> {
}
