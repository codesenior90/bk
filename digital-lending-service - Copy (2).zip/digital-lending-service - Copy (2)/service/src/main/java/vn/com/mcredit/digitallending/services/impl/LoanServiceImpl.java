package vn.com.mcredit.digitallending.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.dto.resp.customer.CustomerInfoResponse;
import vn.com.mcredit.digitallending.proxy.LoanProxy;
import vn.com.mcredit.digitallending.services.LoanService;

import java.util.Map;

@Service
public class LoanServiceImpl implements LoanService {
    @Autowired
    private LoanProxy loanProxy;
    @Override
    public CustomerInfoResponse getCustomerInfo(Map<String, String> requestParams) {
        return loanProxy.getCustomerCreditInfo(requestParams);
    }
}
