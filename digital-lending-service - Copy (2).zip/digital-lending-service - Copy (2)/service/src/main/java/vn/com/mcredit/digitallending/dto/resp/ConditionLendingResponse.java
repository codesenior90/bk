package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class ConditionLendingResponse {
    private String icon;
    private String title;
    private String content;
}
