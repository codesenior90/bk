package vn.com.mcredit.digitallending.dto.resp.internal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class UserLinkResponse {
        private String backImageUrl;
        private String frontImageUrl;
        private String selfieImageUrl;
        private String leftImageUrl;
        private String rightImageUrl;
        private String name;
        private String dob;
        private String issuedDate;
        private String expiredDate;
        private String gender;
        private String username;
        private String citizenId;
        private String citizenIdOld;
        private String address;
        private String contractStatus;
        private String contractNumber;
}
