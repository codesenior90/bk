package vn.com.mcredit.digitallending.enums;

public enum SourceCreateEnum {
    DIGITAL("Tiktak_mc"), DIGITAL_MINI_APP("Tiktak_sdk"), DIGITAL_WEB("");

    private String value;

    SourceCreateEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
