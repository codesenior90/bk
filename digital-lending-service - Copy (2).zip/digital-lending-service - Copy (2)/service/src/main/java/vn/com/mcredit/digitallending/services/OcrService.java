package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.OcrForm;
import vn.com.mcredit.digitallending.dto.resp.OcrResponse;


public interface OcrService {
    OcrResponse ocr(OcrForm ocrForm);

}
