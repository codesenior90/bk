package vn.com.mcredit.digitallending.constants;

public class Constants {


    public static final String FACE_IDS_CHECK_RESPONSE = "FACE_IDS_CHECK_RESPONSE";
    public static final String DIGITAL = "DIGITAL";
    public static final String PPC02 = "PPC02";
    public static final String MILLISECOND = "millisecond";
    public static final String IDS03 = "IDS03";
    public static final String CUC_CS_QLHC_V_TTXH = "Cục CS QLHC về TTXH";
    public static final String CCCDQR = "CCCDQR";
    public static final String OFFER_ID_NOT_VALID = "Offer Id không hợp lệ" ;
    public static final String CREATE_LOAN_PROCESSING = "Đang xử lý tạo khoản vay";
    public static final String OFFER_NOT_EXIST = "Offer không tồn tại trên hệ thống";
    public static final String DIGITAL_LENDING = "DIGITAL_LENDING";
    public static final String MAINID = "MAINID";
    public static final String EXTRAID = "EXTRAID";
    public static final String CMND = "CMND";
    public static final String CCCD_NON_CHIP = "CMND";
    public static final String FAILED_CODE_1 = "-1";
    public static final String SIGN_COMPLETED = "DONE";
    public static final String OBJECT_HAS_RESPONSE = "Đã có kết quả trả về";
    public static final String OBJECT_NOT_RESPONSE = "Chưa có kết quả trả về";
    public static final String USERNAME_NOT_EXIST = "Tài khoản không tồn tại trên hệ thống.";
    public static final String UNAME_PW_INCORRECT = "Thông tin đăng nhập không đúng.";
    public static final String USERNAME_EXISTED_ON_SYSTEM = "Số điện thoại đã được sử dụng.";
    public static final String INFORMATION_REGISTER_EXISTED = "Thông tin đăng ký đã được sử dụng.";
    public static final String MARI02 = "MARI02";
    public static final String MALE = "Nam";
    public static final String FEMALE = "Nữ";

    private Constants() {throw new IllegalStateException("Constants class"); }
    public static final String EXCEPTION_MES = "Dịch vụ tạm thời gián đoạn, bạn vui lòng thực hiện lại sau ít phút.";
    public static final String APP_EXCEPTION_MESSAGE = "Đã có lỗi xảy ra";
    public static final String APP_EXCEPTION_CODE = "500";
    public static final String HTTP_MESSAGE = "Dữ liệu không hợp lệ";
    public static final String ERROR_400_CODE = "400";
    public static final String ERROR_400_BAD = "400";
    public static final String SUCCESS_CODE = "200";
    public static final String SUCCESS_CODE_0 = "0";
    public static final String SUCCESS_CODE_1 = "1";
    public static final String SUCCESS_MESSAGE = "SUCCESS";
    public static final String FAILED_MESSAGE = "FAILED";
    public static final String CURRENT_USER = "CurrentUser";
    public static final String SOURCE_APP_ID = "SourceAppID";
    public static final String CLIENT_MESSAGE_ID = "ClientMessageId";
    public static final String SERVICE_NAME = "ServiceName";
    public static final String SERVICE_VERSION = "ServiceVersion";
    public static final String RANDOM_CHARACTERS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String RETURN_CODE = "returnCode";
    public static final String RETURN_MES = "returnMes";
    public static final String CREDIT_OPEN = "OPEN";
    public static final String CREDIT_BACKDATE = "BACKDATE";
    public static final String CREDIT_RL = "RL";
    public static final String HOME_LENDING_PAGE_CONFIG = "HOME_LENDING_PAGE_CONFIG";
    public static final String AUTHORIZATION_INVALID = "Token không hợp lệ, vui lòng đăng nhập lại.";
    public static final String KC_PASS_DEFAULT = "Admin@123";
    public static final String PASS = "PASS";
    public static final String FAILED = "FAILED";
    public static final String SEND_OTP_MESSAGE_SUCCESS = "Mã OTP đã được gửi tới bạn";
    public static final String VERIFY_OTP_MESSAGE_SUCCESS = "OTP đã được verify.";
    public static final String CHECK_DUP_SUCCESS = "CHECK_DUP_SUCCESS";
    public static final String CHECK_DUP_FAIL = "CHECK_DUP_FAIL";
    public static final String CHECK_DUP_RESPONSE_FAIL = "CHECK_DUP_RESPONSE_FAIL";
    public static final String CHECK_ID_INTERNAL_FAIL = "CHECK_ID_INTERNAL_FAIL";
    public static final String CHECK_ID_INTERNAL_RESPONSE_FAIL = "CHECK_ID_INTERNAL_RESPONSE_FAIL";
    public static final String CHECK_DUP_RESPONSE = "CHECK_DUP_RESPONSE";
    public static final String DOC_VALIDATE_RESPONSE = "DOC_VALIDATE_RESPONSE";
    public static final String FACE_MATCHING_RESPONSE = "FACE_MATCHING_RESPONSE";
    public static final String CHECK_BLACKLIST_RESPONSE = "CHECK_BLACKLIST_RESPONSE";
    public static final String CHECK_FACE_IDS_RESPONSE = "CHECK_FACE_IDS_RESPONSE";
    public static final String CHECK_IDS_FACE_RESPONSE = "CHECK_IDS_FACE_RESPONSE";
    public static final String FACE_MATCHING_3WAY_RESPONSE = "FACE_MATCHING_3WAY_RESPONSE";
    public static final String FACE_MATCHING_4WAY_RESPONSE = "FACE_MATCHING_4WAY_RESPONSE";
    public static final String FAIL_FACE_MATCHING_4WAY = "FAIL_FACE_MATCHING_4WAY";
    public static final String FAIL_FACE_MATCHING_3WAY = "FAIL_FACE_MATCHING_3WAY";
    public static final String FAIL_FACE_MATCHING = "FAIL_FACE_MATCHING";
    public static final String FRONT = "frontImg";
    public static final String BACK = "backImg";
    public static final String SELFIE = "selfieImg";
    public static final String LEFT = "leftImg";
    public static final String RIGHT = "rightImg";
    public static final String MODE = "mode";
    public static final String EKYC_DTO = "ekycDTO";
    public static final String PREFIX_QRCODE = "qrCode_";
    public static final String PREFIX_LEFT = "left_";
    public static final String PREFIX_RIGHT = "right_";
    public static final String PREFIX_SELFIE = "selfie_";
    public static final String PREFIX_FRONT = "front_";
    public static final String PREFIX_BACK = "back_";
    public static final String FACE_RAW_IMG1 = "img1";
    public static final String FACE_RAW_IMG2 = "img2";
    public static final String FACE_RAW_IMG3 = "img3";

    public static final String XCELL_DEFAULT = "N";
    public static final String FUM01 = "FUM01"; // Chung minh noi o
    public static final String FUM02 = "FUM02"; // Chung minh cong viec
    public static final String FUM03 = "FUM03"; // Chung minh thu nhap truc tiep
    public static final String FUM04 = "FUM04"; // Chung minh thu nhap gian tiep
    public static final String FUM05 = "FUM05"; // Bang lai xe
    public static final String FUM06 = "FUM06"; // CMND/CCCD/CMQD
    public static final String FUM07 = "FUM07"; // Hinh anh khach hang
    public static final String FUM08 = "FUM08"; // Voice Captcha file của KH
    public static final String FUEC1 = "FUEC1"; // Hinh anh CCCD
    public static final String FUEC2 = "FUEC2"; // Hinh anh khach hang

    public static final String MB_BANK = "MB";
    public static final String YES_VALUE = "YES";
    public static final String NO_VALUE = "NO";
    public static final String PRF20_VALUE = "PRF20";
    public static final String DISBURSEMENT_TYPE_TT = "TT";
    public static final String DISBURSEMENT_TYPE_FT = "FT";
    public static final String SEND_CREATE_OFFER = "SEND_CREATE_OFFER";
    public static final String RECEIVE_CREATE_OFFER = "RECEIVE_CREATE_OFFER";
    public static final String SEND_CREATE_CASE = "SEND_CREATE_CASE";
    public static final String RECEIVE_CREATE_CASE = "RECEIVE_CREATE_CASE";
    public static final String RECEIVE_MESSAGE_FROM_ECONTRACT = "RECEIVE_MESSAGE_FROM_ECONTRACT";

    public static final String REASON_CODE_NOT_EXIST = "REASON_CODE_NOT_EXIST";
    public static final String EKYC_IDENTIFIED_UN_SUCCESS = "Xác thực không thành công. Bạn vui lòng kiểm tra và thử lại sau.";

    public static final String YES = "Y";
    public static final String NA = "NA";
    public static final String EMPTY = "";

    public static final String RULE_C3 = "internalId";

    public static final String RULE_C4 = "offlineId";
    public static final String FIRSTPHONENUMBER = "0";
    public static final String REPLACEFIRSTPHONENUMBER = "84";

    public static final String RULE_C10_1 = "C10.1";
    public static final String RULE_C10_2 = "C10.2";

    public static final String UNVERIFIED = "UNVERIFIED";

    public static final String VERIFIED = "VERIFIED";
    public static final String FORBIDDEN_MESSAGE = "Không có quyền thực hiện chức năng này.";

    public static final String CHANNEL = "DGL";

    public static final String PREFIX_VOICE_CAPTCHA = "voice_captcha_";
    public static final String LOGIN = "LOGIN";
    public static final String REGISTER = "REGISTER";
    public static final String SML_CODE_MB = "970422";
    public static final String BANK_CODE_MB = "MB";
    public static final String BANK_NAME_MB = "Quân đội (MB)";
    public static final String DISBURSEMENT_MODEL_MB = "C15.194";

    public static final String ACTIVE = "ACTIVE";
    public static final String INACTIVE = "INACTIVE";

    public static final String CRITERIA_TYPE_G = "G";
    public static final String CRITERIA_ALL = "ALL";
    public static final Integer CRITERIA_LIMIT = 20000;
    public static final String ERROR_CODE_ZERO = "0";
}
