package vn.com.mcredit.digitallending.dto.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerResponseInfo {
    private String clientMessageId;
    private String errorCode;
    private List<String> errorDesc;
    private CustomerCheckInfo data;
}
