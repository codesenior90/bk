package vn.com.mcredit.digitallending.dto.resp;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class TelcoAdvanceLocationCheckResponse {
    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("response_id")
    private String responseId;

    @JsonProperty("response_date")
    private String responseDate;

    @JsonProperty("error_code")
    private String errorCode;

    @JsonProperty("message")
    private String message;

    @JsonProperty("location_check_result")
    private LocationCheckResult locationCheckResult;



}
