package vn.com.mcredit.digitallending.proxy;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.services.KeycloakService;
import vn.com.mcredit.digitallending.utils.LogUtils;

@Component
@RequiredArgsConstructor
public class EcmProxy extends BaseProxy{
    @Value("${custom.properties.ecm-api-host}")
    protected String ecmApiHost;
    private final KeycloakService keycloakService;

    public String upload(Object object) {
        try {
            return this.post(ecmApiHost + "/customers/uploadFile",
                    initHeaderMultipartFormData(keycloakService.issueDocumentLibraryToken()), object, String.class);
        } catch (HttpStatusCodeException e) {
            LogUtils.error("[EcmProxy] Upload File to ecm Error", e.getResponseBodyAsString());
            return null;
        }
    }
}
