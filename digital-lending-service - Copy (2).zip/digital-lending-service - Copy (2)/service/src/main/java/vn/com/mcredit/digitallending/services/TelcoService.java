package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.TelcoLocationRequest;
import vn.com.mcredit.digitallending.dto.resp.DigitalLendingResponse;
import vn.com.mcredit.digitallending.dto.resp.TelcoAdvanceLocationCheckResponse;

public interface TelcoService {
    DigitalLendingResponse telcoLocationCheck(TelcoLocationRequest request);
}
