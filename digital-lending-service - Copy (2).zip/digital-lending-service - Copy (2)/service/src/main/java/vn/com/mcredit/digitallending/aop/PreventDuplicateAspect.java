package vn.com.mcredit.digitallending.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.handles.DuplicateSubmissionException;
import vn.com.mcredit.digitallending.services.CacheKeyGeneratorService;
import vn.com.mcredit.digitallending.utils.LogUtils;


@Aspect
@Configuration
@SuppressWarnings("all")
public class PreventDuplicateAspect {

	@Autowired
	@Qualifier("redissonClient")
	protected RedissonClient redissonClient;
	@Autowired
	private CacheKeyGeneratorService cacheKeyGenerator;

	@Around("execution(public * *(..)) && @annotation(PreventDuplicateMethod)")
	public Object preventDuplicateMethod(ProceedingJoinPoint pjp) throws Throwable {
		final String lockKey = cacheKeyGenerator.generateLockMethodKey(pjp);
		return process(pjp, lockKey, Error.DUPLICATE_METHOD);
	}

	private Object process(ProceedingJoinPoint pjp, String lockKey, Error error) throws Throwable {
		RLock lock = redissonClient.getLock(lockKey);
		LogUtils.info("Thread preventDuplicate:process: {}, lockKey : {} {}", Thread.currentThread().getName(), lockKey, lock.getName());
		if (lock.tryLock()) {
			try {
				LogUtils.info("Thread process: {} ----LOCK---.", Thread.currentThread().getName());
				lock.lock();
				return pjp.proceed();
			} finally {
				try {
					LogUtils.info("Thread process: {} ----UNLOCK----.", Thread.currentThread().getName());
					lock.forceUnlock();
				} catch (Exception e) {
					LogUtils.info("Thread process: {} , EXCEPTION: {}", Thread.currentThread().getName(), e.getMessage());
				}
			}
		} else {
            LogUtils.info("Thread process: {} ----DUPLICATE SUBMISSION----.", Thread.currentThread().getName());
			throw new DuplicateSubmissionException(error);
		}
	}

}
