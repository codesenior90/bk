package vn.com.mcredit.digitallending.dto.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class CustomerInfoMbResponse {
    private String partner;
    private String system;
    private String customerCode;
    private String clientMessageId;
    private int errorCode;
    private List<String> errorDesc;
    private CustomerInfoDataResponse data;
    private String id;
    private String code;
    private String createdBy;
    private String createdDate;
    private String lastModified;
    private String status;
}

