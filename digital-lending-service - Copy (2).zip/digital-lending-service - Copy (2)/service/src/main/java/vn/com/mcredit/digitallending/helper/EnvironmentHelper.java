package vn.com.mcredit.digitallending.helper;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.utils.LogUtils;

// profile được lấy từ env -> SPRING_PROFILES_ACTIVE hoặc application.yml -> spring.profiles.active
@Component
public class EnvironmentHelper {

    @Autowired
    private Environment env;

    public boolean isDev() {
        String[] profiles = env.getActiveProfiles();
        LogUtils.info("[ENV] profile");
        for (String profile : profiles) {
            if (StringUtils.isNotEmpty(profile) && (profile.equalsIgnoreCase("prod") || profile.equalsIgnoreCase("live"))) {
                return false;
            }
        }
        return true;
    }


}