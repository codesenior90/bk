package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class BpmBaseResponse {
    private Integer availableLoanAmount;
    private String errorCode;
    private String message;
    private String timestamp;
    private String returnMessage;
    private Integer loanAmount;
    private Integer totalCount;
}
