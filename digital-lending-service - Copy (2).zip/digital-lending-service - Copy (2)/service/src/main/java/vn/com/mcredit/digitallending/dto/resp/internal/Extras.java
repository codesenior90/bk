package vn.com.mcredit.digitallending.dto.resp.internal;

import lombok.Data;

@Data
public class Extras {
    private String sessionId;
    private String cif;
    private String fullnameVn;
    private String idCardType;
    private String idCardNo;
    private String idCardIssuedDate;
    private String idCardIssuedPlace;
    private String idCardExpiryDate;
    private String gender;
    private String address;
    private String permanentAddress;
    private String maritalStatus;
    private String nationality;
    private String accountList;
    private String accountDefault;
    private String sector;
    private String deviceId;
}