package vn.com.mcredit.digitallending.enums;

public enum SourceEKYC {
    EKYC_CENTRALIZATION("EKYC_CENTRALIZATION"),
    OTHER("OTHER");

    private String value;

    SourceEKYC(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
