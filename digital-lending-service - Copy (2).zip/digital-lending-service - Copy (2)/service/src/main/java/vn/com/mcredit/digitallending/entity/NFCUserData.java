package vn.com.mcredit.digitallending.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "nfc_user_data")
public class NFCUserData {
    @Id
    @Column(name = "id", unique = true, nullable = false, length = 36)
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid")
    private String id;

    @Column(name ="internal_check_id", length = 36, nullable = false)
    private String internalCheckId; // Id của bảng id_internal_check

    @Column(name ="username", length = 10, nullable = false)
    private String username; // Số Điện thoại

    @Column(name = "gender", length = 20)
    private String gender; // Giới tính

    @Column(name = "id_number", length = 12)
    private String idNumber; // Số CCCD CHIP

    @Column(name = "id_number_old", length = 12)
    private String idNumberOld; // Số CMND|CCCD cũ

    @Column(name = "full_name")
    private String name; // Họ và tên

    @Column(name = "address")
    private String address; // Địa chỉ sinh sống

    @Column(name = "nationality", length = 50)
    private String nationality; // Quốc gia

    @Column(name = "home_town")
    private String homeTown; // Nguyên quán

    @Column(name = "issued_date", length = 10)
    private String issuedDate; // Ngày phát hành

    @Column(name = "dob", length = 10)
    private String dob; // Ngày sinh

    @Column(name = "expiry_date", length = 10)
    private String expiryDate; // Ngày hết hạn

    @Column(name = "religion", length = 50)
    private String religion; // Tôn giáo

    @Column(name = "ethnic", length = 50)
    private String ethnic; // Dân tộc

    @Column(name = "personal_identification")
    private String personalIdentification; // Đặc điểm nhận dạng

    @Column(name = "error_code", length = 50)
    private String errorCode; // Mã lỗi

    @Column(name = "error_message")
    private String errorMessage; // Mô tả mã lỗi

    @CreationTimestamp
    @Column(name = "created_at")
    private Date createdAt; // Ngày tạo

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updatedAt; // Ngày update

    @Column(name = "face_image_url")
    private String faceImageUrl; // url ảnh khuôn mặt trên giấy tờ quét bằng công nghệ NFC

    @Column(name = "father_name")
    private String fatherName; // Tên bố

    @Column(name = "mother_name")
    private String motherName; // Tên Mẹ

    @Column(name = "score_accuracy")
    private String scoreAccuracy; // Điểm so khớp khuôn mặt
}
