package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserInfoDTO {
    private String username;
    private String email;
    private String gender;
    private String idNumber;
    private String idNumberOld;
    private String cardType;
    private String frontImageEcmURL;
    private String backImageEcmURL;
    private String frontImageURL;
    private String backImageURL;
    private String selfieImageURL;
    private String leftImageURL;// link ảnh mặt trái
    private String rightImageURL;// link ảnh mặt phải
    private String selfieImageEcmURL;// link ảnh mặt selfie
    private String status;
    private String system;
    private Boolean isEkyc;
    private String name;
    private String address;
    private String addressCorrection;
    private String nationality;
    private String homeTown;
    private String hometownCorrection;
    private String issuedDate;
    private String dob;
    private String expiryDate;
    private String province;
    private String district;
    private String city;
}
