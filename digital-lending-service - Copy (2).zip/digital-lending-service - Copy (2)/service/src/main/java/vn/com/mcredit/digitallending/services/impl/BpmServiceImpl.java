package vn.com.mcredit.digitallending.services.impl;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import lombok.RequiredArgsConstructor;
import net.minidev.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.constants.Constants;
import vn.com.mcredit.digitallending.constants.Error;
import vn.com.mcredit.digitallending.dto.NotificationEContractReqDTO;
import vn.com.mcredit.digitallending.dto.req.*;
import vn.com.mcredit.digitallending.dto.req.contract.ContractDTO;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.internal.UserLinkResponse;
import vn.com.mcredit.digitallending.entity.*;
import vn.com.mcredit.digitallending.enums.*;
import vn.com.mcredit.digitallending.enums.LoanState;
import vn.com.mcredit.digitallending.exceptions.ApplicationException;
import vn.com.mcredit.digitallending.kafka.KafKaProducer;
import vn.com.mcredit.digitallending.proxy.BPMProxy;
import vn.com.mcredit.digitallending.repositories.*;
import vn.com.mcredit.digitallending.services.*;
import vn.com.mcredit.digitallending.utils.*;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BpmServiceImpl implements BpmService {

    @Value("${custom.properties.insurance-rate}")
    private Float insuranceRate;
    private final BPMProxy bpmProxy;
    private final FaceMatchRawRepository faceMatchRawRepository;
    private final CreateLoanRepository createLoanRepository;
    private final PreCheckRepository preCheckRepository;
    private final PreOfferRepository preOfferRepository;
    private final EkycModelService ekycModelService;
    private final ImageSearchService imageSearchService;
    private final NotificationEContractRepository notificationEContractRepository;
    private final EcmService ecmService;
    private final ObjectMapper objectMapper;

    private final KafKaProducer kafKaProducer;
    private final ModelMapper modelMapper;

    private final IdInternalCheckRepository idInternalCheckRepository;

    private final FaceIdsRepository faceIdsRepository;

    private final IdsFaceRepository idsFaceRepository;

    private final TelcoRepository telcoRepository;

    private final MCPortalService mcPortalService;
    @Autowired
    @Qualifier("sendMessageThreadPoolTaskExecutor")
    private TaskExecutor taskExecutor;
    @Autowired
    @Qualifier("addVectorThreadPoolTaskExecutor")
    private TaskExecutor addVectorTaskExecutor;

    @Autowired
    @Qualifier("sendUpdateLoanRequestThreadPoolTaskExecutor")
    private TaskExecutor updateLoanRequestExecutor;
    @Override
    public void callCheckDupMC(Ocr ocr, CheckFraudC3AppRequestDTO dto, Map<String, Object> map) {
        try {
            CheckDupMcResponse checkDupMcResponse = bpmProxy.checkDupMc(dto);
            this.handleCheckDupMcSuccess(map, checkDupMcResponse);
        } catch (HttpStatusCodeException e) {
            this.handleCheckDupMcFailure(e, map);
        }
    }

    private void handleCheckDupMcSuccess(Map<String, Object> map, CheckDupMcResponse checkDupMcResponse) {
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        digitalLendingResponse.setMessage(checkDupMcResponse.getMessage());
        digitalLendingResponse.setData(checkDupMcResponse);
        digitalLendingResponse.setCode(Constants.SUCCESS_CODE_0.equalsIgnoreCase(checkDupMcResponse.getErrorCode()) ? Constants.SUCCESS_CODE : checkDupMcResponse.getErrorCode());
        digitalLendingResponse.setStatus(Constants.SUCCESS_CODE_0.equalsIgnoreCase(checkDupMcResponse.getErrorCode()) ? Constants.SUCCESS_MESSAGE : Constants.FAILED_MESSAGE);
        map.put(Constants.CHECK_DUP_RESPONSE, digitalLendingResponse);

    }

    private void handleCheckDupMcFailure(HttpStatusCodeException httpStatusCodeException, Map<String, Object> map) {
        DigitalLendingResponse digitalLendingResponse = new DigitalLendingResponse();
        digitalLendingResponse.setMessage(httpStatusCodeException.getResponseBodyAsString());
        digitalLendingResponse.setStatus(Constants.FAILED_MESSAGE);
        digitalLendingResponse.setCode(Constants.ERROR_400_CODE);
        map.put(Constants.CHECK_DUP_RESPONSE, digitalLendingResponse);
    }

    public CheckFraudC3AppRequestDTO buildCheckDupMcRequest(Ocr ocr, String idNumberOld) {
        CheckFraudC3AppRequestDTO fraudC3AppRequestDTO = new CheckFraudC3AppRequestDTO();
        fraudC3AppRequestDTO.setBirthDay(ocr.getDob());
        fraudC3AppRequestDTO.setFullName(ocr.getName());
        fraudC3AppRequestDTO.setNumberExtraId(idNumberOld);
        fraudC3AppRequestDTO.setNumberId(ocr.getIdNumber());
        fraudC3AppRequestDTO.setRequestId(ocr.getRequestId());
        fraudC3AppRequestDTO.setPhoneNumber(JWTUtils.getUsername());
        return fraudC3AppRequestDTO;
    }

    @Override
    public BpmBaseResponse checkDupMc(CheckFraudC3AppRequestDTO dto) {
        try {
            return bpmProxy.checkDupMc(dto);
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    /**
     * @param preCheckRequestDTO tham số đầu vào
     *
     * @return Trả về giá trị Precheck từ BPM
     */
    @Override
    public PreCheckResponse preCheck(PreCheckRequestDTO preCheckRequestDTO) {
        try {
            return bpmProxy.preCheck(preCheckRequestDTO);
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }

    }

    /**
     * @param offerRequestDTO dữ liệu đầu vào
     *
     * @return Trả về preOffer từ BPM
     */
    @Override
    public BpmBaseResponse preOffer(OfferRequestDTO offerRequestDTO) {
        try {
            return bpmProxy.preOffer(offerRequestDTO);
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    /**
     * @param rejectOfferRequestDTO tham số đầu vào
     *
     * @return Từ chối Offer
     */
    @Override
    public RejectOfferResponse rejectOffer(RejectOfferRequestDTO rejectOfferRequestDTO) {
        String username = JWTUtils.getUsername();
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(username);
        ekycModelService.verifyDeviceId(ekycModel);
        try {
            LogUtils.info(this.getClass().getName() + "-rejectOffer");
            PreOffer preOffer = preOfferRepository.getPreOfferByUserNameAndOfferId(username, rejectOfferRequestDTO.getOfferId());
            RejectOfferResponse rejectOfferResponse;
            if (preOffer != null && OfferState.OFFER_PASSED.getValue().equalsIgnoreCase(preOffer.getStatus())) {
                if (createLoanRepository.existsByRequestIdAndOfferId(preOffer.getRequestId(), preOffer.getOfferId())) {
                    throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
                }
                preOffer.setStatus(OfferState.OFFER_REJECT.getValue());
                rejectOfferRequestDTO.setRequestId(preOffer.getRequestId());
                preOffer.setReasonCode(rejectOfferRequestDTO.getReasonCode());
                preOffer.setReason(rejectOfferRequestDTO.getReasonMessage());
                preOffer.setUpdatedDate(new Date());
                rejectOfferResponse = bpmProxy.rejectOffer(rejectOfferRequestDTO);
                LogUtils.info("[BpmService] rejectOffer bpm response");
                if (rejectOfferResponse != null && Constants.SUCCESS_CODE_0.equals(rejectOfferResponse.getErrorCode())
                        && Boolean.TRUE.equals(rejectOfferResponse.getData())){
                    this.upsertOffer(preOffer);
                }
            } else {
                rejectOfferResponse = new RejectOfferResponse();
                rejectOfferResponse.setErrorCode(Constants.FAILED_MESSAGE);
                rejectOfferResponse.setMessage(Constants.OFFER_NOT_EXIST);
            }
            mcPortalService.sendLeadOfferReject(preOffer);
            return rejectOfferResponse;
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    /**
     * @param statusOfferRequestDTO dữ liệu đầu vào
     *
     * @return trả ra kết quả Offer
     */
    @Override
    public DigitalLendingResponse getStatusOffer(StatusOfferRequestDTO statusOfferRequestDTO) {
        try {
            return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(new StatusOfferResponse()).build();
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    /**
     * @return trả lại Offer cho khách hàng
     */
    @Override
    public DigitalLendingResponse getStatusOffer(String caseNumber) {
        LogUtils.info(this.getClass().getName() + "-getStatusOffer", "Execute");
        String username = JWTUtils.getUsername();
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(username);
        ekycModelService.verifyDeviceId(ekycModel);
        StatusOfferDataResponse statusOfferDataResponse = new StatusOfferDataResponse();
        try {
            PreOffer preOffer;
            if (!StringUtils.isNullOrEmpty(caseNumber)){
                preOffer = preOfferRepository.getPreOfferByUserNameAndCaseNumber(username, caseNumber);
            } else {
                preOffer = preOfferRepository.getPreOfferByUserName(username);
            }

            if (preOffer != null) {
                this.buildOfferStatus(statusOfferDataResponse, preOffer);
                return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(statusOfferDataResponse).build();
            } else {
                statusOfferDataResponse.setProcess(Constants.SUCCESS_CODE_0);
                statusOfferDataResponse.setOfferStatus(Constants.SUCCESS_CODE_0);
                return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.FAILED_MESSAGE).data(statusOfferDataResponse).build();
            }
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        } catch (Exception e) {
            LogUtils.info(this.getClass().getName() + "-getStatusOffer Error", e.getMessage());
            throw new ApplicationException(Constants.APP_EXCEPTION_CODE, e.getMessage());
        }
    }

    private void buildOfferStatus(StatusOfferDataResponse statusOfferDataResponse, PreOffer preOffer) throws JsonProcessingException, ParseException {
        statusOfferDataResponse.setOfferStatus(preOffer.getStatus());
        if (!StringUtils.isNullOrEmpty(preOffer.getOfferDGTResponse())) {
            statusOfferDataResponse.setDetailOffer(preOffer.getOfferDGTDetailResponse());
            statusOfferDataResponse.setRequestId(preOffer.getRequestId());
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            OfferDGTDetailResponse offerDGTDetailResponse = objectMapper.readValue(preOffer.getOfferDGTDetailResponse(), OfferDGTDetailResponse.class);
            if (offerDGTDetailResponse == null) {
                statusOfferDataResponse.setProcess(Constants.SUCCESS_CODE_1);
            } else {
                statusOfferDataResponse.setOfferStatus(offerDGTDetailResponse.getReturnCode());
                if ((!CollectionUtils.isEmpty(offerDGTDetailResponse.getOffers()))) {
                    List<OfferDGTDataResponse> offers = offerDGTDetailResponse.getOffers();
                    statusOfferDataResponse.setLoanAmtMinusInsu(offerDGTDetailResponse.getOffers().get(0).getLoanAmtMinusInsu());
                    statusOfferDataResponse.setLoanAmount(offers.get(0).getLoanAmount());
                    statusOfferDataResponse.setLoanTenor(offers.get(0).getLoanTenor());
                    statusOfferDataResponse.setCampaignCode(offers.get(0).getProgramCode());
                    statusOfferDataResponse.setCampaignName(offers.get(0).getProgramName());
                    statusOfferDataResponse.setInterestRate(offers.get(0).getBaseRate());
                    statusOfferDataResponse.setLoanMethod(offers.get(0).getLoanMethod());
                    statusOfferDataResponse.setOfferId(offers.get(0).getId());
                    statusOfferDataResponse.setInsuranceRate(offers.get(0).getInsuranceRate());
                    statusOfferDataResponse.setInsuranceFee(offers.get(0).getInsuranceFee());
                    statusOfferDataResponse.setInsuranceCompany(offers.get(0).getInsuranceCompany());
                    statusOfferDataResponse.setApproveAmount(offers.get(0).getApproveAmount());
                    statusOfferDataResponse.setProcess(Constants.SUCCESS_CODE_1);
                    statusOfferDataResponse.setDetailOffer(preOffer.getOfferDGTResponse());
                    String strExpiredTime = offers.get(0).getExpiredTime();
                    Date expiredDate = DateUtils.toDate(strExpiredTime, DateUtils.FORMAT_TIME_BPM_YYYY_MM_DD_HH_MM_SS);
                    statusOfferDataResponse.setExpiredTime(expiredDate);
                    statusOfferDataResponse.setRemainTime(CommonUtils.calculateRemainTime(expiredDate));
                    statusOfferDataResponse.setRemainTimeUnit(Constants.MILLISECOND);
                }
            }
        }
    }

    /**
     * @param getOfferRequestDTO dữ liệu đầu vào
     *
     * @return Giá trị Offer
     */
    @Override
    public DigitalLendingResponse getOffer(GetOfferRequestDTO getOfferRequestDTO) {
        String userName = JWTUtils.getUsername();
        String requestId = UUID.randomUUID().toString();
        LogUtils.info(this.getClass().getName() + "-getOffer: " + userName);
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(userName);
        ekycModelService.verifyDeviceId(ekycModel);
        GetOfferResponse getOfferResponse;
        try {
            if(this.isHasOffer(userName)) {
                throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.BAD_REQUEST.getMessage());
            }
            PreCheckRequestDTO preCheckRequestDTO = new PreCheckRequestDTO();
            preCheckRequestDTO.setIdNumber(ekycModel.getIdNumber());
            preCheckRequestDTO.setOldIdNumber(ekycModel.getIdNumberOld());
            Double loadAmountValue = (getOfferRequestDTO.getLoanAmtMinusInsu().doubleValue() * (100 + insuranceRate)) / 100;
            preCheckRequestDTO.setLoanAmount(loadAmountValue);
            preCheckRequestDTO.setXsell(Constants.XCELL_DEFAULT);
            preCheckRequestDTO.setRequestId(requestId);
            preCheckRequestDTO.setReferId(ekycModel.getObjectId());
            preCheckRequestDTO.setFullName(ekycModel.getName());

            PreCheck preCheck = modelMapper.map(preCheckRequestDTO, PreCheck.class);
            preCheck.setUserName(userName);
            preCheck.setUpdatedBy(userName);
            preCheck.setCreatedBy(userName);
            Date currentDate = new Date();
            preCheck.setUpdatedDate(currentDate);
            preCheck.setCreatedDate(currentDate);
            // Kiểm tra 1 device chỉ được get offer với 1 khách hàng
            this.checkDeviceOffer(requestId, preCheck);
            String partnerCode = JWTUtils.getPartnerCode();
            preCheckRequestDTO.setSystem(this.getSystemFormPartnerCode(partnerCode));
            PreCheckResponse responsePreCheck = bpmProxy.preCheck(preCheckRequestDTO);
            modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
            preCheck.setStatus(responsePreCheck.getData() != null && responsePreCheck.getData().getResult() != null ? responsePreCheck.getData().getResult() : Constants.FAILED_MESSAGE );
            preCheck.setMessage(responsePreCheck.getMessage());
            preCheck.setErrorCode(responsePreCheck.getErrorCode());
            if(responsePreCheck.getData() != null)
                preCheck.setCaseNumber(responsePreCheck.getData().getCaseNumber());
            if(StringUtils.isNotBlank(partnerCode))
                preCheck.setPartnerCode(partnerCode);
            preCheckRepository.save(preCheck);
            getOfferResponse = modelMapper.map(responsePreCheck, GetOfferResponse.class);
            // Trường hợp precheck thành công
            if (responsePreCheck.getData() != null && Constants.PASS.equals(responsePreCheck.getData().getResult())) {
                NotificationRequestDTO notificationRequestDTO = new NotificationRequestDTO();
                notificationRequestDTO.setDeviceId(JWTUtils.getDeviceId());
                notificationRequestDTO.setRequestId(requestId);
                notificationRequestDTO.setTopic(kafKaProducer.getTopicDLCreateOffer());
                OfferRequestDTO offerRequestDTO = new OfferRequestDTO();
                offerRequestDTO.setTopic(kafKaProducer.getTopicDLCreateOffer());
                offerRequestDTO.setCreateBy(userName);
                offerRequestDTO.setRequestId(requestId);
                Date dob = DateUtils.toDate(ekycModel.getDob(), DateUtils.F_DDMMYYYY, new Date());
                offerRequestDTO.setAge(DateUtils.calculateAge(new Date(), dob));
                // Thông tin List Phone cung cấp trong giai đoạn Phase 2
                offerRequestDTO.setCity("HN");
                offerRequestDTO.setSex(ekycModel.getGender());
                offerRequestDTO.setLoanAmtMinusInsu(getOfferRequestDTO.getLoanAmtMinusInsu());
                offerRequestDTO.setCustomerGroup(Constants.DIGITAL);
                offerRequestDTO.setBusinessChannel(Constants.DIGITAL);
                offerRequestDTO.setHasInsurance(getOfferRequestDTO.getHasInsurance());
                offerRequestDTO.setLoanPurpose(getOfferRequestDTO.getLoanPurpose());
                offerRequestDTO.setLoanTenor(getOfferRequestDTO.getLoanTenor());
                offerRequestDTO.setNumberId(ekycModel.getIdNumber());
                offerRequestDTO.setFullName(ekycModel.getName());
                offerRequestDTO.setBirthDay(ekycModel.getDob());
                offerRequestDTO.setNumberExtraId(ekycModel.getIdNumberOld());
                offerRequestDTO.setPhoneNumber(ekycModel.getUsername());
                offerRequestDTO.setPartnerCode(JWTUtils.getPartnerCode());
                notificationRequestDTO.setMessage(offerRequestDTO);
                PreOffer preOffer = modelMapper.map(offerRequestDTO, PreOffer.class);
                preOffer.setUserName(userName);
                preOffer.setCreatedBy(userName);
                preOffer.setUpdatedBy(userName);
                preOffer.setReferId(ekycModel.getObjectId());
                Date date = new Date();
                preOffer.setUpdatedDate(date);
                preOffer.setCreatedDate(date);
                preOffer.setStatus(OfferState.OFFER_PROCESSING.getValue());
                preOffer.setOfferRequest(CommonUtils.toJsonString(notificationRequestDTO));
                preOffer.setCaseNumber(preCheck.getCaseNumber());
                if(StringUtils.isNotBlank(partnerCode))
                    preOffer.setPartnerCode(partnerCode);
                this.upsertOffer(preOffer);
                getOfferResponse.setData(preOffer);
                this.pushPreOfferToKafka(notificationRequestDTO);
            }
            return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(getOfferResponse).build();
        } catch (HttpStatusCodeException e) {
            LogUtils.error(this.getClass().getName() + "-getOffer ex" + userName , e.getMessage());
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    private String getSystemFormPartnerCode( String partnerCode) {
        if (EPartnerCode.MC_CREDIT_APP.getValue().equalsIgnoreCase(partnerCode)){
            return SourceAppType.DIGITAL_LENDING.getValue();
        } else if (EPartnerCode.MB_BANK.getValue().equalsIgnoreCase(partnerCode)){
            return SourceAppType.DL_MBBANK.getValue();
        } else if (EPartnerCode.WEB_APP.getValue().equalsIgnoreCase(partnerCode)){
            return SourceAppType.DL_WEB.getValue();
        } else {
            return SourceAppType.DIGITAL_LENDING.getValue();
        }
    }

    public boolean isHasLoan(String username) {
        List<String> statuses = Arrays.asList(LoanState.LOAN_PROCESSING.getValue(), LoanState.LOAN_PASSED.getValue(), LoanState.SIGN_COMPLETED.getValue());
        return createLoanRepository.existsByUserNameAndStatusIn(username, statuses);
    }

    private boolean isHasOffer(String username) {
        List<String> statuses = Arrays.asList(OfferState.OFFER_PROCESSING.getValue(), OfferState.OFFER_PASSED.getValue(), OfferState.OFFER_IN_USE.getValue());
        return preOfferRepository.existsByUserNameAndStatusIn(username, statuses);
    }

    /**
     * @param createCaseRequestDTO dữ liệu đầu vào
     *
     * @return Create Case
     */
    @Override
    public DigitalLendingResponse createCase(CreateCaseRequestDTO createCaseRequestDTO) {
        LogUtils.info(this.getClass().getName() + "-createCase");
        this.checkCustomerRelative(createCaseRequestDTO.getCustomerRelativesRequests(), createCaseRequestDTO.getMaritalStatus());
        this.validateCustomerAddresses(createCaseRequestDTO.getCustomerAddressRequests());
        this.validateDisbursementType(createCaseRequestDTO);
        String username = JWTUtils.getUsername();
        this.validateLoanRequest(username);
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(username);
        ekycModelService.verifyDeviceId(ekycModel);

        this.validateDibursementFT(createCaseRequestDTO, ekycModel);
        this.validateSearchOption(createCaseRequestDTO.getCustProfessional(), createCaseRequestDTO.getMaritalStatus(), createCaseRequestDTO.getIncomeRange());
        CreateCaseResponse createCaseResponse = new CreateCaseResponse();
        try {
            NotificationRequestDTO notificationRequestDTO = new NotificationRequestDTO();
            PreOffer preOffer = preOfferRepository.getPreOfferByUserNameAndOfferId(username, createCaseRequestDTO.getOfferId());
            if ((preOffer != null) && (!StringUtils.isNullOrEmpty(preOffer.getOfferDGTResponse()))) {
                this.checkAML(createCaseRequestDTO, this.buidCheckAMLDTO(preOffer.getRequestId(), ekycModel.getDob(),ekycModel.getName(),createCaseRequestDTO.getCustProfessional(), ekycModel.getIdNumber(), ekycModel.getIdNumberOld(), preOffer.getCaseNumber()));
                notificationRequestDTO.setTopic(kafKaProducer.getTopicDLCreateCase());
                notificationRequestDTO.setSourceCreate(this.getSourceCreateFromPartnerCode(JWTUtils.getPartnerCode()));

                //Dinh nghia message day vao kafka
                CaseRequestDTO caseRequestDTO = new CaseRequestDTO();
                caseRequestDTO.setRequestId(preOffer.getRequestId());
                caseRequestDTO.setCreateBy(username);
                caseRequestDTO.setDeviceId(JWTUtils.getDeviceId());
                objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                OfferDGTDetailResponse offerDGTDetailResponse = objectMapper.readValue(preOffer.getOfferDGTDetailResponse(), OfferDGTDetailResponse.class);
                if (offerDGTDetailResponse != null && offerDGTDetailResponse.getOffers() != null) {
                    TelcoLocation telcoLocation = this.validateTelcoLocation(createCaseRequestDTO.getLocationTelcoRequestId(), offerDGTDetailResponse.getCodeStatus());
                    List<OfferDGTDataResponse> offers = offerDGTDetailResponse.getOffers();
                    String[] imageNames = this.uploadFileToEcm(ekycModel);

                    caseRequestDTO.setLoansOfferId(offers.get(0).getId());
                    caseRequestDTO.setRequestId(preOffer.getRequestId());
                    List<IdentityPaperRequest> identityPaperRequestList = this.getIdentityPaperRequests(ekycModel);
                    caseRequestDTO.setIdentityPaperRequests(identityPaperRequestList);
                    List<LoansFileUploadRequest> loansFileUploadRequestList = this.getListLoanFileUploadRequest(ekycModel, imageNames);
                    caseRequestDTO.setLoansFileUploadRequests(loansFileUploadRequestList);
                    List<CustomerAddressRequest> customerAddressRequestList = createCaseRequestDTO.getCustomerAddressRequests();
                    caseRequestDTO.setCustomerAddressRequests(customerAddressRequestList);
                    List<CustomerRelativesRequest> customerRelativesRequestList = createCaseRequestDTO.getCustomerRelativesRequests();
                    caseRequestDTO.setCustomerRelativesRequests(customerRelativesRequestList);
                    CustomerRequest customerRequest = this.getCustomerRequest(ekycModel, createCaseRequestDTO);
                    caseRequestDTO.setCustomerRequest(customerRequest);
                    caseRequestDTO.setDisbursementInfoRequest(this.getDisbursementInfo(createCaseRequestDTO));
                    caseRequestDTO.setPartnerCode(JWTUtils.getPartnerCode());
                    this.setDataLocationTelco(createCaseRequestDTO, caseRequestDTO, telcoLocation);
                    notificationRequestDTO.setRequestId(preOffer.getRequestId());
                    notificationRequestDTO.setMessage(caseRequestDTO);

                    CreateLoan createLoan = createLoanRepository.findCreateLoanByRequestId(preOffer.getRequestId());
                    if (createLoan != null) {
                        LogUtils.info("[BpmService] create-case bpm đã tồn tại requestId", preOffer.getRequestId());
                        throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
                    }
                    createLoan = new CreateLoan();
                    createLoan.setRequestId(preOffer.getRequestId());
                    createLoan.setReferId(preOffer.getReferId());
                    createLoan.setOfferId(offers.get(0).getId());
                    createLoan.setIdentityPaper(CommonUtils.toJsonString(identityPaperRequestList));
                    createLoan.setCustomerRelatives(CommonUtils.toJsonString(customerRelativesRequestList));
                    createLoan.setLoansFileUpload(CommonUtils.toJsonString(loansFileUploadRequestList));
                    createLoan.setCustomerAddress(CommonUtils.toJsonString(customerAddressRequestList));
                    createLoan.setCustomerRequest(CommonUtils.toJsonString(customerRequest));
                    createLoan.setNotificationRequest(CommonUtils.toJsonString(notificationRequestDTO));
                    createLoan.setUserName(username);
                    Date currentTime = new Date();
                    createLoan.setCreatedBy(username);
                    createLoan.setUpdatedBy(username);
                    createLoan.setUpdatedDate(currentTime);
                    createLoan.setCreatedDate(currentTime);
                    createLoan.setStatus(LoanState.LOAN_PROCESSING.getValue());
                    createLoan.setPartnerCode(JWTUtils.getPartnerCode());
                    createLoan.setCaseNumber(preOffer.getCaseNumber());
                    if(telcoLocation != null) createLoan.setTelcoLocationRequestId(telcoLocation.getId());
                    createLoanRepository.save(createLoan);
                    // save ekyc model
                    ekycModelService.save(ekycModel);
                    createCaseResponse.setLoanAmount(offers.get(0).getLoanAmount());
                    createCaseResponse.setData(createLoan);

                    this.pushCreateCaseToKafka(notificationRequestDTO);
                    // call uid|vector to image search service
                    this.callAddVectors(ekycModel);
                }
            } else {
                return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(Constants.OFFER_ID_NOT_VALID).build();
            }
            return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(createCaseResponse).build();
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        } catch (JsonProcessingException e) {
            throw new ApplicationException(String.valueOf(e.getMessage()), e.getMessage());
        }
    }

    private void checkAML(CreateCaseRequestDTO createCaseRequestDTO, CheckAMLDTO checkAMLDTO) {
        CheckAMLResponse checkAMLResponse = null;
        try {
            checkAMLResponse = bpmProxy.checkAML(checkAMLDTO);
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        } catch (Exception e) {
            throw new ApplicationException(Constants.ERROR_400_BAD, Constants.EXCEPTION_MES);
        }
        if(!Constants.ERROR_CODE_ZERO.equals(checkAMLResponse.getErrorCode())) {
            throw new ApplicationException(Constants.ERROR_400_BAD, Constants.EXCEPTION_MES);
        }
        if(AMLResult.FAIL.getValue().equalsIgnoreCase(checkAMLResponse.getData().getResult())) {
            throw new ApplicationException(Error.FAIL_CHECK_AML.getCode(), Error.FAIL_CHECK_AML.getMessage());
        }
        if(AMLScore.H.getValue().equalsIgnoreCase(checkAMLResponse.getData().getScoreAML()) && (StringUtils.isNullOrEmpty(createCaseRequestDTO.getCompanyPhone()) || StringUtils.isNullOrEmpty(createCaseRequestDTO.getCompanyAddress()))) {
            throw new ApplicationException(Error.FAIL_CHECK_AML_SCORE.getCode(), Error.FAIL_CHECK_AML_SCORE.getMessage());
        }
    }

    private CheckAMLDTO buidCheckAMLDTO(String requestId, String dob,String custName, String custCareer, String idNumber, String oldIdNumber, String caseNumber) {
        return CheckAMLDTO.builder().requestId(requestId).birthday(dob).custName(custName).custCareer(custCareer).idNumber(idNumber).oldIdNumber(oldIdNumber).loansProfileId(caseNumber).build();
    }

    private void validateDibursementFT(CreateCaseRequestDTO createCaseRequestDTO, EkycModel ekycModel) {
        if (Constants.DISBURSEMENT_TYPE_FT.equalsIgnoreCase(createCaseRequestDTO.getDisbursementType())) {
            this.validateCardNumberMB(createCaseRequestDTO.getAccountNumber(), ekycModel);
            if(EPartnerCode.MC_CREDIT_APP.getValue().equalsIgnoreCase(JWTUtils.getPartnerCode())) {
                if(StringUtils.isNullOrEmpty(createCaseRequestDTO.getBankCode()) || StringUtils.isNullOrEmpty(createCaseRequestDTO.getBankName())
                        || StringUtils.isNullOrEmpty(createCaseRequestDTO.getSmlCode()) || StringUtils.isNullOrEmpty(createCaseRequestDTO.getDisbursementModel())) {
                    throw new ApplicationException(Error.INVALID_DISBURSEMENT_DATA.getCode(), Error.INVALID_DISBURSEMENT_DATA.getMessage());
                }
                this.validateAccountDisbursement(createCaseRequestDTO);
            }
        }
    }

    private void validateAccountDisbursement(CreateCaseRequestDTO createCaseRequestDTO) {
        CheckAccountDisbursementRequestDTO requestDTO = new CheckAccountDisbursementRequestDTO();
        requestDTO.setAccountNumber(createCaseRequestDTO.getAccountNumber());
        requestDTO.setSmlCode(createCaseRequestDTO.getSmlCode());
        CheckAccountDisbursementResponse response = this.getCheckAccountDisbursementResponse(requestDTO);
        if(response != null && response.getData() != null && !Constants.PASS.equalsIgnoreCase(response.getData().getResult())) {
            throw new ApplicationException(response.getData().getErrorCode(), Error.ACCOUNT_NUMBER_INVALID.getMessage());
        }
    }

    private void validateLoanRequest(String username) {
        if(this.isHasLoan(username)) {
            throw new ApplicationException(Error.BAD_REQUEST.getCode(), Error.BAD_REQUEST.getMessage());
        }
    }

    private String getSourceCreateFromPartnerCode(String partnerCode) {
        if (EPartnerCode.MC_CREDIT_APP.getValue().equalsIgnoreCase(partnerCode)){
            return SourceCreateEnum.DIGITAL.getValue();
        } else if (EPartnerCode.MB_BANK.getValue().equalsIgnoreCase(partnerCode)){
            return SourceCreateEnum.DIGITAL_MINI_APP.getValue();
        } else if (EPartnerCode.WEB_APP.getValue().equalsIgnoreCase(partnerCode)){
            return SourceCreateEnum.DIGITAL_WEB.getValue();
        } else {
            return SourceCreateEnum.DIGITAL.getValue();
        }
    }

    private TelcoLocation validateTelcoLocation(String locationTelcoRequestId, List<CodeStatus> codeStatus) {
        // Kiểm tra rule c10.2 trong codeStatus nếu rule c10.2 có result Y thì cần phải check location telco. Nếu check telco status pass thì tạo case.
        String ruleC102 = Utils.getResultByRule(codeStatus, Constants.RULE_C10_2);
        TelcoLocation telcoLocation = null;
        if (Constants.YES.equalsIgnoreCase(ruleC102)){
            if (StringUtils.isNullOrEmpty(locationTelcoRequestId)){
                throw new ApplicationException(Error.FAIL_LOCATION_TELCO.getCode(), Error.FAIL_LOCATION_TELCO.getMessage());
            } else {
                telcoLocation = telcoRepository.findTelcoLocationByRequestId(locationTelcoRequestId);
                if (telcoLocation == null || !telcoLocation.getStatus()){
                    throw new ApplicationException(Error.FAIL_LOCATION_TELCO.getCode(), Error.FAIL_LOCATION_TELCO.getMessage());
                }
            }
        }
        return telcoLocation;
    }

    private void setDataLocationTelco(CreateCaseRequestDTO createCaseRequestDTO, CaseRequestDTO caseRequestDTO, TelcoLocation telcoLocation) {
        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setLatitude(createCaseRequestDTO.getLatitude());
        locationRequest.setLongitude(createCaseRequestDTO.getLongitude());
        if (telcoLocation != null) {
            locationRequest.setWardRatio1Month(telcoLocation.getRatio1MonthWard());
            locationRequest.setWardRatioRange1Month(telcoLocation.getRatioRange1MonthWard());
            locationRequest.setWardRatio3Months(telcoLocation.getRatio3monthsWard());
            locationRequest.setWardRatioRange3Months(telcoLocation.getRatioRange3MonthsWard());
            locationRequest.setWardName(telcoLocation.getWard());
            locationRequest.setDistrictName(telcoLocation.getDistrict());
            locationRequest.setProvinceName(telcoLocation.getProvince());
        }
        caseRequestDTO.setLocationRequest(locationRequest);
    }

    private CustomerRequest getCustomerRequest(EkycModel ekycModel, CreateCaseRequestDTO createCaseRequestDTO) {
        LogUtils.info(this.getClass().getName() + "-getCustomerRequest");
        try {
            CustomerRequest customerRequest = new CustomerRequest();
            if (StringUtils.isNullOrEmpty(createCaseRequestDTO.getTempSamePermAddress())) {
                customerRequest.setTempSamePermAddress(Constants.YES_VALUE);
            } else {
                customerRequest.setTempSamePermAddress(createCaseRequestDTO.getTempSamePermAddress());
            }
            customerRequest.setCustCareer(Constants.PRF20_VALUE);
            customerRequest.setCustEmail(ekycModel.getEmail());
            customerRequest.setCustGender(ekycModel.getGender());
            customerRequest.setCompanyName(createCaseRequestDTO.getCompanyName());
            String companyPhone = createCaseRequestDTO.getCompanyPhone();
            String companyAddress = createCaseRequestDTO.getCompanyAddress();
            if(!StringUtils.isNullOrEmpty(companyPhone) && !StringUtils.isNullOrEmpty(companyAddress)) {
                customerRequest.setCompanyPhone(companyPhone);
                customerRequest.setCompanyAddress(companyAddress);
            }
            customerRequest.setIncomeRange(createCaseRequestDTO.getIncomeRange());
            // Thông tin List Phone cung cấp trong giai đoạn Phase 2
            customerRequest.setListPhone(Constants.EMPTY);
            customerRequest.setCustDob(ekycModel.getDob());
            customerRequest.setCustName(ekycModel.getName());
            customerRequest.setCustMaritalStatus(createCaseRequestDTO.getMaritalStatus());
            customerRequest.setPhone(JWTUtils.getUsername());
            customerRequest.setCustProfessional(createCaseRequestDTO.getCustProfessional());
            customerRequest.setCustPosition(createCaseRequestDTO.getCustPosition());
            return customerRequest;
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    private DisbursementInfoDTO getDisbursementInfo(CreateCaseRequestDTO createCaseRequestDTO) {
        LogUtils.info(this.getClass().getName() + "-getDisbursementInfo", createCaseRequestDTO);
        try {
            DisbursementInfoDTO disbursementInfoDTO = new DisbursementInfoDTO();
            disbursementInfoDTO.setCreatedBy(JWTUtils.getUsername());
            disbursementInfoDTO.setDisbursementType(createCaseRequestDTO.getDisbursementType());
            disbursementInfoDTO.setDisbursementModel(createCaseRequestDTO.getDisbursementModel());


            if (Constants.DISBURSEMENT_TYPE_TT.equalsIgnoreCase(createCaseRequestDTO.getDisbursementType()))
                disbursementInfoDTO.setPayPartnerCode(createCaseRequestDTO.getPayPartnerCode());
            if (Constants.DISBURSEMENT_TYPE_FT.equalsIgnoreCase(createCaseRequestDTO.getDisbursementType())) {
                MatrixResponse matrixResponse = this.disbursementMatrix(createCaseRequestDTO.getOfferId());
                LogUtils.info(this.getClass().getName() + "-matrixResponse", matrixResponse);
                if(matrixResponse != null && matrixResponse.getData() != null && matrixResponse.getData().getDisbursementResponse() != null) {
                    this.validateDisbursementInfor(createCaseRequestDTO, matrixResponse);
                }
                disbursementInfoDTO.setAccountNumber(createCaseRequestDTO.getAccountNumber());
                disbursementInfoDTO.setAccountName(createCaseRequestDTO.getAccountName());
                disbursementInfoDTO.setBankCode(createCaseRequestDTO.getBankCode());
                disbursementInfoDTO.setBankName(createCaseRequestDTO.getBankName());
                disbursementInfoDTO.setBank(createCaseRequestDTO.getBank());
                disbursementInfoDTO.setSmlCode(createCaseRequestDTO.getSmlCode());

                this.setDisbursementMBInfor(createCaseRequestDTO, disbursementInfoDTO);
            }

            return disbursementInfoDTO;
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    private void setDisbursementMBInfor(CreateCaseRequestDTO createCaseRequestDTO, DisbursementInfoDTO disbursementInfoDTO) {
        if (StringUtils.isNullOrEmpty(createCaseRequestDTO.getSmlCode())) disbursementInfoDTO.setSmlCode(Constants.SML_CODE_MB);
        if (StringUtils.isNullOrEmpty(createCaseRequestDTO.getBankName())) disbursementInfoDTO.setBankName(Constants.BANK_NAME_MB);
        if (StringUtils.isNullOrEmpty(createCaseRequestDTO.getBankCode())) disbursementInfoDTO.setBankCode(Constants.BANK_CODE_MB);
        if (StringUtils.isNullOrEmpty(createCaseRequestDTO.getDisbursementModel())) disbursementInfoDTO.setDisbursementModel(Constants.DISBURSEMENT_MODEL_MB);
        if (StringUtils.isNullOrEmpty(createCaseRequestDTO.getBank())) disbursementInfoDTO.setBank(Constants.MB_BANK);
    }

    private void validateDisbursementInfor(CreateCaseRequestDTO createCaseRequestDTO, MatrixResponse matrixResponse) {
        MatrixDisbursementResponse matrixDisbursementResponse = matrixResponse.getData().getDisbursementResponse();
        if (EPartnerCode.MC_CREDIT_APP.getValue().equalsIgnoreCase(JWTUtils.getPartnerCode()) && (!matrixDisbursementResponse.getDisbursementModel().equalsIgnoreCase(createCaseRequestDTO.getDisbursementModel())
                || (Constants.BANK_CODE_MB.equalsIgnoreCase(matrixDisbursementResponse.getBankCode()) && !Constants.BANK_CODE_MB.equalsIgnoreCase(createCaseRequestDTO.getBankCode())))) {
            throw new ApplicationException(Error.INVALID_DISBURSEMENT_DATA.getCode(), Error.INVALID_DISBURSEMENT_DATA.getMessage());
        }
    }

    private List<IdentityPaperRequest> getIdentityPaperRequests(EkycModel ekycModel) {
        LogUtils.info(this.getClass().getName() + "-getIdentityPaperRequests", ekycModel);
        try {
            List<IdentityPaperRequest> identityPaperRequestList = new ArrayList<>();
            IdentityPaperRequest identityMainPaperRequest = new IdentityPaperRequest();
            identityMainPaperRequest.setIdentityCode(Constants.MAINID);
            identityMainPaperRequest.setIdNumber(ekycModel.getIdNumber());
            identityMainPaperRequest.setIdentityIssuePlaceCode(Constants.IDS03);
            identityMainPaperRequest.setIdentityIssuePlace(Constants.CUC_CS_QLHC_V_TTXH);
            identityMainPaperRequest.setIdentityType(Constants.CCCDQR);
            identityMainPaperRequest.setIdentityIssueDate(ekycModel.getIssuedDate());
            identityMainPaperRequest.setIdentityExpiredDate(ekycModel.getExpiryDate());
            identityPaperRequestList.add(identityMainPaperRequest);
            if (!StringUtils.isNullOrEmpty(ekycModel.getIdNumberOld())) {
                IdentityPaperRequest identityExtraPaperRequest = new IdentityPaperRequest();
                identityExtraPaperRequest.setIdentityCode(Constants.EXTRAID);
                identityExtraPaperRequest.setIdNumber(ekycModel.getIdNumberOld());
                identityExtraPaperRequest.setIdentityType(Constants.CMND);
                identityPaperRequestList.add(identityExtraPaperRequest);
            }
            return identityPaperRequestList;
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    private List<LoansFileUploadRequest> getListLoanFileUploadRequest(EkycModel ekycModel, String[] imageNames) {
        LogUtils.info(this.getClass().getName() + "-getListLoanFileUploadRequest", ekycModel);
        try {
            List<LoansFileUploadRequest> loansFileUploadRequestList = new ArrayList<>();
            LoansFileUploadRequest loansFileUploadFrontRequest = new LoansFileUploadRequest();
            loansFileUploadFrontRequest.setSourceUpload(Constants.DIGITAL);
            if (imageNames.length > 0)
                loansFileUploadFrontRequest.setName(imageNames[0]);
            loansFileUploadFrontRequest.setUrl(ekycModel.getFrontImageEcmURL());
            loansFileUploadFrontRequest.setType(Constants.FUM06);
            loansFileUploadRequestList.add(loansFileUploadFrontRequest);

            LoansFileUploadRequest loansFileUploadBackRequest = new LoansFileUploadRequest();
            loansFileUploadBackRequest.setSourceUpload(Constants.DIGITAL);
            if (imageNames.length > 1)
                loansFileUploadBackRequest.setName(imageNames[1]);
            loansFileUploadBackRequest.setUrl(ekycModel.getBackImageEcmURL());
            loansFileUploadBackRequest.setType(Constants.FUM06);
            loansFileUploadRequestList.add(loansFileUploadBackRequest);

            LoansFileUploadRequest loansFileUploadSelfieRequest = new LoansFileUploadRequest();
            loansFileUploadSelfieRequest.setSourceUpload(Constants.DIGITAL);
            if (imageNames.length > 2)
                loansFileUploadSelfieRequest.setName(imageNames[2]);
            loansFileUploadSelfieRequest.setUrl(ekycModel.getSelfieImageEcmURL());
            loansFileUploadSelfieRequest.setType(Constants.FUM07);
            loansFileUploadRequestList.add(loansFileUploadSelfieRequest);
            if (StringUtils.isNotBlank(ekycModel.getVoiceCaptchaEcmURL())) {
                LoansFileUploadRequest loansFileUploadVoiceRequest = new LoansFileUploadRequest();
                loansFileUploadVoiceRequest.setSourceUpload(Constants.DIGITAL);
                if (imageNames.length > 3) loansFileUploadVoiceRequest.setName(imageNames[3]);
                loansFileUploadVoiceRequest.setUrl(ekycModel.getVoiceCaptchaEcmURL());
                loansFileUploadVoiceRequest.setType(Constants.FUM08);
                loansFileUploadRequestList.add(loansFileUploadVoiceRequest);
            }
            return loansFileUploadRequestList;
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        }
    }

    /**
     * @param statusCaseRequestDTO dữ liệu đầu vào
     *
     * @return trả ra trạng thái Case
     */
    @Override
    public DigitalLendingResponse getStatusCase(StatusCaseRequestDTO statusCaseRequestDTO) {
        LogUtils.info(this.getClass().getName() + "-getStatusCase", statusCaseRequestDTO);
        try {
            CreateLoan createLoan = createLoanRepository.getCreateLoanByName(JWTUtils.getUsername());
            if (createLoan != null) {
                objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                NotificationResponseDTO notificationResponseDTO = objectMapper.readValue(createLoan.getNotificationResponse(), NotificationResponseDTO.class);
                return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(notificationResponseDTO).build();
            }
            return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(Constants.CREATE_LOAN_PROCESSING).build();
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        } catch (JsonProcessingException e) {
            throw new ApplicationException(String.valueOf(e.getMessage()), e.getMessage());
        }
    }

    /**
     * @return trả ra trạng thái Case
     */
    @Override
    public DigitalLendingResponse getStatusCase(String caseNumber) {
        String username = JWTUtils.getUsername();
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(username);
        ekycModelService.verifyDeviceId(ekycModel);
        try {
            CreateLoan createLoan;
            if(!StringUtils.isNullOrEmpty(caseNumber)) {
                createLoan = createLoanRepository.getCreateLoanByNameAndAndCaseNumber(username, caseNumber);
            }else {
                createLoan = createLoanRepository.getCreateLoanByName(username);
            }
            NotificationResponseDTO notificationResponseDTO = new NotificationResponseDTO();
            // Trường hợp đã có thông tin khoản vay
            if (createLoan != null) {
                if (!StringUtils.isNullOrEmpty(createLoan.getNotificationResponse())) {
                    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                    objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                    notificationResponseDTO = objectMapper.readValue(createLoan.getNotificationResponse(), NotificationResponseDTO.class);
                    notificationResponseDTO.setProcess(Constants.SUCCESS_CODE_1);
                    if((notificationResponseDTO.getMessage() != null)  && (!StringUtils.isNullOrEmpty(notificationResponseDTO.getMessage().getReturnCode()))) {
                        notificationResponseDTO.setData(notificationResponseDTO.getMessage().getReturnCode().equals("0") ? Constants.PASS : Constants.FAILED);
                    }
                    return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(notificationResponseDTO).build();
                }
                notificationResponseDTO.setProcess(Constants.SUCCESS_CODE_0);
                notificationResponseDTO.setData(Constants.FAILED);
                return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.FAILED).data(notificationResponseDTO).build();
            }
            // Trường hợp không có thông tin khoản vay
            notificationResponseDTO.setProcess(Constants.FAILED_CODE_1);
            notificationResponseDTO.setData(Constants.FAILED);
            return DigitalLendingResponse.builder().code(Constants.SUCCESS_CODE).status(Constants.FAILED).data(notificationResponseDTO).build();
        } catch (HttpStatusCodeException e) {
            throw new ApplicationException(String.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        } catch (JsonProcessingException e) {
            throw new ApplicationException(String.valueOf(e.getMessage()), e.getMessage());
        }
    }

    /**
     * @param dto = {NotificationRequestDTO@21626} "NotificationRequestDTO(topic=DIGITAL_CREATE_OFFER, contentType=null, caseNumber=null, requestId=5bc88c1a-872d-4d19-983a-e3f976235ba8, contractNumber=null, status=null, sourceCreate=null, message=OfferRequestDTO(birthDay=03/11/1983, topic=DIGITAL_CREATE_OFFER, createBy=0918362328, age=0, businessChannel=DIGITAL, city=HN, customerGroup=DIGITAL, hasInsurance=Y, insuranceCompany=null, insuranceFee=null, loanAmtMinusInsu=900000, loanPurpose=068656465, loanTenor=1000, requestId=5bc88c1a-872d-4d19-983a-e3f976235ba8, score=null, sex=Nam, fullName=ĐÀM THẬN SIÊM, phoneNumber=0918362328, numberExtraId=0918362328, numberId=027083004884), system=null)"
     */
    private void pushPreOfferToKafka(Object dto) {
        LogUtils.info("[BpmService] pushPreOfferToKafka", dto);
        kafKaProducer.sendMessageCreateOffer(CommonUtils.toJsonString(dto));
    }

    private void pushCreateCaseToKafka(Object dto) {
        LogUtils.info("[BpmService] pushCreateCaseToKafka ", dto);
        kafKaProducer.sendMessageCreateCase(CommonUtils.toJsonString(dto));
    }

    /**
     * @param data dữ liệu đầu vào
     */
    @Override
    public void receiveCreateCaseFromKafka(String data) {
        try {
            LogUtils.info("[BpmService] receiveMessageCreateCase", data);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            NotificationResponseDTO notificationResponseDTO = objectMapper.readValue(data, NotificationResponseDTO.class);
            if(StringUtils.isNullOrEmpty(notificationResponseDTO.getRequestId()))
                return;
            PreOffer preOffer = preOfferRepository.getPreOfferByRequestId(notificationResponseDTO.getRequestId());
            if(preOffer == null) return;
            CreateLoan createLoan = createLoanRepository.findCreateLoanByRequestId(notificationResponseDTO.getRequestId());
            createLoan.setNotificationResponse(data);
            Date date = new Date();

            preOffer.setStatus(OfferState.OFFER_IN_USE.getValue());
            preOffer.setUpdatedDate(date);
            createLoan.setOfferId(preOffer.getOfferId());

            createLoan.setUpdatedDate(date);
            if (Constants.SUCCESS_CODE_0.equals(notificationResponseDTO.getMessage().getReturnCode())) {
                if (!preOffer.getCaseNumber().equals(notificationResponseDTO.getCaseNumber())) {
                    createLoan.setStatus(LoanState.LOAN_FAILED.getValue());
                    createLoan.setReason(Error.ERROR_CASE_NUMBER.getMessage());
                } else {
                    createLoan.setCaseNumber(notificationResponseDTO.getCaseNumber());
                    createLoan.setContractNumber(notificationResponseDTO.getContractNumber());
                    createLoan.setStatus(LoanState.LOAN_PASSED.getValue());
                }
            } else {
                createLoan.setStatus(LoanState.LOAN_FAILED.getValue());
                createLoan.setReason(Error.getStringValueFromKey(notificationResponseDTO.getMessage().getReturnMess()));
            }
            createLoanRepository.save(createLoan);
            this.upsertOffer(preOffer);
        } catch (Exception e) {
            LogUtils.info("[BpmService] receiveMessageCreateCase exception", e.getMessage());
        }

    }

    /**
     * @param data dữ liệu đầu vào
     */
    @Override
    public void receiveGetOfferFromKafka(String data) {
        try {
            LogUtils.info("[BpmService] receiveMessageCreateOffer", data);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            objectMapper.setDateFormat(new SimpleDateFormat(DateUtils.FORMAT_TIME_BPM_YYYY_MM_DD_HH_MM_SS_SSS));
            OfferDGTResponse offerDGTResponse = objectMapper.readValue(data, OfferDGTResponse.class);
            LogUtils.info("[BpmService] receiveMessageCreateOffer offerDGTResponse", offerDGTResponse);
            OfferDGTDetailResponse offerDGTDetailResponse = modelMapper.map(offerDGTResponse.getMessage(), OfferDGTDetailResponse.class);
            LogUtils.info("[BpmService] receiveMessageCreateOffer offerDGTDetailResponse", offerDGTDetailResponse);
            if(StringUtils.isNullOrEmpty(offerDGTResponse.getRequestId()))
                return;
            PreOffer preOffer = this.getOfferByRequestId(offerDGTResponse.getRequestId());
            preOffer.setOfferDGTResponse(CommonUtils.toJsonString(offerDGTResponse));
            preOffer.setOfferDGTDetailResponse(CommonUtils.toJsonString(offerDGTDetailResponse));
            preOffer.setReason(offerDGTDetailResponse.getReturnMes());
            preOffer.setReasonCode(offerDGTDetailResponse.getReturnCode());
            if (!CollectionUtils.isEmpty(offerDGTDetailResponse.getOffers())) {
                preOffer.setOfferId(offerDGTDetailResponse.getOffers().get(0).getId());
            }
            Date date = new Date();
            preOffer.setUpdatedDate(date);
            if (Constants.PASS.equalsIgnoreCase(offerDGTResponse.getStatus())) {
                preOffer.setStatus(OfferState.OFFER_PASSED.getValue());
            } else {
                preOffer.setStatus(OfferState.OFFER_FAILED.getValue());
                if(ReasonAbort.FAIL_CALL_TELCO.getCode().equalsIgnoreCase(offerDGTDetailResponse.getReturnMes())) mcPortalService.sendLeadToMcPortal(offerDGTResponse, preOffer.getPartnerCode());
            }
            this.upsertOffer(preOffer);

        } catch (Exception e) {
            LogUtils.info("[BpmService] receiveMessageCreateOffer exception", e.getMessage());
        }

    }
    private PreOffer getOfferByRequestId(String requestId){
        return preOfferRepository.findPreOfferByRequestId(requestId);
    }
    private void upsertOffer(PreOffer preOffer){
        if (preOffer != null) preOfferRepository.save(preOffer);
    }
    /**
     * @param data dữ liệu đầu vào
     */
    @Override
    public void sendGetOfferToKafka(String data) {
        try {
            taskExecutor.execute(new LoanRunnable(Constants.SEND_CREATE_OFFER, data, this));
        } catch (Exception e) {
            LogUtils.error("[BpmService] sendGetOfferToKafka", e.getMessage());
        }
    }

    @Override
    public void sendCreateCaseToKafka(String data) {
        try {
            taskExecutor.execute(new LoanRunnable(Constants.SEND_CREATE_CASE, data, this));
        } catch (Exception e) {
            LogUtils.error("[BpmService] sendCreateCaseToKafka", e.getMessage());
        }
    }

    /**
     * Đẩy file lên ECM từ đường dẫn file trên s3 và lưu thông tin vào ekyc_model
     *
     * @param ekycModel dữ liệu đầu vào
     */
    private String[] uploadFileToEcm(EkycModel ekycModel) {
        String[] images = {};
        try {
            String strFormatPath = "%s%s%s";
            String strVoiceFormatPath = "%s.%s.%s.%s";
            String strFileExtension = ".jpg";
            String strVoiceExtension = ".wav";
            String frontName = String.format(strFormatPath, Constants.PREFIX_FRONT, UUID.randomUUID(), strFileExtension);
            String backName = String.format(strFormatPath, Constants.PREFIX_BACK, UUID.randomUUID(), strFileExtension);
            String selfieName = String.format(strFormatPath, Constants.PREFIX_SELFIE, UUID.randomUUID(), strFileExtension);
            String voiceCaptchaName = String.format(strVoiceFormatPath, ekycModel.getIdNumber(), DateUtils.dateTime(), UUID.randomUUID(), strVoiceExtension);

            String uuidFront = ekycModel.getFrontImageEcmURL();
            if (uuidFront == null) {
                uuidFront = ecmService.upload(ekycModel.getIdNumber(), DocumentType.CUSTOMER_RECORDS, ekycModel.getFrontImageURL(), frontName);

            }
            String uuidBack = ekycModel.getBackImageEcmURL();
            if (uuidBack == null) {
                uuidBack = ecmService.upload(ekycModel.getIdNumber(), DocumentType.CUSTOMER_RECORDS, ekycModel.getBackImageURL(), backName);
            }
            String uuidSelfie = ekycModel.getSelfieImageEcmURL();
            if (uuidSelfie == null) {
                uuidSelfie = ecmService.upload(ekycModel.getIdNumber(), DocumentType.CUSTOMER_RECORDS, ekycModel.getSelfieImageURL(), backName);
            }
            String uuidVoiceCaptcha = ekycModel.getVoiceCaptchaEcmURL();
            if (uuidVoiceCaptcha == null && StringUtils.isNotBlank(ekycModel.getVoiceCaptchaURL()))  {
                uuidVoiceCaptcha = ecmService.upload(ekycModel.getIdNumber(), DocumentType.CUSTOMER_RECORDS, ekycModel.getVoiceCaptchaURL(), voiceCaptchaName);
            }
            if (StringUtils.isBlank(uuidFront) || StringUtils.isBlank(uuidBack)
                    || StringUtils.isBlank(uuidSelfie)) {
                LogUtils.error("[BpmService] uploadFileToEcm error");
                throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
            }
            ekycModel.setFrontImageEcmURL(uuidFront);
            ekycModel.setBackImageEcmURL(uuidBack);
            ekycModel.setSelfieImageEcmURL(uuidSelfie);
            ekycModel.setVoiceCaptchaEcmURL(uuidVoiceCaptcha);
            images = new String[]{frontName, backName, selfieName, voiceCaptchaName};
        } catch (Exception e) {
            LogUtils.error("[BpmService] uploadFileToEcm error", e.getMessage());
        }
        return images;
    }

    /**
     * Thực hiện đẩy uid/vector của ảnh mặt trước cccd và mặt selfie lên image-search-service
     *
     * @param ekycModel dữ liệu đầu vào
     */
    private Map<String, Object> callAddVectors(EkycModel ekycModel) {
        Map<String, Object> map = new HashMap<>();
        try {
            addVectorTaskExecutor.execute(() -> {
                FaceMatchRaw faceMatchRaw = faceMatchRawRepository.findByOcrRequestId(ekycModel.getObjectId());
                if (faceMatchRaw != null) {
                    String db = "front";
                    String vec = faceMatchRaw.getVec1();
                    String uid = ekycModel.getFrontImageEcmURL();
                    AddVectorRequest addVectorRequest = imageSearchService.buildAddVectorRequest(db, vec, uid);
                    map.put(db, imageSearchService.addVector(addVectorRequest));
                    db = "selfie";
                    vec = faceMatchRaw.getVec2();
                    uid = ekycModel.getSelfieImageEcmURL();
                    addVectorRequest = imageSearchService.buildAddVectorRequest(db, vec, uid);
                    map.put(db, imageSearchService.addVector(addVectorRequest));
                }
                LogUtils.error("[BpmService] callAddVectors response map");
            });
        } catch (Exception e) {
            LogUtils.error("[BpmService] callAddVectors error", e.getMessage());
        }
        return map;
    }

    @Override
    public void receiveMessageFromEContract(String data) {
        Gson gson = new Gson();
        final var dto = gson.fromJson(data, NotificationEContractReqDTO.class);
        String contractNumber = dto.getContractCode();
        CreateLoan createLoan = createLoanRepository.findByContractNumber(contractNumber);
        if (createLoan != null) {
            createLoan.setCompleteDate(dto.getSignContractDate());
            createLoan.setSignDate(dto.getSignContractDate());
            createLoan.setContractStatus(Constants.SIGN_COMPLETED);
            createLoan.setUserSign(dto.getSignUser());
            createLoan.setCaseNumber(dto.getLoansProfileId());
            createLoan.setStatus(Constants.SIGN_COMPLETED);
            createLoan.setUpdatedDate(new Date());
            createLoanRepository.save(createLoan);
        }
        NotificationEContract notificationEContract = new NotificationEContract();
        notificationEContract.setContractNumber(dto.getContractCode());
        notificationEContract.setSignDate(dto.getSignContractDate());
        notificationEContract.setUserSign(dto.getSignUser());
        this.saveNotificationEContract(notificationEContract);
    }

    private void saveNotificationEContract(NotificationEContract notify) {
        try {
            notificationEContractRepository.save(notify);
        } catch (Exception e) {
            LogUtils.error("[BpmService] saveNotificationEContract", e.getMessage());
        }
    }
    private CompleteCaseDTO buildCompleteCaseDTO(EkycModel ekycModel, CreateLoan createLoan){

        String caseNumber = createLoan.getCaseNumber();
        String contractNumber = createLoan.getContractNumber();
        CompleteCaseDTO completeCaseDTO = new CompleteCaseDTO();
        completeCaseDTO.setLoansProfileId(caseNumber);
        List<LoansFileUploadRequest> fileUploadDTOS = new ArrayList<>();
        String strFormatPath = "%s_%s_%s";
        String fileNameCCCD = "CCCD.pdf";
        String fileNameHAKH = "HINH_ANH_KHACH_HANG.pdf";
        String fileType = ".pdf";
        String frontName = String.format(strFormatPath, caseNumber, contractNumber, fileNameCCCD);
        String selfieName = String.format(strFormatPath, caseNumber, contractNumber, fileNameHAKH);
        // hinh anh CCCD
        LoansFileUploadRequest fileUploadRequest = new LoansFileUploadRequest();
        fileUploadRequest.setLoansProfileId(caseNumber);
        fileUploadRequest.setName(frontName);
        fileUploadRequest.setUrl(ekycModel.getFrontImageEcmURL());
        fileUploadRequest.setType(Constants.FUEC1);
        fileUploadRequest.setSourceUpload(Constants.DIGITAL);
        fileUploadRequest.setFileType(fileType);
        fileUploadDTOS.add(fileUploadRequest);
        // hinh anh khach hang
        fileUploadRequest = new LoansFileUploadRequest();
        fileUploadRequest.setLoansProfileId(caseNumber);
        fileUploadRequest.setSourceUpload(Constants.DIGITAL);
        fileUploadRequest.setName(selfieName);
        fileUploadRequest.setUrl(ekycModel.getSelfieImageEcmURL());
        fileUploadRequest.setType(Constants.FUEC2);
        fileUploadRequest.setFileType(fileType);
        fileUploadDTOS.add(fileUploadRequest);
        completeCaseDTO.setFileUploadDTOS(fileUploadDTOS);
        return completeCaseDTO;
    }
    public CompleteCaseResponse completeCase(String loansProfileId, String contractNumber){
        String username = JWTUtils.getUsername();
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(username);
        CreateLoan createLoan = createLoanRepository.findByUserNameAndCaseNumberAndContractNumber(username, loansProfileId, contractNumber);
        CompleteCaseDTO completeCaseDTO = this.buildCompleteCaseDTO(ekycModel, createLoan);
        CompleteCaseResponse response;
        try {
            response = bpmProxy.completeCase(completeCaseDTO);
            LogUtils.info("[BpmService] completeCase response", response);
        } catch (HttpStatusCodeException e){
            LogUtils.error("[BpmService] completeCase exception", e.getResponseBodyAsString());
            throw new ApplicationException(Constants.ERROR_400_BAD, "Hệ thống đang xử lý.");
        }
        if (!Constants.SUCCESS_CODE_0.equalsIgnoreCase(response.getErrorCode())){
            throw new ApplicationException(response.getErrorCode(), "Hệ thống đang xử lý.");
        }
        LogUtils.info("[BpmService] completeCase successful");
        createLoan.setStatus(Constants.SIGN_COMPLETED);
        createLoanRepository.save(createLoan);
        return response;
    }
    @Override
    public CustomerResponseInfo customerCheckInfo(CustomerRequestDTO dto){
        return bpmProxy.customerCheckInfo(dto);
    }
    @Override
    public String checkAccMBInfo(String accountNumber){
        MBAccountQueryReq queryReq = new MBAccountQueryReq();
        QueryMBAccountStatusRequest statusRequest = new QueryMBAccountStatusRequest();
        statusRequest.setAccountNumber(accountNumber);
        queryReq.setQueryMBAccountStatusRequest(statusRequest);
        MBAccountQueryRes res = bpmProxy.getMBAccountInfo(queryReq);
        LogUtils.info("ơBPMService] checkAccMBInfo getMBAccountInfo res");
        if (res == null || res.getQueryMBAccountStatus() == null) {
            throw new ApplicationException(Error.ACCOUNT_NUMBER_INVALID.getCode(), Error.ACCOUNT_NUMBER_INVALID.getMessage());
        }
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(JWTUtils.getUsername());
        this.validateAccountMB(ekycModel, res);

        this.validateMBAccountLV3(res.getQueryMBAccountStatus().getIdCardNumber(), res.getQueryMBAccountStatus().getAccountName());
        return res.getQueryMBAccountStatus().getAccountName();
    }
    private void validateAccountMB(EkycModel ekycModel, MBAccountQueryRes res){
        String idNumber = ekycModel.getIdNumber();
        String idNumberOld = ekycModel.getIdNumberOld();
        String idCardNumber = res.getQueryMBAccountStatus().getIdCardNumber();
        String accountName = res.getQueryMBAccountStatus().getAccountName();
        LogUtils.info("[BpmService] validateAccountMB res accountName", accountName);
        String name = VNCharacterUtils.removeAccentV2(ekycModel.getName());
        if(!name.equalsIgnoreCase(accountName) || StringUtils.isNullOrEmpty(idCardNumber) ||
                !(idCardNumber.equalsIgnoreCase(idNumber) || idCardNumber.equalsIgnoreCase(idNumberOld))){
            throw new ApplicationException(Error.ACCOUNT_NUMBER_INVALID.getCode(), Error.ACCOUNT_NUMBER_INVALID.getMessage());
        }
    }

    @Override
    public CheckAccountResponse checkMBAccount(MbAccountDTO dto){
        return bpmProxy.checkMBAccount(dto);
    }
    @Override
    public MBAccountQueryRes getMBAccountInfo(MBAccountQueryReq dto){
        MBAccountQueryRes res = bpmProxy.getMBAccountInfo(dto);
        QueryMBAccountStatus status = res.getQueryMBAccountStatus();
        status.setIdCardNumber(null);
        res.setQueryMBAccountStatus(status);
        return res;
    }
    private void validateCardNumberMB(String accountNumber, EkycModel ekycModel){
        if (EPartnerCode.MB_BANK.getValue().equalsIgnoreCase(JWTUtils.getPartnerCode())) {
            MBAccountQueryReq req = new MBAccountQueryReq();
            QueryMBAccountStatusRequest statusReq = new QueryMBAccountStatusRequest();
            statusReq.setAccountNumber(accountNumber);
            req.setQueryMBAccountStatusRequest(statusReq);
            MBAccountQueryRes res = bpmProxy.getMBAccountInfo(req);
            this.validateAccountMB(ekycModel, res);
            this.validateMBAccountLV3(res.getQueryMBAccountStatus().getIdCardNumber(), res.getQueryMBAccountStatus().getAccountName());
        }
    }
    private CustomerRequestDTO buildCustomerCheckInfoRequest(String idCardNumber, String accountName){
        CustomerRequestDTO dto = new CustomerRequestDTO();
        dto.setPersonId(idCardNumber);
        dto.setCustomerName(accountName);
        dto.setPhoneNumber(JWTUtils.getUsername());
        return dto;
    }
    private void validateMBAccountLV3(String idCardNumber, String accountName){
        List<String> noneLV3 = Arrays.asList("1917", "1911", "1918");
        CustomerResponseInfo responseInfo = bpmProxy.customerCheckInfo(this.buildCustomerCheckInfoRequest(idCardNumber, accountName));
        if (responseInfo == null || responseInfo.getData() == null){
            throw new ApplicationException(Error.ERROR_CHECK_LV3.getCode(), Error.ERROR_CHECK_LV3.getMessage());
        }
        if(noneLV3.contains(responseInfo.getData().getCustomerSector())){
            throw new ApplicationException(Error.ACCOUNT_NONE_LV3.getCode(), Error.ACCOUNT_NONE_LV3.getMessage());
        }
    }
    private void validateSearchOption(String custProfessional, String maritalStatus, String incomeRange){
        if (EPartnerCode.MB_BANK.getValue().equalsIgnoreCase(JWTUtils.getPartnerCode())) {
            List<SearchOptionData> response = Arrays.asList(bpmProxy.searchOption(new OptionDTO()));
            if (response == null || response.isEmpty())
                throw new ApplicationException(Error.SYSTEM_ERROR.getCode(), Error.SYSTEM_ERROR.getMessage());
            boolean exists = response.stream().anyMatch(r -> custProfessional.equalsIgnoreCase(r.getCode()));
            if (!exists) {
                throw new ApplicationException(Error.ERROR_CUST_PROCESSIONAL_INVALID.getCode(), Error.ERROR_CUST_PROCESSIONAL_INVALID.getMessage());
            }
            exists = response.stream().anyMatch(r -> maritalStatus.equalsIgnoreCase(r.getCode()));
            if (!exists) {
                throw new ApplicationException(Error.ERROR_MARITAL_STATUS_INVALID.getCode(), Error.ERROR_MARITAL_STATUS_INVALID.getMessage());
            }
            exists = response.stream().anyMatch(r -> incomeRange.equalsIgnoreCase(r.getCode()));
            if (!exists) {
                throw new ApplicationException(Error.ERROR_INCOME_RANGE_INVALID.getCode(), Error.ERROR_INCOME_RANGE_INVALID.getMessage());
            }
        }
    }

    public Object searchOption(OptionDTO dto){
        return bpmProxy.searchOption(dto);
    }

    @Override
    public MatrixResponse disbursementMatrix(BigInteger offerId) {
        MatrixDisbursementRequest request = this.buildMatrixDisbursementRequest(offerId);
        return bpmProxy.disbursement(request);
    }

    @Override
    public DigitalLendingResponse checkAccountDisbursement(CheckAccountDisbursementRequestDTO checkAccountDisbursementRequestDTO) {
        CheckAccountDisbursementResponse accountDisbursementResponse = getCheckAccountDisbursementResponse(checkAccountDisbursementRequestDTO);
        if(!Constants.PASS.equalsIgnoreCase(accountDisbursementResponse.getData().getResult())) {
            if(Error.FAIL_ACCBANK_INVALID.getCode().equalsIgnoreCase(accountDisbursementResponse.getData().getErrorCode())) {
                this.updateLoanRequest(Error.FAIL_ACCBANK_INVALID.getCode(), Error.FAIL_ACCBANK_INVALID.getMessage(), JWTUtils.getUsername());
            }
            if(Error.FAIL_ACCBANK_INFO.getCode().equalsIgnoreCase(accountDisbursementResponse.getData().getErrorCode())) {
                this.updateLoanRequest(Error.FAIL_ACCBANK_INFO.getCode(), Error.FAIL_ACCBANK_INFO.getMessage(), JWTUtils.getUsername());
            }
            if(Error.FAIL_ACCBANK_LEVEL3.getCode().equalsIgnoreCase(accountDisbursementResponse.getData().getErrorCode())) {
                this.updateLoanRequest(Error.FAIL_ACCBANK_LEVEL3.getCode(), Error.FAIL_ACCBANK_LEVEL3.getMessage(), JWTUtils.getUsername());
            }
            return DigitalLendingResponse.builder()
                    .code(Constants.FAILED).status(Constants.FAILED_MESSAGE).data(accountDisbursementResponse).build();
        }
        return DigitalLendingResponse.builder()
                .code(Constants.SUCCESS_CODE).status(Constants.SUCCESS_MESSAGE).data(accountDisbursementResponse).build();
    }

    private CheckAccountDisbursementResponse getCheckAccountDisbursementResponse(CheckAccountDisbursementRequestDTO checkAccountDisbursementRequestDTO) {
        String username = JWTUtils.getUsername();
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(username);
        checkAccountDisbursementRequestDTO.setPhoneNumber(username);
        if(StringUtils.isNullOrEmpty(checkAccountDisbursementRequestDTO.getSmlCode())) {
            checkAccountDisbursementRequestDTO.setSmlCode(Constants.SML_CODE_MB);
        }
        checkAccountDisbursementRequestDTO.setFullName(ekycModel.getName());
        checkAccountDisbursementRequestDTO.setIdNumber(ekycModel.getIdNumber());
        checkAccountDisbursementRequestDTO.setIdNumberOld(ekycModel.getIdNumberOld());
        return bpmProxy.checkAccountDisbursement(checkAccountDisbursementRequestDTO);
    }

    @Override
    public BpmCheckDeviceResponse checkLoanDevice(BpmCheckDeviceReq req) {
        return bpmProxy.bpmCheckDeviceId(req);
    }

    @Override
    public void updateLoanRequest(String reasonCode, String reasonDetail, String username) {
        try {
            updateLoanRequestExecutor.execute(() -> bpmProxy.updateLoanRequest(this.buildDataUpdateLoanRequest(reasonCode, reasonDetail, username)));
        }catch (Exception e) {
            LogUtils.error("[BPMService] updateLoanRequest ex:", e.getMessage());
        }
    }

    private UpdateLoanRequestDTO buildDataUpdateLoanRequest(String reasonCode, String reasonDetail, String username) {
        PreOffer offer = preOfferRepository.getPreOfferByUserName(username);
        UpdateLoanRequestDTO requestDTO = new UpdateLoanRequestDTO();
        requestDTO.setRequestId(offer.getRequestId());
        requestDTO.setReferId(offer.getReferId());
        requestDTO.setReasonReject(reasonCode);
        requestDTO.setReasonRejectDetail(reasonDetail);
        requestDTO.setChannel(Constants.CHANNEL);
        return requestDTO;
    }

    private MatrixDisbursementRequest buildMatrixDisbursementRequest(BigInteger offerId){
        MatrixDisbursementRequest request = new MatrixDisbursementRequest();
        String username = JWTUtils.getUsername();
        EkycModel ekycModel = ekycModelService.findEkycModelByUsername(username);
        LogUtils.info("buildMatrixDisbursementRequest ", ekycModel.getIsEkyc());
        request.setDisbursementRequest(this.buildDisbursementRequest(ekycModel, username, offerId));
        return request;
    }

    private DisbursementRequest buildDisbursementRequest(EkycModel ekycModel, String username, BigInteger offerId) {
        DisbursementRequest disbursementRequest = new DisbursementRequest();
        if(ekycModel.getInternalIdC3() == null || ekycModel.getImageSearchOneFaceMultiIdC62() == null
                || ekycModel.getImageSearchOneIdMultiFaceC5() == null || ekycModel.getOfflineIdC4() == null ) {
            String requestId = ekycModel.getObjectId();
            this.addDataForDisbursementRequest(ekycModel, username, requestId);

        }
        disbursementRequest.setInternalId(ekycModel.getInternalIdC3());
        disbursementRequest.setImageSearchOneFaceMultiId(ekycModel.getImageSearchOneFaceMultiIdC62());
        disbursementRequest.setImageSearchOneIdMultiFace(ekycModel.getImageSearchOneIdMultiFaceC5());
        disbursementRequest.setOfflineId(ekycModel.getOfflineIdC4());
        disbursementRequest.setOfflineMobile(this.getOfflineMobile(username, offerId));
        return disbursementRequest;
    }

    private void addDataForDisbursementRequest(EkycModel ekycModel, String username, String requestId) {
        IdInternalCheck idInternalCheck = idInternalCheckRepository.findIdInternalCheckByRequestIdAndUsername(requestId, username);
        try{
            CheckDupMcResponse checkDupMcResponse = Utils.fromJson(idInternalCheck.getCheckDupMcResult(), CheckDupMcResponse.class);
            if(checkDupMcResponse != null && checkDupMcResponse.getCodeStatuses() != null ) {
                ekycModel.setInternalIdC3(Utils.getResultByRule(checkDupMcResponse.getCodeStatuses(), Constants.RULE_C3));
                ekycModel.setOfflineIdC4(Utils.getResultByRule(checkDupMcResponse.getCodeStatuses(), Constants.RULE_C4));
            }
        } catch (Exception e) {
            LogUtils.error("Can't parse Json to CheckDupMcResponse: addDataForDisbursementRequest");
            ekycModel.setInternalIdC3(Constants.EMPTY);
            ekycModel.setOfflineIdC4(Constants.EMPTY);
        }

        setImageSearchOneFaceMutilId(ekycModel, requestId);
        setImageSearchOneIdMultiFace(ekycModel, requestId);
    }

    private void setImageSearchOneIdMultiFace(EkycModel ekycModel, String requestId) {
        IdsFace idsFace = idsFaceRepository.findByOcrRequestId(requestId);
        if(idsFace != null) {
            if(Boolean.TRUE.equals(idsFace.getImageSearchByIdCheckResult())) {
                if(StringUtils.isNotBlank(idsFace.getImageSearchByIdCheckDetails())) ekycModel.setImageSearchOneIdMultiFaceC5(Constants.YES);
                else ekycModel.setImageSearchOneIdMultiFaceC5(Constants.NA);
            }
        }else {
            ekycModel.setImageSearchOneIdMultiFaceC5(Constants.EMPTY);
        }
    }

    private void setImageSearchOneFaceMutilId(EkycModel ekycModel, String requestId) {
        FaceIds faceIds = faceIdsRepository.findByOcrRequestId(requestId);
        if(faceIds != null) {
            if(Boolean.TRUE.equals(faceIds.getImageSearchByIdCheckResult())) {
                if(StringUtils.isNotBlank(faceIds.getImageIdInfoDetails())) ekycModel.setImageSearchOneFaceMultiIdC62(Constants.YES);
                else ekycModel.setImageSearchOneFaceMultiIdC62(Constants.NA);
            }
        }else {
            ekycModel.setImageSearchOneFaceMultiIdC62(Constants.EMPTY);
        }
    }

    private String getOfflineMobile(String username,BigInteger offerId) {
        try {
            PreOffer offer = preOfferRepository.findByOfferIdAndUsername(offerId, username);
            OfferDGTDetailResponse offerDGTDetailResponse = objectMapper.readValue(offer.getOfferDGTDetailResponse(), OfferDGTDetailResponse.class);
            if(offerDGTDetailResponse == null || offerDGTDetailResponse.getCodeStatus() == null) {
                return Constants.EMPTY;
            }
            return this.getResultByRule(offerDGTDetailResponse.getCodeStatus(), Constants.RULE_C10_1);
        } catch (Exception e) {
            return Constants.EMPTY;
        }
    }
    public CheckAccountMBResponse checkAccountMB(CheckAccountMBRequest request){
        return null;
    }

    private void checkCustomerRelative(List<CustomerRelativesRequest> customerRelativesRequestList, String maritalStatus) {
        List<CustomerRelativesRequest> relatives = customerRelativesRequestList.stream().filter(c -> RelativeTypeEnum.RELATIVES.name().equalsIgnoreCase(c.getType())).collect(Collectors.toList());
        List<CustomerRelativesRequest> referencePerson = customerRelativesRequestList.stream().filter(c -> RelativeTypeEnum.REFERENCE_PERSON.name().equalsIgnoreCase(c.getType())).collect(Collectors.toList());

        if(!referencePerson.isEmpty()) {
            // Validate số người tham chiếu (< 2 báo lỗi)
            this.validDateReferencePerson(customerRelativesRequestList, maritalStatus, referencePerson);
        } else {
            // validate người hôn phối nếu maritalStatus = MARI02 thì cần có thông tin người hôn phối
            this.validateRelativesPerson(customerRelativesRequestList, maritalStatus, relatives);
        }
        this.validateInfoRelative(customerRelativesRequestList);
    }

    private void validateRelativesPerson(List<CustomerRelativesRequest> customerRelativesRequestList, String maritalStatus, List<CustomerRelativesRequest> relatives) {
        if (Constants.MARI02.equalsIgnoreCase(maritalStatus)){
            // Validate số người tham chiếu là người thân
            if (relatives.size() != 1){
                throw new ApplicationException(Error.ERROR_RELATIVES_PERSON.getCode(),
                        Error.ERROR_RELATIVES_PERSON.getMessage());
            }
            List<CustomerRelativesRequest> spouseCustomerRelatives = customerRelativesRequestList.stream().filter(c -> RelativeTypeEnum.SPOUSE.name().equalsIgnoreCase(c.getType())).collect(Collectors.toList());
            if (spouseCustomerRelatives.isEmpty()){
                throw new ApplicationException(Error.ERROR_RELATIVE_INFO_EMPTY.getCode(),
                        Error.ERROR_RELATIVE_INFO_EMPTY.getMessage());
            }
        } else {
            if (relatives.size() != 2){
                throw new ApplicationException(Error.ERROR_RELATIVES_PERSON.getCode(),
                        Error.ERROR_RELATIVES_PERSON.getMessage());
            }
        }
    }

    private void validDateReferencePerson(List<CustomerRelativesRequest> customerRelativesRequestList, String maritalStatus, List<CustomerRelativesRequest> referencePerson) {
        if (referencePerson.size() < 2){
            throw new ApplicationException(Error.ERROR_MIN_RELATIVE_REFERENCE_PERSON.getCode(),
                    Error.ERROR_MIN_RELATIVE_REFERENCE_PERSON.getMessage());
        }
        // validate người hôn phối nếu maritalStatus = MARI02 thì cần có thông tin người hôn phối
        if (Constants.MARI02.equalsIgnoreCase(maritalStatus)){
            List<CustomerRelativesRequest> spouseCustomerRelatives = customerRelativesRequestList.stream().filter(c -> RelativeTypeEnum.SPOUSE.name().equalsIgnoreCase(c.getType())).collect(Collectors.toList());
            if (spouseCustomerRelatives.isEmpty()){
                throw new ApplicationException(Error.ERROR_RELATIVE_INFO_EMPTY.getCode(),
                        Error.ERROR_RELATIVE_INFO_EMPTY.getMessage());
            }
        }
    }

    private void validateInfoRelative(List<CustomerRelativesRequest> customerRelativesRequestList) {
        String phone = null;
        // Validate người tham chiếu/người hôn phối
        for(CustomerRelativesRequest customerRelative : customerRelativesRequestList) {
            String type = customerRelative.getType();
            String name = customerRelative.getRelativesName();
            String idNumber = customerRelative.getRelativesIdNumber();
            Integer relative = customerRelative.getNumberRelative();
            this.validatePhoneRelativeSamePhoneUser(customerRelative);
            this.validatePhoneRelativeAreTheSame(phone, customerRelative);
            phone = customerRelative.getRelativesPhone();
            // validate tên người hôn phối (không được để trống)
            if (RelativeTypeEnum.SPOUSE.name().equalsIgnoreCase(type)
                    && (StringUtils.isNullOrEmpty(name)
                    || StringUtils.isNullOrEmpty(idNumber)
                    || StringUtils.isNullOrEmpty(phone))){
                throw new ApplicationException(Error.ERROR_RELATIVE_INFO_EMPTY.getCode(),
                    this.buildErrorMessageCheckCustomerRelative(relative, Error.ERROR_RELATIVE_INFO_EMPTY, type));
            }

            // Validate SDT người tham chiếu/người hôn phối
            if(Boolean.FALSE.equals(UserNameUtils.isValid(phone))) {
                throw new ApplicationException(Error.ERROR_RELATIVE_PHONE_NUMBER_FORMAT.getCode(),
                    this.buildErrorMessageCheckCustomerRelative(relative, Error.ERROR_RELATIVE_PHONE_NUMBER_FORMAT, type));
            }
            LogUtils.info(RelativeTypeEnum.SPOUSE.name(), type);
            // validate số CCCD người hôn phối đúng định dạng (9 hoặc 12 số)

            if (RelativeTypeEnum.SPOUSE.name().equalsIgnoreCase(type) && !Utils.isCmndOrCccd(idNumber)){
                throw new ApplicationException(Error.ERROR_RELATIVE_ID_NUMBER_FORMAT.getCode(),
                    this.buildErrorMessageCheckCustomerRelative(relative, Error.ERROR_RELATIVE_ID_NUMBER_FORMAT, type));
            }
        }
    }

    private void validatePhoneRelativeAreTheSame(String phone, CustomerRelativesRequest customerRelative) {
        if (StringUtils.isNotBlank(phone) && StringUtils.isNotBlank(customerRelative.getRelativesPhone()) && customerRelative.getRelativesPhone().equals(phone)) {
            throw new ApplicationException(Error.ERROR_RELATIVE_PHONE_ARE_THE_SAME_USER.getCode(),
                Error.ERROR_RELATIVE_PHONE_ARE_THE_SAME_USER.getMessage());
        }
    }

    private void validatePhoneRelativeSamePhoneUser(CustomerRelativesRequest customerRelative) {
        if (JWTUtils.getUsername().equals(customerRelative.getRelativesPhone())) {
            throw new ApplicationException(Error.ERROR_RELATIVE_PHONE_THE_SAME_USER.getCode(),
                Error.ERROR_RELATIVE_PHONE_THE_SAME_USER.getMessage());
        }
    }


    /**
     * Kiểm tra trùng số điện thoại trong ds người tham chiếu/người hôn phối và trùng số CCCD với số điện thoại đăng nhập
     * @param customerRelativesRequest
     * @param phones
     * @param idNumberUser
     * @param idNumberOldUser
     */
    public void validateDuplicatePhone(CustomerRelativesRequest customerRelativesRequest, Set<String> phones, String idNumberUser, String idNumberOldUser){

            if (StringUtils.isNotBlank(customerRelativesRequest.getRelativesPhone()) && phones.contains(customerRelativesRequest.getRelativesPhone())) {
                throw new ApplicationException(Error.ERROR_RELATIVE_PHONE_DUPLICATE.getCode(),Error.ERROR_RELATIVE_PHONE_DUPLICATE.getMessage());
            }
            if (phones.contains(JWTUtils.getUsername())){
                throw new ApplicationException(Error.ERROR_RELATIVE_PHONE_DUPLICATE_WITH_USER.getCode(),Error.ERROR_RELATIVE_PHONE_DUPLICATE_WITH_USER.getMessage());
            }
            phones.add(customerRelativesRequest.getRelativesPhone());
            if (idNumberUser.equals(customerRelativesRequest.getRelativesIdNumber()) || customerRelativesRequest.getRelativesIdNumber().equals(idNumberOldUser)) {
                throw new ApplicationException(Error.ERROR_RELATIVE_ID_NUMBER_DUPLICATE_WITH_USER.getCode(),Error.ERROR_RELATIVE_ID_NUMBER_DUPLICATE_WITH_USER.getMessage());
            }

    }
    private String buildErrorMessageCheckCustomerRelative(Integer numberRelative, Error error, String type ) {
        if(RelativeTypeEnum.SPOUSE.name().equals(type)) {
            return String.format(error.getMessage(), RelativeTypeEnum.SPOUSE.getValue(), "");
        }
        return String.format(error.getMessage(), RelativeTypeEnum.REFERENCE_PERSON.getValue(), numberRelative + " ");
    }

    private String getResultByRule(List<CodeStatus> codeStatuses, String rule) {
        for(CodeStatus status : codeStatuses) {
            if(rule.equalsIgnoreCase(status.getRule())) {
                return status.getResult();

            }
        }
        return Constants.EMPTY;
    }
    // Kiểm tra deviceId đã được sử dụng tạo case với 1 user chưa
    private void checkDeviceOffer(String requestId, PreCheck preCheck) {
        String deviceId = JWTUtils.getDeviceId();
        String username = JWTUtils.getUsername();
        LogUtils.info("[BPMService] checkDeviceOffer: ", username);
        LogUtils.info("[BPMService] checkDeviceOffer: deviceId ", deviceId);

        BpmCheckDeviceReq req = BpmCheckDeviceReq.builder().deviceId(deviceId).numberPhone(username).requestId(requestId).build();
        try {
            BpmCheckDeviceResponse response = bpmProxy.bpmCheckDeviceId(req);
            LogUtils.info("[BPMService] checkDeviceOffer: BpmCheckDeviceResponse ", response);
            if(response.getData() != null && !Constants.PASS.equalsIgnoreCase(response.getData().getResult())) {
                preCheck.setStatus(response.getData().getResult());
                preCheck.setMessage(this.buildErrorCheckDeviceMessage(response.getData().getNumberPhone()));
                preCheck.setErrorCode(Error.FAIL_DEVICEID.getCode());
                String partnerCode = JWTUtils.getPartnerCode();
                if(StringUtils.isNotBlank(partnerCode))
                    preCheck.setPartnerCode(partnerCode);
                preCheckRepository.save(preCheck);
                throw new ApplicationException(Error.FAIL_DEVICEID.getCode(), this.buildErrorCheckDeviceMessage(response.getData().getNumberPhone()));
            }
        } catch (HttpStatusCodeException e){
            LogUtils.info("[BPMService] checkDeviceOffer ex : " + e.getMessage());
            preCheck.setStatus(Constants.FAILED_MESSAGE);
            preCheck.setMessage(e.getStatusText());
            preCheck.setErrorCode(e.getStatusCode().name());
            preCheckRepository.save(preCheck);
            throw new ApplicationException(Error.FAIL_DEVICEID.getCode(), Constants.EXCEPTION_MES);
        }
    }
    private void validateCustomerAddresses(List<CustomerAddressRequest> customerAddressRequests){
        // validate thông tin địa chỉ tạm trú (ADDRESS_LIVE)
        List<CustomerAddressRequest> addressLive = customerAddressRequests.stream()
                .filter(a -> CustomerAddressType.ADDRESS_LIVE.name().equalsIgnoreCase(a.getType())).collect(Collectors.toList());
        LogUtils.info("addressLive", addressLive);
        this.validateCustomerAddresses(addressLive, Error.CUSTOMER_ADDRESS_LIVE_MISS);
        // validate thông tin địa chỉ bao địa chỉ thường trú (ADDRESS_PERMANENT)
        List<CustomerAddressRequest> addressPermanent = customerAddressRequests.stream()
                .filter(a -> CustomerAddressType.ADDRESS_PERMANENT.name().equalsIgnoreCase(a.getType())).collect(Collectors.toList());
        LogUtils.info("addressPermanent", addressPermanent);
        this.validateCustomerAddresses(addressPermanent, Error.CUSTOMER_ADDRESS_PERMANENT_MISS);
    }
    private void validateCustomerAddresses(List<CustomerAddressRequest> addresses, Error error){
        if (addresses.isEmpty())
            throw new ApplicationException(error.getCode(), error.getMessage());
        CustomerAddressRequest address = addresses.get(0);
        if( StringUtils.isNullOrEmpty(address.getAddress())
                || StringUtils.isNullOrEmpty(address.getProvince()) || StringUtils.isNullOrEmpty(address.getProvinceName())
                || StringUtils.isNullOrEmpty(address.getDistrict()) || StringUtils.isNullOrEmpty(address.getDistrictName())
                || StringUtils.isNullOrEmpty(address.getWard()) || StringUtils.isNullOrEmpty(address.getWardName())) {
            throw new ApplicationException(error.getCode(), error.getMessage());
        }
    }

    private String buildErrorCheckDeviceMessage(String oldPhoneNumber) {
        int length = oldPhoneNumber.length();
        String phoneNumberTail = oldPhoneNumber.substring(length - 4);
        return String.format(Error.FAIL_DEVICEID.getMessage(), phoneNumberTail);
    }
    private void validateDisbursementType(CreateCaseRequestDTO createCaseRequestDTO) {
        if (Constants.DISBURSEMENT_TYPE_TT.equalsIgnoreCase(createCaseRequestDTO.getDisbursementType())
                && StringUtils.isNullOrEmpty(createCaseRequestDTO.getPayPartnerCode())){
            throw new ApplicationException(Constants.ERROR_400_BAD, "Vui lòng cung cấp đối tác thu hộ");
        }
        if (Constants.DISBURSEMENT_TYPE_FT.equalsIgnoreCase(createCaseRequestDTO.getDisbursementType())) {
            if (StringUtils.isNullOrEmpty(createCaseRequestDTO.getAccountNumber())){
                throw new ApplicationException(Constants.ERROR_400_BAD, "Vui lòng cung cấp số tài khoản");
            }
            if(StringUtils.isNullOrEmpty(createCaseRequestDTO.getAccountName())) {
                throw new ApplicationException(Constants.ERROR_400_BAD, "Vui lòng cung cấp tên tài khoản");
            }
        }
    }
    @Override
    public UserLinkResponse getContractInfo(ContractDTO contract){
        List<Object[]> objects = createLoanRepository.getContractInfo(contract.getUsername(), contract.getCitizenId(), contract.getContractCode());
        if (objects.isEmpty()){
            throw new ApplicationException(Constants.ERROR_400_BAD, "Truy vấn dữ liệu không thành công.");
        }
        UserLinkResponse response = this.parseContractInfo(objects);
        if (response == null || StringUtils.isBlank(response.getBackImageUrl())
                || StringUtils.isBlank(response.getFrontImageUrl())
                || StringUtils.isBlank(response.getSelfieImageUrl()))
            throw new ApplicationException(Constants.ERROR_400_BAD, "Truy vấn dữ liệu không thành công.");

        return response;
    }
    private UserLinkResponse parseContractInfo(List<Object[]> objects){
        try {
            JSONObject response = new JSONObject();
            Object[] data = objects.get(0);
            this.setAttributeContractInfo("username", response, data, 0);
            this.setAttributeContractInfo("citizenId", response, data, 1);
            this.setAttributeContractInfo("citizenIdOld", response, data, 2);
            this.setAttributeContractInfo("name", response, data, 3);
            this.setAttributeContractInfo("gender", response, data, 4);
            this.setAttributeContractInfo("dob", response, data, 5);
            this.setAttributeContractInfo("issuedDate", response, data, 6);
            this.setAttributeContractInfo("expiredDate", response, data, 7);
            this.setAttributeContractInfo("address", response, data, 8);
            this.setAttributeContractInfo("frontImageUrl", response, data, 9);
            this.setAttributeContractInfo("backImageUrl", response, data, 10);
            this.setAttributeContractInfo("selfieImageUrl", response, data, 11);
            this.setAttributeContractInfo("leftImageUrl", response, data, 12);
            this.setAttributeContractInfo("rightImageUrl", response, data, 13);
            this.setAttributeContractInfo("contractStatus", response, data, 14);
            this.setAttributeContractInfo("contractNumber", response, data, 15);
            this.setAttributeContractInfo("partnerCode", response, data, 16);
            return modelMapper.map(response, UserLinkResponse.class);
        } catch (Exception e){
            return null;
        }
    }
    private void setAttributeContractInfo(String key, JSONObject jsonObject, Object[] data, int i){
        if (data.length > i ){
            jsonObject.put(key, String.valueOf(data[i]));
        }

    }
}
