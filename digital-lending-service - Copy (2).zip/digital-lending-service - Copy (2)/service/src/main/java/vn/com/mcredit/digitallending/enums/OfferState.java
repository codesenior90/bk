package vn.com.mcredit.digitallending.enums;

public enum OfferState {
    OFFER_PROCESSING("offer_processing"),
    OFFER_PASSED("offer_passed"),
    OFFER_FAILED("offer_failed"),
    OFFER_TIMEOUT("offer_timeout"),
    OFFER_REJECT("offer_reject"),
    OFFER_IN_USE("offer_in_use"),
    LOAN_ABORT_15D("loan_abort_15d"),
    ;

    private String value;

    OfferState(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
