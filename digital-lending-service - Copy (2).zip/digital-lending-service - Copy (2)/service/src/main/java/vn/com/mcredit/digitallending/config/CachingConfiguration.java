package vn.com.mcredit.digitallending.config;

import lombok.RequiredArgsConstructor;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;

import java.time.Duration;

@Configuration
@RequiredArgsConstructor
public class CachingConfiguration extends CachingConfigurerSupport {
    public static final String DL_PARTNER_SERVICE_TOKEN_CACHE = "dlPartnerServiceTokenCache";
    private final RedisConnectionFactory redisConnectionFactory;

    @Bean
    @Override
    public CacheManager cacheManager() {
        return RedisCacheManager.RedisCacheManagerBuilder.fromConnectionFactory(redisConnectionFactory)
                .withCacheConfiguration(DL_PARTNER_SERVICE_TOKEN_CACHE, RedisCacheConfiguration
                        .defaultCacheConfig().entryTtl(Duration.ofMinutes(59))).build();
    }
}