package vn.com.mcredit.digitallending.dto;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;
import vn.com.mcredit.digitallending.validator.OTP;
import vn.com.mcredit.digitallending.validator.Password;
import vn.com.mcredit.digitallending.validator.Username;


@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude
public class UserProfileCreateDTO {

    @NotNullorEmpty(message = "Vui lòng nhập số điện thoại.")
    @Username
    private String username;

    @NotNullorEmpty(message = "Họ tên không được để trống.")
    @Size(min = 3, max =100, message = "Họ và tên tối thiểu 3 ký tự và không vượt quá 100 kí tự.")
    private String fullName;

    @NotNullorEmpty(message = "Mật khẩu mới không được để trống.")
    @Password(
            message = "Mật khẩu ít nhất 6 kí tự, có cả chữ và số trong đó có ít nhất 1 kí tự viết hoa và chỉ chứa các kí tự đặc biệt <>!@#$%^&*()+.?- .")
    private String password;

    @NotNullorEmpty(message = "Mã OTP không được để trống.")
    @OTP
    private String otp;

    private String deviceId;

}