package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude
public class UserProfileDTO implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String keycloakId;
    private String username;
    private String cif;
    private String fullName;
    private String dob;
    private String phoneNumber;
    private String redeemCode;
    private String email;
    private String cardId;
    private String cardType;
    private String cardIssuedAt;
    private String cardExpiredAt;
    private String gender;
    private String address;
    private String province;
    private String district;
    private String city;
    private String avatar;
    private String userType;
    private Boolean isEKYC;
    private Boolean isMatching;
    private String cardIdForSale;
    private Boolean isInhouse;
    private String position;
    private Boolean isVerifiedDevice;
    private String inviteFriendsShortLink;
    private String inviteFriendsLongLink;
    private Boolean isChangePasswordRequired;
}
