package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;
import vn.com.mcredit.digitallending.dto.CaseInforDTO;

import java.util.List;

@Data
public class BpmCheckLoanDeviceResp {
    private String result;
    private String errorCode;
    private List<CaseInforDTO> caseInfor;
    private String requestId;
}
