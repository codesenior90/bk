package vn.com.mcredit.digitallending.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.com.mcredit.digitallending.entity.HomeLending;
import vn.com.mcredit.digitallending.repositories.HomeLendingRepository;
import vn.com.mcredit.digitallending.services.HomeLendingService;

import java.util.Optional;

@Service
public class HomeLendingServiceImpl implements HomeLendingService {
    @Autowired
    HomeLendingRepository homeLendingRepository;
    @Override
    public HomeLending getHomeLending(String id) {
        Optional<HomeLending> optionalHomeLending = homeLendingRepository.findById(id);
        if (optionalHomeLending.isPresent()){
            return optionalHomeLending.get();
        }
        return null;
    }
}
