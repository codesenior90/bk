package vn.com.mcredit.digitallending.services;

import org.aspectj.lang.ProceedingJoinPoint;

public interface CacheKeyGeneratorService {

    String generateLockMethodKey(ProceedingJoinPoint pjp);

}
