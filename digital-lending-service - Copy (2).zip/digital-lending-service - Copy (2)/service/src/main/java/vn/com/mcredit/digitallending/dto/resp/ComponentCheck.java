package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ComponentCheck {
    @JsonProperty("gender_check")
    private boolean genderCheck;
    @JsonProperty("gender_check_reason")
    private String genderCheckReason;
    @JsonProperty("id_number_check")
    private boolean idNumberCheck;
    @JsonProperty("id_number_check_reason")
    private String idNumberCheckReason;
    @JsonProperty("dob_check")
    private boolean dobCheck;
    @JsonProperty("dob_check_reason")
    private String dobCheckReason;
    @JsonProperty("nameCheck")
    private boolean nameCheck;
    @JsonProperty("nameCheckReason")
    private boolean nameCheckReason;
    @JsonProperty("mrz_checksum_check")
    private boolean mrzChecksumCheck;

}
