package vn.com.mcredit.digitallending.proxy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import vn.com.mcredit.digitallending.dto.resp.authen_service.AuthenResponse;
import vn.com.mcredit.digitallending.redis.services.BaseService;
import vn.com.mcredit.digitallending.utils.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Component
public class AuthenticationServiceProxy extends BaseProxy {

    public static final long TOKEN_TIMEOUT = 1740L;
    @Value("${authentication-service.host}")
    private String authenticationHost;
    @Value("${authentication-service.realms}")
    private String realms;
    @Value("${authentication-service.clientId}")
    private String clientId;
    @Value("${authentication-service.username}")
    private String username;
    @Value("${authentication-service.password}")
    private String password;
    @Autowired
    private BaseService baseService;
    private static final String ACCESS_TOKEN = "DIGITAL_LENDING_AUTHENTICATION_SERVICE_ACCESS_TOKEN";
    private static final String REFRESH_ACCESS_TOKEN = "DIGITAL_LENDING_AUTHENTICATION_SERVICE_REFRESH_ACCESS_TOKEN";

    public AuthenResponse login() {
        String url = String.format("%s%s", authenticationHost, "/login");
        Map<String, String> request = new HashMap<>();
        request.put("realms", realms);
        request.put("clientId", clientId);
        request.put("username", username);
        request.put("password", password);
        return this.post(url, initHeaderAppJson(), request, AuthenResponse.class);
    }

    public Object logout(String accessToken) {
        String url = String.format("%s%s", authenticationHost, "/logout");
        Map<String, String> request = new HashMap<>();
        request.put("accessToken", accessToken);
        return this.post(url, initHeaderAppJson(), request, Object.class);
    }

    public Object validateToken(String accessToken) {
        String url = String.format("%s%s", authenticationHost, "/token/validation");
        Map<String, String> request = new HashMap<>();
        request.put("accessToken", accessToken);
        return this.post(url, initHeaderAppJson(), request, Object.class);
    }

    public AuthenResponse refreshToken(String refreshToken) {
        String url = String.format("%s%s", authenticationHost, "/token/refresh");
        Map<String, String> request = new HashMap<>();
        request.put("refresh_token", refreshToken);
        return this.post(url, initHeaderAppJson(), request, AuthenResponse.class);
    }

    public String authentication() {
        if(StringUtils.isNullOrEmpty(baseService.get(ACCESS_TOKEN))) {
            AuthenResponse authenResponse;
            if(StringUtils.isNullOrEmpty(baseService.get(REFRESH_ACCESS_TOKEN))) {
                authenResponse = this.refreshToken(baseService.get(REFRESH_ACCESS_TOKEN));
            }else {
                authenResponse = this.login();
            }
            baseService.set(ACCESS_TOKEN, authenResponse.getData().getAccessToken(), TOKEN_TIMEOUT, TimeUnit.SECONDS);
            baseService.set(REFRESH_ACCESS_TOKEN, authenResponse.getData().getRefreshToken(), TOKEN_TIMEOUT, TimeUnit.SECONDS);
            return authenResponse.getData().getAccessToken();
        } else {
            return baseService.get(ACCESS_TOKEN);
        }
    }
}
