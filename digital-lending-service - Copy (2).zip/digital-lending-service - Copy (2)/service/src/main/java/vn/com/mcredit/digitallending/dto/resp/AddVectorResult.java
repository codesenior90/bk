package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AddVectorResult {

    @JsonProperty("bucket")
    private String bucket;

    @JsonProperty("object_name")
    private String objectName;
}
