package vn.com.mcredit.digitallending.middleware;


import com.google.gson.Gson;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdviceAdapter;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;
import vn.com.mcredit.digitallending.constants.WebConstants;
import vn.com.mcredit.digitallending.dto.LogDTO;
import vn.com.mcredit.digitallending.dto.LogResponseDTO;
import vn.com.mcredit.digitallending.enums.TransactionKeeperEnum;
import vn.com.mcredit.digitallending.factory.LoggingFactory;
import vn.com.mcredit.digitallending.helper.EnvironmentHelper;
import vn.com.mcredit.digitallending.logging.TransactionKeeper;
import vn.com.mcredit.digitallending.models.ExceptionDTO;
import vn.com.mcredit.digitallending.services.CallApiLogService;
import vn.com.mcredit.digitallending.utils.DateUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.util.*;



@ControllerAdvice
public class HTTPMonitoringInterceptor extends RequestBodyAdviceAdapter
		implements HandlerInterceptor, ResponseBodyAdvice<Object> {
	private static final Logger log = LoggingFactory.getLogger(HTTPMonitoringInterceptor.class);
	public static final String ORIGIN_NOT_ALLOW = " không được cho phép truy cập API";
	private static final String START_TIME_KEY = "start-time";
	private static final String START_TIME_MILLI_KEY = "start-time-milli";
	private static final String URI_KEY = "uri-key";
	private static final String APP_NAME = "DIGITAL-LENDING-SERVICE";
	public static final String X_LOG_INFO = "x-log-info";
	public static final String HEADERS = "headers";
	public static final String RESPONSE = "response";

	@Value("${whitelist.hosts.origins}")
	private String allowHosts;

	@Value("${whitelist.hosts.k8s-url}")
	private String allowUrlsK8S;

	@Value("${whitelist.hosts.parter-access.ips}")
	private String allowIpsParter;

	@Value("${whitelist.hosts.parter-access.urls}")
	private String allowUrlsPartner;

	@Value("${whitelist.hosts.van-hanh.urls}")
	private String allowUrlVanHanh;

	private static final Gson g = new Gson();

	@Autowired
	HttpServletRequest httpServletRequest;

	@Autowired
	HttpServletResponse httpServletResponse;

	@Autowired
	TransactionKeeper tk;
	@Autowired
	private CallApiLogService callApiLogService;
	@Autowired
	private EnvironmentHelper environmentHelper;
	@Override
	public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o)
			throws Exception {
		if (isCaptured(httpServletRequest)) {

			try {
				httpServletRequest.setAttribute(START_TIME_KEY, System.nanoTime());
				httpServletRequest.setAttribute(START_TIME_MILLI_KEY, System.currentTimeMillis());
				LogDTO item = new LogDTO();

				var hNames = httpServletRequest.getHeaderNames();
				while (hNames.hasMoreElements()) {
					String hName = hNames.nextElement();
					if (hName.equalsIgnoreCase("Authorization"))
						item.getHeaders().put(hName, "NOT RECORDED");
					else
						item.getHeaders().put(hName, httpServletRequest.getHeader(hName));
				}
				item.getHeaders().put(TransactionKeeperEnum.SERVICE_MESSAGE_ID.value(),
						getServiceMessageId(httpServletRequest));
				item.getHeaders().put(TransactionKeeperEnum.TRANSACTION_ID.value(),
						getTransactionId(httpServletRequest));
				item.getHeaders().put(TransactionKeeperEnum.SOURCE_SYSTEM.value(),
						httpServletRequest.getHeader(TransactionKeeperEnum.SOURCE_SYSTEM.value()));
				item.getHeaders().put("service-type", getServiceType(httpServletRequest.getMethod()));
				item.getHeaders().put("path", getFullURL(httpServletRequest));
				item.getHeaders().put("http-method", httpServletRequest.getMethod());
				item.getHeaders().put("created-date", DateUtils.getTime());

				HttpMessageObject httpMessageObject = new HttpMessageObject(httpServletRequest);
				Map<String, Object> map = new LinkedHashMap<>();
				map.put("origin", httpServletRequest.getRemoteHost() != null ? "REMOTE" : "LOCAL");
				map.put("type", "request");
				map.put("correlation", "");
				map.put("protocol", httpServletRequest.getProtocol());
				map.put("ip", httpServletRequest.getRemoteAddr());
				map.put("method", httpMessageObject.getHttpMethod());
				map.put("uri", httpMessageObject.getHttpPath());
				httpServletRequest.setAttribute(URI_KEY, httpMessageObject.getHttpPath());
				item.setMessage(map);

				var strObj = g.toJson(item);
				httpServletRequest.setAttribute(X_LOG_INFO, strObj);
				httpServletRequest.setAttribute(TransactionKeeperEnum.SERVICE_MESSAGE_ID.value(),
						item.getHeaders().get(TransactionKeeperEnum.SERVICE_MESSAGE_ID.value()));
				httpServletRequest.setAttribute(TransactionKeeperEnum.TRANSACTION_ID.value(),
						item.getHeaders().get(TransactionKeeperEnum.TRANSACTION_ID.value()));
				httpServletRequest.setAttribute(TransactionKeeperEnum.JWT.value(),
						item.getHeaders().get(TransactionKeeperEnum.JWT.value()));
				httpServletRequest.setAttribute(TransactionKeeperEnum.SOURCE_SYSTEM.value(),
						item.getHeaders().get(TransactionKeeperEnum.SOURCE_SYSTEM.value()));
			} catch (Exception e) {
				LogUtils.error("[HTTPMonitoringInterceptor] PRE HANDLE", e.getMessage());
			}

		}
		return true;
	}

	// POST, PUT, PATCH request
	@Override
	public boolean supports(MethodParameter methodParameter, Type targetType,
							Class<? extends HttpMessageConverter<?>> converterType) {
		return true;
	}

	// POST, PUT, PATCH request
	@Override
	public Object afterBodyRead(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType,
								Class<? extends HttpMessageConverter<?>> converterType) {
		try {
			var l = g.fromJson(httpServletRequest.getAttribute(X_LOG_INFO).toString(), LogDTO.class);
			if (l != null) {
				l.setPayload(body);
				var strObj = g.toJson(l);
				httpServletRequest.setAttribute(X_LOG_INFO, strObj);
				log.info("{} + HEADER => {}", l.getMessage(),  l.getHeaders());
			}
		} catch (Exception e) {
			LogUtils.error("[HTTPMonitoringInterceptor].afterBodyRead", e.getMessage());
		}
		return super.afterBodyRead(body, inputMessage, parameter, targetType, converterType);
	}

	// response body
	@Override
	public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
		return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
								Object body, Exception ex) {
		// Fix sonar
	}

	// response body
	@Override
	public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
								  Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request,
								  ServerHttpResponse response) {

		try {
			var logInfo = g.fromJson(httpServletRequest.getAttribute(X_LOG_INFO).toString(), LogDTO.class);
			if (logInfo != null) {
				long startMillisecond = (long) httpServletRequest.getAttribute(START_TIME_MILLI_KEY);
				long start = (long) httpServletRequest.getAttribute(START_TIME_KEY);
				String uri = (String) httpServletRequest.getAttribute(URI_KEY);
				long elapsed = System.nanoTime() - start;

				logInfo.setElapsedTimeInMilliseconds(String.valueOf(elapsed / 1000000.0));

				var status = httpServletResponse.getStatus();
				if (status >= 200 && status < 300)
					logInfo.setResponseSuccess(body);
				else {
					checkStatus400And500(body, logInfo, status);
				}
				Map<String, Object> map = new LinkedHashMap<>();
				map.put("origin", httpServletRequest.getRemoteHost() != null ? "REMOTE" : "LOCAL");
				map.put("type", RESPONSE);
				map.put("correlation", "");
				map.put("protocol", httpServletRequest.getProtocol());
				map.put("method", httpServletRequest.getMethod());
				map.put("status", httpServletResponse.getStatus());
				map.put("duration", String.format("%.3f", elapsed / 1000000.0));
				map.put("request-time", Instant.ofEpochMilli(startMillisecond).atZone(ZoneId.systemDefault()).toLocalDateTime().toString());
				map.put("uri", uri);
				String originReferer = httpServletRequest.getHeader(WebConstants.Headers.REFERER);
				String postmanToken = httpServletRequest.getHeader(WebConstants.Headers.POSTMAN_TOKEN);
				LogUtils.info("originReferer", originReferer);
				LogUtils.info("postmanToken", postmanToken);
				if (!environmentHelper.isDev() && this.isCorsNotAllowHost(originReferer, postmanToken))  {
					this.writeResponseError(httpServletResponse);
					return null;
				}
				this.saveLog(body, httpServletRequest, httpServletResponse, logInfo);

			}
		} catch (Exception e) {
			if (e.getMessage() != null){
				LogUtils.error("HTTPMonitoringInterceptor beforeBodyWrite", e.getMessage());
			}
		}
		return body;
	}

	private void checkStatus400And500(Object body, LogDTO logInfo, int status) {
		if (body instanceof ExceptionDTO) {
			var ex = (ExceptionDTO) body;
			var tempStatus =  "";
			if (status > 500){
				tempStatus = "3";
			} else if (status >= 400 && status < 500) {
				tempStatus = "2";
			}
			logInfo.setResponseError(LogResponseDTO.builder().status(tempStatus)
					.statusCode(ex.getCode()).statusDesc(ex.getMessage()).build());
		} else
			logInfo.setResponseError(body);
	}

	private boolean isCaptured(HttpServletRequest httpServletRequest) {
		return "GET".equals(httpServletRequest.getMethod()) || "DELETE".equals(httpServletRequest.getMethod())
				|| "POST".equals(httpServletRequest.getMethod()) || "PUT".equals(httpServletRequest.getMethod());
	}

	private String getFullURL(HttpServletRequest request) {
		StringBuilder requestURL = new StringBuilder(request.getRequestURL().toString());
		String queryString = request.getQueryString();

		if (queryString == null)
			return requestURL.toString();

		return requestURL.append('?').append(queryString).toString();

	}

	private String getServiceMessageId(HttpServletRequest httpRequest) {
		try {
			/* get from clients: mobile app or web or other system. */
			var id = httpRequest.getHeader(TransactionKeeperEnum.SERVICE_MESSAGE_ID.value());
			return StringUtils.isBlank(id) ? UUID.randomUUID().toString() : id;
		} catch (Exception e) {
			return StringUtils.EMPTY;
		}
	}

	private String getTransactionId(HttpServletRequest httpRequest) {
		try {
			var transactionId = httpRequest.getHeader(TransactionKeeperEnum.TRANSACTION_ID.value());
			return StringUtils.isBlank(transactionId)
					? APP_NAME + "-" + DateUtils.dateTime() + "-" + UUID.randomUUID()
					: transactionId;
		} catch (Exception e) {
			return StringUtils.EMPTY;
		}

	}

	private String getServiceType(String method) {
		if ("GET".equalsIgnoreCase(method))
			return "Query";
		if ("POST".equalsIgnoreCase(method))
			return "Commit_or_Query";
		if ("PUT".equalsIgnoreCase(method))
			return "Commit";
		if ("DELETE".equalsIgnoreCase(method))
			return "Rollback_or_Delete_or_Revert";
		return StringUtils.EMPTY;
	}

	private void saveLog(Object body, HttpServletRequest request, HttpServletResponse response, LogDTO logInfo){
    	if (!request.getRequestURI().contains("/api/v1/log")) {
      		callApiLogService.saveLog(body, request, response, logInfo);
		}
	}

	public void writeResponseError(HttpServletResponse response) throws IOException {
		byte[] responseBody = ORIGIN_NOT_ALLOW.getBytes(StandardCharsets.UTF_8);
		response.setContentLength(responseBody.length);
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		response.getOutputStream().write(responseBody);
		response.getOutputStream().close();
	}

	public boolean isCorsNotAllowHost(String origin, String postmanToken) {
		boolean isNotAllowHost = ObjectUtils.isNotEmpty(origin) && Arrays.stream(allowHosts.split(",")).noneMatch(e -> e.contains(origin) || origin.contains(e));
		return isNotAllowHost || this.isNotAllowPostman(origin, postmanToken);

	}

	private boolean isNotAllowPostman(String origin, String postmanToken){
		return ObjectUtils.isEmpty(origin) && ObjectUtils.isNotEmpty(postmanToken);
	}

	public boolean isNotAllowK8S(String origin, String postmanToken, String uri) {
		return ObjectUtils.isEmpty(origin) && ObjectUtils.isNotEmpty(postmanToken) && ObjectUtils.isNotEmpty(uri) && allowUrlsK8S.contains(uri) || uri.contains(allowUrlsK8S);
	}

	public boolean isNotAllowTool(String origin, String postmanToken, String uri) {
		return ObjectUtils.isEmpty(origin) && ObjectUtils.isNotEmpty(postmanToken) && ObjectUtils.isNotEmpty(uri) && Arrays.stream(allowUrlVanHanh.split(",")).noneMatch(u -> uri.contains(u) || u.contains(uri));
	}
	public boolean isCorsNotAllowHost(String origin) {
		return ObjectUtils.isNotEmpty(origin) && Arrays.stream(allowHosts.split(",")).noneMatch(e -> e.contains(origin) || origin.contains(e));
	}
	public boolean isCorsNotAllowHost(HttpServletRequest request, String origin, String postmanToken, String uri) {
		boolean isNotAllowHost = ObjectUtils.isNotEmpty(origin) && Arrays.stream(allowHosts.split(",")).noneMatch(e -> e.contains(origin) || origin.contains(e));
		boolean isNotAllowPartner = isNotAllowHost || isNotAllowPartnerAccessUri(request, postmanToken);
		boolean isNotAllowTool = isNotAllowPartner || isNotAllowTool(origin, postmanToken, uri);
		return isNotAllowTool || isNotAllowK8S(origin,postmanToken,uri);
	}
	public boolean isNotAllowPartnerAccessUri(HttpServletRequest request, String postmanToken) {
		String hostPartner = request.getHeader(WebConstants.Headers.X_ORIGIN_FORARDER_FOR);
		String[] ips = ObjectUtils.isNotEmpty(hostPartner) ? hostPartner.split(",") : null;
		String uri = request.getHeader(WebConstants.Headers.PATH);
		boolean isAllowIp = ObjectUtils.isEmpty(postmanToken) || (ObjectUtils.isNotEmpty(ips) && Arrays.stream(allowIpsParter.split(",")).anyMatch(e -> Arrays.stream(ips).anyMatch(h -> h.contains(e))));
		return isAllowIp && (ObjectUtils.isNotEmpty(uri) && Arrays.stream(allowUrlsPartner.split(",")).noneMatch(e -> e.contains(uri) || uri.contains(e)));
	}
}