package vn.com.mcredit.digitallending.dto.resp;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import vn.com.mcredit.digitallending.dto.req.FraudCheck;

import java.util.List;

@Data
@JsonInclude
public class EkycDetailResponse {
    private String id;
    private String username;
    private String cardType;
    private String status;
    private String frontImageURL;
    private String backImageURL;
    private String selfieImageURL;
    private String leftImageURL;
    private String rightImageURL;
    private String originSystem;
    private String type;
    private Object ocrUpdate;
    private Object ocr;
    private Object faceMatching;
    private Object faceMatching3Way;
    private List<FraudCheck> fraudChecks;
    private String qrCode;
    private String ocrCode;
    private String qrCodeImageURL;
}
