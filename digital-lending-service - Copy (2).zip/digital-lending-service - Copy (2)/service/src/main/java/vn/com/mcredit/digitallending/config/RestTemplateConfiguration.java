package vn.com.mcredit.digitallending.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import vn.com.mcredit.digitallending.logging.Logging;
import vn.com.mcredit.digitallending.logging.TransactionKeeper;
import vn.com.mcredit.digitallending.middleware.RestTemplateInterceptor;
import vn.com.mcredit.digitallending.services.CallApiLogService;

import java.util.Collections;

@Configuration
public class RestTemplateConfiguration {

    private TransactionKeeper transactionKeeper;

    private Logging logging;
    private CallApiLogService callApiLogService;
    @Autowired
    public RestTemplateConfiguration(TransactionKeeper transactionKeeper, Logging logging, CallApiLogService callApiLogService) {
        this.transactionKeeper = transactionKeeper;
        this.logging = logging;
        this.callApiLogService = callApiLogService;
    }

    @Bean
    public RestTemplate restTemplate() {

        var rest = new RestTemplate();
        rest.setInterceptors(Collections.singletonList(new RestTemplateInterceptor(transactionKeeper, logging, callApiLogService)));
        return rest;
    }
}