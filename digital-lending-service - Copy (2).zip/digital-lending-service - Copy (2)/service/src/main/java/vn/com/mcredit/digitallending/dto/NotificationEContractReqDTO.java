package vn.com.mcredit.digitallending.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class NotificationEContractReqDTO {

    private String system;

    /**
     * số hợp đồng.
     */
    private String contractCode;

    /**
     * CCCD.
     */
    private String loansProfileId;

    /**
     * Ngày ký hợp đồng (confirm-otp)
     */
    private String signContractDate;

    private String signUser;

}
