package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.PreOffer;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface PreOfferRepository extends JpaRepository<PreOffer, String> {
    PreOffer findPreOfferByRequestId(String requestId);
    PreOffer findFirstByUserNameOrderByUpdatedDateDesc(String userName);

    @Query(value = "SELECT * FROM pre_offer WHERE user_name = :userName order by updated_date desc limit 1 ", nativeQuery = true)
    PreOffer getPreOfferByUserName(String userName);

    @Query(value = "SELECT * FROM pre_offer WHERE user_name = :userName and offer_id = :offerId order by updated_date desc limit 1 ", nativeQuery = true)
    PreOffer getPreOfferByUserNameAndOfferId(String userName, BigInteger offerId);

    @Query(value = "SELECT * FROM pre_offer WHERE user_name = :userName and request_id = :requestId order by updated_date desc limit 1 ", nativeQuery = true)
    PreOffer getPreOfferByUserNameAndRequestId(String userName, String requestId);

    @Query(value = "SELECT * FROM pre_offer WHERE request_id = :requestId order by updated_date desc limit 1 ", nativeQuery = true)
    PreOffer getPreOfferByRequestId(String requestId);
    PreOffer findByUserNameAndRequestId(String username, String requestId);

    @Query(value = "SELECT * FROM pre_offer WHERE offer_id = :offerId and user_name = :username", nativeQuery = true)
    PreOffer findByOfferIdAndUsername(BigInteger offerId, String username);

    @Query(value = "SELECT * FROM pre_offer WHERE offer_id = :offerId and request_id = :requestId", nativeQuery = true)
    PreOffer findByOfferIdAndRequestId(BigInteger offerId, String requestId);

    @Query(value = "SELECT * FROM pre_offer WHERE user_name = :userName and case_number = :caseNumber", nativeQuery = true)
    PreOffer getPreOfferByUserNameAndCaseNumber(String userName, String caseNumber);

    boolean existsByUserNameAndStatusIn(String username, List<String> statues);
}
