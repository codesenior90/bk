package vn.com.mcredit.digitallending.services;

import org.springframework.web.multipart.MultipartFile;
import vn.com.mcredit.digitallending.dto.req.AddVectorRequest;
import vn.com.mcredit.digitallending.dto.req.FaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.req.FaceSearchRequest;
import vn.com.mcredit.digitallending.dto.req.UpdateFaceMatchingDTO;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.entity.Ocr;

import java.util.Map;


public interface ImageSearchService {
    AddVectorRequest buildAddVectorRequest(String db, String vec, String uid);
    AddVectorResponse addVector(AddVectorRequest request);
    BlacklistCheckResponse checkBlacklist(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber, Map<String, Object> map, String username);
    IdFacesCheckResponse checkIdsFace(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber, Map<String, Object> map, String username);
    FaceIdsCheckResponse checkFaceIds(Ocr ocr, String idVector, String selfieVector, String cccdNumber, String cmndoNumber, Map<String, Object> map, String username);
    FaceMatchRawResponse faceMatchRaw(Ocr ocr, MultipartFile frontImg, FaceMatchingDTO faceMatchingDTO, String username);
    FaceMatch3WayResponse faceMatch3Way(FaceMatchingDTO faceMatchingDTO, String ocrRequestId, String username, String idNumber, Integer processType);
    FaceMatchRawResponse faceMatchRaw(MultipartFile frontImg, MultipartFile selfieImg, String username);
    FaceMatch3WayResponse faceMatch3Way(UpdateFaceMatchingDTO faceMatchingDTO, String username, String idNumber);
    FaceSearchRequest buildFaceSearchRequest(String idNumber, String idNumberOld, String name, String dob, String idNumberVector, String selfieVector);
    Map<String, Object> checkFaceSearch(FaceSearchRequest request, String username, String ocrRequestId);
}
