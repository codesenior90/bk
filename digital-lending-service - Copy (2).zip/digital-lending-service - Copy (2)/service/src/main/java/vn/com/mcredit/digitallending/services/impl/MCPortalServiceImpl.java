package vn.com.mcredit.digitallending.services.impl;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import vn.com.mcredit.digitallending.dto.AbortOfferDTO;
import vn.com.mcredit.digitallending.dto.req.CheckLeadRequest;
import vn.com.mcredit.digitallending.dto.req.CreateLeadRequest;
import vn.com.mcredit.digitallending.dto.resp.*;
import vn.com.mcredit.digitallending.dto.resp.aws_auth.AwsAuthResponse;
import vn.com.mcredit.digitallending.dto.resp.aws_auth.Credentials;
import vn.com.mcredit.digitallending.entity.CreateLoan;
import vn.com.mcredit.digitallending.entity.EkycModel;
import vn.com.mcredit.digitallending.entity.PreOffer;
import vn.com.mcredit.digitallending.enums.*;
import vn.com.mcredit.digitallending.enums.LoanState;
import vn.com.mcredit.digitallending.proxy.AWSProxy;
import vn.com.mcredit.digitallending.redis.services.BaseService;
import vn.com.mcredit.digitallending.repositories.CreateLoanRepository;
import vn.com.mcredit.digitallending.repositories.EkycModelRepository;
import vn.com.mcredit.digitallending.repositories.PreOfferRepository;
import vn.com.mcredit.digitallending.services.AfcService;
import vn.com.mcredit.digitallending.services.MCPortalService;
import vn.com.mcredit.digitallending.utils.DateUtils;
import vn.com.mcredit.digitallending.utils.LogUtils;
import vn.com.mcredit.digitallending.utils.StringUtils;
import vn.com.mcredit.digitallending.utils.Utils;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;


@Service
@RequiredArgsConstructor
public class MCPortalServiceImpl implements MCPortalService {

    public static final String FROM_TIKTAK_MB = "TIKTAK_MB";
    public static final String FROM_TIKTAK = "TIKTAK";
    @Value("${aws.sts.url}")
    private String url;

    @Value("${aws.sts.access-key}")
    private String accessKey;

    @Value("${aws.sts.secret-key}")
    private String secretKey;

    @Value("${custom.properties.leadgen-host}")
    protected String leadUrl;

    @Value("${custom.properties.leadgen-partner-code}")
    protected String leadgenPartnerCode;

    private final AfcService afcService;
    private static final String AWS_CREDENTIAL = "DIGITAL_LENDING_STS_AWS_SESSION_TOKEN_KEY";

    private static final String PASS_CHECK_LEAD_STATUS = "passed";

    private static final String CAMPAIGN_CODE = "DL-";

    private static final int DL_LEAD_CARD_TYPE = 1;

    private static final int TOKEN_EXPIRED_TIME = 60 * 59 * 1000;

    private final AWSProxy awsProxy;

    private final ObjectMapper objectMapper;

    private final BaseService baseService;

    private final PreOfferRepository preOfferRepository;

    private final EkycModelRepository ekycModelRepository;

    private final CreateLoanRepository createLoanRepository;

    @Autowired
    @Qualifier("sendLeadToMCPortalThreadPoolTaskExecutor")
    private TaskExecutor taskExecutor;

    @Override
    public AwsAuthResponse authenticate() {
        try {
            Object response = awsProxy.authenticate(url, accessKey, secretKey, Object.class);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            AwsAuthResponse authResponse = objectMapper.convertValue(response, AwsAuthResponse.class);
            baseService.set(AWS_CREDENTIAL, Utils.toJson(authResponse.getAssumeRoleResponse().getAssumeRoleResult().getCredentials()), TOKEN_EXPIRED_TIME, TimeUnit.MILLISECONDS);
            return authResponse;
        } catch (HttpStatusCodeException ex) {
            LogUtils.error("[MCPortalService] authenticate -ex :" + ex.getResponseBodyAsString());
            return null;
        }
    }

    public CheckLeadResponse checkLead(CheckLeadRequest checkLeadRequest) {
        CheckLeadResponse checkLeadResponse;
        try {
            Credentials credentials = this.getAWSSessionToken();
            if (credentials == null) return null;
            checkLeadResponse = awsProxy.post(leadUrl + "/check", credentials.getAccessKeyId(), credentials.getSecretAccessKey(), credentials.getSessionToken(), checkLeadRequest, CheckLeadResponse.class);
        } catch (HttpStatusCodeException ex) {
            LogUtils.info("[MCPortalService] checkLead -ex " + ex.getMessage());
            return null;
        }
        LogUtils.info("[MCPortalService] checkLead checkLeadResponse");
        return checkLeadResponse;
    }

    public CreateLeadResponse createLead(CreateLeadRequest createLeadRequest) {
        CreateLeadResponse createLeadResponse;
        try {
            Credentials credentials = this.getAWSSessionToken();
            if (credentials == null) return null;
            createLeadResponse = awsProxy.post(leadUrl + "/create", credentials.getAccessKeyId(), credentials.getSecretAccessKey(), credentials.getSessionToken(), createLeadRequest, CreateLeadResponse.class);
        } catch (HttpStatusCodeException ex) {
            LogUtils.info("[MCPortalService] createLead -ex  " + ex.getMessage());
            return null;
        }
        LogUtils.info("[MCPortalService] createLead createLeadResponse");
        return createLeadResponse;
    }

    private Credentials getAWSSessionToken() {
        String data = baseService.get(AWS_CREDENTIAL);
        Credentials credentials;
        if (data != null) {
            credentials = Utils.fromJson(data, Credentials.class);
        } else {
            AwsAuthResponse authResponse = this.authenticate();
            credentials = authResponse.getAssumeRoleResponse().getAssumeRoleResult().getCredentials();
        }
        return credentials;
    }

    @Override
    public void sendLeadToMcPortal(OcrResultResponse ocrResultResponse, String username, String partnerCode) {
        try {
            taskExecutor.execute(() -> {
                CreateLeadRequest createLeadRequest = this.buildCreateLeadRequest(ocrResultResponse, username);
                createLeadRequest.setSource(this.getPartnerName(partnerCode));
                this.sendData(createLeadRequest, username);
            });
        } catch (Exception e) {
            LogUtils.error("[MCPortalService] sendLeadToMcPortal execute error", e.getMessage());
        }
    }

    @Override
    public void sendLeadToMcPortal(String idNumber, String name, String gender, BigInteger loanAmount, String address, String username) {
        try {
            taskExecutor.execute(() -> {
                CreateLeadRequest request = this.getCreateLeadRequest(username, idNumber, name, gender, address, loanAmount, ReasonAbort.INVALID_CMT.getMessage());
                this.sendData(request, username);
            });
        } catch (Exception e) {
            LogUtils.error("[MCPortalService] sendLeadToMcPortal error", e.getMessage());
        }

    }
    @Override
    public void sendData(CreateLeadRequest createLeadRequest, String username) {
        try {
            LogUtils.info("[MCPortalService] sendLeadToMcPortal createLeadRequest", createLeadRequest);
            CheckLeadRequest checkLeadRequest = CheckLeadRequest.builder().
                    requestId(createLeadRequest.getRequestId()).
                    nationalId(createLeadRequest.getNationalId()).
                    phoneNumber(createLeadRequest.getPhoneNumber()).
                    partner(createLeadRequest.getPartner()).build();
            CheckLeadResponse checkLeadResponse = this.checkLead(checkLeadRequest);
            LogUtils.info("[MCPortalService] sendLeadToMcPortal checkLeadResponse", checkLeadResponse);
            if (checkLeadResponse != null && PASS_CHECK_LEAD_STATUS.equals(checkLeadResponse.getStatus())) {
                CreateLeadResponse createLeadResponse = this.createLead(createLeadRequest);
                LogUtils.info("[MCPortalService] sendLeadToMcPortal status " + createLeadResponse.getStatus());
                LogUtils.info("[MCPortalService] sendLeadToMcPortal username " + username + " bankLeadId " + createLeadResponse.getBankLeadId());
            }

        } catch (Exception ex) {
            LogUtils.info("[MCPortalService] sendLeadToMcPortal CMT09 failed");
        }
    }

    @Override
    public void sendLeadToMcPortal(String data, String type) {
        try {
            taskExecutor.execute(() -> this.processSendLeadAbort(data, type));
        } catch (Exception e) {
            LogUtils.error("[MCPortalService] receiveAbortCase15Day execute error", e.getMessage());
        }
    }

    public void processSendLeadAbort(String data, String type) {
        try {
            LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal abort case ", data);
            LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal type ", type);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            objectMapper.setDateFormat(new SimpleDateFormat(DateUtils.FORMAT_TIME_BPM_YYYY_MM_DD_HH_MM_SS_SSS));
            AbortOfferDTO abortOffer = objectMapper.readValue(data, AbortOfferDTO.class);

            String other;
            BigInteger offerId = abortOffer.getOfferId();
            String preOfferStatus;
            String reasonCode;
            CreateLoan createLoan;
            if (AbortType.CASE.name().equals(type)) {
                createLoan = createLoanRepository.getCreateLoanAbort(abortOffer.getCaseNumber(), abortOffer.getRequestId(), abortOffer.getContractNumber());
                if (createLoan == null) {
                    LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal pre_offer not found caseNumber " + abortOffer.getCaseNumber() + " requestId " + abortOffer.getRequestId() + " contractNumber " + abortOffer.getContractNumber());
                    return;
                }
                createLoan.setStatus(LoanState.CREATE_CASE_REJECT.getValue());
                createLoan.setReason(ReasonAbort.CASE_REJECT_15D.getMessage());
                createLoan.setUpdatedDate(new Date());
                createLoanRepository.save(createLoan);

                other = ReasonAbort.CASE_REJECT_15D.getMessage();
                offerId = createLoan.getOfferId();
                preOfferStatus = OfferState.LOAN_ABORT_15D.getValue();
                reasonCode = ReasonAbort.CASE_REJECT_15D.getCode();
            } else {
                other = ReasonAbort.OFFER_REJECT_72H.getMessage();
                reasonCode = ReasonAbort.OFFER_REJECT_72H.getCode();
                preOfferStatus = OfferState.OFFER_REJECT.getValue();
            }
            PreOffer preOffer = preOfferRepository.findByOfferIdAndRequestId(offerId, abortOffer.getRequestId());
            if (preOffer == null) {
                LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal pre_offer not found requestId " + abortOffer.getRequestId() + " offerId " + offerId);
                return;
            }
            if (AbortType.OFFER.name().equals(type)) {
                createLoan = createLoanRepository.findCreateLoanByUserNameAndRequestId(preOffer.getUserName(), preOffer.getRequestId());
                if (createLoan != null) return;
            }
            preOffer.setStatus(preOfferStatus);
            preOffer.setReason(other);
            preOffer.setReasonCode(reasonCode);
            preOffer.setUpdatedDate(new Date());
            preOfferRepository.save(preOffer);

            LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal abort case username", preOffer.getUserName());

            EkycModel ekycModel = ekycModelRepository.findByUsername(preOffer.getUserName());
            this.sendData(this.buildCreateLeadRequest(ekycModel, ekycModel.getUsername(), preOffer.getLoanAmtMinusInsu(), other, abortOffer.getPartnerCode()), preOffer.getUserName());
        } catch (Exception e) {
            LogUtils.info("[MCPortalService] sendLeadToMcPortal abort case failed");
        }
    }


    private CreateLeadRequest buildCreateLeadRequest(OcrResultResponse ocrResultResponse, String username) {
        CreateLeadRequest createLeadRequest = this.getCreateLeadRequest(username, ocrResultResponse.getIdNumber(), ocrResultResponse.getName(), ocrResultResponse.getGender(), ocrResultResponse.getAddress(), null, ReasonAbort.INVALID_CMT.getMessage());
        createLeadRequest.setDob(this.convertDob(ocrResultResponse.getDob()));
        return createLeadRequest;
    }

    @Override
    public CreateLeadRequest buildCreateLeadRequest(EkycModel ekycModel, String username, BigInteger loanAmount, String other, String partnerCode) {
        CreateLeadRequest createLeadRequest =  this.getCreateLeadRequest(username, ekycModel.getIdNumber(), ekycModel.getName(), ekycModel.getGender(), ekycModel.getAddress(), loanAmount, other);
        createLeadRequest.setSource(this.getPartnerName(partnerCode));
        createLeadRequest.setDob(this.convertDob(ekycModel.getDob()));
        return createLeadRequest;
    }

    @Override
    public void sendLeadToMcPortal(OfferDGTResponse offerDGTResponse, String partnerCode) {
        LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal fail call telco ", offerDGTResponse);
        PreOffer preOffer = preOfferRepository.findPreOfferByRequestId(offerDGTResponse.getRequestId());
        EkycModel ekycModel = ekycModelRepository.findByUsername(preOffer.getUserName());
        this.sendData(this.buildCreateLeadRequest(ekycModel, ekycModel.getUsername(), preOffer.getLoanAmtMinusInsu(), ReasonAbort.FAIL_CALL_TELCO.getMessage(), partnerCode), preOffer.getUserName());
    }

    private CreateLeadRequest getCreateLeadRequest(String username, String idNumber, String name, String gender, String address, BigInteger loanAmount, String other) {
        CreateLeadRequest createLeadRequest = new CreateLeadRequest();
        String requestId = UUID.randomUUID().toString();
        createLeadRequest.setRequestId(requestId);
        createLeadRequest.setPhoneNumber(username);
        createLeadRequest.setNationalId(idNumber);
        createLeadRequest.setFullName(name);
        createLeadRequest.setRefId(requestId);
        createLeadRequest.setPartner(leadgenPartnerCode);
        createLeadRequest.setGender(this.getGender(gender));
        createLeadRequest.setAddress(this.getCustomerAddress(address));
        createLeadRequest.setCardType(DL_LEAD_CARD_TYPE);
        createLeadRequest.setCampaignCode(this.generateCampaignCode());
        createLeadRequest.setOther(other);
        if (loanAmount != null) {
            createLeadRequest.setLoanAmount(loanAmount);
        }
        return createLeadRequest;
    }

    private String getPartnerName(String partnerCode) {
        if(!StringUtils.isNullOrEmpty(partnerCode)) {
            if(EPartnerCode.MB_BANK.getValue().equalsIgnoreCase(partnerCode)) return FROM_TIKTAK_MB;
            if(EPartnerCode.MC_CREDIT_APP.getValue().equalsIgnoreCase(partnerCode)) return FROM_TIKTAK;
        }
        return null;
    }

    private String getGender(String gender) {
        if (Gender.FEMALE.getValue().equalsIgnoreCase(gender) || Gender.FEMALE.name().equalsIgnoreCase(gender)) {
            return "Nu";
        }
        else if(Gender.MALE.getValue().equalsIgnoreCase(gender) || Gender.MALE.name().equalsIgnoreCase(gender)) {
            return "Nam";
        } else {
            return "NA";
        }
    }

    private String generateCampaignCode() {
        String pattern = "MMyyyy";
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return CAMPAIGN_CODE + format.format(new Date());
    }

    private String getCustomerAddress(String address) {
        String[] addArr = address.split(",");
        return addArr[addArr.length - 1];
    }
    @Override
    public void sendLeadToMcPortal(String idNumber, String name, String gender, String address, String username, String partnerCode) {
        try {
            taskExecutor.execute(() -> {
                CreateLeadRequest createLeadRequest = this.getCreateLeadRequest(username, idNumber, name, gender, address, null, ReasonAbort.INVALID_CMT.getMessage());
                this.sendData(createLeadRequest, username);
            });
        } catch (Exception e) {
            LogUtils.error("[MCPortalService] sendLeadToMcPortal receiveAbortCase15Day execute error", e.getMessage());
        }
    }

    @Override
    public void sendLeadOfferReject(PreOffer preOffer) {
        LogUtils.info("[MCPortalServiceImpl] sendLeadToMcPortal offer reject ", preOffer.getOfferId());
        EkycModel ekycModel = ekycModelRepository.findByUsername(preOffer.getUserName());
        this.sendData(this.buildCreateLeadRequest(ekycModel, ekycModel.getUsername(), preOffer.getLoanAmtMinusInsu(), ReasonAbort.OFFER_REJECT.getMessage(), preOffer.getPartnerCode()), preOffer.getUserName());
    }

    private String convertDob(String dob) {
        return dob.replace("/", "-");
    }
}
