package vn.com.mcredit.digitallending.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import vn.com.mcredit.digitallending.validator.NotNullorEmpty;

@Data
public class EcontractTransactionRequestDTO {
    @JsonProperty("citizenId")
    @NotNullorEmpty(message = "Vui lòng cung cấp CCCD")
    private String citizenId;
    @JsonProperty("customerName")
    @NotNullorEmpty(message = "Vui lòng cung cấp tên khách hàng")
    private String customerName;
    private String page;
    private String email;
}
