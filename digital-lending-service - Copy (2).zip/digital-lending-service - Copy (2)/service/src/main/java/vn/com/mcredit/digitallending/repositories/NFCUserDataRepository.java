package vn.com.mcredit.digitallending.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vn.com.mcredit.digitallending.entity.NFCUserData;

@Repository
public interface NFCUserDataRepository extends JpaRepository<NFCUserData, String> {
    NFCUserData findByUsernameAndInternalCheckId(String username, String idInternalId);
}
