package vn.com.mcredit.digitallending.services;

import vn.com.mcredit.digitallending.dto.req.DocValidateDTO;
import vn.com.mcredit.digitallending.dto.req.RawUserDataReq;
import vn.com.mcredit.digitallending.dto.resp.DocValidateResponse;
import vn.com.mcredit.digitallending.entity.Ocr;

import java.util.Map;

public interface FraudCheckService {
    DocValidateResponse callValidateDoc(DocValidateDTO docValidateDTO, Map<String, Object> map);
    DocValidateDTO buildDocValidateRequest(Ocr ocr, String qrCode, RawUserDataReq rawUserDataReq);
}
