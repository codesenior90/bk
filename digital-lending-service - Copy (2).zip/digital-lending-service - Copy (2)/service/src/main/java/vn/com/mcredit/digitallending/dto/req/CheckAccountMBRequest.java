package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class CheckAccountMBRequest {
    private String accountNumber; // Số tài khoản ngân hàng
    private String phoneNumber; // Số điện thoại KH
    private String smlCode; // Mã NH tại Napas
    private String offerId; // OfferID
}
