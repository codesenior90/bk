package vn.com.mcredit.digitallending.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import vn.com.mcredit.digitallending.utils.LogUtils;

@Service
@RequiredArgsConstructor
public class KafKaProducer {

    @Value(value = "${kafka.topic.digital-create-case}")
    private String topicDLCreateCase;
    @Value(value = "${kafka.topic.digital-create-offer}")
    private String topicDLCreateOffer;

    private final KafkaTemplate<String, String> kafkaTemplate;

    public void sendMessageCreateCase(String message)
    {
        ListenableFuture<SendResult<String, String>> future = this.kafkaTemplate.send(topicDLCreateCase, message);

        future.addCallback(new ListenableFutureCallback<>() {
            @Override
            public void onSuccess(SendResult<String, String> result) {
                LogUtils.info("[KafKaProducer] Sent message Success");
            }

            @Override
            public void onFailure(Throwable ex) {
                LogUtils.error("[KafKaProducer] Unable to send message", ex.getMessage());
            }
        });
    }

    public void sendMessageCreateOffer(String message)
    {
        ListenableFuture<SendResult<String, String>> future = this.kafkaTemplate.send(topicDLCreateOffer, message);

        future.addCallback(new ListenableFutureCallback<>() {
            @Override
            public void onSuccess(SendResult<String, String> result) {
                LogUtils.info("[KafKaProducer] sendMessageCreateOffer Success");
            }

            @Override
            public void onFailure(Throwable ex) {
                LogUtils.error("[KafKaProducer] sendMessageCreateOffer error", ex.getMessage());
            }
        });
    }

    public String getTopicDLCreateCase() {
        return topicDLCreateCase;
    }


    public String getTopicDLCreateOffer() {
        return topicDLCreateOffer;
    }
}