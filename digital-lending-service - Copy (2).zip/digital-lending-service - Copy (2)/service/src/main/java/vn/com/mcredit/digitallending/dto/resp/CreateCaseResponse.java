package vn.com.mcredit.digitallending.dto.resp;

import lombok.Data;

@Data
public class CreateCaseResponse extends BpmBaseResponse{
    private Object data;
}
