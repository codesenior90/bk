package vn.com.mcredit.digitallending.dto.req;

import lombok.Data;

@Data
public class DisbursementInfoDTO {
    private Integer id;
    private Integer loansProfileId;
    private Integer customerId;
    private String disbursementType;
    private String accountNumber;
    private String accountName;
    private String bank;
    private String branchBank;
    private String mcReferenceNumber;
    private String remark;
    private String payPartnerCode;
    private String createdBy;
    private String updateBy;
    private String disbursementModel;
    private String smlCode;
    private String bankCode;
    private String bankName;
}
