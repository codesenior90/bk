package vn.com.mcredit.digitallending.dto.resp.ekyc;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Compares {
    @JsonProperty("0-1")
    private CompareModel s12;
    @JsonProperty("1-2")
    private CompareModel s23;
    @JsonProperty("0-2")
    private CompareModel s31;
}
