package vn.com.mcredit.digitallending.dto.resp.ekyc;

import lombok.Data;

@Data
public class ScreenScore {
    private Float screenDetectionScore;
    private Boolean screenDetectionResult;
}
