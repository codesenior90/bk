package com.carsaa.form;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.MultipartFile;

public class CarsaaForm {

	@NotNull
	@Size(min = 1, max = 9999)
	private String country;

	@NotNull
	@Size(min = 1, max = 9999)
	private String brand;

	@NotNull
	@Size(min = 1, max = 9999)
	private String model;

	@NotNull
	@Size(min = 1, max = 9999)
	private Long year;

	@NotNull
	@Size(min = 1, max = 9999)
	private String gearbox;

	private String fuel;
	private String madein;
	private String cartype;
	private String carseat;
	private String carcolor;

	@NotNull
	@Size(min = 1, max = 9999)
	private String state;

	@NotNull
	@Size(min = 1, max = 9999)
	private Double price;

	private Long kmused;

	@NotNull
	private String description;

	private MultipartFile carimage1;
	private MultipartFile carimage2;
	private MultipartFile carimage3;
	private MultipartFile carimage4;
	private MultipartFile carimage5;

	@NotNull
	@Size(min = 1, max = 9999)
	private List<String> imagehidden;
	private String image1hidden;
	private String image2hidden;
	private String image3hidden;
	private String image4hidden;
	private String image5hidden;

	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Long getYear() {
		return year;
	}
	public void setYear(Long year) {
		this.year = year;
	}
	public String getGearbox() {
		return gearbox;
	}
	public void setGearbox(String gearbox) {
		this.gearbox = gearbox;
	}
	public String getFuel() {
		return fuel;
	}
	public void setFuel(String fuel) {
		this.fuel = fuel;
	}
	public String getMadein() {
		return madein;
	}
	public void setMadein(String madein) {
		this.madein = madein;
	}
	public String getCartype() {
		return cartype;
	}
	public void setCartype(String cartype) {
		this.cartype = cartype;
	}
	public String getCarseat() {
		return carseat;
	}
	public void setCarseat(String carseat) {
		this.carseat = carseat;
	}
	public String getCarcolor() {
		return carcolor;
	}
	public void setCarcolor(String carcolor) {
		this.carcolor = carcolor;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Long getKmused() {
		return kmused;
	}
	public void setKmused(Long kmused) {
		this.kmused = kmused;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<String> getImagehidden() {
		return imagehidden;
	}
	public void setImagehidden(List<String> imagehidden) {
		this.imagehidden = imagehidden;
	}
	public MultipartFile getCarimage1() {
		return carimage1;
	}
	public void setCarimage1(MultipartFile carimage1) {
		this.carimage1 = carimage1;
	}
	public MultipartFile getCarimage2() {
		return carimage2;
	}
	public void setCarimage2(MultipartFile carimage2) {
		this.carimage2 = carimage2;
	}
	public MultipartFile getCarimage3() {
		return carimage3;
	}
	public void setCarimage3(MultipartFile carimage3) {
		this.carimage3 = carimage3;
	}
	public MultipartFile getCarimage4() {
		return carimage4;
	}
	public void setCarimage4(MultipartFile carimage4) {
		this.carimage4 = carimage4;
	}
	public MultipartFile getCarimage5() {
		return carimage5;
	}
	public void setCarimage5(MultipartFile carimage5) {
		this.carimage5 = carimage5;
	}
	public String getImage1hidden() {
		return image1hidden;
	}
	public void setImage1hidden(String image1hidden) {
		this.image1hidden = image1hidden;
	}
	public String getImage2hidden() {
		return image2hidden;
	}
	public void setImage2hidden(String image2hidden) {
		this.image2hidden = image2hidden;
	}
	public String getImage3hidden() {
		return image3hidden;
	}
	public void setImage3hidden(String image3hidden) {
		this.image3hidden = image3hidden;
	}
	public String getImage4hidden() {
		return image4hidden;
	}
	public void setImage4hidden(String image4hidden) {
		this.image4hidden = image4hidden;
	}
	public String getImage5hidden() {
		return image5hidden;
	}
	public void setImage5hidden(String image5hidden) {
		this.image5hidden = image5hidden;
	}



}
