package com.carsaa.form;

public class CarsForm {
	private String country;
	private String stateCountry;
	private String zip;
	private String maker;
	private String model;
	private String state;
	private Long minyear;
	private Long maxyear;
	private String gearbox;
	private Double minprice;
	private Double maxprice;
	private String q;
	private String sort;

	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getStateCountry() {
		return stateCountry;
	}
	public void setStateCountry(String stateCountry) {
		this.stateCountry = stateCountry;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Long getMinyear() {
		return minyear;
	}
	public void setMinyear(Long minyear) {
		this.minyear = minyear;
	}
	public Long getMaxyear() {
		return maxyear;
	}
	public void setMaxyear(Long maxyear) {
		this.maxyear = maxyear;
	}
	public String getGearbox() {
		return gearbox;
	}
	public void setGearbox(String gearbox) {
		this.gearbox = gearbox;
	}
	public Double getMinprice() {
		return minprice;
	}
	public void setMinprice(Double minprice) {
		this.minprice = minprice;
	}
	public Double getMaxprice() {
		return maxprice;
	}
	public void setMaxprice(Double maxprice) {
		this.maxprice = maxprice;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getQ() {
		return q;
	}
	public void setQ(String q) {
		this.q = q;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
}
