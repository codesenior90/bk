package com.carsaa.constant;

public enum TypeBrand {
	SHOW(1),
	HIDE(0);

	private final int levelCode;

    private TypeBrand(int levelCode) {
        this.levelCode = levelCode;
    }

    public int getLevelCode() {
        return this.levelCode;
    }
}
