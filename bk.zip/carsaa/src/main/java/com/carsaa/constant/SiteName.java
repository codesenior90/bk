package com.carsaa.constant;

public enum SiteName {
	CARS_COM("CARS.COM");
	private final String code;

    private SiteName(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
