package com.carsaa.constant;

public enum StateCar {
	NEW("New"),
	USED("Used");
	private final String code;

    private StateCar(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
