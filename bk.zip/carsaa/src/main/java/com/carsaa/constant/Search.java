package com.carsaa.constant;

public enum Search {
	MY(1),
	ALL(0);

	private final int levelCode;

    private Search(int levelCode) {
        this.levelCode = levelCode;
    }

    public int getLevelCode() {
        return this.levelCode;
    }
}
