package com.carsaa.constant;

public enum Role {
	ROLE_USER,ROLE_ADMIN
}
