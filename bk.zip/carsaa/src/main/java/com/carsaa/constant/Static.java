package com.carsaa.constant;

import java.util.regex.Pattern;

public interface Static {
	int n30000 = 30000;
	long l30000 = 30000;
	int n9999 = 9999;
	int n999 = 999;
	int n333 = 333;
	int n99 = 99;
	Integer zero = 0;
	Integer z39 = 39;
	Integer z40 = 40;
	Integer size = 3;
	String zeroS = "0";
	String blank = "";
	String separation = "/";
	String image = "image";
	String notimage = "not image";
	String n = "\n";

	//message
	String site = "you must enter your site";
	String brand = "you must enter brand your car";
	String model = "you must enter model your car";
	String year = "you must enter year of manufacture your car";
	String gear ="you must enter gear box your car";
	String state = "you must enter state your car";
	String price ="you must enter price your car";
	String title = "you must enter title car sale";
	String description = "you must enter description your car";
	String upload = "you must upload at least one image your car";
	String address = "you must enter your address";
	String state_country = "you must enter state country";
	String zipcode = "you must enter your zip code";
	String regexpzipcode = "^[0-9]{5}(?:-[0-9]{4})?$";
	String invalidzipcode = "invalid zip code";
	String carimage1 = "you must upload one image your car";
	String userpass = "Wrong username and password";

	String user = "you must enter username";
	String user_ = "username is only alphabets and numbers";
	String user_exist = "username is exist";
	String pass = "you must enter password";
	String email = "you must enter email";
	String fullname = "you must enter fullname";
	String mobile = "you must enter phone";

	String error = "error";
	String username = "username";
	String expireddate = "expireddate";

	String signup = "signup";
	String login = "login";
	String carsaa = "carsaa";
	String carsale = "carsale";
	String salecar = "salecar";
	String home = "redirect:/";
	String redirectsignup = "redirect:/signup";
	String redirectlogin = "redirect:/login";
	String redirectcarsaa = "redirect:/carsaa";
	String redirectmycar = "redirect:/mycar";
	String redirect = "redirect:";
	String success = "success";
	String cancel = "cancel";
	String approved = "approved";
	String reuse = "reuse";
	String approval_url = "approval_url";

    String znamealphanumber = "^[a-zA-Z0-9]*$";

    Pattern robustPattern = Pattern
	        .compile(
	                // Robust expression from before
	                "^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$"
	                // Area code, within or without parentheses,
	                // followed by groups of 3-4 numbers with or without hyphens
	                + "| ((\\(\\d{3}\\) ?)|(\\d{3}-))?\\d{3}-\\d{4}"
	                // (+) followed by 10-12 numbers
	                + "|^\\+\\d{10,12}"
	);

    String URL_PAYPAL_SUCCESS = "pay/success";
	String URL_PAYPAL_CANCEL = "pay/cancel";
	double pricecarsaa = 3;
	int totalDay = 90;
	String usd = "USD";
	String md5 = "MD5";
	String closed = "closed";

	String login_ = "/login";
	String loginForm = "loginForm";

	String Certified = "Certified";
	String New = "New";
	String Used = "Used";
}
