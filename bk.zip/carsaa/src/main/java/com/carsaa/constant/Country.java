package com.carsaa.constant;

public enum Country {
	US("US");
	private final String code;

    private Country(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
