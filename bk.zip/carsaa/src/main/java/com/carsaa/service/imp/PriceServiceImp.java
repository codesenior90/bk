package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.PriceDao;
import com.carsaa.entity.Price;
import com.carsaa.service.PriceService;

@Service
public class PriceServiceImp extends BaseServiceImpl<Price> implements PriceService {

	@Autowired
	PriceDao priceDao;

	@Override
	public List<Price> findByDelete(Integer delete) {
		return priceDao.findByDel(delete);
	}

}
