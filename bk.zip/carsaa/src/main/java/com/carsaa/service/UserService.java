package com.carsaa.service;

import com.carsaa.base.BaseService;
import com.carsaa.entity.User;

public interface UserService extends BaseService<User, Long> {
	User findByUsernameAndPasswordAndDelAndActive(String username, String password,Integer del,Integer active);
	User findByUsername(final String username);
}
