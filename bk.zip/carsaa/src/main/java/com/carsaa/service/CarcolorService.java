package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Carcolor;

public interface CarcolorService extends BaseService<Carcolor, Long> {
	List<Carcolor> findByDelete(Integer delete);
}
