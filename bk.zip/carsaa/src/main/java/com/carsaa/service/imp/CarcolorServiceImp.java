package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.CarcolorDao;
import com.carsaa.entity.Carcolor;
import com.carsaa.service.CarcolorService;

@Service
public class CarcolorServiceImp extends BaseServiceImpl<Carcolor> implements CarcolorService {

	@Autowired
	CarcolorDao carcolorDao;

	@Override
	public List<Carcolor> findByDelete(Integer delete) {
		return carcolorDao.findByDel(delete);
	}

}
