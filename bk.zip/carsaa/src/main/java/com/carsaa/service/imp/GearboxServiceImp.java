package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.GearboxDao;
import com.carsaa.entity.Gearbox;
import com.carsaa.service.GearboxService;

@Service
public class GearboxServiceImp extends BaseServiceImpl<Gearbox> implements GearboxService {

	@Autowired
	GearboxDao gearboxDao;

	@Override
	public List<Gearbox> findByDelete(Integer delete) {
		return gearboxDao.findByDel(delete);
	}

}
