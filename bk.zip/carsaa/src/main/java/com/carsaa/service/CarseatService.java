package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Carseat;

public interface CarseatService extends BaseService<Carseat, Long> {
	List<Carseat> findByDelete(Integer delete);
}
