package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.CartypeDao;
import com.carsaa.entity.Cartype;
import com.carsaa.service.CartypeService;

@Service
public class CartypeServiceImp extends BaseServiceImpl<Cartype> implements CartypeService {

	@Autowired
	CartypeDao cartypeDao;

	@Override
	public List<Cartype> findByDelete(Integer delete) {
		return cartypeDao.findByDel(delete);
	}

}
