package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.MadeinDao;
import com.carsaa.entity.Madein;
import com.carsaa.service.MadeinService;

@Service
public class MadeinServiceImp extends BaseServiceImpl<Madein> implements MadeinService {

	@Autowired
	MadeinDao madeinDao;

	@Override
	public List<Madein> findByDelete(Integer delete) {
		return madeinDao.findByDel(delete);
	}

}
