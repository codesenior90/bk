package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Gearbox;

public interface GearboxService extends BaseService<Gearbox, Long> {
	List<Gearbox> findByDelete(Integer delete);
}
