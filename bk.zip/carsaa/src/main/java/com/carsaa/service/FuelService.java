package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Fuel;

public interface FuelService extends BaseService<Fuel, Long> {
	List<Fuel> findByDelete(Integer delete);
}
