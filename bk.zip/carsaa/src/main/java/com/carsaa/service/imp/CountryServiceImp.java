package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.CountryDao;
import com.carsaa.entity.Country;
import com.carsaa.service.CountryService;

@Service
public class CountryServiceImp extends BaseServiceImpl<Country> implements CountryService {

	@Autowired
	CountryDao countryDao;

	@Override
	public List<Country> findByDelete(Integer delete) {
		return countryDao.findByDel(delete);
	}

	@Override
	public List<Country> findByDelAndIss(Integer delete, String iss) {
		return countryDao.findByDelAndIss(delete, iss);
	}

}
