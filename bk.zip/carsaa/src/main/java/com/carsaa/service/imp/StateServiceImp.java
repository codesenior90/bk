package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.StateDao;
import com.carsaa.entity.State;
import com.carsaa.service.StateService;

@Service
public class StateServiceImp extends BaseServiceImpl<State> implements StateService {

	@Autowired
	StateDao stateDao;

	@Override
	public List<State> findByDelete(Integer delete) {
		return stateDao.findByDel(delete);
	}

	@Override
	public State findByNameAndDel(String name, Integer del) {
		return stateDao.findByNameAndDel(name, del);
	}

}
