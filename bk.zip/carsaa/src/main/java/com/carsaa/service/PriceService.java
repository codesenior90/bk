package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Price;

public interface PriceService extends BaseService<Price, Long> {
	List<Price> findByDelete(Integer delete);
}
