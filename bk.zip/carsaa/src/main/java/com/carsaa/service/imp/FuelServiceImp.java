package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.FuelDao;
import com.carsaa.entity.Fuel;
import com.carsaa.service.FuelService;

@Service
public class FuelServiceImp extends BaseServiceImpl<Fuel> implements FuelService {

	@Autowired
	FuelDao fuelDao;

	@Override
	public List<Fuel> findByDelete(Integer delete) {
		return fuelDao.findByDel(delete);
	}

}
