package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.CarsCustomDao;
import com.carsaa.dao.CarsaaDao;
import com.carsaa.dto.CarsaaDto;
import com.carsaa.entity.Carsaa;
import com.carsaa.entity.pag.Paged;
import com.carsaa.entity.pag.Paging;
import com.carsaa.form.CarsForm;
import com.carsaa.service.CarsaaService;

@Service
@Transactional
public class CarsaaServiceImp extends BaseServiceImpl<Carsaa> implements CarsaaService {

	@Autowired
	CarsCustomDao carsCustomDao;

	@Autowired
	CarsaaDao carsaaDao;

	@Override
	public Carsaa findByTitle(String title) {
		return carsaaDao.findByTitle(title);
	}

	@Override
	public Page<Carsaa> findByActiveAndDelAndCreateuserOrderByIdDesc(Integer active, Integer del,
			String createuser, Pageable pageable) {
		return carsaaDao.findByActiveAndDelAndCreateuserOrderByIdDesc(active, del, createuser, pageable);
	}

	@Override
	public Paged<Carsaa> getPage(Integer active, Integer del, String createuser, int pageNumber, int size) {
//		PageRequest request = new PageRequest(pageNumber - 1, size);
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Carsaa> postPage = carsaaDao.findByActiveAndDelAndCreateuserOrderByIdDesc(active, del, createuser,
				request);
		return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public Carsaa findByUrl(String url) {
		return carsaaDao.findByUrl(url);
	}

	@Override
	public List<Carsaa> findTop5ByBrandAndModelAndActiveAndDelOrderByIdDesc(String brand, String model,Integer active, Integer del) {
		return carsaaDao.findTop5ByBrandAndModelAndActiveAndDelOrderByIdDesc(brand, model, active, del);
	}

	@Override
	public Paged<CarsaaDto> search(CarsForm carsForm, Integer active, Integer del, int pageNumber, int size) {
//		PageRequest request = new PageRequest(pageNumber - 1, size);
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<CarsaaDto> postPage = carsCustomDao.search(carsForm, active, del, request);
		return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public long countCarsaa(String username, Long id, int del) {
		return carsaaDao.countCarsaa(username, id, del);
	}

	@Override
	public int updateDel(int del, String username, Long id) {
		return carsaaDao.updateDel(del, username, id);
	}

	@Override
	public Carsaa findByUrlWebAndDel(String urlWeb, Integer del) {
		return carsaaDao.findByUrlWebAndDel(urlWeb, del);
	}

	@Override
	public Long findLastId(Long limit) {
		return carsaaDao.findLastId(limit);
	}

	@Override
	public List<Carsaa> findAllById(Long id) {
		return carsaaDao.findAllById(id);
	}

	@Override
	public Object[] findRandom(Integer limit) {
		return carsaaDao.findRandom(limit);
	}

}
