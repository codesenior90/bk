package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.State;

public interface StateService extends BaseService<State, Long> {
	List<State> findByDelete(Integer delete);
	State findByNameAndDel(String name, Integer del);
}
