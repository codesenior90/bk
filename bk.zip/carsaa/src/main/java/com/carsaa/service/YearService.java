package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Year;

public interface YearService extends BaseService<Year, Long> {
	List<Year> findByDelete(Integer delete);
}
