package com.carsaa.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.carsaa.base.BaseService;
import com.carsaa.dto.CarsaaDto;
import com.carsaa.entity.Carsaa;
import com.carsaa.entity.pag.Paged;
import com.carsaa.form.CarsForm;

public interface CarsaaService extends BaseService<Carsaa, Long> {

	Carsaa findByTitle(String title);

	Carsaa findByUrl(String url);

	Carsaa findByUrlWebAndDel(String urlWeb, Integer del);

	List<Carsaa> findTop5ByBrandAndModelAndActiveAndDelOrderByIdDesc(String brand, String model,Integer active, Integer del);

	Page<Carsaa> findByActiveAndDelAndCreateuserOrderByIdDesc(Integer active, Integer del, String createuser,
			Pageable pageable);

	public Paged<Carsaa> getPage(Integer active, Integer del, String createuser, int pageNumber, int size);

	public Paged<CarsaaDto> search(CarsForm carsForm, Integer active, Integer del, int pageNumber, int size);

	public long countCarsaa(String zname, Long id, int del);

	public int updateDel(int del, String zname, Long id);

	Long findLastId(Long limit);

	List<Carsaa> findAllById(Long id);

	Object[] findRandom(Integer limit);
}
