package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Brand;

public interface BrandService extends BaseService<Brand, Long> {
	Brand findFirst();
	List<Brand> findByDeleteAndIs(Integer delete, String name);
	List<Brand> findByDeleteAndName(Integer delete, String name);
	Brand findTop1ByDelAndValue(Integer delete, String value);
	List<Brand> findByDelAndIssAndType(Integer delete, String is, Integer type);
	List<Brand> findByKeyword(String keyword);
}
