package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.SiteDao;
import com.carsaa.entity.Site;
import com.carsaa.service.SiteService;

@Service
public class SiteServiceImp extends BaseServiceImpl<Site> implements SiteService {

	@Autowired
	SiteDao siteDao;

	@Override
	public List<Site> findByDelete(Integer delete) {
		return siteDao.findByDel(delete);
	}

	@Override
	public Site findByNameAndDel(String name, Integer delete) {
		return siteDao.findByNameAndDel(name, delete);
	}

}
