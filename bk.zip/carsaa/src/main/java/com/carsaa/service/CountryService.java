package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Country;

public interface CountryService extends BaseService<Country, Long> {
	List<Country> findByDelete(Integer delete);
	List<Country> findByDelAndIss(Integer delete, String iss);
}
