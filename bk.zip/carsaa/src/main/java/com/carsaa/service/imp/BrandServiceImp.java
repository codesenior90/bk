package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.BrandDao;
import com.carsaa.entity.Brand;
import com.carsaa.service.BrandService;

@Service
public class BrandServiceImp extends BaseServiceImpl<Brand> implements BrandService {

	@Autowired
	BrandDao brandDao;

	@Override
	public List<Brand> findByDeleteAndIs(Integer delete, String is) {
		return brandDao.findByDelAndIss(delete, is);
	}

	@Override
	public List<Brand> findByDeleteAndName(Integer delete, String name) {
		return brandDao.findByDelAndName(delete, name);
	}

	@Override
	public Brand findFirst() {
		return brandDao.findFirstByOrderByIdDesc();
	}

	@Override
	public Brand findTop1ByDelAndValue(Integer delete, String value) {
		return brandDao.findTop1ByDelAndValue(delete, value);
	}

	@Override
	public List<Brand> findByDelAndIssAndType(Integer delete, String is, Integer type) {
		return brandDao.findByDelAndIssAndType(delete, is, type);
	}

	@Override
	public List<Brand> findByKeyword(String keyword) {
		return brandDao.findByKeyword(keyword);
	}

}
