package com.carsaa.service.imp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.UserDAO;
import com.carsaa.entity.User;
import com.carsaa.service.UserService;

@Service
public class UserServiceImp extends BaseServiceImpl<User> implements UserService {

	@Autowired
	UserDAO userDao;

	@Override
	public User findByUsernameAndPasswordAndDelAndActive(String username, String password, Integer del,
			Integer active) {
		return userDao.findByUsernameAndPasswordAndDelAndActive(username, password, del, active);
	}

	@Override
	public User findByUsername(String username) {
		return userDao.findByUsername(username);
	}



}
