package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.YearDao;
import com.carsaa.entity.Year;
import com.carsaa.service.YearService;

@Service
public class YearServiceImp extends BaseServiceImpl<Year> implements YearService {

	@Autowired
	YearDao yearDao;

	@Override
	public List<Year> findByDelete(Integer delete) {
		return yearDao.findByDel(delete);
	}

}
