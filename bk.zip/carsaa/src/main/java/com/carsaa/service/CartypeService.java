package com.carsaa.service;

import java.util.List;

import com.carsaa.base.BaseService;
import com.carsaa.entity.Cartype;

public interface CartypeService extends BaseService<Cartype, Long> {
	List<Cartype> findByDelete(Integer delete);
}
