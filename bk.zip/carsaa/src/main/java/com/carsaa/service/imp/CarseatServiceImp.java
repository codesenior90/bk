package com.carsaa.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carsaa.base.BaseServiceImpl;
import com.carsaa.dao.CarseatDao;
import com.carsaa.entity.Carseat;
import com.carsaa.service.CarseatService;

@Service
public class CarseatServiceImp extends BaseServiceImpl<Carseat> implements CarseatService {

	@Autowired
	CarseatDao carseatDao;

	@Override
	public List<Carseat> findByDelete(Integer delete) {
		return carseatDao.findByDel(delete);
	}

}
