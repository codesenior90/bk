package com.carsaa.base;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Transactional;

/**
 *
* @ClassName: BaseServiceImpl
* @Description: TODO
* @author codefirst90@gmail.com
* @date May 23, 2022 12:12:06 PM
*
* @param <T>
 */
@NoRepositoryBean
public class BaseServiceImpl<T> implements BaseService<T, Long> {

	@Autowired
	BaseDao<T> baseDao;

	@Override
	public List<T> findAll() {
		return baseDao.findAll();
	}

	@Override
	public List<T> findAll(Sort sort) {
		return baseDao.findAll(sort);
	}

	@Override
	public T insert(T entity) {
		return baseDao.save(entity);
	}

	@Override
	public List<T> insert(Iterable<T> entities) {
		return baseDao.saveAll(entities);
	}

	@Override
	public Page<T> findAll(Pageable pageable) {
		return baseDao.findAll(pageable);
	}

	@Transactional
	@Override
	public T save(T entity) {
		return baseDao.save(entity);
	}

	@Override
	public List<T> save(Iterable<T> entities) {
		return baseDao.saveAll(entities);
	}

	@Override
	public T findOne(Long id) {
		return baseDao.getReferenceById(id);
	}

	@Override
	public boolean exists(Long id) {
		return baseDao.existsById(id);
	}

	@Override
	public Iterable<T> findAll(Iterable<Long> ids) {
		return baseDao.findAllById(ids);
	}

	@Override
	public long count() {
		return baseDao.count();
	}

	@Override
	public void delete(Long id) {
		baseDao.deleteById(id);
	}

	@Override
	public void deleteEntity(T entity) {
		baseDao.delete(entity);
	}

	@Override
	public void delete(Iterable<? extends T> entities) {
		baseDao.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		baseDao.deleteAll();
	}

}
