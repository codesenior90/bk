//package com.carsaa.cfg;
//
//public enum PaypalPaymentMethod {
//	credit_card, paypal
//}
