//package com.carsaa.cfg;
//
//public enum PaypalPaymentIntent {
//	sale, authorize, order
//}
