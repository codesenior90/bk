package com.carsaa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carsaa.service.CarsaaService;

@RestController
public class Ads {

	@Autowired
	CarsaaService carsaaService;

	@CrossOrigin
	@RequestMapping(value = { "/ads" }, method = RequestMethod.GET)
	public Object[] ads(
			@RequestParam(value = "limit", required = false, defaultValue = "5") Integer limit
			) {
		try {
			return carsaaService.findRandom(limit);
		} catch (Exception e) {
//			e.printStackTrace();
		}
		return null;
	}

}
