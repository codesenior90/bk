package com.carsaa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.carsaa.constant.Active;
import com.carsaa.constant.Country;
import com.carsaa.constant.Del;
import com.carsaa.constant.Static;
import com.carsaa.dto.AjaxResponseBody;
import com.carsaa.dto.CarsaaDto;
import com.carsaa.entity.Carsaa;
import com.carsaa.entity.pag.Paged;
import com.carsaa.form.CarsForm;
import com.carsaa.service.BrandService;
import com.carsaa.service.CarsaaService;
import com.carsaa.service.CountryService;
import com.carsaa.service.GearboxService;
import com.carsaa.service.PriceService;
import com.carsaa.service.StateService;
import com.carsaa.service.YearService;

@Controller
public class CarController {

	private static final Logger logger = LoggerFactory.getLogger(CarController.class);
	@Autowired
	BrandService brandService;
	@Autowired
	YearService yearService;
	@Autowired
	GearboxService gearboxService;
	@Autowired
	StateService stateService;
	@Autowired
	PriceService priceService;
	@Autowired
	CountryService countryService;

	@Value("${welcome.message}")
	private String message;

	@Autowired
	CarsaaService carsaaService;

	@RequestMapping(value = { "/" }, method = RequestMethod.GET)
	public String index(
			@ModelAttribute("carsForm") CarsForm carsForm,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size,
			Model model) {
        try {
        	model.addAttribute("countryList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Static.zeroS));
        	model.addAttribute("stateCountryList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Country.US.getCode()));
        	model.addAttribute("brandList", brandService.findByDeleteAndIs(Static.zero, Static.zeroS));
			model.addAttribute("yearList", yearService.findByDelete(Static.zero));
			model.addAttribute("gearboxList", gearboxService.findByDelete(Static.zero));
			model.addAttribute("stateList", stateService.findByDelete(Static.zero));
			model.addAttribute("priceList", priceService.findByDelete(Static.zero));
			Paged<CarsaaDto> cars = carsaaService.search(carsForm, Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(), page, size);
			model.addAttribute("cars", cars);
			model.addAttribute("url", "/cars?");
        } catch (Exception e) {
        	e.printStackTrace();
		}
		return "cars";
	}

	@RequestMapping(value = { "/cars" }, method = {RequestMethod.POST,RequestMethod.GET})
	public String post(
			@ModelAttribute("carsForm") CarsForm carsForm,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size,
			HttpServletRequest request,
			Model model) {
        try {
        	StringBuilder url = new StringBuilder(request.getRequestURI());
        	String query = request.getQueryString();
        	if(null != query && "" != query) {
        		url.append("?");
            	url.append(request.getQueryString());
        	}
        	int idx = url.lastIndexOf("&page");
        	if(idx >= 0) {
        		url.replace(url.lastIndexOf("&page"), url.length(), "");
        	}
        	int index = url.lastIndexOf("?page");
        	if(index >= 0) {
        		url.replace(url.lastIndexOf("?page"), url.length(), "");
        	}
        	if(url.indexOf("?") >=0) {
        		url.append("&");
        	} else {
        		url.append("?");
        	}
			model.addAttribute("brandList", brandService.findByDeleteAndIs(Static.zero, Static.zeroS));
			if(carsForm==null) {
			} else {
				String maker = carsForm.getMaker();
				if(maker == null) {
				} else {
					model.addAttribute("modelList", brandService.findByDeleteAndIs(Static.zero, maker));
				}
			}
        	model.addAttribute("countryList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Static.zeroS));
        	model.addAttribute("stateCountryList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Country.US.getCode()));
        	model.addAttribute("yearList", yearService.findByDelete(Static.zero));
			model.addAttribute("gearboxList", gearboxService.findByDelete(Static.zero));
			model.addAttribute("stateList", stateService.findByDelete(Static.zero));
			model.addAttribute("priceList", priceService.findByDelete(Static.zero));
			Paged<CarsaaDto> cars = carsaaService.search(carsForm, Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(), page, size);
			model.addAttribute("url", url.toString());
			model.addAttribute("cars", cars);
        } catch (Exception e) {
        	e.printStackTrace();
		}
		return "cars";
	}

	@RequestMapping(value = { "/cars-content" }, method = {RequestMethod.POST,RequestMethod.GET})
	public String cars_content(
			@ModelAttribute("carsForm") CarsForm carsForm,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size,
			HttpServletRequest request,
			Model model) {
        try {
        	StringBuilder url = new StringBuilder(request.getRequestURI());
        	String query = request.getQueryString();
        	if(null != query && "" != query) {
        		url.append("?");
            	url.append(request.getQueryString());
        	}
        	int idx = url.lastIndexOf("&page");
        	if(idx >= 0) {
        		url.replace(url.lastIndexOf("&page"), url.length(), "");
        	}
        	int index = url.lastIndexOf("?page");
        	if(index >= 0) {
        		url.replace(url.lastIndexOf("?page"), url.length(), "");
        	}
        	if(url.indexOf("?") >=0) {
        		url.append("&");
        	} else {
        		url.append("?");
        	}
			model.addAttribute("brandList", brandService.findByDeleteAndIs(Static.zero, Static.zeroS));
			if(carsForm==null) {
			} else {
				String maker = carsForm.getMaker();
				if(maker == null) {
				} else {
					model.addAttribute("modelList", brandService.findByDeleteAndIs(Static.zero, maker));
				}
			}
        	model.addAttribute("countryList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Static.zeroS));
        	model.addAttribute("stateCountryList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Country.US.getCode()));
        	model.addAttribute("yearList", yearService.findByDelete(Static.zero));
			model.addAttribute("gearboxList", gearboxService.findByDelete(Static.zero));
			model.addAttribute("stateList", stateService.findByDelete(Static.zero));
			model.addAttribute("priceList", priceService.findByDelete(Static.zero));
			Paged<CarsaaDto> cars = carsaaService.search(carsForm, Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(), page, size);
			model.addAttribute("url", url.toString());
			model.addAttribute("cars", cars);
        } catch (Exception e) {
        	e.printStackTrace();
		}
		return "cars-content";
	}

	@RequestMapping(value = { "/cars/{url}" }, method = RequestMethod.GET)
	public String detail(
			@RequestParam(value = "show", required = false, defaultValue = "1") int show,
			@PathVariable String url,
			Model model) {
        try {
        	Carsaa carsaa = carsaaService.findByUrl(url);
        	List<Carsaa> carsaaList = carsaaService.findTop5ByBrandAndModelAndActiveAndDelOrderByIdDesc(carsaa.getBrand(), carsaa.getModel(), Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode());
        	model.addAttribute("car", carsaa);
        	model.addAttribute("carList", carsaaList);
        	model.addAttribute("show", show);
        } catch (Exception e) {
        	e.printStackTrace();
		}
		return "detail";
	}

	@RequestMapping(value = { "/mycar" }, method = RequestMethod.GET)
	public String mycarsale(@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size,
			HttpSession session,
			Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if(usernameSession == null) {
				return Static.redirectlogin;
			}
//			Object expireddateSession = session.getAttribute(Static.expireddate);
//			Date expireddate = (Date)expireddateSession;
//			if (expireddate.before(new Date())) {
//			} else {
//
//			}
			String username = (String) usernameSession;
			model.addAttribute("carsaa", carsaaService.getPage(Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(),
					username, pageNumber, size));
			model.addAttribute("carsaaDel", carsaaService.getPage(Active.ACTIVE.getLevelCode(), Del.DEL.getLevelCode(),
					username, page, size));
			return Static.carsale;

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return Static.home;
	}

	@RequestMapping(value = "/closesale/{id}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public AjaxResponseBody closesale(@PathVariable("id") Long id,
			HttpSession session) throws Exception {
		AjaxResponseBody result = new AjaxResponseBody();
		result.setMsg(Static.blank);
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if(usernameSession == null) {
				return result;
			}
			String username = (String) usernameSession;
			long count = carsaaService.countCarsaa(username, id , Del.NOTDEL.getLevelCode());
			if(count > Static.zero) {
				int del = carsaaService.updateDel(Del.DEL.getLevelCode(), username, id);
				if(del > Static.zero) {
					result.setMsg(Static.closed);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = { "/carsale/{name}" }, method = RequestMethod.GET)
	public String javasenior13(
			@PathVariable("name") String name,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size,
			HttpSession session,
			Model model) {
		try {
			model.addAttribute("carsaa", carsaaService.getPage(Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(),
					name, pageNumber, size));
			model.addAttribute("carsaaDel", carsaaService.getPage(Active.ACTIVE.getLevelCode(), Del.DEL.getLevelCode(),
					name, page, size));
			return Static.salecar;

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return Static.home;
	}

	@RequestMapping(value = { "/contact" }, method = RequestMethod.GET)
	public String contact(
			Model model) {
        try {
        } catch (Exception e) {
        	e.printStackTrace();
		}
		return "contact";
	}

}
