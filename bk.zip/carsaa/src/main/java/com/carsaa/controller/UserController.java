package com.carsaa.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.carsaa.constant.Active;
import com.carsaa.constant.Country;
import com.carsaa.constant.Del;
import com.carsaa.constant.Static;
import com.carsaa.entity.User;
import com.carsaa.form.CarsForm;
import com.carsaa.form.UserForm;
import com.carsaa.service.CountryService;
import com.carsaa.service.UserService;
import com.carsaa.util.EmailValidatorApache;
import com.carsaa.util.Util;

@Controller
public class UserController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserService userService;

	@Autowired
	CountryService countryService;

//	@Autowired
//	private PaypalService paypalService;

	@RequestMapping(value = {Static.login_ }, method = { RequestMethod.POST, RequestMethod.GET })
	public String login(@ModelAttribute(Static.loginForm) CarsForm loginForm,
			@RequestParam(value = "username", required = false, defaultValue = "username") String username,
			@RequestParam(value = "password", required = false, defaultValue = "password") String password,
			HttpServletRequest request, HttpSession session, Model model) {
		try {
			User user = userService.findByUsernameAndPasswordAndDelAndActive(username.trim(), Util.password(password.trim()),
					Del.NOTDEL.getLevelCode(), Active.ACTIVE.getLevelCode());
			if (user == null) {
				model.addAttribute(Static.error, Static.userpass);
				return Static.login;
			} else {
				session.setAttribute(Static.username, username);
				Date expireddate = user.getExpireddate();
				session.setAttribute(Static.expireddate, expireddate);
				return Static.redirectcarsaa;
//				if (expireddate.after(new Date())) {
//					return Static.redirectcarsaa;
//				} else {
//					return Static.reuse;
//				}
			}
		} catch (Exception e) {
		}
		return Static.redirectcarsaa;
	}

	@RequestMapping(value = { "/logout" }, method = { RequestMethod.POST, RequestMethod.GET })
	public String logout(HttpSession session) {
		try {
			session.removeAttribute(Static.username);
		} catch (Exception e) {
		}
		return Static.home;
	}

	@RequestMapping(value = { "/signup" }, method = { RequestMethod.GET })
	public String signup(@ModelAttribute("userForm") UserForm userForm,Model model) {
		try {
        	model.addAttribute("stateList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Country.US.getCode()));
		} catch (Exception e) {
		}
		return Static.signup;
	}

	@RequestMapping(value = { "/signup" }, method = { RequestMethod.POST })
	public String signup(@ModelAttribute("userForm") UserForm userForm,
			@RequestParam(value = "username", required = false, defaultValue = "username") String username,
			@RequestParam(value = "password", required = false, defaultValue = "password") String password,
			HttpServletRequest request, HttpSession session, Model model) {
		try {
			StringBuilder str = new StringBuilder();
			if (userForm.getUsername() == null || userForm.getUsername().equals(Static.blank)) {
				str.append(Static.user);
				str.append(Static.n);
			} else {
				if (!Util.isAlpha(username)) {
					str.append(Static.user_);
					str.append(Static.n);
				}
				if (userService.findByUsername(username) != null) {
					str.append(Static.user_exist);
					str.append(Static.n);
				}
			}
			if (!EmailValidatorApache.isValid(userForm.getEmail())) {
				str.append(Static.email);
				str.append(Static.n);
			}
			if (userForm.getPassword() == null || userForm.getPassword().equals(Static.blank)) {
				str.append(Static.pass);
				str.append(Static.n);
			}
			if (userForm.getFullname() == null || userForm.getFullname().equals(Static.blank)) {
				str.append(Static.fullname);
				str.append(Static.n);
			}
			if (userForm.getMobile() == null || userForm.getMobile().equals(Static.blank)) {
				str.append(Static.mobile);
				str.append(Static.n);
			} else {
				if (!Util.isPhone(userForm.getMobile())) {
					str.append(Static.mobile);
					str.append(Static.n);
				}
			}
			if (userForm.getAddress() == null || userForm.getAddress().equals(Static.blank)) {
				str.append(Static.address);
				str.append(Static.n);
			}

			if (userForm.getState() == null || userForm.getState().equals(Static.blank)) {
				str.append(Static.state_country);
				str.append(Static.n);
			}
			if (userForm.getZip() == null || userForm.getZip().equals(Static.blank)) {
				str.append(Static.zipcode);
				str.append(Static.n);
			}
			if (str.length() > Static.zero) {
	        	model.addAttribute("stateList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Country.US.getCode()));
				model.addAttribute(Static.error, str);
				return Static.signup;
			} else {
//				User user = new User();
//				user.setActive(Active.ACTIVE.getLevelCode());
//				user.setDel(Del.NOTDEL.getLevelCode());
//				BeanUtils.copyProperties(userForm, user);
//				user.setPassword(Util.password(user.getPassword()));
//
//				user = userService.save(user);
				return Static.redirectcarsaa;
//				String cancelUrl = Util.getBaseURL(request) + Static.separation + Static.URL_PAYPAL_CANCEL;
//				String successUrl = Util.getBaseURL(request) + Static.separation + Static.URL_PAYPAL_SUCCESS;
//				try {
//					Payment payment = paypalService.createPayment(Static.pricecarsaa, Static.usd,
//							PaypalPaymentMethod.paypal, PaypalPaymentIntent.sale, String.valueOf(user.getId()),
//							cancelUrl, successUrl);
//					for (Links links : payment.getLinks()) {
//						if (links.getRel().equals(Static.approval_url)) {
//							return Static.redirect + links.getHref();
//						}
//					}
//				} catch (PayPalRESTException e) {
//					LOGGER.error(e.getMessage());
//				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.signup;
	}

//	@RequestMapping(value = { "/reuse" }, method = { RequestMethod.GET })
//	public String reuse(
//			HttpServletRequest request, HttpSession session, Model model) {
//		try {
//			Object usernameSession = session.getAttribute(Static.username);
//			if(usernameSession == null) {
//				return Static.redirectlogin;
//			}
//			String username = (String) usernameSession;
//			User user = userService.findByUsername(username);
//			if(user == null) {
//			} else {
//				String cancelUrl = Util.getBaseURL(request) + Static.separation + Static.URL_PAYPAL_CANCEL;
//				String successUrl = Util.getBaseURL(request) + Static.separation + Static.URL_PAYPAL_SUCCESS;
//				try {
//					Payment payment = paypalService.createPayment(Static.pricecarsaa, Static.usd,
//							PaypalPaymentMethod.paypal, PaypalPaymentIntent.sale, String.valueOf(user.getId()), cancelUrl,
//							successUrl);
//					for (Links links : payment.getLinks()) {
//						if (links.getRel().equals(Static.approval_url)) {
//							return Static.redirect + links.getHref();
//						}
//					}
//				} catch (PayPalRESTException e) {
//					LOGGER.error(e.getMessage());
//				}
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return Static.reuse;
//	}

//	@RequestMapping(value = { Static.URL_PAYPAL_CANCEL }, method = RequestMethod.GET)
//	public String cancelPay() {
//		return Static.home;
//	}
//
//	@RequestMapping(value = { Static.URL_PAYPAL_SUCCESS }, method = RequestMethod.GET)
//	public String successPay(@RequestParam("paymentId") String paymentId, @RequestParam("PayerID") String payerId,
//			HttpSession session, Model model) {
//		try {
//			Payment payment = paypalService.executePayment(paymentId, payerId);
//			if (payment.getState().equals(Static.approved)) {
//				List<Transaction> transactions = payment.getTransactions();
//				for (Transaction tr : transactions) {
//					Long userId = Long.valueOf(tr.getDescription());
//					User user = userService.findOne(userId);
//					if (user != null) {
//						Calendar now = Calendar.getInstance();
//						now.add(Calendar.DAY_OF_YEAR, Static.totalDay);
//						user.setExpireddate(now.getTime());
//						user.setActive(Active.ACTIVE.getLevelCode());
//						user = userService.save(user);
//						session.setAttribute(Static.username, user.getUsername());
//						Date expireddate = user.getExpireddate();
//						session.setAttribute(Static.expireddate, expireddate);
//					}
//				}
//				return Static.redirectcarsaa;
//			}
//		} catch (Exception e) {
//		}
//		return Static.home;
//	}

}
