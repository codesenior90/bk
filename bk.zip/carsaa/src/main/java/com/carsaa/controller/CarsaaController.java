package com.carsaa.controller;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import com.carsaa.constant.Active;
import com.carsaa.constant.Del;
import com.carsaa.constant.Static;
import com.carsaa.entity.Brand;
import com.carsaa.entity.Carsaa;
import com.carsaa.entity.User;
import com.carsaa.form.CarsaaForm;
import com.carsaa.service.BrandService;
import com.carsaa.service.CarcolorService;
import com.carsaa.service.CarsaaService;
import com.carsaa.service.CarseatService;
import com.carsaa.service.CartypeService;
import com.carsaa.service.CountryService;
import com.carsaa.service.FuelService;
import com.carsaa.service.GearboxService;
import com.carsaa.service.MadeinService;
import com.carsaa.service.StateService;
import com.carsaa.service.UserService;
import com.carsaa.service.YearService;
import com.carsaa.util.Util;

@Controller
public class CarsaaController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CarsaaController.class);

	@Autowired
	CountryService countryService;
	@Autowired
	BrandService brandService;
	@Autowired
	YearService yearService;
	@Autowired
	GearboxService gearboxService;
	@Autowired
	FuelService fuelService;
	@Autowired
	MadeinService madeinService;
	@Autowired
	CartypeService cartypeService;
	@Autowired
	CarseatService carseatService;
	@Autowired
	CarcolorService carcolorService;
	@Autowired
	StateService stateService;
	@Autowired
	CarsaaService carsaaService;
	@Autowired
	UserService userService;

	private static final String UPLOAD_FOLDER = Util.getPath("static/carsaa/");

	private static final int scaledWidth = 640;
	private static final int scaledHeight = 480;

	@RequestMapping(value = { "/carsaa" }, method = RequestMethod.GET)
	public String get(@ModelAttribute("carsaaForm") CarsaaForm carsaaForm, HttpSession session,Model model) {
		try {
			Object znameSession = session.getAttribute(Static.username);
			if(znameSession == null) {
				return Static.redirectlogin;
			}
        	model.addAttribute("countryList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Static.zeroS));
			model.addAttribute("brandList", brandService.findByDeleteAndIs(Static.zero, Static.zeroS));
			model.addAttribute("yearList", yearService.findByDelete(Static.zero));
			model.addAttribute("gearboxList", gearboxService.findByDelete(Static.zero));
			model.addAttribute("fuelList", fuelService.findByDelete(Static.zero));
			model.addAttribute("madeinList", madeinService.findByDelete(Static.zero));
			model.addAttribute("cartypeList", cartypeService.findByDelete(Static.zero));
			model.addAttribute("carseatList", carseatService.findByDelete(Static.zero));
			model.addAttribute("carcolorList", carcolorService.findByDelete(Static.zero));
			model.addAttribute("stateList", stateService.findByDelete(Static.zero));
		} catch (Exception e) {
		}
		return Static.carsaa;
	}

	@RequestMapping(value = "/getmodel/{name}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public Object getUsers(@PathVariable("name") String name) throws Exception {
		return brandService.findByDeleteAndIs(Static.zero, name);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/upload")
	@ResponseBody
	public Map<String, Object> uploadFile(@RequestParam(value = "image", required = false) MultipartFile image,
			@RequestParam(value = "key", required = false) String key) {
		Map<String, Object> result = new HashMap<>();
		if (null == key || "".equals(key)) {
			UUID uuid = UUID.randomUUID();
			StringBuilder sb1 = saveImage(image, uuid.toString());
			if (sb1 != null) {
				result.put("uuid", uuid);
				result.put("src", sb1.toString());
			}
		} else {
			StringBuilder sb1 = saveImage(image, key);
			if (sb1 != null) {
				result.put("uuid", key);
				result.put("src", sb1.toString());
			}
		}

		return result;
	}

	@Transactional
	@RequestMapping(value = { "/carsaa" }, method = RequestMethod.POST)
	public String post(HttpServletRequest request, @ModelAttribute("carsaaForm") CarsaaForm carsaaForm,
			HttpSession session,
			BindingResult bindingResult, Errors errors, Model model) throws Exception {
		try {
			if (null != errors && errors.getErrorCount() > 0) {
	        	model.addAttribute("countryList",countryService.findByDelAndIss(Del.NOTDEL.getLevelCode(), Static.zeroS));
				model.addAttribute("brandList", brandService.findByDeleteAndIs(Static.zero, Static.zeroS));
				model.addAttribute("yearList", yearService.findByDelete(Static.zero));
				model.addAttribute("gearboxList", gearboxService.findByDelete(Static.zero));
				model.addAttribute("fuelList", fuelService.findByDelete(Static.zero));
				model.addAttribute("madeinList", madeinService.findByDelete(Static.zero));
				model.addAttribute("cartypeList", cartypeService.findByDelete(Static.zero));
				model.addAttribute("carseatList", carseatService.findByDelete(Static.zero));
				model.addAttribute("carcolorList", carcolorService.findByDelete(Static.zero));
				model.addAttribute("stateList", stateService.findByDelete(Static.zero));
				return "carsaa";
			} else {
				Carsaa carsaa = new Carsaa();
				carsaa.setActive(Active.ACTIVE.getLevelCode());
				BeanUtils.copyProperties(carsaaForm, carsaa);
				carsaa.setDel(Del.NOTDEL.getLevelCode());

				Date now = new Date();
				carsaa.setCreatedate(now);
				carsaa.setUpdatedate(now);
				Object usernameSession = session.getAttribute(Static.username);
				if(usernameSession == null) {
					return Static.redirectlogin;
				}
				String username = (String) usernameSession;
				User user = userService.findByUsername(username);
				carsaa.setCreateuser(user.getUsername());
				carsaa.setUpdateuser(user.getUsername());
				carsaa.setMobile(user.getMobile());
				carsaa.setFullname(user.getFullname());
				carsaa.setExpireddate(user.getExpireddate());
				carsaa.setAddress(user.getAddress());

				Brand brand = brandService.findTop1ByDelAndValue(Del.NOTDEL.getLevelCode(), carsaa.getBrand());

				Brand modelBrand = brandService.findTop1ByDelAndValue(Del.NOTDEL.getLevelCode(), carsaa.getModel());

				StringBuilder titleStrBuilder = new StringBuilder();
				titleStrBuilder.append(brand.getName());
				titleStrBuilder.append(" ");
				titleStrBuilder.append(modelBrand.getName());
				titleStrBuilder.append(" ");
				titleStrBuilder.append(carsaa.getYear());
				titleStrBuilder.append(" ");
				titleStrBuilder.append(carsaa.getState());
				carsaa.setTitle(titleStrBuilder.toString());

				StringBuilder urlStrBuilder = new StringBuilder();
				urlStrBuilder.append(carsaa.getBrand());
				urlStrBuilder.append("-");
				urlStrBuilder.append(carsaa.getModel());
				urlStrBuilder.append("-");
				urlStrBuilder.append(carsaa.getYear());
				urlStrBuilder.append("-");
				urlStrBuilder.append(carsaa.getState());

				if (null == carsaaForm.getImagehidden()) {
				} else {
					for (String img : carsaaForm.getImagehidden()) {
						if (carsaa.getCarimage1() == null) {
							carsaa.setCarimage1(img);
						} else {
							if (carsaa.getCarimage2() == null) {
								carsaa.setCarimage2(img);
							} else {
								if (carsaa.getCarimage3() == null) {
									carsaa.setCarimage3(img);
								} else {
									if (carsaa.getCarimage4() == null) {
										carsaa.setCarimage4(img);
									} else {
										if(carsaa.getCarimage5() == null) {
											carsaa.setCarimage5(img);
										}
									}
								}
							}
						}
					}
				}

				carsaa = carsaaService.save(carsaa);
				carsaa.setTitle(carsaa.getTitle().replaceAll("-", " "));
				urlStrBuilder.append("-");
				urlStrBuilder.append(carsaa.getId());
				String url = urlStrBuilder.toString().toLowerCase();
				url = url.replaceAll(" ", "");
				carsaa.setUrl(url);
				carsaa = carsaaService.save(carsaa);
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		}
		return Static.home;
	}

	private StringBuilder saveImage(MultipartFile carimage1, String uuid) {
		if (!carimage1.isEmpty()) {
			try {
				if (carimage1.getContentType() != null
						&& !carimage1.getContentType().toLowerCase().startsWith(Static.image)) {
					throw new MultipartException(Static.notimage);
				}
				StringBuilder uploadFolderId = new StringBuilder();
				uploadFolderId.append(UPLOAD_FOLDER);
				uploadFolderId.append(Static.separation);
				uploadFolderId.append(uuid);
				uploadFolderId.append(Static.separation);

				if ((!Files.exists(Paths.get(uploadFolderId.toString())))) {
					Files.createDirectories(Paths.get(uploadFolderId.toString()));
				}
				BufferedImage originalImage = ImageIO.read(carimage1.getInputStream());

				int width = originalImage.getWidth();
				int height = originalImage.getHeight();
				if (width < scaledWidth) {
					BufferedImage newResizedImage = new BufferedImage(width, height, BufferedImage.SCALE_SMOOTH);
					Graphics2D g = newResizedImage.createGraphics();
					g.setComposite(AlphaComposite.Src);
					g.fillRect(0, 0, width, height);

					g.drawImage(originalImage, 0, 0, width, height, null);
					g.dispose();
					String s = carimage1.getOriginalFilename();
					String fileExtension = s.substring(s.lastIndexOf(".") + 1);

					ImageIO.write(newResizedImage, fileExtension,
							Paths.get(uploadFolderId.toString(), carimage1.getOriginalFilename()).toFile());
					StringBuilder url = new StringBuilder();
					url.append(uuid).append(Static.separation).append(s);
					return url;
				} else {
					float f = (float) width / scaledWidth;
					int scaleHeight = (int) Math.round(height / f);

					BufferedImage newResizedImage = new BufferedImage(scaledWidth, scaleHeight,
							BufferedImage.SCALE_SMOOTH);
					Graphics2D g = newResizedImage.createGraphics();
					g.setComposite(AlphaComposite.Src);
					g.fillRect(0, 0, scaledWidth, scaleHeight);

					g.drawImage(originalImage, 0, 0, scaledWidth, scaleHeight, null);
					g.dispose();
					String s = carimage1.getOriginalFilename();
					String fileExtension = s.substring(s.lastIndexOf(".") + 1);

					ImageIO.write(newResizedImage, fileExtension,
							Paths.get(uploadFolderId.toString(), carimage1.getOriginalFilename()).toFile());
					StringBuilder url = new StringBuilder();
					url.append(uuid).append(Static.separation).append(s);
					return url;
				}
//				BufferedImage newResizedImage = new BufferedImage(scaledWidth, scaledHeight,
//						BufferedImage.SCALE_SMOOTH);
//				Graphics2D g = newResizedImage.createGraphics();
//				g.setComposite(AlphaComposite.Src);
//				g.fillRect(0, 0, scaledWidth, scaledHeight);
//
//				g.drawImage(originalImage, 0, 0, scaledWidth, scaledHeight, null);qqqqq
//					Files.copy(file.getInputStream(),
//							Paths.get(uploadFolderId.toString(), file.getOriginalFilename()));
			} catch (IOException | RuntimeException e) {

			}
		}
		return null;
	}

}
