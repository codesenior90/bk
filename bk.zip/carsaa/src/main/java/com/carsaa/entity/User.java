package com.carsaa.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import com.carsaa.base.BaseModel;
import com.carsaa.constant.Static;

@Entity
public class User extends BaseModel {

	private static final long serialVersionUID = 1L;
	@Column(length = Static.n999)
	private String username;
	@Column(length = Static.n999)
	private String password;
	@Column(length = Static.n999)
	private String email;
	@Column(length = Static.n999)
	private String fullname;
	@Column(length = Static.n999)
	private String mobile;
	@Column(length = Static.n999)
	private String address;
	private String state;
	private String zip;
	private String zrole;
	private int active;
	private Date expireddate;


	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getZrole() {
		return zrole;
	}

	public void setZrole(String zrole) {
		this.zrole = zrole;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public Date getExpireddate() {
		return expireddate;
	}

	public void setExpireddate(Date expireddate) {
		this.expireddate = expireddate;
	}

	public enum zRole {
		z1(1),
		z2(2),
		z3(3);
		private final int code;

	    private zRole(int code) {
	        this.code = code;
	    }

	    public int getCode() {
	        return this.code;
	    }
	}

}
