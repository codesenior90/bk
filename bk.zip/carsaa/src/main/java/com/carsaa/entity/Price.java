package com.carsaa.entity;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import javax.persistence.Column;
import javax.persistence.Entity;

import com.carsaa.base.BaseModel;
import com.carsaa.constant.Static;


/**
 * The persistent class for the price database table.
 *
 */
@Entity
public class Price extends BaseModel {
	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String name;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDisplay() {
		DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator(',');
        String pattern = "$#,##0.###";
        DecimalFormat decimalFormat = new DecimalFormat(pattern, symbols);
        BigDecimal bigDecimal = new BigDecimal(this.name);
        String bigDecimalConvertedValue = decimalFormat.format(bigDecimal);
		return bigDecimalConvertedValue;
	}

}