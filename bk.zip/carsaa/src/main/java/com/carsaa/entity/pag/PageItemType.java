package com.carsaa.entity.pag;

public enum PageItemType {

    DOTS,
    PAGE

}
