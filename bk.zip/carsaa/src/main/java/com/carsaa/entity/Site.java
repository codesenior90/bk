package com.carsaa.entity;

import javax.persistence.Entity;

import com.carsaa.base.BaseModel;

@Entity
public class Site extends BaseModel {

	private static final long serialVersionUID = 1L;

	private String root;

	private String rootStr;

	private String url;

	private String name;

	public String getRoot() {
		return root;
	}

	public void setRoot(String root) {
		this.root = root;
	}

	public String getRootStr() {
		return rootStr;
	}

	public void setRootStr(String rootStr) {
		this.rootStr = rootStr;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
