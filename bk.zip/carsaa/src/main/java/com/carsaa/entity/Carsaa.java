package com.carsaa.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.SqlResultSetMapping;

import com.carsaa.base.BaseModel;
import com.carsaa.constant.Static;
import com.carsaa.dto.CarsaaDto;
import com.carsaa.util.Util;

/**
 * The persistent class for the car database table.
 *
 */

@SqlResultSetMapping( //
		name = "CarsaaDtoMapping", //
		classes = @ConstructorResult(targetClass = CarsaaDto.class,
				columns = { @ColumnResult(name = "id", type = Long.class),
                        @ColumnResult(name = "url"),
                        @ColumnResult(name = "carimage1"),
                        @ColumnResult(name = "carimage2"),
                        @ColumnResult(name = "carimage3"),
                        @ColumnResult(name = "carimage4"),
                        @ColumnResult(name = "carimage5"),
                        @ColumnResult(name = "title"),
                        @ColumnResult(name = "state"),
                        @ColumnResult(name = "price" ,type = Double.class),
                        @ColumnResult(name = "description"),
                        @ColumnResult(name = "createdate", type= Date.class),
                        @ColumnResult(name = "address"),
                        @ColumnResult(name = "fullname"),
                        @ColumnResult(name = "mobile"),
                        @ColumnResult(name = "country")
				}))
@Entity
public class Carsaa extends BaseModel {
	private static final long serialVersionUID = 1L;

	private Integer active;

	@Column(length = Static.n333)
	private String address;

//	@Column(length = Static.n333)
	private String brand;

//	@Column(length = Static.n333)
	private String carcolor;

//	@Column(length = Static.n333)
	private String carseat;

//	@Column(length = Static.n333)
	private String cartype;

	@Lob
//	@Column(length = Static.n9999)
	private String description;

//	@Column(length = Static.n333)
	private String madein;

	//
//	@Column(length = Static.n333)
	private String fuel;

	@Column(length = Static.n999)
	private String gearbox;

	@Column(length = Static.n999)
	private String model;

	private Double price;

	private String priceunit;

	private Long kmused;

	@Column(length = Static.n999)
	private String country;

	private String state;

	@Column(length = Static.n999)
	private String title;

	private Long year;

	@Column(length = Static.n333)
	private String carimage1;

	@Column(length = Static.n333)
	private String carimage2;

	@Column(length = Static.n333)
	private String carimage3;

	@Column(length = Static.n333)
	private String carimage4;

	@Column(length = Static.n333)
	private String carimage5;

	@Column(length = Static.n333)
	private String carimage6;

	@Column(length = Static.n333)
	private String carimage7;

	@Column(length = Static.n333)
	private String carimage8;

	@Column(length = Static.n333)
	private String carimage9;

	@Column(length = Static.n333)
	private String carimage10;

	@Column(length = Static.n333)
	private String carimage11;

	@Column(length = Static.n333)
	private String carimage12;

	@Column(length = Static.n333)
	private String carimage13;

	@Column(length = Static.n999)
	private String fullname;

	private String mobile;

	@Column(length = Static.n999)
	private String url;

	private Date expireddate;

	private String urlWeb;

	private Integer isWeb;



	public Integer getActive() {
		return this.active;
	}

	public void setActive(Integer active) {
		this.active = active;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBrand() {
		return this.brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getCarcolor() {
		return this.carcolor;
	}

	public void setCarcolor(String carcolor) {
		this.carcolor = carcolor;
	}

	public String getCarseat() {
		return this.carseat;
	}

	public void setCarseat(String carseat) {
		this.carseat = carseat;
	}

	public String getCartype() {
		return this.cartype;
	}

	public void setCartype(String cartype) {
		this.cartype = cartype;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMadein() {
		return this.madein;
	}

	public void setMadein(String madein) {
		this.madein = madein;
	}

	public String getFuel() {
		return this.fuel;
	}

	public void setFuel(String fuel) {
		this.fuel = fuel;
	}

	public String getGearbox() {
		return this.gearbox;
	}

	public void setGearbox(String gearbox) {
		this.gearbox = gearbox;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Double getPrice() {
		return this.price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getPriceunit() {
		return this.priceunit;
	}

	public void setPriceunit(String priceunit) {
		this.priceunit = priceunit;
	}

	public Long getKmused() {
		return kmused;
	}

	public void setKmused(Long kmused) {
		this.kmused = kmused;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Long getYear() {
		return this.year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	public String getCarimage1() {
		return carimage1;
	}

	public void setCarimage1(String carimage1) {
		this.carimage1 = carimage1;
	}

	public String getCarimage2() {
		return carimage2;
	}

	public void setCarimage2(String carimage2) {
		this.carimage2 = carimage2;
	}

	public String getCarimage3() {
		return carimage3;
	}

	public void setCarimage3(String carimage3) {
		this.carimage3 = carimage3;
	}

	public String getCarimage4() {
		return carimage4;
	}

	public void setCarimage4(String carimage4) {
		this.carimage4 = carimage4;
	}

	public String getCarimage5() {
		return carimage5;
	}

	public void setCarimage5(String carimage5) {
		this.carimage5 = carimage5;
	}

	public String getCarimage6() {
		return carimage6;
	}

	public void setCarimage6(String carimage6) {
		this.carimage6 = carimage6;
	}

	public String getCarimage7() {
		return carimage7;
	}

	public void setCarimage7(String carimage7) {
		this.carimage7 = carimage7;
	}

	public String getCarimage8() {
		return carimage8;
	}

	public void setCarimage8(String carimage8) {
		this.carimage8 = carimage8;
	}

	public String getCarimage9() {
		return carimage9;
	}

	public void setCarimage9(String carimage9) {
		this.carimage9 = carimage9;
	}

	public String getCarimage10() {
		return carimage10;
	}

	public void setCarimage10(String carimage10) {
		this.carimage10 = carimage10;
	}

	public String getCarimage11() {
		return carimage11;
	}

	public void setCarimage11(String carimage11) {
		this.carimage11 = carimage11;
	}

	public String getCarimage12() {
		return carimage12;
	}

	public void setCarimage12(String carimage12) {
		this.carimage12 = carimage12;
	}

	public String getCarimage13() {
		return carimage13;
	}

	public void setCarimage13(String carimage13) {
		this.carimage13 = carimage13;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Date getExpireddate() {
		return expireddate;
	}

	public void setExpireddate(Date expireddate) {
		this.expireddate = expireddate;
	}

	public String getUrlWeb() {
		return urlWeb;
	}

	public void setUrlWeb(String urlWeb) {
		this.urlWeb = urlWeb;
	}

	public Integer getIsWeb() {
		return isWeb;
	}

	public void setIsWeb(Integer isWeb) {
		this.isWeb = isWeb;
	}

	public String getPriceDisplay() {
		return Util.getPriceDisplay(this.price);
	}

	public String getDateDisplay() {
		return Util.getDateDisplay(this.getCreatedate());
	}

	public String getExpireddateDisplay() {
		return Util.getExpireddateDisplay(this.expireddate);
	}
}