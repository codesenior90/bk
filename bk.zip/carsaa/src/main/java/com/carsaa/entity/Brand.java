package com.carsaa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import com.carsaa.base.BaseModel;
import com.carsaa.constant.Static;


/**
 * The persistent class for the brand database table.
 *
 */
@Entity
public class Brand extends BaseModel {

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String iss;

	@Column(length = Static.n999)
	private String name;

	@Column(length = Static.n999)
	private String value;

	private Integer type;

	public String getIss() {
		return iss;
	}

	public void setIss(String iss) {
		this.iss = iss;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}