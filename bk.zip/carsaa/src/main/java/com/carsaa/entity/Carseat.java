package com.carsaa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import com.carsaa.base.BaseModel;
import com.carsaa.constant.Static;


/**
 * The persistent class for the carseat database table.
 *
 */
@Entity
public class Carseat extends BaseModel {
	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String name;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}