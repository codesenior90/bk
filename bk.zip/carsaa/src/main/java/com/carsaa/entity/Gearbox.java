package com.carsaa.entity;

import javax.persistence.Entity;

import com.carsaa.base.BaseModel;


/**
 * The persistent class for the gearbox database table.
 *
 */
@Entity
public class Gearbox extends BaseModel {
	private static final long serialVersionUID = 1L;

	private String name;

	private String value;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}