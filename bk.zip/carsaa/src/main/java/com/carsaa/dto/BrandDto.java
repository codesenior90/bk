package com.carsaa.dto;

import java.util.List;

import com.carsaa.entity.Brand;

public class BrandDto {

	private String name;

	private String value;

	private List<Brand> brandList;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<Brand> getBrandList() {
		return brandList;
	}

	public void setBrandList(List<Brand> brandList) {
		this.brandList = brandList;
	}

}
