package com.carsaa.dto;

import java.util.Date;

import com.carsaa.util.Util;

public class CarsaaDto {

	private Long id;

	private String url;

	private String carimage1;

	private String carimage2;

	private String carimage3;

	private String carimage4;

	private String carimage5;

	private String title;

	private String state;

	private Double price;

	private String description;

	private Date createdate;

	private String address;

	private String fullname;

	private String mobile;

	private Date expireddate;

	private String country;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getCarimage1() {
		return carimage1;
	}

	public void setCarimage1(String carimage1) {
		this.carimage1 = carimage1;
	}

	public String getCarimage2() {
		return carimage2;
	}

	public void setCarimage2(String carimage2) {
		this.carimage2 = carimage2;
	}

	public String getCarimage3() {
		return carimage3;
	}

	public void setCarimage3(String carimage3) {
		this.carimage3 = carimage3;
	}

	public String getCarimage4() {
		return carimage4;
	}

	public void setCarimage4(String carimage4) {
		this.carimage4 = carimage4;
	}

	public String getCarimage5() {
		return carimage5;
	}

	public void setCarimage5(String carimage5) {
		this.carimage5 = carimage5;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Date getExpireddate() {
		return expireddate;
	}

	public void setExpireddate(Date expireddate) {
		this.expireddate = expireddate;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public CarsaaDto(Long id, String url, String carimage1, String carimage2, String carimage3, String carimage4,
			String carimage5, String title, String state, Double price, String description, Date createdate,
			String address, String fullname, String mobile, String country) {
		super();
		this.id = id;
		this.url = url;
		this.carimage1 = carimage1;
		this.carimage2 = carimage2;
		this.carimage3 = carimage3;
		this.carimage4 = carimage4;
		this.carimage5 = carimage5;
		this.title = title;
		this.state = state;
		this.price = price;
		this.description = description;
		this.createdate = createdate;
		this.address = address;
		this.fullname = fullname;
		this.mobile = mobile;
		this.country = country;
	}

	public String getPriceDisplay() {
		return Util.getPriceDisplay(this.price);
	}

	public String getDateDisplay() {
		return Util.getDateDisplay(this.getCreatedate());
	}

	public String getExpireddateDisplay() {
		return Util.getExpireddateDisplay(this.expireddate);
	}

	public String getDescriptionDisplay() {
		return Util.getDescriptionDisplay(this.description);
	}

}
