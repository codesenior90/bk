package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Price;

public interface PriceDao extends BaseDao<Price> {
	List<Price> findByDel(Integer delete);
}
