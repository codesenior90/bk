package com.carsaa.dao;

import java.util.List;

import com.carsaa.entity.Carsaa;

public interface CustomCarsaaDao {
	 List<Carsaa> search(String terms, int limit, int offset);
}
