package com.carsaa.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.carsaa.dto.CarsaaDto;
import com.carsaa.form.CarsForm;

@Repository
public class CarsCustomDaoImp implements CarsCustomDao {

	@PersistenceContext
	private EntityManager em;

	@Override
	public Page<CarsaaDto> search(CarsForm carsForm, Integer active, Integer del, Pageable pageable) {
		int pageNumber = pageable.getPageNumber();
		int pageSize = pageable.getPageSize();
		StringBuilder sql = new StringBuilder();
		sql.append("select c.id id,c.url url,c.carimage1 carimage1,c.carimage2 carimage2,c.carimage3 carimage3,c.carimage4 carimage4,c.carimage5 carimage5,c.title title,c.state state,c.price price,c.description description,c.createdate createdate,c.address address,u.fullname fullname,u.mobile mobile,c.country country");
		sql.append(" from carsaa c left join User u on u.username = c.createuser where 1=1 and c.active = 1 and c.del = 0  ");
		StringBuilder sqlTotal = new StringBuilder("select count(*) from Carsaa c left join User u on u.username = c.createuser where 1=1 and c.active = 1 and c.del = 0 ");
//		sql.append(" and c.expireddate > :expireddate");
//		sqlTotal.append(" and c.expireddate > :expireddate");
		if (null == carsForm.getQ() | "".equals(carsForm.getQ())) {
			if (null == carsForm.getStateCountry() | "".equals(carsForm.getStateCountry())) {

			} else {
				sql.append(" and u.state = :stateCountry");
				sqlTotal.append(" and u.state = :stateCountry");
			}
			if (null == carsForm.getCountry() | "".equals(carsForm.getCountry())) {

			} else {
				sql.append(" and c.country = :country");
				sqlTotal.append(" and c.country = :country");
			}
			if (null == carsForm.getMaker() | "".equals(carsForm.getMaker())) {

			} else {
				sql.append(" and c.brand = :maker");
				sqlTotal.append(" and c.brand = :maker");
			}
			if (null == carsForm.getModel() | "".equals(carsForm.getModel())) {

			} else {
				sql.append(" and c.model = :model");
				sqlTotal.append(" and c.model = :model");
			}
			if (null == carsForm.getState() | "".equals(carsForm.getState())) {

			} else {
				sql.append(" and c.state = :state");
				sqlTotal.append(" and c.state = :state");
			}
			if (null == carsForm.getMinyear()) {

			} else {
				sql.append(" and c.year >= :minyear");
				sqlTotal.append(" and c.year >= :minyear");
			}
			if (null == carsForm.getMaxyear()) {

			} else {
				sql.append(" and c.year <= :maxyear");
				sqlTotal.append(" and c.year <= :maxyear");
			}
			if (null == carsForm.getGearbox() | "".equals(carsForm.getGearbox())) {

			} else {
				sql.append(" and c.gearbox = :gearbox");
				sqlTotal.append(" and c.gearbox = :gearbox");
			}
			if (null == carsForm.getMinprice()) {

			} else {
				sql.append(" and c.price >= :minprice");
				sqlTotal.append(" and c.price >= :minprice");
			}
			if (null == carsForm.getMaxprice()) {

			} else {
				sql.append(" and c.price <= :maxprice");
				sqlTotal.append(" and c.price <= :maxprice");
			}

			if (null == carsForm.getSort() | "".equals(carsForm.getSort())) {
				sql.append(" ORDER BY c.id DESC");
				sqlTotal.append(" ORDER BY c.id DESC");
			} else {
				String sort = carsForm.getSort();
				if (sort.equals("price")) {
					sql.append(" ORDER BY c.price asc");
					sqlTotal.append(" ORDER BY c.price asc");
				}

				if (sort.equals("price_desc")) {
					sql.append(" ORDER BY c.price desc");
					sqlTotal.append(" ORDER BY c.price desc");
				}

				if (sort.equals("year")) {
					sql.append(" ORDER BY c.year asc");
					sqlTotal.append(" ORDER BY c.year asc");
				}
				if (sort.equals("year_desc")) {
					sql.append(" ORDER BY c.year desc");
					sqlTotal.append(" ORDER BY c.year desc");
				}
			}
		} else {
			sql.append(" and (c.title like CONCAT('%', :q, '%') or c.gearbox like CONCAT('%', :q, '%') or c.description like CONCAT('%', :q, '%') ) ");
			sqlTotal.append(" and (c.title like CONCAT('%', :q, '%') or c.gearbox like CONCAT('%', :q, '%') or c.description like CONCAT('%', :q, '%') ) ");
		}


		Query query = em.createNativeQuery(sql.toString(), "CarsaaDtoMapping");
		Query queryTotal = em.createQuery(sqlTotal.toString());
//		Date now = new Date();
//		query.setParameter("expireddate", now);
//		queryTotal.setParameter("expireddate", now);
		if (null == carsForm.getQ() | "".equals(carsForm.getQ())) {
			if (null == carsForm.getStateCountry() | "".equals(carsForm.getStateCountry())) {

			} else {
				query.setParameter("stateCountry", carsForm.getStateCountry());
				queryTotal.setParameter("stateCountry", carsForm.getStateCountry());
			}
			if (null == carsForm.getCountry() | "".equals(carsForm.getCountry())) {

			} else {
				query.setParameter("country", carsForm.getCountry());
				queryTotal.setParameter("country", carsForm.getCountry());
			}
			if (null == carsForm.getMaker() | "".equals(carsForm.getMaker())) {

			} else {
				query.setParameter("maker", carsForm.getMaker());
				queryTotal.setParameter("maker", carsForm.getMaker());
			}

			if (null == carsForm.getModel() | "".equals(carsForm.getModel())) {

			} else {
				query.setParameter("model", carsForm.getModel());
				queryTotal.setParameter("model", carsForm.getModel());
			}
			if (null == carsForm.getState() | "".equals(carsForm.getState())) {

			} else {
				query.setParameter("state", carsForm.getState());
				queryTotal.setParameter("state", carsForm.getState());
			}
			if (null == carsForm.getGearbox() | "".equals(carsForm.getGearbox())) {

			} else {
				query.setParameter("gearbox", carsForm.getGearbox());
				queryTotal.setParameter("gearbox", carsForm.getGearbox());
			}
			if (null == carsForm.getMinprice()) {

			} else {
				query.setParameter("minprice", carsForm.getMinprice());
				queryTotal.setParameter("minprice", carsForm.getMinprice());
			}
			if (null == carsForm.getMaxprice()) {

			} else {
				query.setParameter("maxprice", carsForm.getMaxprice());
				queryTotal.setParameter("maxprice", carsForm.getMaxprice());
			}
			if (null == carsForm.getMinyear()) {

			} else {
				query.setParameter("minyear", carsForm.getMinyear());
				queryTotal.setParameter("minyear", carsForm.getMinyear());
			}
			if (null == carsForm.getMaxyear()) {

			} else {
				query.setParameter("maxyear", carsForm.getMaxyear());
				queryTotal.setParameter("maxyear", carsForm.getMaxyear());
			}
		} else {
			query.setParameter("q", carsForm.getQ());
			queryTotal.setParameter("q", carsForm.getQ());
		}

		query.setFirstResult((pageNumber) * pageSize);
		query.setMaxResults(pageSize);
		List<CarsaaDto> carsaaList = query.getResultList();
		Long countResult = (Long) queryTotal.getSingleResult();
		return new PageImpl<>(carsaaList, pageable, countResult);
	}
}
