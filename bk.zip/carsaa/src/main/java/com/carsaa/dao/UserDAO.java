package com.carsaa.dao;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.User;

public interface UserDAO extends BaseDao<User>{

	User findByUsernameAndPasswordAndDelAndActive(String username, String password,Integer del,Integer active);
	User findByUsername(final String username);

}
