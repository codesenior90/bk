package com.carsaa.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Brand;

public interface BrandDao extends BaseDao<Brand> {
	Brand findFirstByOrderByIdDesc();
	List<Brand> findByDelAndIss(Integer delete, String is);
	List<Brand> findByDelAndName(Integer delete, String name);

	@Query(value = "select * from brand b where b.value like :keyword%", nativeQuery = true)
	List<Brand> findByKeyword(@Param("keyword") String keyword);

	Brand findTop1ByDelAndValue(Integer delete, String value);

	List<Brand> findByDelAndIssAndType(Integer delete, String is, Integer type);
}
