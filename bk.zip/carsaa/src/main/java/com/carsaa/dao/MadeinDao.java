package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Madein;

public interface MadeinDao extends BaseDao<Madein> {
	List<Madein> findByDel(Integer delete);
}
