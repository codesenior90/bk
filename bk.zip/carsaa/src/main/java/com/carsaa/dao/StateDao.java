package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.State;

public interface StateDao extends BaseDao<State> {
	List<State> findByDel(Integer delete);
	State findByNameAndDel(String name, Integer del);
}
