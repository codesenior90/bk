package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Site;

public interface SiteDao extends BaseDao<Site> {
	List<Site> findByDel(Integer delete);
	Site findByNameAndDel(String name, Integer delete);
}
