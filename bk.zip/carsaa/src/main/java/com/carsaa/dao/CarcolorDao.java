package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Carcolor;

public interface CarcolorDao extends BaseDao<Carcolor> {
	List<Carcolor> findByDel(Integer delete);
}
