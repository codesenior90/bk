package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Carseat;

public interface CarseatDao extends BaseDao<Carseat> {
	List<Carseat> findByDel(Integer delete);
}
