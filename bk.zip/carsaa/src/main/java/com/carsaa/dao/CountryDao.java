package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Country;

public interface CountryDao extends BaseDao<Country> {
	List<Country> findByDel(Integer delete);
	List<Country> findByDelAndIss(Integer delete, String iss);
}
