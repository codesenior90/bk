package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Fuel;

public interface FuelDao extends BaseDao<Fuel> {
	List<Fuel> findByDel(Integer delete);
}
