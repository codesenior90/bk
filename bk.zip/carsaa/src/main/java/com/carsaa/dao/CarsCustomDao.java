package com.carsaa.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.carsaa.dto.CarsaaDto;
import com.carsaa.form.CarsForm;

public interface CarsCustomDao {

	Page<CarsaaDto> search(CarsForm carsForm, Integer active, Integer del,
			Pageable pageable);

}
