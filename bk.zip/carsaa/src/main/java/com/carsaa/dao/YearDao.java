package com.carsaa.dao;

import java.util.List;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Year;

public interface YearDao extends BaseDao<Year> {
	List<Year> findByDel(Integer delete);
}
