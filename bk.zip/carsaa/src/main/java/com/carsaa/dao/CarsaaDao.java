package com.carsaa.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.carsaa.base.BaseDao;
import com.carsaa.entity.Carsaa;

public interface CarsaaDao extends BaseDao<Carsaa> {

	Carsaa findByTitle(String title);

	Carsaa findByUrl(String url);

	Carsaa findByUrlWebAndDel(String urlWeb, Integer del);

	List<Carsaa> findTop5ByBrandAndModelAndActiveAndDelOrderByIdDesc(String brand, String model,Integer active, Integer del);

	Page<Carsaa> findByActiveAndDelAndCreateuserOrderByIdDesc(Integer active, Integer del, String createuser,
			Pageable pageable);

	@Query("SELECT COUNT(c) FROM Carsaa c inner join User u on u.username = c.createuser where 1=1 and u.username=:username and c.id=:id and c.del=:del")
    long countCarsaa(@Param("username") String username,@Param("id") Long id, @Param("del") int del);

	@Modifying
    @Query("UPDATE Carsaa c SET c.del = :del, c.updateuser = :username WHERE c.id = :id")
    int updateDel(@Param("del") int del, @Param("username") String username, @Param("id") Long id);

	@Query(value = "select sub.id from (SELECT id FROM carsaa v order by v.id desc limit ?1) as sub order by sub.id asc limit 1", nativeQuery = true)
	Long findLastId(Long limit);


	@Query("SELECT v FROM Carsaa v WHERE v.id < ?1")
	List<Carsaa> findAllById(Long id);


	@Query(value = "SELECT v.url FROM carsaa v ORDER BY RAND() limit ?1", nativeQuery = true)
	Object[] findRandom(Integer limit);
}
