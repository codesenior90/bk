package com.carsaa.job;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.carsaa.constant.Active;
import com.carsaa.constant.Del;
import com.carsaa.constant.IsWeb;
import com.carsaa.constant.SiteName;
import com.carsaa.constant.StateCar;
import com.carsaa.constant.Static;
import com.carsaa.entity.Brand;
import com.carsaa.entity.Carsaa;
import com.carsaa.entity.Site;
import com.carsaa.entity.State;
import com.carsaa.service.BrandService;
import com.carsaa.service.CarsaaService;
import com.carsaa.service.CountryService;
import com.carsaa.service.SiteService;
import com.carsaa.service.StateService;
import com.carsaa.util.Util;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlImage;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.util.FalsifyingWebConnection;

@Component
public class GetCars {

	private static final Logger log = LoggerFactory.getLogger(GetCars.class);

	private static final boolean TRUE = true;
	private static final boolean FALSE = false;
	private static final int TIMEOUT = 60000;
	public static final long SL = 10000;
	private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 Mobile Safari/537.36";

	private final static String STR_ = " ";

	private static final String UPLOAD_FOLDER = Util.getPath("static/carsaa/");
	private static final String IMG_FOLDER = "/carsaa/";
	private static final int scaledWidth = 640;
	private static final int scaledHeight = 480;

	@Autowired
	SiteService siteService;
	@Autowired
	CarsaaService carsaaService;
	@Autowired
	StateService stateService;

	@Autowired
	CountryService countryService;

	@Autowired
	BrandService brandService;

	@Scheduled(initialDelay = 3 * 1000, fixedDelay = 60 * 1000)
	public void get() {
//		log.info("start GetCars");
		try {
			Site site = siteService.findByNameAndDel(SiteName.CARS_COM.getCode(), Del.NOTDEL.getLevelCode());
			if (site != null) {
				try {
					String url = site.getUrl();

					WebClient webClient = new WebClient(BrowserVersion.CHROME);

					webClient.setWebConnection(new FalsifyingWebConnection(webClient) {
						@Override
						public WebResponse getResponse(WebRequest request) throws IOException {
							if (!request.getUrl().getHost().toLowerCase().contains(site.getRootStr())) {
								return createWebResponse(request, "", "application/javascript");
							}

							return super.getResponse(request);
						}
					});

					webClient.getOptions().setUseInsecureSSL(TRUE);
					webClient.getOptions().setRedirectEnabled(TRUE);
					webClient.getOptions().setJavaScriptEnabled(TRUE);
					webClient.getOptions().setCssEnabled(FALSE);
					webClient.getOptions().setThrowExceptionOnScriptError(FALSE);
					webClient.getOptions().setThrowExceptionOnFailingStatusCode(FALSE);
					webClient.getCookieManager().setCookiesEnabled(TRUE);
					webClient.getOptions().setTimeout(TIMEOUT);
					webClient.getOptions().setScreenHeight(768);
					webClient.getOptions().setScreenWidth(1024);
					webClient.getOptions().setDownloadImages(FALSE);
//					webClient.getBrowserVersion().setUserAgent(USER_AGENT);
					// webClient.setJavaScriptTimeout(8000);
					// webClient.waitForBackgroundJavaScript(500);
					// webClient.getOptions().setDownloadImages(false);
					// webClient.getOptions().setGeolocationEnabled(false);
					// webClient.getOptions().setAppletEnabled(false);

					HtmlPage page = webClient.getPage(url);
					Thread.sleep(SL);
					webClient.getOptions().setJavaScriptEnabled(FALSE);
					List<HtmlElement> alist = page
							.getByXPath("//a[contains(@class, 'vehicle-card-visited-tracking-link')]");
					List<Carsaa> carsaalist = new ArrayList<Carsaa>();
					for (HtmlElement e : alist) {
						try {
							String href = e.getAttribute("href");
							url = site.getRoot().concat(href);
							Carsaa carsaaExits = carsaaService.findByUrlWebAndDel(url, Del.NOTDEL.getLevelCode());
							if (carsaaExits == null) {
//								page = webClient.getPage(url);
								page = webClient.getPage(url);
								Carsaa carsaa = new Carsaa();
//								HtmlElement address = e.getFirstByXPath("//div[contains(@class, 'miles-from')]");
//								carsaa.setAddress(address.asNormalizedText().trim());
								carsaa.setCountry("US");
								carsaa.setActive(Active.ACTIVE.getLevelCode());
								carsaa.setDel(Del.NOTDEL.getLevelCode());
								carsaa.setIsWeb(IsWeb.ISWEB.getLevelCode());
								carsaa.setUrlWeb(url);

								HtmlElement newusedE = page.getFirstByXPath("//p[contains(@class, 'new-used')]");
								HtmlElement titleE = page.getFirstByXPath("//h1[contains(@class, 'listing-title')]");
								HtmlElement priceE = page.getFirstByXPath("//span[contains(@class, 'primary-price')]");
								HtmlElement kmUsedE = page
										.getFirstByXPath("//div[contains(@class, 'listing-mileage')]");
//						HtmlElement phoneE = page.getFirstByXPath("//div[contains(@class, 'dealer-phone')]");
								HtmlElement phoneE = page.getFirstByXPath(
										"//div[contains(@class, 'dealer-phone')]");
//								HtmlElement phoneE = page.getFirstByXPath(
//										"//a[contains(@class, 'vdp-content-wrapper--full__mobile-call-link')]");
								HtmlElement sellerNameE = page.getFirstByXPath("//h3[contains(@class, 'seller-name')]");
								HtmlElement dealerAddressE = page
										.getFirstByXPath("//div[contains(@class, 'dealer-address')]");
								HtmlElement sellersNotesE = page
										.getFirstByXPath("//div[contains(@class, 'sellers-notes')]");
								List<HtmlElement> basicsE = page
										.getByXPath("//dl[contains(@class, 'fancy-description-list')]/dd");

								String title = newusedE.asNormalizedText().trim().concat(STR_)
										.concat(titleE.asNormalizedText().trim()).concat(STR_)
										.concat(priceE.asNormalizedText().trim());

								String year = titleE.asNormalizedText().trim();
								String[] yearArr = year.split(STR_);
								carsaa.setYear(Long.valueOf(yearArr[0]));

								String maker = yearArr[1].trim().toLowerCase();

								List<Brand> brands = brandService.findByKeyword(maker);

								if(brands != null && !brands.isEmpty()) {
									Brand b = new Brand();
									for (Brand br : brands) {
										if(br.getIss().equals("0")) {
											b = br;
											break;
										}
									}
									String bvalue = b.getValue();
									String[] bvalue_arr = bvalue.split("_");
									int len = bvalue_arr.length;
									int lenmodel = len + 1;
									String model = yearArr[lenmodel].trim().toLowerCase();
									if(lenmodel != yearArr.length) {
										lenmodel = lenmodel + 1;
										model = model.concat("_").concat(yearArr[lenmodel].trim().toLowerCase());
									}

									List<Brand> brandsModel = brandService.findByKeyword(bvalue.concat("-").concat(model));
									if(brandsModel != null && !brandsModel.isEmpty()) {
										Brand bmodel = brandsModel.get(0);
										carsaa.setModel(bmodel.getValue());
									}
									carsaa.setBrand(b.getValue());
								}

								if (newusedE.asNormalizedText().trim().contains(Static.Certified)) {
									State state = stateService.findByNameAndDel(StateCar.USED.getCode(),
											Del.NOTDEL.getLevelCode());
									if (state != null) {
										carsaa.setState(state.getName());
									}

								}
								if (newusedE.asNormalizedText().trim().contains(Static.Used)) {
									State state = stateService.findByNameAndDel(StateCar.USED.getCode(),
											Del.NOTDEL.getLevelCode());
									if (state != null) {
										carsaa.setState(state.getName());
									}

								}
								if (newusedE.asNormalizedText().trim().contains(Static.New)) {
									State state = stateService.findByNameAndDel(StateCar.NEW.getCode(),
											Del.NOTDEL.getLevelCode());
									if (state != null) {
										carsaa.setState(state.getName());
									}

								}
								carsaa.setTitle(title);
								String price = priceE.asNormalizedText().replace("$", "").replace(",", "").trim();
								carsaa.setPrice(Double.parseDouble(price));

								String kmUsed = kmUsedE.asNormalizedText().replace("mi.", "").replace(",", "").trim();
								carsaa.setKmused(Long.parseLong(kmUsed));

//								String phone = phoneE.getAttribute("href").trim();
								String phone = phoneE.asNormalizedText().trim();
								carsaa.setMobile(phone);

								String sellerName = sellerNameE.asNormalizedText().trim();
								carsaa.setFullname(sellerName);
//
								String dealerAddress = dealerAddressE.asNormalizedText().trim();
								carsaa.setAddress(dealerAddress);

								String note = sellersNotesE.asNormalizedText().trim();
								carsaa.setDescription(note);

								String color = basicsE.get(0).asNormalizedText().trim();
								String[] colorArray = color.split(" ");
								if (colorArray.length > 1) {
									carsaa.setCarcolor(colorArray[1]);
								} else {
									carsaa.setCarcolor(colorArray[0]);
								}

								String fuel = basicsE.get(4).asNormalizedText().trim();
								carsaa.setFuel(fuel);

								String transmission = basicsE.get(5).asNormalizedText().trim();
								carsaa.setGearbox(transmission);

								HtmlElement gallery = page.getFirstByXPath("//gallery-slides");
								List<HtmlImage> imglist = gallery.getByXPath("img");
								UUID uuid = UUID.randomUUID();
								for (int i = 0; i < imglist.size(); i++) {
									if (i == 13) {
										break;
									}
									HtmlImage imgE = imglist.get(i);

									String src = imgE.getSrcAttribute();

									if (i == 0) {
										carsaa.setCarimage1(src);
									}
									if (i == 1) {
										carsaa.setCarimage2(src);
									}
									if (i == 2) {
										carsaa.setCarimage3(src);
									}
									if (i == 3) {
										carsaa.setCarimage4(src);
									}
									if (i == 4) {
										carsaa.setCarimage5(src);
									}

									if (i == 5) {
										carsaa.setCarimage6(src);
									}
									if (i == 6) {
										carsaa.setCarimage7(src);
									}
									if (i == 7) {
										carsaa.setCarimage8(src);
									}
									if (i == 8) {
										carsaa.setCarimage9(src);
									}
									if (i == 9) {
										carsaa.setCarimage10(src);
									}

									if (i == 10) {
										carsaa.setCarimage11(src);
									}
									if (i == 11) {
										carsaa.setCarimage12(src);
									}
									if (i == 12) {
										carsaa.setCarimage13(src);
									}

								}
								carsaalist.add(carsaa);
							}
						} catch (Exception ex) {
//							ex.printStackTrace();
						}
					}
					if (!carsaalist.isEmpty()) {
						List<Carsaa> carsaaListResult = carsaaService.save(carsaalist);
						carsaalist = new ArrayList<Carsaa>();
						for (Carsaa car : carsaaListResult) {
							String title = car.getTitle().toLowerCase().concat("-").concat(String.valueOf(car.getId()));
							title = title.replace(" ", "-");
							car.setUrl(title);
							carsaalist.add(car);
						}
						if (!carsaalist.isEmpty()) {
							carsaaService.save(carsaalist);
						}
					}

				} catch (Exception e) {
//					e.printStackTrace();
				}
			}
		} catch (Exception exx) {
		}

		try {
			long count = carsaaService.count();
			if(count > Static.l30000) {
				Pageable pageable = PageRequest.of(1, Static.n30000,Sort.by("id").descending());
				Page<Carsaa> page = carsaaService.findAll(pageable);
				List<Carsaa> list = page.getContent();
				if(list != null && !list.isEmpty()) {
					carsaaService.delete(list);
				}
			}
		} catch (Exception e) {
		}
//		log.info("end GetCars");
	}

	private StringBuilder saveImage(String carimage1, String uuid) {
		if (carimage1 != null) {
			try {

				StringBuilder uploadFolderId = new StringBuilder();
				uploadFolderId.append(UPLOAD_FOLDER);
				uploadFolderId.append(Static.separation);
				uploadFolderId.append(uuid);
				uploadFolderId.append(Static.separation);

				if ((!Files.exists(Paths.get(uploadFolderId.toString())))) {
					Files.createDirectories(Paths.get(uploadFolderId.toString()));
				}
				String strImageName = carimage1.substring(carimage1.lastIndexOf("/") + 1);

				URL urlImage = new URL(carimage1);
				InputStream in = urlImage.openStream();

				byte[] buffer = new byte[4096];
				int n = -1;

				OutputStream os = new FileOutputStream(uploadFolderId.append(strImageName).toString());

				while ((n = in.read(buffer)) != -1) {
					os.write(buffer, 0, n);
				}

				os.close();
				StringBuilder url = new StringBuilder();
				url.append(IMG_FOLDER);
				url.append(uuid).append(Static.separation).append(strImageName);
				return url;
			} catch (Exception e) {

			}
		}
		return null;
	}

}
