package com.carsaa.job;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.carsaa.constant.Active;
import com.carsaa.constant.Del;
import com.carsaa.constant.IsWeb;
import com.carsaa.constant.SiteName;
import com.carsaa.constant.StateCar;
import com.carsaa.constant.Static;
import com.carsaa.entity.Brand;
import com.carsaa.entity.Carsaa;
import com.carsaa.entity.Country;
import com.carsaa.entity.Site;
import com.carsaa.entity.State;
import com.carsaa.service.BrandService;
import com.carsaa.service.CarsaaService;
import com.carsaa.service.CountryService;
import com.carsaa.service.SiteService;
import com.carsaa.service.StateService;
import com.carsaa.util.Util;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlImage;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlOption;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import com.gargoylesoftware.htmlunit.util.FalsifyingWebConnection;

@Component
public class GetState {

	private static final Logger log = LoggerFactory.getLogger(GetState.class);

	private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 Mobile Safari/537.36";

	private static final String HTML = "<ul class=\"dropdown-menu inner show\"><li class=\"selected active\"><a role=\"option\" class=\"dropdown-item selected active\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"true\"><span class=\"text\">State</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Alabama</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Alaska</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Arizona</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Arkansas</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">California</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Colorado</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Connecticut</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">District of Columbia</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Delaware</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Florida</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Georgia</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Hawaii</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Idaho</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Illinois</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Indiana</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Iowa</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Kansas</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Kentucky</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Louisiana</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Maine</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Maryland</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Massachusetts</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Michigan</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Minnesota</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Mississippi</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Missouri</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Montana</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Nebraska</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Nevada</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">New Hampshire</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">New Jersey</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">New Mexico</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">New York</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">North Carolina</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">North Dakota</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Ohio</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Oklahoma</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Oregon</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Pennsylvania</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Rhode Island</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">South Carolina</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">South Dakota</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Tennessee</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Texas</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Utah</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Vermont</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Virginia</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Washington</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">West Virginia</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Wisconsin</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">Wyoming</span></a></li><li><a role=\"option\" class=\"dropdown-item\" aria-disabled=\"false\" tabindex=\"0\" aria-selected=\"false\"><span class=\"text\">US Virgin Islands</span></a></li></ul>";

	@Autowired
	CountryService countryService;

//	@Scheduled(initialDelay = 3 * 1000, fixedDelay = Long.MAX_VALUE)
	public void get() {
		log.info("start GetState");
		try {
			Document doc = Jsoup.parse(HTML);
			Elements els = doc.getElementsByClass("text");
			List<Country> list = new ArrayList<Country>();
			for (Element e : els) {
				String s = e.text().trim();
				if(!s.equals("State")) {
					Country country = new Country();
					country.setIss("US");
					country.setDel(Del.NOTDEL.getLevelCode());
					country.setName(s);
					country.setValue(s);
					list.add(country);
				}
			}

			if(!list.isEmpty()) {
				countryService.save(list);
			}
		} catch (Exception e) {
//					e.printStackTrace();
		}

		log.info("end GetState");
	}

}
