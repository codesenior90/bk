package com.carsaa.job;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.carsaa.entity.Carsaa;
import com.carsaa.service.CarsaaService;

@Component
public class DeleteCarsaa {

	private static final Logger log = LoggerFactory.getLogger(DeleteCarsaa.class);

	private static final long max = 3000L;

	@Autowired
	CarsaaService carsaaService;

//	@Scheduled(initialDelay = 3 * 1000, fixedDelay = 2 * 1000)
	@Transactional
//	@Scheduled(cron = "0 0 12 * * *")
	public void get() {
//		log.info("start DeleteVideo");
		try {
			long total = carsaaService.count();
			if(max < total) {
				long id = carsaaService.findLastId(max);
				List<Carsaa> list = carsaaService.findAllById(id);
				if(!list.isEmpty()) {
					carsaaService.delete(list);
				 }
			}
		} catch (Exception exx) {
			exx.printStackTrace();
		}

//		log.info("end DeleteVideo");
	}

}
