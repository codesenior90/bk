package com.carsaa.job;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.carsaa.constant.Active;
import com.carsaa.constant.Del;
import com.carsaa.constant.IsWeb;
import com.carsaa.constant.SiteName;
import com.carsaa.constant.StateCar;
import com.carsaa.constant.Static;
import com.carsaa.constant.TypeBrand;
import com.carsaa.entity.Brand;
import com.carsaa.entity.Carsaa;
import com.carsaa.entity.Site;
import com.carsaa.entity.State;
import com.carsaa.service.BrandService;
import com.carsaa.service.CarsaaService;
import com.carsaa.service.SiteService;
import com.carsaa.service.StateService;
import com.carsaa.util.Util;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlImage;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlOption;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import com.gargoylesoftware.htmlunit.util.FalsifyingWebConnection;

@Component
public class GetBrands {

	private static final Logger log = LoggerFactory.getLogger(GetBrands.class);

	private static final String URL = "https://www.cars.com/shopping/results/?dealer_id=&keyword=&list_price_max=&list_price_min=&maximum_distance=all&mileage_max=&monthly_payment=&page_size=20&sort=best_match_desc&stock_type=cpo&year_max=&year_min=&zip=&makes[]=";

	private static final boolean TRUE = true;
	private static final boolean FALSE = false;
	private static final int TIMEOUT = 60000;
	public static final long SL = 10000;
	private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 Mobile Safari/537.36";

	private final static String STR_ = " ";

	@Autowired
	SiteService siteService;
	@Autowired
	CarsaaService carsaaService;
	@Autowired
	StateService stateService;
	@Autowired
	BrandService brandService;

//	@Scheduled(initialDelay = 3 * 1000, fixedDelay = Long.MAX_VALUE)
	public void get() {
		log.info("start GetBrands");
		Brand brandExits = brandService.findFirst();
		if (brandExits == null) {
			try {
				String url = URL;

				WebClient webClient = new WebClient();

				webClient.setWebConnection(new FalsifyingWebConnection(webClient) {
					@Override
					public WebResponse getResponse(WebRequest request) throws IOException {
						if (!request.getUrl().getHost().toLowerCase().contains("cars.com")) {
							return createWebResponse(request, "", "application/javascript");
						}

						return super.getResponse(request);
					}
				});

				webClient.getOptions().setUseInsecureSSL(TRUE);
				webClient.getOptions().setRedirectEnabled(TRUE);
				webClient.getOptions().setJavaScriptEnabled(FALSE);
				webClient.getOptions().setCssEnabled(FALSE);
				webClient.getOptions().setThrowExceptionOnScriptError(FALSE);
				webClient.getOptions().setThrowExceptionOnFailingStatusCode(FALSE);
				webClient.getCookieManager().setCookiesEnabled(TRUE);
				webClient.getOptions().setTimeout(TIMEOUT);
				webClient.getOptions().setScreenHeight(768);
				webClient.getOptions().setScreenWidth(1024);
				webClient.getOptions().setDownloadImages(TRUE);
//					webClient.getBrowserVersion().setUserAgent(USER_AGENT);
				// webClient.setJavaScriptTimeout(8000);
				// webClient.waitForBackgroundJavaScript(500);
				// webClient.getOptions().setDownloadImages(false);
				// webClient.getOptions().setGeolocationEnabled(false);
				// webClient.getOptions().setAppletEnabled(false);

				HtmlPage page = webClient.getPage(url);
//				System.out.println(page.asXml());
//				Thread.sleep(SL);
				webClient.getOptions().setJavaScriptEnabled(FALSE);
//				HtmlElement makes = page.getFirstByXPath("//div[contains(@class, 'makes-select')]");
				HtmlSelect makesSelect = page.getHtmlElementById("make_select");
				List<HtmlOption> oplist = makesSelect.getOptions();
				List<Brand> brandlist = new ArrayList<Brand>();
				int i = 1;
				for (HtmlOption op : oplist) {
					if(op.getValueAttribute().equals("")) {
						continue;
					}
					Brand brand = new Brand();
					if(i < 28) {
						brand.setType(TypeBrand.SHOW.getLevelCode());
					} else {
						brand.setType(TypeBrand.HIDE.getLevelCode());
					}
					i++;
					brand.setDel(Del.NOTDEL.getLevelCode());
					brand.setIss(Static.zeroS);
					brand.setName(op.getTextContent());
					brand.setValue(op.getValueAttribute());
					brandlist.add(brand);
				}

				if (!brandlist.isEmpty()) {
					brandService.save(brandlist);
				}
				List<Brand> brandl = new ArrayList<Brand>();
				for (Brand brand : brandlist) {
					page = webClient.getPage(url.concat(brand.getValue()));
					HtmlElement models = page.getHtmlElementById("model");
					List<HtmlElement> sds = models.getByXPath("div/div/div[contains(@class, 'sds-checkbox')]");

					for (HtmlElement e : sds) {
						HtmlInput input = e.getFirstByXPath("input");
						Brand b = new Brand();
						b.setDel(Del.NOTDEL.getLevelCode());
						b.setIss(brand.getValue());


//						String value = input.getValueAttribute().replaceAll("_", " ");
//						value = value.replaceAll("-", " ");
//						value = value.replaceAll(brand.getValue(), "");
						b.setValue(input.getValueAttribute());

						HtmlElement label = e.getFirstByXPath("label");
						HtmlElement span = label.getFirstByXPath("span");
						String name = label.asNormalizedText();
						name = name.substring(0, name.indexOf(span.asNormalizedText())).trim();
						b.setName(name);
						brandl.add(b);
					}
				}
				if (!brandl.isEmpty()) {
					brandService.save(brandl);
				}

			} catch (Exception e) {
//					e.printStackTrace();
			}
		}

		log.info("end GetBrands");
	}

}
