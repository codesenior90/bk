$(document).ready(function() {
	$('#paynow').click(function() {
		validateCountry();
		validateBrand();
		validateModel();
		validateYear();
		validateGearbox();
		validateState();
		validatePrice();
		validateDescription();
		//validateAddress();
		//validateZipcode();
		validateImage1();
		if ((countryError == true) && (brandError == true)
			&& (modelError == true) && (yearError == true)
			&& (gearboxError == true) && (stateError == true)
			&& (priceError == true)
			&& (descriptionError == true)
			&& (addressError == true) && (zipcodeError == true) && (image1Error == true)) {
			$('form#carsaaForm').submit();
			return true;
		} else {
			document.documentElement.scrollTop = 0;
			return false;
		}
	});

	$('#countrycheck').hide();
	let countryError = true;
	$('#country').change(function() {
		validateCountry();
		//validateZipcode();
	});
	function validateCountry() {
		let countryValue = $('#country').val();
		if (countryValue.length == '') {
			$('#countrycheck').show();
			countryError = false;
			$('#countrycheck').html('You must enter your country');
		} else {
			$('#countrycheck').hide();
			countryError = true;
		}
	}

	$('#brandcheck').hide();
	let brandError = true;
	$('#brand').change(function() {
		validateBrand();
		let brandValue = $('#brand').val();
		if (brandValue.length == '') {
			$('#model')
				.find('option')
				.remove()
				.end()
				.append('<option value="">select model</option>');
		} else {
			$.getJSON("/getmodel/" + brandValue, function(result) {
				$('#model')
					.find('option')
					.remove()
					.end()
					.append('<option value="">select model</option>');
				$.each(result, function(i, field) {
					$('#model').append($('<option>', {
						value: field.value,
						text: field.name
					}));
				});
			});
		}
	});

	function validateBrand() {
		let brandValue = $('#brand').val();
		if (brandValue.length == '') {
			$('#brandcheck').show();
			brandError = false;
			$('#brandcheck').html('You must enter brand your car');

		} else {
			brandError = true;
			$('#brandcheck').hide();

		}
	}

	$('#modelcheck').hide();
	let modelError = true;
	$('#model').change(function() {
		validateModel();
	});

	function validateModel() {
		let modelValue = $('#model').val();
		if (modelValue.length == '') {
			$('#modelcheck').show();
			modelError = false;
			$('#modelcheck').html('You must enter model your car');

		} else {
			modelError = true;
			$('#modelcheck').hide();

		}
	}

	$('#yearcheck').hide();
	let yearError = true;
	$('#year').change(function() {
		validateYear();
	});

	function validateYear() {
		let yearValue = $('#year').val();
		if (yearValue.length == '') {
			$('#yearcheck').show();
			yearError = false;
			$('#yearcheck').html('You must enter year of manufacture your car');
		} else {
			yearError = true;
			$('#yearcheck').hide();
		}
	}

	$('#gearboxcheck').hide();
	let gearboxError = true;
	$('input[name="gearbox"]').change(function() {
		validateGearbox();
	});

	function validateGearbox() {
		if ($('input[name="gearbox"]:checked').length == 0) {
			$('#gearboxcheck').show();
			gearboxError = false;
			$('#gearboxcheck').html('You must enter gear box your car');
		} else {
			gearboxError = true;
			$('#gearboxcheck').hide();
		}
	}

	$('#statecheck').hide();
	let stateError = true;
	$('input[name="state"]').change(function() {
		validateState();
	});

	function validateState() {
		if ($('input[name="state"]:checked').length == 0) {
			$('#statecheck').show();
			stateError = false;
			$('#statecheck').html('You must enter state your car');
		} else {
			stateError = true;
			$('#statecheck').hide();
		}
	}

	$('#pricecheck').hide();
	let priceError = true;
	$('#price').keyup(function() {
		validatePrice();
	});

	function validatePrice() {
		let priceValue = $('#price').val();
		if (priceValue.length == '') {
			$('#pricecheck').show();
			priceError = false;
			$('#pricecheck').html('You must enter price your car');
		} else {
			priceError = true;
			$('#pricecheck').hide();
		}
	}

	$('#descriptioncheck').hide();
	let descriptionError = true;
	$('#description').keyup(function() {
		validateDescription();
	});

	function validateDescription() {
		let descriptionValue = $('#description').val();
		if (descriptionValue.length == '') {
			$('#descriptioncheck').show();
			descriptionError = false;
			$('#descriptioncheck').html('You must enter description your car sale');
		} else {
			descriptionError = true;
			$('#descriptioncheck').hide();
		}
	}

	$('#addresscheck').hide();
	let addressError = true;
	$('#address').keyup(function() {
		validateAddress();
	});

	function validateAddress() {
		let addressValue = $('#address').val();
		if (addressValue.length == '') {
			$('#addresscheck').show();
			addressError = false;
			$('#addresscheck').html('You must enter your address');
		} else {
			addressError = true;
			$('#addresscheck').hide();
		}
	}

	$('#zipcodecheck').hide();
	let zipcodeError = true;
	$('#zipcode').keyup(function() {
		//validateZipcode();
	});

	function validateZipcode() {
		let zipcodeValue = $('#zipcode').val();
		if (zipcodeValue.length == '') {
			$('#zipcodecheck').show();
			zipcodeError = false;
			$('#zipcodecheck').html('You must enter your zip code');
		} else if (!validateRegexZipcode(zipcodeValue)) {
			$('#zipcodecheck').show();
			zipcodeError = false;
			$('#zipcodecheck').html('invalid zip code');
		} else {
			zipcodeError = true;
			$('#zipcodecheck').hide();
		}
	}

	function validateRegexZipcode(str) {
		let countryValue = $('#country').val();
		if(countryValue == 'US') {
			return validateRegexZipcodeUS(str);
		}
		if(countryValue == 'China') {
			return validateRegexZipcodeCN(str);
		}
	}

	function validateRegexZipcodeUS(str) {
		return /^\d{5}(-\d{4})?$/.test(str);
	}

	function validateRegexZipcodeCN(str) {
		return /^[0-9]{6}$/.test(str);
	}

	$('#image1check').hide();
	let image1Error = true;
//	$('#carimage1').change(function() {
//		validateCarimage1();
//	});

	function validateImage1() {
		let image1Value = $('#uuid').val();
		if (image1Value.length == '') {
			$('#image1check').show();
			image1Error = false;
			$('#image1check').html('You must upload one image your car');
		} else {
			image1Error = true;
			$('#image1check').hide();
		}
	}

	$(function() {
		var token = $("input[name='_csrf']").val();
		var header = "X-CSRF-TOKEN";
		$(document).ajaxSend(function(e, xhr, options) {
			xhr.setRequestHeader(header, token);
		});
	});

	function upload(x, y, z) {
		let form_data = new FormData();
		let files = $(x)[0].files;
		if (files.length > 0) {
			form_data.append(y, files[0]);
			form_data.append('key', $("#uuid").val());
			$.ajax({
				//dataType: 'json',
				url: "upload",
				data: form_data,
				type: "POST",
				enctype: 'multipart/form-data',
				processData: false,
				contentType: false,
				success: function(result) {
					if (result.src) {
						let src = "/carsaa/" + result.src;
						$("<span class=\"pip\">" +
							"<img class=\"imageThumb\" src=\"" + src + "\" title=\"" + "\"/>" +
							"<br/><span class=\"remove\">Remove</span>" +
							"<input type=\"hidden\" id=\"imagehidden\" name=\"imagehidden\" value=\""+ src +"\">"
							+"</span>").insertBefore(x);
						$(".remove").click(function() {
							$(this).parent(".pip").remove();
							$(x).val('');
						});
						$(x).val('');
//						$(z).val(result.src);
					}
					if (result.uuid) {
						$("#uuid").val(result.uuid);
					}

				},
				error: function(result) {

				}
			});
		}
	}
	$('#image1').change(function(e) {

		upload('#image1', 'image', '#image1hidden');
	});

	$('#image2').change(function(e) {
		upload('#image2', 'image', '#image2hidden');
	});

	$('#image3').change(function(e) {
		upload('#image3', 'image', '#image3hidden');
	});

	$('#image4').change(function(e) {
		upload('#image4', 'image', '#image4hidden');
	});

	$('#image5').change(function(e) {
		upload('#image5', 'image', '#image5hidden');
	});

});
