$(document).ready(function() {
});

function change() {
	$("#q").val('');
	$("#carsForm").submit();
}

function search() {
	$("#stateCountry").val('');
	$("#maker").val('');
	$("#model").val('');
	$("#state").val('');
	$("#minyear").val('');
	$("#maxyear").val('');
	$("#gearbox").val('');
	$("#minprice").val('');
	$("#maxprice").val('');
	$("#sort").val('');
	var carsForm = document.forms.carsForm;

	var formData = Array.from(carsForm.elements);
	$.ajax({
		url: '/cars-content',
		type: 'POST',
		dataType: 'html',
		data: formData
	}).done(function(rs) {
		$('#cars-content').html("");
		$('#cars-content').html(rs);
		var q = $("#q").val();
		history.pushState({}, null, "cars?q="+q);
	}).fail(function(error) {

	});
}

function change2() {
	$("#q").val('');
	var carsForm = document.forms.carsForm;

	var formData = Array.from(carsForm.elements);
	$.ajax({
		url: '/cars-content',
		type: 'POST',
		dataType: 'html',
		data: formData
	}).done(function(rs) {
		$('#cars-content').html("");
		$('#cars-content').html(rs);
		history.pushState({}, null, "cars?country=US&stateCountry="+$("#stateCountry").val()+"&maker="+$("#brand").val()+"&model="+$("#model").val()+"&state="+$("#state").val()+"&minprice="+$("#minprice").val()+"&maxprice="+$("#maxprice").val()+"&minyear="+$("#minyear").val()+"&maxyear="+$("#maxyear").val()+"&gearbox="+$("#gearbox").val()+"&q=&sort="+$("#sort").val());
	}).fail(function(error) {

	});
}
