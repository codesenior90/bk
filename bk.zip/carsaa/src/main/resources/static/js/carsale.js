$(document).ready(function() {
});

function closeSale(title,id) {
	if (confirm("Do you really want to close " + title + "?")) {
		$.get("/closesale/" + id, function(result) {
			console.log('closed');
			location.reload(true);
		});
	}
}