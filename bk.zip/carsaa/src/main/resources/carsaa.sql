-- MySQL dump 10.13  Distrib 5.7.36, for Win64 (x86_64)
--
-- Host: localhost    Database: carsaa
-- ------------------------------------------------------
-- Server version	5.7.36-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brand` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(133) DEFAULT NULL,
  `is` varchar(13) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand`
--

LOCK TABLES `brand` WRITE;
/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
INSERT INTO `brand` VALUES (1,'BMW','0',NULL,NULL,NULL,NULL,0),(2,'1 Series','BMW',NULL,NULL,NULL,NULL,0),(3,'2 Series','BMW',NULL,NULL,NULL,NULL,0),(4,'3 Series','BMW',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carcolor`
--

DROP TABLE IF EXISTS `carcolor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carcolor` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(133) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carcolor`
--

LOCK TABLES `carcolor` WRITE;
/*!40000 ALTER TABLE `carcolor` DISABLE KEYS */;
INSERT INTO `carcolor` VALUES (1,'white',NULL,NULL,NULL,NULL,0),(2,'yellow',NULL,NULL,NULL,NULL,0),(3,'other',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `carcolor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carsaa`
--

DROP TABLE IF EXISTS `carsaa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carsaa` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `title` varchar(1300) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `priceunit` varchar(13) DEFAULT NULL,
  `state` varchar(13) DEFAULT NULL,
  `description` varchar(1300) DEFAULT NULL,
  `brand` varchar(133) DEFAULT NULL,
  `model` varchar(133) DEFAULT NULL,
  `year` bigint(33) DEFAULT NULL,
  `gearbox` varchar(133) DEFAULT NULL,
  `fuel` varchar(13) DEFAULT NULL,
  `cartype` varchar(133) DEFAULT NULL,
  `carseat` varchar(13) DEFAULT NULL,
  `carcolor` varchar(13) DEFAULT NULL,
  `address` varchar(133) DEFAULT NULL,
  `site` varchar(13) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(133) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(133) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `zipcode` varchar(13) DEFAULT NULL,
  `kmused` double DEFAULT NULL,
  `madein` varchar(255) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `carimage1` varchar(555) DEFAULT NULL,
  `carimage2` varchar(555) DEFAULT NULL,
  `carimage3` varchar(555) DEFAULT NULL,
  `carimage4` varchar(555) DEFAULT NULL,
  `carimage5` varchar(555) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carsaa`
--

LOCK TABLES `carsaa` WRITE;
/*!40000 ALTER TABLE `carsaa` DISABLE KEYS */;
INSERT INTO `carsaa` VALUES (1,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:34','test','2022-02-09 19:46:34','test',1,'12345',65432.1111,'',0,'54f62766-3dd1-45d2-9782-8fc64629cbd2/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(2,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:34','test','2022-02-09 19:46:34','test',1,'12345',65432.1111,'',0,'a16af75d-446f-4433-bc23-4c2074b091f7/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(3,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:34','test','2022-02-09 19:46:34','test',1,'12345',65432.1111,'',0,'bfb696d2-9cdd-4cc0-9233-285864f01bcd/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(4,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:34','test','2022-02-09 19:46:34','test',1,'12345',65432.1111,'',0,'e4d6d12f-27cc-4f8f-9b13-78fdd7ed0bac/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(5,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'cf6d67a1-174a-4f4c-8a6c-38d59d2f0a52/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(6,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'f30ff47f-0022-477b-897d-dba24b2fd465/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(7,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'2f4485db-ae17-4d19-9b7b-a1bbde432a63/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(8,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'e814959a-741a-4b80-8813-bae82bdac42f/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(9,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'43c355f6-c023-415f-bdc5-64c174450186/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(10,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'8f016395-9e38-470f-ac67-89b8d5318240/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(11,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'f50a832c-8257-47ab-973c-690ebe527711/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(12,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'97c82b9a-cc8d-4354-9b76-17a428509b93/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(13,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'3bea1df4-d934-43ec-9cfe-b3f60af7e2c4/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(14,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'6bc49c68-6a01-4487-8191-e9ed8fe2e69f/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(15,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'0ec39d59-0856-449e-a236-7d45475e1a7b/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(16,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'f26e7c78-6ce9-48a0-96c3-b7e79626e9c7/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(17,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'679d248a-bb65-452a-acb5-aec19400306c/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(18,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'92fa8778-7dc1-4f0e-9461-c34a1fee63b6/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(19,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'47dab7e0-7086-4817-8c57-c3925c2ffac5/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(20,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:35','test','2022-02-09 19:46:35','test',1,'12345',65432.1111,'',0,'72718f98-99b5-4925-af82-3c90afe44763/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(21,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'4fd9051f-48e7-40b8-b2bf-a1ee8a574ec8/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(22,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'5684a40c-721a-412a-a0dd-136327e8ebd5/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(23,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'21c55583-5201-4b86-9afc-f6fe0de7f5ca/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(24,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'a0b28968-b9bd-4735-b06f-9c6d78f128a4/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(25,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'4527819e-2907-4b18-9d34-c7b2db949bb7/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(26,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'87d65970-e011-40f1-8bc4-bfa645286e07/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(27,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'fd3df3bb-4098-474f-91ae-5e39000aab52/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(28,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'04466f4a-ce13-40e7-9753-2d43990559b7/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(29,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'3ca1cbc8-e68a-4af2-83cb-a5210c58db94/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(30,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'108b1926-db15-4d81-b0bf-8aa4ea550e13/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(31,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'9d8e0252-b895-4e47-98a7-4126ceb9e3ab/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(32,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'daa1401c-4855-4cc2-91be-58ee08a2eb3f/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(33,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'91bbbc38-057d-47b4-a606-9a0f55d75520/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(34,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'5b5175cb-8ed3-4b5a-a442-451bc7ab1b14/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(35,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:36','test','2022-02-09 19:46:36','test',1,'12345',65432.1111,'',0,'205b1be4-2c35-474a-a05e-bbf73bab5b29/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(36,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'63f2fb55-1d30-4d3b-bdec-8814f04dee1e/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(37,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'a9121aaf-06a6-4126-be46-a7b4d7017f36/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(38,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'2b95d672-38e4-4982-9935-d36b443dce36/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(39,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'700133aa-fb61-432f-9cc2-b31d5deb5f2f/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(40,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'7fd4b7c6-077a-4fac-b7cd-973c0aa75f87/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(41,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'29929ff1-fe50-4043-b250-3437987a524b/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(42,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'20c14d42-bd50-457a-a8e9-4f596158686d/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(43,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'f8683758-0b27-4e14-b223-27857143ed7c/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(44,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'c4e198e7-640d-431e-b26d-d55628ad06fe/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(45,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'9be207de-f193-47c0-abdf-3d8af84f14e2/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(46,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'ec6813c4-4125-42d6-87d6-f64b550bc5f2/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(47,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'652aca7f-7e22-45cd-b5e3-8ecf9402ea60/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(48,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'72ed3517-670e-4e35-b40c-1aed6b44e82b/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(49,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'07c373f8-c512-4f5e-88b3-ed0c80255c4a/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(50,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'935034af-28cf-4530-9f41-c8cbd589240a/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(51,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:37','test','2022-02-09 19:46:37','test',1,'12345',65432.1111,'',0,'7442a1a6-4ce0-44d3-b23e-9652e1db473a/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(52,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'b26602dc-edf4-42ff-b3a7-2852a2326763/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(53,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'015079a9-6110-4d42-92aa-c1474ab5bfc1/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(54,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'e49a90f8-d753-428e-807b-9d43071d33cc/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(55,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'8b3ee987-d92e-458c-b346-cc60e7f546ee/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(56,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'a01c5b02-4464-4445-80cb-4aed735712e3/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(57,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'ffa52ebf-31ed-4269-a9cd-1e861b1335ae/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(58,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'e4726ad4-7feb-4c00-bea6-3740280b435d/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(59,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'a75b76d8-8018-40e1-8367-a413b4ecf644/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(60,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'e8affe2c-5889-4ca0-ada2-619469e8d1c6/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(61,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'98836746-bb83-4043-acab-27f94db7a996/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(62,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'f70179b9-fd83-4075-bf78-f844c5e59661/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(63,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'a576cfef-dfaf-4cc7-b447-a7ad729e6073/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(64,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'2a91d122-733c-44fa-aaf4-f2a4cc782d2c/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(65,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'a05df447-d163-408c-a9aa-9d19fb9ee1ab/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(66,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'fc092b6c-81db-4838-b5b6-7648737100c9/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(67,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'22355328-39dd-4ec6-978a-0b010e388035/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(68,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:38','test','2022-02-09 19:46:38','test',1,'12345',65432.1111,'',0,'adcb40c8-f7df-4f67-a419-e9b379ad9e96/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(69,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'7aaf85f6-b8a4-445e-9c64-5f66c83f5e28/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(70,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'ace69c2a-93ec-49a4-bf42-946d19565dd0/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(71,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'1ae22cca-a500-47d2-a97b-2e8d5e5299e2/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(72,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'e09d50b0-7774-4ba9-9fae-7bccbed3cafd/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(73,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'30d74327-b9da-4fc7-95db-10bc920c49e7/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(74,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'59ed2f0f-cc59-4784-af5f-fb3aab862c0b/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(75,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'f81a0dda-6b44-491c-bfb9-7e8d74d58e8c/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(76,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'ef0ac029-81c7-4e2f-9e59-a5f88f5394ce/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(77,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'557fc737-39c4-43a3-b408-d44a5e43e3fe/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(78,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'8b281404-44de-4f7c-9660-aa9a7f11dc81/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(79,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'450a603c-061a-48ab-adef-ecf0abb38c49/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(80,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'bf7efe9b-08e6-4892-b157-013712034225/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(81,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'c8923f51-2a43-4c84-a96c-79a91613215a/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(82,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'839457cd-078e-44c5-b0f0-55236bb5499b/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(83,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'a4cedb47-af28-457b-b393-0b56e40e1c10/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(84,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'95e5011b-8a4b-401d-9a0b-b26d17dd73de/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(85,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:39','test','2022-02-09 19:46:39','test',1,'12345',65432.1111,'',0,'debb1b1e-1294-43da-afae-61515a80b356/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(86,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'a3251073-b84b-44e0-b1e2-99b8c8d0b26e/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(87,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'c4271fbd-2caf-4589-aeb4-c9d8bdf4c65c/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(88,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'abd8cdce-bc3f-46a8-bbb7-5fda3b4c4553/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(89,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'9f54e8d5-b186-48bb-a3c6-1f3a4b002d0a/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(90,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'a7b42c2c-ebfd-471b-8d7d-e59736f26819/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(91,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'524298b6-67d9-4002-998d-39d87ded4456/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(92,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'6aae968d-6ba8-4dad-be2a-d3660b139f7b/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(93,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'6a7472b4-4240-4971-94e6-8bb49cd0bb52/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(94,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'fe0dcf5c-4e0f-4ef7-bc09-1e4fc3fdb3ea/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(95,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'21487b42-de58-4ffc-9980-2043e0777d7a/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(96,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'3bd84b31-a533-49a0-b011-47656637820e/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(97,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'762f7754-01d7-46d0-8374-5e5f36b53fe6/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(98,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:40','test','2022-02-09 19:46:40','test',1,'12345',65432.1111,'',0,'437ebf5b-b168-403e-8a92-84e1a6dfddc4/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(99,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:41','test','2022-02-09 19:46:41','test',1,'12345',65432.1111,'',0,'48db449d-8941-40ae-b0ae-fe225b0bfe2e/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(100,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:41','test','2022-02-09 19:46:41','test',1,'12345',65432.1111,'',0,'92340f1c-0bc0-4c0e-a32a-38c8bbd1d80f/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(101,'title',12345.6,NULL,'new','description','BMW','1 Series',2002,'Manual transmission',NULL,'','','','newyork city','US','2022-02-09 19:46:41','test','2022-02-09 19:46:41','test',1,'12345',65432.1111,'',0,'39747c80-cdb1-40b9-bd15-70f569fe26c5/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL,NULL),(102,'title',22000,NULL,'used','test','BMW','2 Series',2001,'Semi-automatic and dual-clutch transmissions',NULL,'','','','newyork us','US','2022-02-10 08:46:12','test','2022-02-10 08:46:12','test',1,'12345',NULL,'',0,'d3545310-d5ea-4921-9fd4-6cd919697077/256452849_124887459953495_2654482776223083794_n.jpg','d3545310-d5ea-4921-9fd4-6cd919697077/2018-buick-encore-preferred-4dr-crossover - Copy.jpg',NULL,NULL,NULL),(103,'title',345678,NULL,'used','desciption','BMW','3 Series',1999,'Manual transmission',NULL,'','','','newyork city','UK','2022-02-10 08:48:01','test','2022-02-10 08:48:01','test',1,'12345',NULL,'',0,'550320f2-5354-4c77-ae6b-1acdf43f7fff/2018-buick-encore-preferred-4dr-crossover.jpg',NULL,NULL,NULL,NULL),(104,'title new',12434,NULL,'used','description','BMW','1 Series',1984,'Manual transmission',NULL,'','','','new york city','US','2022-02-10 09:10:00','test','2022-02-10 09:10:00','test',1,'12345',240,'',0,'32ef4535-d4c1-4e6c-9504-5cc259434141/2018-buick-encore-preferred-4dr-crossover - Copy.jpg','32ef4535-d4c1-4e6c-9504-5cc259434141/2018-buick-encore-preferred-4dr-crossover.jpg','32ef4535-d4c1-4e6c-9504-5cc259434141/256452849_124887459953495_2654482776223083794_n.jpg',NULL,NULL);
/*!40000 ALTER TABLE `carsaa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carseat`
--

DROP TABLE IF EXISTS `carseat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carseat` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carseat`
--

LOCK TABLES `carseat` WRITE;
/*!40000 ALTER TABLE `carseat` DISABLE KEYS */;
INSERT INTO `carseat` VALUES (1,'2',NULL,NULL,NULL,NULL,0),(2,'4',NULL,NULL,NULL,NULL,0),(3,'5',NULL,NULL,NULL,NULL,0),(4,'6',NULL,NULL,NULL,NULL,0),(5,'7',NULL,NULL,NULL,NULL,0),(6,'8',NULL,NULL,NULL,NULL,0),(7,'9',NULL,NULL,NULL,NULL,0),(8,'10',NULL,NULL,NULL,NULL,0),(9,'12',NULL,NULL,NULL,NULL,0),(10,'14',NULL,NULL,NULL,NULL,0),(11,'16',NULL,NULL,NULL,NULL,0),(12,'Other',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `carseat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cartype`
--

DROP TABLE IF EXISTS `cartype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cartype` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(133) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartype`
--

LOCK TABLES `cartype` WRITE;
/*!40000 ALTER TABLE `cartype` DISABLE KEYS */;
INSERT INTO `cartype` VALUES (1,'Minivan (MPV)',NULL,NULL,NULL,NULL,0),(2,'Pick-up',NULL,NULL,NULL,NULL,0),(3,'Hatchback',NULL,NULL,NULL,NULL,0),(4,'SUV / Cross over',NULL,NULL,NULL,NULL,0),(5,'Sedan',NULL,NULL,NULL,NULL,0),(6,'Van',NULL,NULL,NULL,NULL,0),(7,'Coupe',NULL,NULL,NULL,NULL,0),(8,'Other',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `cartype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'US',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuel`
--

DROP TABLE IF EXISTS `fuel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuel` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(133) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuel`
--

LOCK TABLES `fuel` WRITE;
/*!40000 ALTER TABLE `fuel` DISABLE KEYS */;
INSERT INTO `fuel` VALUES (1,'Gasoline ',NULL,NULL,NULL,NULL,0),(2,'Diesel ',NULL,NULL,NULL,NULL,0),(3,'Hybrid ',NULL,NULL,NULL,NULL,0),(4,'Other',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `fuel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gearbox`
--

DROP TABLE IF EXISTS `gearbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gearbox` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(133) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gearbox`
--

LOCK TABLES `gearbox` WRITE;
/*!40000 ALTER TABLE `gearbox` DISABLE KEYS */;
INSERT INTO `gearbox` VALUES (1,'Manual transmission',NULL,NULL,NULL,NULL,0),(2,'Automatic transmission',NULL,NULL,NULL,NULL,0),(3,'Continuously variable transmission (CVT)',NULL,NULL,NULL,NULL,0),(4,'Semi-automatic and dual-clutch transmissions',NULL,NULL,NULL,NULL,0),(5,'Other',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `gearbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `madein`
--

DROP TABLE IF EXISTS `madein`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `madein` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(133) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `madein`
--

LOCK TABLES `madein` WRITE;
/*!40000 ALTER TABLE `madein` DISABLE KEYS */;
INSERT INTO `madein` VALUES (3,'US',NULL,NULL,NULL,NULL,0),(4,'UK',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `madein` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price`
--

DROP TABLE IF EXISTS `price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(255) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price`
--

LOCK TABLES `price` WRITE;
/*!40000 ALTER TABLE `price` DISABLE KEYS */;
INSERT INTO `price` VALUES (1,NULL,NULL,0,NULL,NULL,'2000'),(2,NULL,NULL,0,NULL,NULL,'4000'),(3,NULL,NULL,0,NULL,NULL,'6000'),(4,NULL,NULL,0,NULL,NULL,'8000'),(5,NULL,NULL,0,NULL,NULL,'10000'),(6,NULL,NULL,0,NULL,NULL,'15000'),(7,NULL,NULL,0,NULL,NULL,'20000'),(8,NULL,NULL,0,NULL,NULL,'25000'),(9,NULL,NULL,0,NULL,NULL,'30000'),(10,NULL,NULL,0,NULL,NULL,'35000'),(11,NULL,NULL,0,NULL,NULL,'40000'),(12,NULL,NULL,0,NULL,NULL,'45000'),(13,NULL,NULL,0,NULL,NULL,'50000'),(14,NULL,NULL,0,NULL,NULL,'60000'),(15,NULL,NULL,0,NULL,NULL,'70000'),(16,NULL,NULL,0,NULL,NULL,'80000'),(17,NULL,NULL,0,NULL,NULL,'90000'),(18,NULL,NULL,0,NULL,NULL,'100000'),(19,NULL,NULL,0,NULL,NULL,'125000'),(20,NULL,NULL,0,NULL,NULL,'175000');
/*!40000 ALTER TABLE `price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'ROLE_ADMIN'),(2,'ROLE_USER');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
INSERT INTO `site` VALUES (1,'US',NULL,NULL,NULL,NULL,0),(2,'UK',NULL,NULL,NULL,NULL,0),(3,'test',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `state` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(13) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state`
--

LOCK TABLES `state` WRITE;
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` VALUES (1,'new',NULL,NULL,NULL,NULL,0),(2,'used',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_r43af9ap4edm43mmtq01oddj6` (`username`),
  UNIQUE KEY `UKr43af9ap4edm43mmtq01oddj6` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'$2a$04$GYGsaJj9l6kH2GikK6QVzO0v3sOCxt3vdkiA2/tcoSw8erI85ZYDG','kai',NULL,NULL),(2,1,'$2a$04$GYGsaJj9l6kH2GikK6QVzO0v3sOCxt3vdkiA2/tcoSw8erI85ZYDG','sena',NULL,NULL),(3,1,'$2a$10$D.EbKKc5zIPopmQqGP1l.e7uQQ8XvaF/sgYWX3RLUARnKMoh52Zou','test','le thanh tung','0929344001');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdda0v1efwjlsljm23y5r6gykl` (`role`),
  KEY `FKkjti9tmthqhpqdhugbhcngweo` (`user`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` VALUES (1,1,1),(2,2,1),(3,2,2),(4,2,3);
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `year`
--

DROP TABLE IF EXISTS `year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `year` (
  `id` bigint(33) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createuser` varchar(45) DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  `updateuser` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `year`
--

LOCK TABLES `year` WRITE;
/*!40000 ALTER TABLE `year` DISABLE KEYS */;
INSERT INTO `year` VALUES (1,'1984',NULL,NULL,NULL,NULL,0),(2,'1985',NULL,NULL,NULL,NULL,0),(3,'1986',NULL,NULL,NULL,NULL,0),(4,'1987',NULL,NULL,NULL,NULL,0),(5,'1988',NULL,NULL,NULL,NULL,0),(6,'1989',NULL,NULL,NULL,NULL,0),(7,'1990',NULL,NULL,NULL,NULL,0),(8,'1991',NULL,NULL,NULL,NULL,0),(9,'1992',NULL,NULL,NULL,NULL,0),(10,'1993',NULL,NULL,NULL,NULL,0),(11,'1994',NULL,NULL,NULL,NULL,0),(12,'1995',NULL,NULL,NULL,NULL,0),(13,'1996',NULL,NULL,NULL,NULL,0),(14,'1997',NULL,NULL,NULL,NULL,0),(15,'1998',NULL,NULL,NULL,NULL,0),(16,'1999',NULL,NULL,NULL,NULL,0),(17,'2000',NULL,NULL,NULL,NULL,0),(18,'2001',NULL,NULL,NULL,NULL,0),(19,'2002',NULL,NULL,NULL,NULL,0),(20,'2003',NULL,NULL,NULL,NULL,0),(21,'2004',NULL,NULL,NULL,NULL,0),(22,'2005',NULL,NULL,NULL,NULL,0),(23,'2006',NULL,NULL,NULL,NULL,0),(24,'2007',NULL,NULL,NULL,NULL,0),(25,'2008',NULL,NULL,NULL,NULL,0),(26,'2009',NULL,NULL,NULL,NULL,0),(27,'2010',NULL,NULL,NULL,NULL,0),(28,'2011',NULL,NULL,NULL,NULL,0),(29,'2012',NULL,NULL,NULL,NULL,0),(30,'2013',NULL,NULL,NULL,NULL,0),(31,'2014',NULL,NULL,NULL,NULL,0),(32,'2015',NULL,NULL,NULL,NULL,0),(33,'2016',NULL,NULL,NULL,NULL,0),(34,'2017',NULL,NULL,NULL,NULL,0),(35,'2018',NULL,NULL,NULL,NULL,0),(36,'2019',NULL,NULL,NULL,NULL,0),(37,'2020',NULL,NULL,NULL,NULL,0),(38,'2021',NULL,NULL,NULL,NULL,0),(39,'2022',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `year` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-10  9:48:34
