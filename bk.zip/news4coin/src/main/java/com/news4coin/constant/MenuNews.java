package com.news4coin.constant;

public enum MenuNews {
	AZNEWS("AZ -News"),
	NEWS("News")
	;

	private final String code;

    private MenuNews(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
