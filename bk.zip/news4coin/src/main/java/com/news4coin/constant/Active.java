package com.news4coin.constant;

public enum Active {
	ACTIVE(1),
	INACTIVE(0);

	private final int levelCode;

    private Active(int levelCode) {
        this.levelCode = levelCode;
    }

    public int getLevelCode() {
        return this.levelCode;
    }
}
