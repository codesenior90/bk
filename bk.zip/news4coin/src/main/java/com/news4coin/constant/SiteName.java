package com.news4coin.constant;

public enum SiteName {
	azcoinnews_com("azcoinnews.com");
	private final String code;

    private SiteName(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
