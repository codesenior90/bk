package com.news4coin.constant;

import java.util.regex.Pattern;

public interface Static {
	int n999 = 999;
	int n444 = 444;
	int n99 = 99;
	Integer zero = 0;
	Long zero_ = 0L;
	Long one = 1L;
	long l60 = 60;
	Integer z39 = 39;
	Integer z40 = 40;
	String zeroS = "0";
	String blank = "";
	String url1 = "?";
	String url2 = "&page";
	String url3 = "?page";
	String url4 = "&";
	String separation = "/";
	String n = "\n";


	String znamealphanumber = "^[a-zA-Z0-9]*$";

    Pattern robustPattern = Pattern
	        .compile(
	                // Robust expression from before
	                "^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$"
	                // Area code, within or without parentheses,
	                // followed by groups of 3-4 numbers with or without hyphens
	                + "| ((\\(\\d{3}\\) ?)|(\\d{3}-))?\\d{3}-\\d{4}"
	                // (+) followed by 10-12 numbers
	                + "|^\\+\\d{10,12}"
	);

    String md5 = "MD5";
    String ptp = "/ptp/";

    String[] HEADERS_TO_TRY = {
            "X-Forwarded-For",
            "Proxy-Client-IP",
            "WL-Proxy-Client-IP",
            "HTTP_X_FORWARDED_FOR",
            "HTTP_X_FORWARDED",
            "HTTP_X_CLUSTER_CLIENT_IP",
            "HTTP_CLIENT_IP",
            "HTTP_FORWARDED_FOR",
            "HTTP_FORWARDED",
            "HTTP_VIA",
            "REMOTE_ADDR" };

    String unknown = "unknown";
    String error = "error";
    String Referer = "Referer";


    String url = "url";
    String q = "q";

    //page

	String home = "redirect:/";

	String redirect = "redirect:/";
	String adminredirect = "redirect:/admin";

	String pagehome = "home";

	String urlhome = "/";


	String post = "div.listing-mix-1-1 .item-inner,div.listing-blog-1 .item-inner";
	String a = "a.img-holder";
	String summary = ".post-summary";
	String href = "href";
	String img = "img";
	String alt = "alt";
	String title = "title";
	String player = ".video-player";
	String item = ".bf-breadcrumb-item";
	String post_server = ".entry-content p, .entry-content img";
	String iframe = "iframe";
	String src = "src";
	String data_src = "data-src";
	String data_url = "data-url";
	String meta_image = "meta[name=twitter:image]";
	String content = "content";
	String tags_list_a = ".tags-list a";
	String category = "category";
	String video_ = "/video/";
	String separation_ = "-";


	String page = "page";
	String show = "show";
	String page_value = "1";
	String size = "size";
	String size_value = "24";


	String modelrs = "rs";
	String modelms = "ms";

}
