package com.news4coin.cfg;

import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {

	@Bean
    public BlockingQueue<Map<Long,String>> getPtpQueue() {
        return new LinkedBlockingQueue<Map<Long,String>>();
    }

}
