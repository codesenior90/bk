package com.news4coin.base;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public abstract class BaseCustomDao {

	@PersistenceContext
    private EntityManager entityManager;

}
