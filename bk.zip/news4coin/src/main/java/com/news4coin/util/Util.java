package com.news4coin.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;

import org.springframework.core.io.ClassPathResource;

import com.news4coin.constant.Static;

public class Util {
	public static String getBaseURL(HttpServletRequest request) {
		String scheme = request.getScheme();
		String serverName = request.getServerName();
		int serverPort = request.getServerPort();
		String contextPath = request.getContextPath();
		StringBuffer url = new StringBuffer();
		url.append(scheme).append("://").append(serverName);
		if ((serverPort != 80) && (serverPort != 443)) {
			url.append(":").append(serverPort);
		}
		url.append(contextPath);
		if (url.toString().endsWith("/")) {
			url.append("/");
		}
		return url.toString();
	}

	public static List<String> readFile(String filename) {
		List<String> urls = new ArrayList<String>();
		BufferedReader br = null;
		FileReader fr = null;
		try {
			br = new BufferedReader(
					new InputStreamReader(new FileInputStream(new ClassPathResource(filename).getFile())));
			String line;
			while ((line = br.readLine()) != null) {
				urls.add(line);
			}
		} catch (Exception e) {
		} finally {
			try {
				if (br != null)
					br.close();
				if (fr != null)
					fr.close();
			} catch (Exception ex) {
			}
		}
		return urls;
	}

	public static String getPath(String name) {
		try {
			return new ClassPathResource(name).getFile().getAbsolutePath();
		} catch (Exception e) {
		}
		return null;
	}

	public static boolean isAlpha(String s) {
		return s != null && s.matches(Static.znamealphanumber);
	}

	public static boolean isPhone(String s) {
		Matcher matcher = Static.robustPattern.matcher(s);
		return matcher.matches();
	}

	public static String password(String password) {
		String myHash = null;
		MessageDigest md;
		try {
			md = MessageDigest.getInstance(Static.md5);
			md.update(password.getBytes());
			byte[] digest = md.digest();
			myHash = DatatypeConverter.printHexBinary(digest).toUpperCase();
		} catch (NoSuchAlgorithmException e) {
		}
		return myHash;
	}

	private static final DecimalFormatSymbols symbols = new DecimalFormatSymbols();
	private static final String pattern = "$#,##0.####";
	private static final DecimalFormat decimalFormat = new DecimalFormat(pattern, symbols);

	public static String getPriceDisplay(BigDecimal price) {
		symbols.setGroupingSeparator(',');
		String bigDecimalConvertedValue = decimalFormat.format(price);
		return bigDecimalConvertedValue;
	}

	private static final String patternprice = "#,##0.##";
	private static final DecimalFormat decimalFormatPrice = new DecimalFormat(patternprice, symbols);

	public static String getPrice(BigDecimal price) {
		symbols.setGroupingSeparator(',');
		String bigDecimalConvertedValue = decimalFormatPrice.format(price);
		return bigDecimalConvertedValue;
	}

	private static final BigDecimal b100 = new BigDecimal(100);
	private static final int itwo = 2;
	private static final Float f100 = 100F;

	public static BigDecimal getPriceNET(BigDecimal price, Float fee) {
		price = price.multiply(BigDecimal.valueOf(f100 - fee));
		price = price.divide(b100);
		price = price.setScale(itwo, BigDecimal.ROUND_HALF_EVEN);
		return price;
	}

	private static final SimpleDateFormat df = new SimpleDateFormat("MM.dd.yyyy");

	public static String getDateDisplay(Date createDate) {
		return df.format(createDate);
	}

	private static final SimpleDateFormat sdf = new SimpleDateFormat("MM.dd.yyyy HH:mm:ss");

	public static String getExpireddateDisplay(Date expireddate) {
		return sdf.format(expireddate);
	}

	public static String getDescriptionDisplay(String description) {
		if (description.length() <= Static.z40) {
			return description;
		} else {
			return description.substring(Static.zero, Static.z39);
		}
	}

	public static String getClientIpAddress(HttpServletRequest request) {
		for (String header : Static.HEADERS_TO_TRY) {
			String ip = request.getHeader(header);
			if (ip != null && ip.length() != 0 && !Static.unknown.equalsIgnoreCase(ip)) {
				return ip;
			}
		}
		return request.getRemoteAddr();
	}
}
