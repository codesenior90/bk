package com.news4coin.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class Ads {

}
