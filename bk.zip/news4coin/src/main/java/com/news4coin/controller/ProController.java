package com.news4coin.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.news4coin.constant.Del;
import com.news4coin.constant.Static;
import com.news4coin.service.MenuService;
import com.news4coin.service.PostService;

@Controller
public class ProController {


	@Autowired
	MenuService menuService;

	@Autowired
	PostService postService;

	@RequestMapping(value = { "/" }, method = { RequestMethod.GET, RequestMethod.POST })
	public String index(Model model, HttpServletRequest request,
			@RequestParam(value = "q", required = false, defaultValue = "") String q,
			@RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
			@RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size) {
		try {
			model.addAttribute(Static.modelms, menuService.findByDelete(Del.NOTDEL.getLevelCode()));
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url1) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}

			if (q == null || Static.blank.equals(q)) {
				model.addAttribute(Static.modelrs, postService.getPage(Del.NOTDEL.getLevelCode(), page, size));
			} else {
				model.addAttribute(Static.modelrs, postService.getPage(q, Del.NOTDEL.getLevelCode(), page, size));
			}

			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, q);
			return "news";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "news";
	}

}
