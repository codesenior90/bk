package com.news4coin.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AllHeaderController {

	@GetMapping("/hs")
    public ResponseEntity<Map<String,String>> getAllheaders(@RequestHeader Map<String,String> headers){
        headers.forEach((key,value) ->{
            System.out.println("Header Name: "+key+" Header Value: "+value);
        });

        return new ResponseEntity<Map<String,String>>(
        		headers, HttpStatus.OK);
    }
}
