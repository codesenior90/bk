package com.news4coin.filter;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.news4coin.component.ApplicationContextProvider;
import com.news4coin.constant.Static;

//@Component
//@Order(1)
public class PTPFilter implements Filter {

	private static final Logger log = LoggerFactory.getLogger(PTPFilter.class);

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;

		log.info("Logging Request  {} : {}", req.getMethod(), req.getRequestURI());

		String uri = req.getRequestURI();
		uri = uri.replaceAll(Static.ptp, Static.blank);
		try {
			Long id = Long.parseLong(uri);
			String ip = getClientIpAddress(req);
			if(id != null && ip != null) {
				BlockingQueue<Map<Long,String>> PTPQueue = ApplicationContextProvider.getApplicationContext().getBean(BlockingQueue.class);
				if(PTPQueue != null) {
					LinkedHashMap<Long,String> map = new LinkedHashMap<Long, String>();
					map.put(id, ip);
					PTPQueue.add(map);
				}
			}
			log.info("Data {} : {}", id, ip);
		} catch (Exception e) {
			e.printStackTrace();
		}
		chain.doFilter(request, response);
		log.info("Logging Response :{}", res.getContentType());
	}

	private String getClientIpAddress(HttpServletRequest request) {
	    for (String header : Static.HEADERS_TO_TRY) {
	        String ip = request.getHeader(header);
	        if (ip != null && ip.length() != 0 && !Static.unknown.equalsIgnoreCase(ip)) {
	            return ip;
	        }
	    }
	    return request.getRemoteAddr();
	}

}
