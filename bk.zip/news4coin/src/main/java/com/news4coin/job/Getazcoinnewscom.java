package com.news4coin.job;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.news4coin.constant.Del;
import com.news4coin.constant.MenuNews;
import com.news4coin.constant.SiteName;
import com.news4coin.constant.Static;
import com.news4coin.entity.Menu;
import com.news4coin.entity.Post;
import com.news4coin.entity.PostDetail;
import com.news4coin.entity.Site;
import com.news4coin.service.MenuService;
import com.news4coin.service.PostService;
import com.news4coin.service.SiteService;

@Component
public class Getazcoinnewscom {

	private static final Logger log = LoggerFactory.getLogger(Getazcoinnewscom.class);

	private final static Integer one = 1;

	@Autowired
	SiteService siteService;
	@Autowired
	PostService postService;

	@Autowired
	MenuService menuService;

	@Transactional
	@Scheduled(initialDelay = 3 * 1000, fixedDelay = 43200 * 1000)
	public void get() {
//		log.info("start GetX");
		try {
			Site site = siteService.findByNameAndDel(SiteName.azcoinnews_com.getCode(), Del.NOTDEL.getLevelCode());
			if (site != null) {
				String url = site.getUrl();
				Integer done = site.getDone();
				if (one.equals(done)) {
					getData(url, site);
				} else {

				}
			}
		} catch (Exception exx) {
			exx.printStackTrace();
		}

//		log.info("end GetX");
	}

	private void getData(String url, Site site) {
		try {
			Document doc = Jsoup.connect(url).get();
			Elements es = doc.select(Static.post);
			List<Post> postList = new ArrayList<Post>();
			for (Element e : es) {
				try {
					Element a = e.selectFirst(Static.a);
					String href = a.attr(Static.href);
					Post PostExits = postService.findTop1ByUrlWebAndDel(href, Del.NOTDEL.getLevelCode());
					if (PostExits == null) {
						String img = a.attr(Static.data_src);
						String title = a.attr(Static.title);
						Element summary = e.selectFirst(Static.summary);
						Post post = new Post();
						post.setDel(Del.NOTDEL.getLevelCode());
						post.setTitle(title);
						post.setUrlWeb(href);
						post.setImg(img);
						if(summary == null) {
							post.setSummary(Static.blank);
						} else {
							post.setSummary(summary.text().trim());
						}

						doc = Jsoup.connect(href).get();
						Elements items = doc.select(Static.item);

						for (int i = 0; i < items.size(); i++) {
							if(i == 0) {
								continue;
							}
							if(i == 1) {
								String m = Static.blank;
								if(MenuNews.AZNEWS.getCode().equals(items.get(i).text().trim())) {
									m = MenuNews.NEWS.getCode();
								} else {
									m = items.get(i).text().trim();
								}
								Menu menu = menuService.findTop1ByNameAndDel(m, Del.NOTDEL.getLevelCode());
								if (menu != null) {
									post.setMenu(menu);

									Elements ps = doc.select(Static.post_server);
									if (ps != null) {
										List<PostDetail> list = new ArrayList<PostDetail>();
										for (Element p : ps) {
											PostDetail postDetail = new PostDetail();
											if (p.hasText()) {
												postDetail.setContent(p.text());
											} else {
												postDetail.setContent(p.attr(Static.src));
											}
											postDetail.setPost(post);
											list.add(postDetail);
										}
										if (!list.isEmpty()) {
											post.setPostDetails(list);
										}
									}
								}
							}

							if(i == 2) {
								Menu menu = menuService.findTop1ByNameAndDel(items.get(i).text().trim(), Del.NOTDEL.getLevelCode());
								if (menu != null) {
									post.setMenu2(menu);
								}
							}
						}
						if(post.getMenu() != null) {
							postList.add(post);
						}
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
			if (!postList.isEmpty()) {
				List<Post> savelist = postService.save(postList);
				postList = new ArrayList<Post>();
				for (Post Post : savelist) {
					try {
						String urlPost = Post.getUrlWeb().replaceAll(site.getRoot(), Static.blank);
						urlPost = urlPost.replaceAll(Static.separation, Static.blank);
						urlPost = urlPost.concat(Static.separation_);
						urlPost = urlPost + Post.getId();
						Post.setUrl(urlPost);
						postList.add(Post);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				if (!postList.isEmpty()) {
					postService.save(postList);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
