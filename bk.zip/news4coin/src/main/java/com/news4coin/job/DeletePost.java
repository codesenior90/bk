package com.news4coin.job;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.news4coin.entity.Post;
import com.news4coin.service.PostService;

@Component
public class DeletePost {

	private static final Logger log = LoggerFactory.getLogger(DeletePost.class);

	private static final long max = 1000L;

	@Autowired
	PostService postService;

//	@Scheduled(initialDelay = 3 * 1000, fixedDelay = 2 * 1000)
	@Transactional
//	@Scheduled(cron = "0 0 12 * * *")
	public void get() {
//		log.info("start DeleteVideo");
		try {
			long total = postService.count();
			if(max < total) {
				long id = postService.findLastId(max);
				List<Post> list = postService.findAllById(id);
				if(!list.isEmpty()) {
					postService.delete(list);
				 }
			}
		} catch (Exception exx) {
			exx.printStackTrace();
		}

//		log.info("end DeleteVideo");
	}

}
