package com.news4coin.entity;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.news4coin.base.BaseModel;
import com.news4coin.constant.Static;

/**
 * The persistent class for the brand database table.
 *
 */
@Entity
public class Menu extends BaseModel {

	/**
	 * @Fields serialVersionUID : TODO
	 */
	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String iss;

	@Column(length = Static.n999)
	private String name;

	@Column(length = Static.n999)
	private String value;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private Menu parent;

	@OneToMany(mappedBy = "parent")
	private Collection<Menu> children;

	@OneToMany(mappedBy = "menu")
	private Collection<Post> posts;

	@OneToMany(mappedBy = "menu2")
	private Collection<Post> posts2;

	public String getIss() {
		return iss;
	}

	public void setIss(String iss) {
		this.iss = iss;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Collection<Post> getPosts() {
		return posts;
	}

	public void setPosts(Collection<Post> posts) {
		this.posts = posts;
	}

	public Menu getParent() {
		return parent;
	}

	public void setParent(Menu parent) {
		this.parent = parent;
	}

	public Collection<Post> getPosts2() {
		return posts2;
	}

	public void setPosts2(Collection<Post> posts2) {
		this.posts2 = posts2;
	}

	public Collection<Menu> getChildren() {
		return children;
	}

	public void setChildren(Collection<Menu> children) {
		this.children = children;
	}

}