package com.news4coin.entity.pag;

public enum PageItemType {

    DOTS,
    PAGE

}
