package com.news4coin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import com.news4coin.base.BaseModel;
import com.news4coin.constant.Static;

@Entity
public class Site extends BaseModel {

	private static final long serialVersionUID = 1L;

	private String root;

	private String rootStr;

	@Column(length = Static.n999)
	private String url;

	private String name;

	private Integer done;

	public String getRoot() {
		return root;
	}

	public void setRoot(String root) {
		this.root = root;
	}

	public String getRootStr() {
		return rootStr;
	}

	public void setRootStr(String rootStr) {
		this.rootStr = rootStr;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getDone() {
		return done;
	}

	public void setDone(Integer done) {
		this.done = done;
	}

}
