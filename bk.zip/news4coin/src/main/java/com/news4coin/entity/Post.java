package com.news4coin.entity;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.news4coin.base.BaseModel;
import com.news4coin.constant.Static;
import com.news4coin.util.Util;

@Entity
public class Post extends BaseModel {

	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String title;

	private Long view;

	@Column(length = Static.n999)
	private String img;

	@Column(length = Static.n999)
	private String url;

	@Column(length = Static.n999)
	private String urlWeb;

	@Column(length = Static.n999)
	private String summary;

	@OneToMany(mappedBy="post", cascade=CascadeType.PERSIST)
    private Collection<PostDetail> postDetails;

	@ManyToOne
    @JoinColumn(name = "menu_id", nullable=false)
    private Menu menu;

	@ManyToOne
    @JoinColumn(name = "menu2_id", nullable=true)
    private Menu menu2;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Long getView() {
		return view;
	}

	public void setView(Long view) {
		this.view = view;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrlWeb() {
		return urlWeb;
	}

	public void setUrlWeb(String urlWeb) {
		this.urlWeb = urlWeb;
	}

	public Collection<PostDetail> getPostDetails() {
		return postDetails;
	}

	public void setPostDetails(Collection<PostDetail> postDetails) {
		this.postDetails = postDetails;
	}

	public String getDateDisplay() {
		return Util.getDateDisplay(this.getCreatedate());
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public Menu getMenu2() {
		return menu2;
	}

	public void setMenu2(Menu menu2) {
		this.menu2 = menu2;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

}

