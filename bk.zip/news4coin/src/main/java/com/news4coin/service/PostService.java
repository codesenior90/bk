package com.news4coin.service;

import java.util.List;

import com.news4coin.base.BaseService;
import com.news4coin.entity.Post;
import com.news4coin.entity.pag.Paged;

public interface PostService extends BaseService<Post, Long> {

	Post findTop1ByUrlWebAndDel(String urlWeb, Integer del);

	Paged<Post> getPage(Integer del, int pageNumber, int size);

	Post findTop1ByUrlAndDel(String url, Integer del);

	Paged<Post> getPage(int pageNumber, int size);

	Paged<Post> getPage(String q, Integer del, int pageNumber, int size);

	Paged<Post> findByMenu_ValueAndDelOrderByIdDesc(String value,Integer del, int pageNumber, int size);

	Paged<Post> getPage(String q, int pageNumber, int size);

	Long findLastId(Long limit);

	List<Post> findAllById(Long id);

	Object[] findRandom(Integer limit);
}
