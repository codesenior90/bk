package com.news4coin.service.imp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news4coin.base.BaseServiceImpl;
import com.news4coin.dao.PostDetailDao;
import com.news4coin.entity.PostDetail;
import com.news4coin.service.PostDetailService;

@Service
public class PostDetailServiceImp extends BaseServiceImpl<PostDetail> implements PostDetailService {

	@Autowired
	PostDetailDao postDetailDao;

}
