package com.news4coin.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.news4coin.base.BaseServiceImpl;
import com.news4coin.dao.PostDao;
import com.news4coin.entity.Post;
import com.news4coin.entity.pag.Paged;
import com.news4coin.entity.pag.Paging;
import com.news4coin.service.PostService;

@Service
public class PostServiceImp extends BaseServiceImpl<Post> implements PostService {

	@Autowired
	PostDao postDao;

	@Override
	public Post findTop1ByUrlWebAndDel(String urlWeb, Integer del) {
		return postDao.findTop1ByUrlWebAndDel(urlWeb, del);
	}

	@Override
	public Paged<Post> getPage(Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Post> page = postDao.findByDelOrderByIdDesc(del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Post findTop1ByUrlAndDel(String url, Integer del) {
		return postDao.findTop1ByUrlAndDel(url, del);
	}

	@Override
	public Paged<Post> getPage(int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Post> page = postDao.findByOrderByIdDesc(request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<Post> getPage(String q, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Post> page = postDao.findByTitleStartsWithAndDelOrderByIdDesc(q, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<Post> findByMenu_ValueAndDelOrderByIdDesc(String value, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Post> page = postDao.findByMenu_ValueAndDelOrderByIdDesc(value, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<Post> getPage(String q, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Post> page = postDao.findByTitleStartsWithOrderByIdDesc(q, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Long findLastId(Long limit) {
		return postDao.findLastId(limit);
	}

	@Override
	public List<Post> findAllById(Long id) {
		return postDao.findAllById(id);
	}

	@Override
	public Object[] findRandom(Integer limit) {
		return postDao.findRandom(limit);
	}


}
