package com.news4coin.service;

import com.news4coin.base.BaseService;
import com.news4coin.entity.PostDetail;

public interface PostDetailService extends BaseService<PostDetail, Long> {

}
