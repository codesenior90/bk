package com.news4coin.service;

import java.util.List;

import com.news4coin.base.BaseService;
import com.news4coin.entity.Menu;
import com.news4coin.entity.pag.Paged;

public interface MenuService extends BaseService<Menu, Long> {
	List<Menu> findByDelete(Integer delete);

	Menu findTop1ByNameAndDel(String name, Integer delete);

	Menu findTop1ByIdAndDel(Long id, Integer del);

	Paged<Menu> getPage(int pageNumber, int size);

	Menu findTop1ByValueAndDel(String value, Integer delete);
}
