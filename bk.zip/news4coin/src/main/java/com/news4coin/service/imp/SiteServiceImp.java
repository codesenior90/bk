package com.news4coin.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news4coin.base.BaseServiceImpl;
import com.news4coin.dao.SiteDao;
import com.news4coin.entity.Site;
import com.news4coin.service.SiteService;

@Service
public class SiteServiceImp extends BaseServiceImpl<Site> implements SiteService {

	@Autowired
	SiteDao siteDao;

	@Override
	public List<Site> findByDelete(Integer delete) {
		return siteDao.findByDel(delete);
	}

	@Override
	public Site findByNameAndDel(String name, Integer delete) {
		return siteDao.findByNameAndDel(name, delete);
	}

}
