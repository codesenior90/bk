package com.news4coin.service;

import java.util.List;

import com.news4coin.base.BaseService;
import com.news4coin.entity.Site;

public interface SiteService extends BaseService<Site, Long> {
	List<Site> findByDelete(Integer delete);

	Site findByNameAndDel(String name, Integer delete);
}
