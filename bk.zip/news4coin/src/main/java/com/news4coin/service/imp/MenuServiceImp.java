package com.news4coin.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.news4coin.base.BaseServiceImpl;
import com.news4coin.dao.MenuDao;
import com.news4coin.entity.Menu;
import com.news4coin.entity.pag.Paged;
import com.news4coin.entity.pag.Paging;
import com.news4coin.service.MenuService;

@Service
public class MenuServiceImp extends BaseServiceImpl<Menu> implements MenuService {

	@Autowired
	MenuDao menuDao;

	@Override
	public List<Menu> findByDelete(Integer delete) {
		return menuDao.findByDel(delete);
	}

	@Override
	public Menu findTop1ByNameAndDel(String name, Integer delete) {
		return menuDao.findTop1ByNameAndDel(name, delete);
	}

	@Override
	public Menu findTop1ByIdAndDel(Long id, Integer del) {
		return menuDao.findTop1ByIdAndDel(id, del);
	}

	@Override
	public Paged<Menu> getPage(int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Menu> page = menuDao.findByOrderByIdDesc(request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Menu findTop1ByValueAndDel(String value, Integer delete) {
		return menuDao.findTop1ByValueAndDel(value, delete);
	}

}
