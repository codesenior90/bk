package com.news4coin.dao;

import java.util.List;

import com.news4coin.base.BaseDao;
import com.news4coin.entity.Site;

public interface SiteDao extends BaseDao<Site> {
	List<Site> findByDel(Integer delete);
	Site findByNameAndDel(String name, Integer delete);
}
