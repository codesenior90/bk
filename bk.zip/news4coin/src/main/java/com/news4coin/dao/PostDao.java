package com.news4coin.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.news4coin.base.BaseDao;
import com.news4coin.entity.Post;

public interface PostDao extends BaseDao<Post> {

	Post findTop1ByUrlWebAndDel(String urlWeb, Integer del);

	Page<Post> findByDelOrderByIdDesc(Integer del, Pageable pageable);

	Post findTop1ByUrlAndDel(String url, Integer del);

	Page<Post> findByOrderByIdDesc(Pageable pageable);

	@Query("SELECT v FROM Post v WHERE (v.title LIKE %?1%) and v.del = ?2 order by v.id desc")
	Page<Post> findByTitleStartsWithAndDelOrderByIdDesc(String title, Integer del, Pageable pageable);

	Page<Post> findByMenu_ValueAndDelOrderByIdDesc(String value,Integer del, Pageable pageable);

	@Query("SELECT v FROM Post v WHERE (v.title LIKE %?1%) order by v.id desc")
	Page<Post> findByTitleStartsWithOrderByIdDesc(String title, Pageable pageable);

	@Query(value = "select sub.id from (SELECT id FROM Post v order by v.id desc limit ?1) as sub order by sub.id asc limit 1", nativeQuery = true)
	Long findLastId(Long limit);


	@Query("SELECT v FROM Post v WHERE v.id < ?1")
	List<Post> findAllById(Long id);

	@Query(value = "SELECT v.url FROM Post v ORDER BY RAND() limit ?1", nativeQuery = true)
	Object[] findRandom(Integer limit);



}
