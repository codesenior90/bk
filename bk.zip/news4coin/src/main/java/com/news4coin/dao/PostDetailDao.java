package com.news4coin.dao;

import com.news4coin.base.BaseDao;
import com.news4coin.entity.PostDetail;

public interface PostDetailDao extends BaseDao<PostDetail> {

}
