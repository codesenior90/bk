$(document).ready(function() {
});

function change() {
	$("#carsForm").submit();
}