package com.adz2pro.job;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.adz2pro.entity.PTPRequest;
import com.adz2pro.service.PTPRequestService;
import com.adz2pro.util.Util;

@Component
public class DeletePtpRequest {

	private static final Logger log = LoggerFactory.getLogger(DeletePtpRequest.class);

	private static final int add2 = -2;
	@Autowired
	PTPRequestService ptpRequestService;

	@Transactional
//	@Scheduled(cron = "0 * * * * *")

//	@Scheduled(cron = "0 21 19 * * *")
	@Scheduled(cron = "0 0 12 * * *")
	public void get() {
//		log.info("start DeletePtpRequest");
		try {
			 Calendar c2 = Calendar.getInstance();
			 Date date = new Date();
			 c2.setTime(date);
			 c2.add(Calendar.DATE, add2);
			 String day = Util.getDateDisplay(c2.getTime());
			 List<PTPRequest> list = ptpRequestService.findByCreateRequest(day);
			 if(!list.isEmpty()) {
				 ptpRequestService.delete(list);
			 }
		} catch (Exception exx) {
			exx.printStackTrace();
		}

//		log.info("end DeletePtpRequest");
	}

}
