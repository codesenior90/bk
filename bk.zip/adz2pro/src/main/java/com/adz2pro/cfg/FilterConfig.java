package com.adz2pro.cfg;
//package com.adz2pro.cfg;
//
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import com.adz2pro.filter.PTPFilter;
//
//@Configuration
//public class FilterConfig {
//
//	@Bean
//	public FilterRegistrationBean<PTPFilter> ptpFilter() {
//		FilterRegistrationBean<PTPFilter> registrationBean = new FilterRegistrationBean<>();
//		registrationBean.setFilter(new PTPFilter());
//		registrationBean.addUrlPatterns("/ptp-*");
//		registrationBean.setOrder(2);
//		return registrationBean;
//	}
//}
