package com.adz2pro.base;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public interface BaseService<T, S> {

    /**
     * Get list
     *
     * @return
     */
    public List<T> findAll() ;

    /**
     * Get list
     *
     * @param sort
     * @return
     */
    public List<T> findAll(Sort sort);

    /**
     * Insert data
     *
     * @param entity
     * @return
     */
    public T insert(T entity);

    /**
     * Insert all data
     *
     * @param entities
     * @return
     */
	public List<T> insert(Iterable<T> entities);

	/**
	 * Get all data paging
	 *
	 * @param pageable
	 * @return
	 */
	public Page<T> findAll(Pageable pageable);

	/**
	 * Save data
	 *
	 * @param entity
	 * @return
	 */
	public T save(T entity);

	/**
	 * Save all data
	 *
	 * @param entities
	 * @return
	 */
	public List<T> save(Iterable<T> entities);

	/**
	 * Find entity
	 *
	 * @param id
	 * @return
	 */
	public T findOne(S id);

	/**
	 * Exist entity
	 *
	 * @param id
	 * @return
	 */
	public boolean exists(S id);

	/**
	 * Find all by list id
	 *
	 * @param ids
	 * @return
	 */
	public Iterable<T> findAll(Iterable<S> ids);

	/**
	 * Count
	 *
	 * @return
	 */
	public long count();

	/**
	 * Delete entity by id
	 *
	 * @param id
	 */
	public void delete(S id);

	/**
	 * Delete entity by entity
	 *
	 * @param entity
	 */
	public void deleteEntity(T entity);

	/**
	 * Delete entity by list entity.
	 *
	 * @param entities
	 */
	public void delete(Iterable<? extends T> entities);

	/**
	 * Delete all entity.
	 *
	 */
	public void deleteAll();

}
