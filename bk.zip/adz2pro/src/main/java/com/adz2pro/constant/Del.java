package com.adz2pro.constant;

public enum Del {
	DEL(1),
	NOTDEL(0);

	private final int levelCode;

    private Del(int levelCode) {
        this.levelCode = levelCode;
    }

    public int getLevelCode() {
        return this.levelCode;
    }
}
