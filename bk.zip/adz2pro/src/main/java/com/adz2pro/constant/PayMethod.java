package com.adz2pro.constant;

public enum PayMethod {
	paypal("paypal"),
	bitcoin("bitcoin"),
	payeer("payeer");

	private final String code;

    private PayMethod(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
