package com.adz2pro.constant;

public enum Done {
	DONE(1),
	NOTDONE(0),
	CANCELLED(2),
	RETURNED(3);

	private final int levelCode;

    private Done(int levelCode) {
        this.levelCode = levelCode;
    }

    public int getLevelCode() {
        return this.levelCode;
    }
}
