package com.adz2pro.constant;

public enum Status {
	SUCCESS("success"),
	FAIL("fail");

	private final String code;

    private Status(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
