package com.adz2pro.constant;

public enum Type {
	PTP(1),
	BANNER(0);

	private final int levelCode;

    private Type(int levelCode) {
        this.levelCode = levelCode;
    }

    public int getLevelCode() {
        return this.levelCode;
    }
}
