package com.adz2pro.constant;

import java.util.regex.Pattern;

public interface Static {
	int n999 = 999;
	int n444 = 444;
	int n99 = 99;
	Integer zero = 0;
	Long zero_ = 0L;
	Long one = 1L;
	long l60 = 60;
	Integer z39 = 39;
	Integer z40 = 40;
	String zeroS = "0";
	String blank = "";
	String url1 = "?";
	String url2 = "&page";
	String url3 = "?page";
	String url4 = "&";
	String separation = "/";
	String n = "\n";


	String znamealphanumber = "^[a-zA-Z0-9]*$";

    Pattern robustPattern = Pattern
	        .compile(
	                // Robust expression from before
	                "^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$"
	                // Area code, within or without parentheses,
	                // followed by groups of 3-4 numbers with or without hyphens
	                + "| ((\\(\\d{3}\\) ?)|(\\d{3}-))?\\d{3}-\\d{4}"
	                // (+) followed by 10-12 numbers
	                + "|^\\+\\d{10,12}"
	);

    String md5 = "MD5";
    String ptp = "/ptp/";

    String[] HEADERS_TO_TRY = {
            "X-Forwarded-For",
            "Proxy-Client-IP",
            "WL-Proxy-Client-IP",
            "HTTP_X_FORWARDED_FOR",
            "HTTP_X_FORWARDED",
            "HTTP_X_CLUSTER_CLIENT_IP",
            "HTTP_CLIENT_IP",
            "HTTP_FORWARDED_FOR",
            "HTTP_FORWARDED",
            "HTTP_VIA",
            "REMOTE_ADDR" };

    String unknown = "unknown";
    String error = "error";
    String Referer = "Referer";
    String price = "price";

    String ptp_data = "ptpdata";
    String promote = "promote";
    String ptptoken = "ptptoken";
    String url = "url";
    String q = "q";

    //page
    String signup = "signup";
    String adminsignup = "admin/signup";
    String myprofile = "my-profile";
    String paymentrequest = "payment-request";
	String login = "login";
	String adminlogin = "admin/login";
	String home = "redirect:/";
	String redirectsignup = "redirect:/signup";
	String redirectlogin = "redirect:/login";
	String redirectadminlogin = "redirect:/admin/login";
	String redirect = "redirect:/";
	String adminredirect = "redirect:/admin";
	String redirectsurfer = "redirect:/surfer";
	String redirectptp = "redirect:/ptp";
	String redirectadminuser = "redirect:/admin/user";
	String redirectmyprofile = "redirect:/my-profile";

	String pagehome = "home";
	String pageptp = "ptp";
	String pagetag = "tag";
	String pageadminuser = "admin/user";
	String pageadminuserupdate = "admin/user-update";
	String pageadminptpupdate = "admin/ptp-update";


	String pageadminpr = "admin/payment-request";
	String pageadminprupdate = "admin/payment-request-update";

	String pageadminptp = "admin/ptp";
	String pageadminptpbanner = "admin/ptp-banner";

	String pagecpm = "cpm";
	String pagecpmblank = "cpm-blank";
	String pagebannerblank = "banner-blank";
	String pageptpmain = "ptp-main";
	String pageptppromote = "ptp-promote";
	String pagebanner = "banner";
	String pagesurfer = "surfer";
	String pagepaymentrequest = "payment-request";

	String urlhome = "/";
	String urlptp = "/ptp";
	String urlptppromote = "/ptp/promote-{promote}";
	String urltag = "/tag";
	String urlbanner = "/banner/promote-{promote}";
	String urlcpm = "/cpm/promote-{promote}";
	String urllogout = "/logout";
	String urlsignup = "/signup";
	String urlmyprofile = "/my-profile";
	String urlsurfer = "/surfer";
	String urlpaymentrequest = "/payment-request";

	String urladminuser = "/user";
	String urladminuserall = "/user-all";

	String urladminuseractive = "/user-active";
	String urladminuserinactive = "/user-inactive";
	String urladminuserdel = "/user-del";
	String urladminuserupdate = "/user-update";
	String urladminptpupdate = "/ptp-update";

	String urladminprall = "/payment-request-all";

	String urladminpr = "/payment-request";
	String urladminprdone = "/payment-request-done";
	String urladminprpending = "/payment-request-notdone";
	String urladminprdel = "/payment-request-del";

	String urladminprupdate = "/payment-request-update";

	String urladminptp = "/ptp";
	String urladminptpbanner = "/ptp-banner";

	String urladmin = "/admin";

	String modeluser = "user";
	String modelpr = "pr";
	String modeladmin = "admin";
	String modelrs = "rs";

	String modelusers = "users";
	String modeltitle = "title";
	String all = "All";


	String username = "username";
	String admin = "admin";


	String login_ = "/login";
	String paymentsave = "/payment-save";
	String loginForm = "loginForm";


    //error message
    String Unknown_Referrer = "Unknown Referrer/Direct Visit is not allowed.";
    String not_allowed = "Visit is not allowed.";

    String userpass = "Wrong username and password";

	String user = "you must enter username";
	String user_ = "username is only alphabets and numbers";
	String user_max = "username max length 999";
	String pass_max = "password max length 999";
	String fullname_max = "fullname max length 999";
	String email_max = "email max length 999";
	String paymentmethod_max = "paymentmethod max length 999";
	String paymentaccount_max = "paymentaccount max length 999";
	String user_exist = "username is exist";
	String ip_exist = "IP address is registed";
	String pass = "you must enter password";
	String email = "you must enter email";
	String fullname = "you must enter fullname";

	String password2 = "you must enter correct password2";

	String paymentmethod = "you must select payment method";
	String paymentmethod_exist = "payment method is not exist";
	String paymentaccount = "you must enter payment account";
	String paymentaccount_exist = "payment account is exist";

	String minpayment = "min payment must %s %s";

	String paymentaccount_not_exist = "payment account is not exist";

    String earn_success = "%s earn %s %s";
    String banner = "<script type='text/javascript' src='%s'></script>";

    String vietnam = "Viet Nam";

    String iplocation = "https://api.iplocation.net/?ip=";
}
