package com.adz2pro.dto;

import java.math.BigDecimal;

public class PTPDto {

	private Long id;

	private String link;
	private BigDecimal today;
	private BigDecimal allTime	;

	private Long todayCount;
	private Long allTimeCount;

	private Long userId;
	private String username;

	public PTPDto(Long id, String link, BigDecimal today,
			BigDecimal allTime, Long todayCount, Long allTimeCount,
			Long userId, String username) {
		super();
		this.id = id;
		this.link = link;
		this.today = today;
		this.allTime = allTime;
		this.todayCount = todayCount;
		this.allTimeCount = allTimeCount;
		this.userId = userId;
		this.username = username;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public BigDecimal getToday() {
		return today;
	}

	public void setToday(BigDecimal today) {
		this.today = today;
	}

	public BigDecimal getAllTime() {
		return allTime;
	}

	public void setAllTime(BigDecimal allTime) {
		this.allTime = allTime;
	}

	public Long getTodayCount() {
		return todayCount;
	}

	public void setTodayCount(Long todayCount) {
		this.todayCount = todayCount;
	}

	public Long getAllTimeCount() {
		return allTimeCount;
	}

	public void setAllTimeCount(Long allTimeCount) {
		this.allTimeCount = allTimeCount;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
