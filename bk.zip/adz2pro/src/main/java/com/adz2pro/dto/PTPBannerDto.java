package com.adz2pro.dto;

import java.math.BigDecimal;

public class PTPBannerDto {

	private Long id;

	private String banner;
	private BigDecimal todayBanner;
	private BigDecimal allTimeBanner	;

	private Long todayBannerCount;
	private Long allTimeBannerCount;

	private Long userId;
	private String username;

	public PTPBannerDto(Long id, String banner, BigDecimal todayBanner,
			BigDecimal allTimeBanner, Long todayBannerCount, Long allTimeBannerCount,
			Long userId, String username) {
		super();
		this.id = id;
		this.banner = banner;
		this.todayBanner = todayBanner;
		this.allTimeBanner = allTimeBanner;
		this.todayBannerCount = todayBannerCount;
		this.allTimeBannerCount = allTimeBannerCount;
		this.userId = userId;
		this.username = username;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBanner() {
		return banner;
	}

	public void setBanner(String banner) {
		this.banner = banner;
	}

	public BigDecimal getTodayBanner() {
		return todayBanner;
	}

	public void setTodayBanner(BigDecimal todayBanner) {
		this.todayBanner = todayBanner;
	}

	public BigDecimal getAllTimeBanner() {
		return allTimeBanner;
	}

	public void setAllTimeBanner(BigDecimal allTimeBanner) {
		this.allTimeBanner = allTimeBanner;
	}

	public Long getTodayBannerCount() {
		return todayBannerCount;
	}

	public void setTodayBannerCount(Long todayBannerCount) {
		this.todayBannerCount = todayBannerCount;
	}

	public Long getAllTimeBannerCount() {
		return allTimeBannerCount;
	}

	public void setAllTimeBannerCount(Long allTimeBannerCount) {
		this.allTimeBannerCount = allTimeBannerCount;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
