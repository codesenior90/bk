package com.adz2pro.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.adz2pro.util.Util;

public class PaymentRequestDto {

	private Long id;

	private String payeer;
	private String bitcoin;
	private String paypal;
	private BigDecimal amount;
	private Integer done;
	private Date createdate;

	public PaymentRequestDto(Long id, String payeer, String bitcoin, String paypal, BigDecimal amount, Integer done,
			Date createdate) {
		super();
		this.id = id;
		this.payeer = payeer;
		this.bitcoin = bitcoin;
		this.paypal = paypal;
		this.amount = amount;
		this.done = done;
		this.createdate = createdate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPayeer() {
		return payeer;
	}

	public void setPayeer(String payeer) {
		this.payeer = payeer;
	}

	public String getBitcoin() {
		return bitcoin;
	}

	public void setBitcoin(String bitcoin) {
		this.bitcoin = bitcoin;
	}

	public String getPaypal() {
		return paypal;
	}

	public void setPaypal(String paypal) {
		this.paypal = paypal;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Integer getDone() {
		return done;
	}

	public void setDone(Integer done) {
		this.done = done;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getAmountDisplay() {
		return Util.getPriceDisplay(this.amount);
	}

	public String getCreatedateDisplay() {
		return Util.getDateDisplay(this.createdate);
	}

}
