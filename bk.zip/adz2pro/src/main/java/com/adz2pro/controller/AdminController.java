package com.adz2pro.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.adz2pro.constant.Active;
import com.adz2pro.constant.Del;
import com.adz2pro.constant.Static;
import com.adz2pro.entity.Admin;
import com.adz2pro.entity.User;
import com.adz2pro.form.UserForm;
import com.adz2pro.service.AdminService;
import com.adz2pro.service.UserService;
import com.adz2pro.util.EmailValidatorApache;
import com.adz2pro.util.Util;

@Controller
@RequestMapping(Static.urladmin)
public class AdminController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	AdminService adminService;

	@Value("${admin.pass}")
	private String pass;

	@Autowired
	UserService userService;

	@RequestMapping(value = { Static.login_ }, method = { RequestMethod.POST, RequestMethod.GET })
	public String login(@RequestParam(value = "username", required = false, defaultValue = Static.blank) String username,
			@RequestParam(value = "password", required = false, defaultValue = Static.blank) String password,
			HttpServletRequest request, HttpSession session, Model model) {
		try {
			StringBuilder str = new StringBuilder();
			username = username.trim();
			password = password.trim();
			if (username == null || Static.blank.equals(username)) {
				str.append(Static.user);
				str.append(Static.n);
			} else {
				if (!Util.isAlpha(username)) {
					str.append(Static.user_);
					str.append(Static.n);
				}
				if(Static.n999 < username.length()) {
					str.append(Static.user_max);
					str.append(Static.n);
				}
			}
			if (password == null || Static.blank.equals(password)) {
				str.append(Static.pass);
				str.append(Static.n);
			} else {
				if(Static.n999 < password.length()) {
					str.append(Static.pass_max);
					str.append(Static.n);
				}
			}
			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return Static.adminlogin;
			}
			Admin admin = adminService.findTop1ByUsernameAndPasswordAndDelAndActive(username.trim(),
					password.trim(), Del.NOTDEL.getLevelCode(), Active.ACTIVE.getLevelCode());
			if (admin == null) {
				model.addAttribute(Static.error, Static.userpass);
				return Static.adminlogin;
			} else {
				session.setAttribute(Static.admin, username);
				return Static.redirectadminuser;
			}
		} catch (Exception e) {
		}
		return Static.adminlogin;
	}

	@RequestMapping(value = { Static.urllogout }, method = { RequestMethod.POST, RequestMethod.GET })
	public String logout(HttpSession session) {
		try {
			session.removeAttribute(Static.admin);
		} catch (Exception e) {
		}
		return Static.adminredirect;
	}

	@RequestMapping(value = { Static.urlsignup }, method = { RequestMethod.GET })
	public String signup(@ModelAttribute("userForm") UserForm userForm) {
		try {
		} catch (Exception e) {
		}
		return Static.adminsignup;
	}

	@RequestMapping(value = { Static.urlsignup }, method = { RequestMethod.POST })
	public String signup(@ModelAttribute("userForm") UserForm userForm,
			@RequestParam(value = "username", required = false, defaultValue = "username") String username,
			@RequestParam(value = "password", required = false, defaultValue = "password") String password,
			HttpServletRequest request, HttpSession session, Model model) {
		try {
			StringBuilder str = new StringBuilder();
			if (userForm.getUsername() == null || userForm.getUsername().equals(Static.blank)) {
				str.append(Static.user);
				str.append(Static.n);
			} else {
				if (!Util.isAlpha(username)) {
					str.append(Static.user_);
					str.append(Static.n);
				}
				if(Static.n999 < username.length()) {
					str.append(Static.user_max);
					str.append(Static.n);
				}
			}
			if (!EmailValidatorApache.isValid(userForm.getEmail())) {
				str.append(Static.email);
				str.append(Static.n);
			} else {
				if(Static.n999 < userForm.getEmail().length()) {
					str.append(Static.email_max);
					str.append(Static.n);
				}
			}
			if (userForm.getPassword() == null || userForm.getPassword().equals(Static.blank)) {
				str.append(Static.pass);
				str.append(Static.n);
			} else {
				if(Static.n999 < userForm.getPassword().length()) {
					str.append(Static.pass_max);
					str.append(Static.n);
				}
			}
			if (userForm.getFullname() == null || userForm.getFullname().equals(Static.blank)) {
				str.append(Static.fullname);
				str.append(Static.n);
			} else {
				if(Static.n999 < userForm.getFullname().length()) {
					str.append(Static.fullname_max);
					str.append(Static.n);
				}
			}
			if(userForm.getPassword2() == null || userForm.getPassword2().equals(Static.blank) || !pass.equals(userForm.getPassword2())) {
				str.append(Static.password2);
				str.append(Static.n);
			}
			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return Static.adminsignup;
			} else {
				if (adminService.findTop1ByUsername(username) != null) {
					str.append(Static.user_exist);
					str.append(Static.n);
				}
				if (str.length() > Static.zero) {
					model.addAttribute(Static.error, str);
					return Static.adminsignup;
				}

				Admin admin = new Admin();
				admin.setActive(Active.ACTIVE.getLevelCode());
				admin.setDel(Del.NOTDEL.getLevelCode());
				BeanUtils.copyProperties(userForm, admin);
//				admin.setPassword(Util.password(admin.getPassword()));
				adminService.save(admin);
				return Static.adminlogin;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.adminsignup;
	}

	@RequestMapping(value = {Static.blank ,Static.urlhome, Static.urladminuser, Static.urladminuserall }, method = RequestMethod.GET)
	public String userall(Model model, HttpSession session,
			HttpServletRequest request,
			@RequestParam(value = Static.q, required = false, defaultValue = Static.blank) String q,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size
			) {
		try {
			Object adminSession = session.getAttribute(Static.admin);
			if (adminSession == null) {
				return Static.redirectadminlogin;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
        	String query = request.getQueryString();
        	if(query != null && !Static.blank.equals(query)) {
        		url.append(Static.url1);
            	url.append(request.getQueryString());
        	}
        	int idx = url.lastIndexOf(Static.url2);
        	if(idx >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
        	}
        	int index = url.lastIndexOf(Static.url3);
        	if(index >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
        	}
        	if(url.indexOf(Static.url4) >=0) {
        		url.append(Static.url4);
        	} else {
        		url.append(Static.url1);
        	}
        	if(q == null || Static.blank.equals(q)) {
        		model.addAttribute(Static.modelusers, adminService.getPage(Del.NOTDEL.getLevelCode(), page, size));
        	} else {
        		model.addAttribute(Static.modelusers, adminService.getPage(q, Del.NOTDEL.getLevelCode(), page, size));
        	}

			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, q);
			model.addAttribute(Static.modeltitle, Static.all.toLowerCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageadminuser;
	}


	@RequestMapping(value = {Static.urladminuserupdate }, method = RequestMethod.GET)
	public String userupdate(Model model, HttpSession session,
			@RequestParam(value = "id", required = false, defaultValue = "0") Long id) {
		try {
			Object adminSession = session.getAttribute(Static.admin);
			if (adminSession == null) {
				return Static.redirectadminlogin;
			}
			if(id == null || id.equals(Static.zero_)) {
				return Static.adminredirect;
			}
			model.addAttribute(Static.modeluser, userService.findOne(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageadminuserupdate;
	}

	@RequestMapping(value = {Static.urladminuserupdate }, method = RequestMethod.POST)
	public String userupdate(Model model, HttpSession session,
			@RequestParam(value = "id", required = false, defaultValue = "0") Long id,
			@RequestParam(value = "active", required = false, defaultValue = "1") Integer active,
			@RequestParam(value = "del", required = false, defaultValue = "0") Integer del
			) {
		try {
			Object adminSession = session.getAttribute(Static.admin);
			if (adminSession == null) {
				return Static.redirectadminlogin;
			}
			if(id == null || id.equals(Static.zero_)) {
				return Static.adminredirect;
			}
			User user = userService.findOne(id);

			if(Active.ACTIVE.getLevelCode() == active) {
				user.setActive(Active.ACTIVE.getLevelCode());
			}

			if(Active.INACTIVE.getLevelCode() == active) {
				user.setActive(Active.INACTIVE.getLevelCode());
			}

			if(Del.DEL.getLevelCode() == del) {
				user.setDel(Del.DEL.getLevelCode());
			}

			if(Del.NOTDEL.getLevelCode() == del) {
				user.setDel(Del.NOTDEL.getLevelCode());
			}

			user = userService.save(user);

			model.addAttribute(Static.modeluser, user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageadminuserupdate;
	}

	@RequestMapping(value = {Static.urladminuseractive }, method = RequestMethod.GET)
	public String useractive(Model model, HttpSession session,
			HttpServletRequest request,
			@RequestParam(value = Static.q, required = false, defaultValue = Static.blank) String q,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size
			) {
		try {
			Object adminSession = session.getAttribute(Static.admin);
			if (adminSession == null) {
				return Static.redirectadminlogin;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
        	String query = request.getQueryString();
        	if(query != null && !Static.blank.equals(query)) {
        		url.append(Static.url1);
            	url.append(request.getQueryString());
        	}
        	int idx = url.lastIndexOf(Static.url2);
        	if(idx >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
        	}
        	int index = url.lastIndexOf(Static.url3);
        	if(index >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
        	}
        	if(url.indexOf(Static.url4) >=0) {
        		url.append(Static.url4);
        	} else {
        		url.append(Static.url1);
        	}

        	if(q == null || Static.blank.equals(q)) {
        		model.addAttribute(Static.modelusers, adminService.getPage(Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(), page, size));
        	} else {
    			model.addAttribute(Static.modelusers, adminService.getPage(q,Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(), page, size));
        	}

			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, q);
			model.addAttribute(Static.modeltitle, Active.ACTIVE.name().toLowerCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageadminuser;
	}

	@RequestMapping(value = {Static.urladminuserinactive }, method = RequestMethod.GET)
	public String userinactive(Model model, HttpSession session,
			HttpServletRequest request,
			@RequestParam(value = Static.q, required = false, defaultValue = Static.blank) String q,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size
			) {
		try {
			Object adminSession = session.getAttribute(Static.admin);
			if (adminSession == null) {
				return Static.redirectadminlogin;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
        	String query = request.getQueryString();
        	if(query != null && !Static.blank.equals(query)) {
        		url.append(Static.url1);
            	url.append(request.getQueryString());
        	}
        	int idx = url.lastIndexOf(Static.url2);
        	if(idx >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
        	}
        	int index = url.lastIndexOf(Static.url3);
        	if(index >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
        	}
        	if(url.indexOf(Static.url4) >=0) {
        		url.append(Static.url4);
        	} else {
        		url.append(Static.url1);
        	}
        	if(q == null || Static.blank.equals(q)) {
        		model.addAttribute(Static.modelusers, adminService.getPage(Active.INACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(), page, size));
        	} else {
    			model.addAttribute(Static.modelusers, adminService.getPage(q,Active.INACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode(), page, size));
        	}
			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, q);
			model.addAttribute(Static.modeltitle, Active.INACTIVE.name().toLowerCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageadminuser;
	}

	@RequestMapping(value = {Static.urladminuserdel }, method = RequestMethod.GET)
	public String userdel(Model model, HttpSession session,
			HttpServletRequest request,
			@RequestParam(value = Static.q, required = false, defaultValue = Static.blank) String q,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size
			) {
		try {
			Object adminSession = session.getAttribute(Static.admin);
			if (adminSession == null) {
				return Static.redirectadminlogin;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
        	String query = request.getQueryString();
        	if(query != null && !Static.blank.equals(query)) {
        		url.append(Static.url1);
            	url.append(request.getQueryString());
        	}
        	int idx = url.lastIndexOf(Static.url2);
        	if(idx >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
        	}
        	int index = url.lastIndexOf(Static.url3);
        	if(index >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
        	}
        	if(url.indexOf(Static.url4) >=0) {
        		url.append(Static.url4);
        	} else {
        		url.append(Static.url1);
        	}
        	if(q == null || Static.blank.equals(q)) {
        		model.addAttribute(Static.modelusers, adminService.getPage(Del.DEL.getLevelCode(), page, size));
        	} else {
    			model.addAttribute(Static.modelusers, adminService.getPage(q, Del.DEL.getLevelCode(), page, size));
        	}
			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, q);
			model.addAttribute(Static.modeltitle, Del.DEL.name().toLowerCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageadminuser;
	}



}
