package com.adz2pro.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.adz2pro.constant.Del;
import com.adz2pro.constant.Static;
import com.adz2pro.service.PTPService;
import com.adz2pro.service.UserService;

@Controller
@RequestMapping(Static.urladmin)
public class AdminPTPBannerController {

	@Autowired
	PTPService ptpService;

	@Autowired
	UserService userService;

	@RequestMapping(value = {Static.urladminptpbanner }, method = RequestMethod.GET)
	public String urladminprall(Model model, HttpSession session,
			HttpServletRequest request,
			@RequestParam(value = Static.q, required = false, defaultValue = Static.blank) String q,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size
			) {
		try {
			Object adminSession = session.getAttribute(Static.admin);
			if (adminSession == null) {
				return Static.redirectadminlogin;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
        	String query = request.getQueryString();
        	if(query != null && !Static.blank.equals(query)) {
        		url.append(Static.url1);
            	url.append(request.getQueryString());
        	}
        	int idx = url.lastIndexOf(Static.url2);
        	if(idx >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
        	}
        	int index = url.lastIndexOf(Static.url3);
        	if(index >= Static.zero.intValue()) {
        		url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
        	}
        	if (url.indexOf(Static.url1) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}

        	if(q== null || Static.blank.equals(q)) {
        		model.addAttribute(Static.modelrs, ptpService.findPTPBannerByDel(Del.NOTDEL.getLevelCode(), page, size));
        	} else {
    			model.addAttribute(Static.modelrs, ptpService.findPTPBannerByQAndDel(q, Del.NOTDEL.getLevelCode(), page, size));
        	}
			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, q);
			model.addAttribute(Static.modeltitle, Static.all.toLowerCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageadminptpbanner;
	}

}
