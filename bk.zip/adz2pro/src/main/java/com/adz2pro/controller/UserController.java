package com.adz2pro.controller;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.adz2pro.constant.Active;
import com.adz2pro.constant.Del;
import com.adz2pro.constant.Done;
import com.adz2pro.constant.PayMethod;
import com.adz2pro.constant.Static;
import com.adz2pro.entity.PaymentRequest;
import com.adz2pro.entity.User;
import com.adz2pro.form.UserForm;
import com.adz2pro.service.PaymentRequestService;
import com.adz2pro.service.UserService;
import com.adz2pro.util.EmailValidatorApache;
import com.adz2pro.util.Util;

@Controller
public class UserController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@Value("${cpm.minpayment}")
	private BigDecimal minpayment;

	@Value("${cpm.type}")
	private String type;

	@Value("${cpm.fee}")
	private Float fee;

	@Autowired
	UserService userService;

	@Autowired
	PaymentRequestService paymentRequestService;

	@RequestMapping(value = { Static.login_ }, method = { RequestMethod.POST, RequestMethod.GET })
	public String login(@RequestParam(value = "username", required = false, defaultValue = "") String username,
			@RequestParam(value = "password", required = false, defaultValue = "") String password,
			HttpServletRequest request, HttpSession session, Model model) {
		try {
			StringBuilder str = new StringBuilder();
			username = username.trim();
			password = password.trim();
			if (username == null || Static.blank.equals(username)) {
				str.append(Static.user);
				str.append(Static.n);
			} else {
				if (!Util.isAlpha(username)) {
					str.append(Static.user_);
					str.append(Static.n);
				}
				if (Static.n999 < username.length()) {
					str.append(Static.user_max);
					str.append(Static.n);
				}
			}
			if (password == null || Static.blank.equals(password)) {
				str.append(Static.pass);
				str.append(Static.n);
			} else {
				if (Static.n999 < password.length()) {
					str.append(Static.pass_max);
					str.append(Static.n);
				}
			}
			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return Static.login;
			}
			User user = userService.findTop1ByUsernameAndPasswordAndDelAndActive(username.trim(),
					password.trim(), Del.NOTDEL.getLevelCode(), Active.ACTIVE.getLevelCode());
			if (user == null) {
				model.addAttribute(Static.error, Static.userpass);
				return Static.login;
			} else {
				session.setAttribute(Static.username, username);
				return Static.redirectptp;
			}
		} catch (Exception e) {
		}
		return Static.login;
	}

	@RequestMapping(value = { Static.urllogout }, method = { RequestMethod.POST, RequestMethod.GET })
	public String logout(HttpSession session) {
		try {
			session.removeAttribute(Static.username);
		} catch (Exception e) {
		}
		return Static.redirect;
	}

	@RequestMapping(value = { Static.urlsignup }, method = { RequestMethod.GET })
	public String signup(@ModelAttribute("userForm") UserForm userForm) {
		try {
		} catch (Exception e) {
		}
		return Static.signup;
	}

	@RequestMapping(value = { Static.urlsignup }, method = { RequestMethod.POST })
	public String signup(@ModelAttribute("userForm") UserForm userForm,
			@RequestParam(value = "username", required = false, defaultValue = "username") String username,
			@RequestParam(value = "password", required = false, defaultValue = "password") String password,
			HttpServletRequest request, HttpSession session, Model model) {
		try {
			StringBuilder str = new StringBuilder();
			if (userForm.getUsername() == null || userForm.getUsername().equals(Static.blank)) {
				str.append(Static.user);
				str.append(Static.n);
			} else {
				if (!Util.isAlpha(username)) {
					str.append(Static.user_);
					str.append(Static.n);
				}
				if (Static.n999 < username.length()) {
					str.append(Static.user_max);
					str.append(Static.n);
				}
			}
			if (!EmailValidatorApache.isValid(userForm.getEmail())) {
				str.append(Static.email);
				str.append(Static.n);
			} else {
				if (Static.n999 < userForm.getEmail().length()) {
					str.append(Static.email_max);
					str.append(Static.n);
				}
			}
			if (userForm.getPassword() == null || userForm.getPassword().equals(Static.blank)) {
				str.append(Static.pass);
				str.append(Static.n);
			} else {
				if (Static.n999 < userForm.getPassword().length()) {
					str.append(Static.pass_max);
					str.append(Static.n);
				}
			}
			if (userForm.getFullname() == null || userForm.getFullname().equals(Static.blank)) {
				str.append(Static.fullname);
				str.append(Static.n);
			} else {
				if (Static.n999 < userForm.getFullname().length()) {
					str.append(Static.fullname_max);
					str.append(Static.n);
				}
			}
			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return Static.signup;
			} else {
				String ip = Util.getClientIpAddress(request);
				if (userService.findTop1ByUsername(username) != null) {
					str.append(Static.user_exist);
					str.append(Static.n);
				}

				if (userService.findTop1ByIpAndDel(ip, Del.NOTDEL.getLevelCode()) != null) {
					str.append(Static.ip_exist);
					str.append(Static.n);
				}

				if (str.length() > Static.zero) {
					model.addAttribute(Static.error, str);
					return Static.signup;
				}
//				for (int i = 0; i < 100; i++) {
					User user = new User();
					user.setIp(ip);
					user.setActive(Active.ACTIVE.getLevelCode());
					user.setDel(Del.NOTDEL.getLevelCode());
					BeanUtils.copyProperties(userForm, user);
//					user.setPassword(Util.password(user.getPassword()));
					userService.signup(user);
//				}
				return Static.login;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.signup;
	}

	@RequestMapping(value = { Static.urlmyprofile }, method = RequestMethod.GET)
	public String profile(Model model, HttpSession session) {
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if (usernameSession == null) {
				return Static.redirectlogin;
			}
			String username = String.valueOf(usernameSession);

			User user = userService.findTop1ByUsernameAndDel(username, Del.NOTDEL.getLevelCode());

			if (user == null) {
				session.removeAttribute(Static.username);
				return Static.redirectlogin;
			}

			model.addAttribute(Static.modeluser, user);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.myprofile;
	}

	@Transactional
	@RequestMapping(value = { Static.urlmyprofile }, method = { RequestMethod.POST })
	public String paymentsave(
			@RequestParam(value = "paymentmethod", required = false, defaultValue = "") String paymentmethod,
			@RequestParam(value = "paymentaccount", required = false, defaultValue = "") String paymentaccount,
			HttpServletRequest request, HttpSession session, Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if (usernameSession == null) {
				return Static.redirectlogin;
			}
			String username = String.valueOf(usernameSession);

			User user = userService.findTop1ByUsernameAndDel(username, Del.NOTDEL.getLevelCode());

			if (user == null) {
				session.removeAttribute(Static.username);
				return Static.redirectlogin;
			}
			model.addAttribute("user", user);
			StringBuilder str = new StringBuilder();
			if (paymentmethod == null || Static.blank.equals(paymentmethod)) {
				str.append(Static.paymentmethod);
				str.append(Static.n);
			} else {
				if (Static.n999 < paymentmethod.length()) {
					str.append(Static.paymentmethod_max);
					str.append(Static.n);
				}
			}
			if (paymentaccount == null || Static.blank.equals(paymentaccount)) {
				str.append(Static.paymentaccount);
				str.append(Static.n);
			} else {
				if (Static.n999 < paymentaccount.length()) {
					str.append(Static.paymentaccount_max);
					str.append(Static.n);
				}
			}
			Boolean check = true;
			if (PayMethod.bitcoin.getCode().equals(paymentmethod)) {
				check = false;
				String account = user.getAccount();
				if(account != null) {
					if (account.equals(paymentaccount)) {
						str.append(Static.paymentaccount_exist);
						str.append(Static.n);
					} else {
						user.setAccount(paymentaccount);
						user.setMethod(paymentmethod);
					}
				} else {
					user.setAccount(paymentaccount);
					user.setMethod(paymentmethod);
				}
			}
			if (PayMethod.payeer.getCode().equals(paymentmethod)) {
				check = false;
				String account = user.getAccount();
				if(account != null) {
					if (account.equals(paymentaccount)) {
						str.append(Static.paymentaccount_exist);
						str.append(Static.n);
					} else {
						user.setAccount(paymentaccount);
						user.setMethod(paymentmethod);
					}
				} else {
					user.setAccount(paymentaccount);
					user.setMethod(paymentmethod);
				}
			}
			if (PayMethod.paypal.getCode().equals(paymentmethod)) {
				check = false;
				String account = user.getAccount();
				if(account != null) {
					if (account.equals(paymentaccount)) {
						str.append(Static.paymentaccount_exist);
						str.append(Static.n);
					} else {
						user.setAccount(paymentaccount);
						user.setMethod(paymentmethod);
					}
				} else {
					user.setAccount(paymentaccount);
					user.setMethod(paymentmethod);
				}
			}
			if (check) {
				str.append(Static.paymentmethod);
				str.append(Static.n);
			}
			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return Static.myprofile;
			}
			userService.save(user);
		} catch (Exception e) {
		}
		return Static.redirectmyprofile;
	}

	@RequestMapping(value = { Static.urlsurfer }, method = RequestMethod.GET)
	public String surfer(Model model, HttpSession session) {
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if (usernameSession == null) {
				return Static.redirectlogin;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pagesurfer;
	}

	@RequestMapping(value = { Static.urlpaymentrequest }, method = RequestMethod.GET)
	public String payment(Model model, HttpSession session,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size) {
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if (usernameSession == null) {
				return Static.redirectlogin;
			}
			String username = String.valueOf(usernameSession);

			User user = userService.findTop1ByUsernameAndDel(username, Del.NOTDEL.getLevelCode());

			if (user == null) {
				session.removeAttribute(Static.username);
				return Static.redirectlogin;
			}

			model.addAttribute(Static.modeluser, user);
			model.addAttribute(Static.modelrs, paymentRequestService.getPage(user, page, size));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pagepaymentrequest;
	}

	@Transactional
	@RequestMapping(value = { Static.urlpaymentrequest }, method = RequestMethod.POST)
	public String paymentrequest(Model model, HttpSession session,
			@RequestParam(value = "paymentmethod", required = false, defaultValue = "") String paymentmethod,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "13") int size) {
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if (usernameSession == null) {
				return Static.redirectlogin;
			}
			String username = String.valueOf(usernameSession);

			User user = userService.findTop1ByUsernameAndDel(username, Del.NOTDEL.getLevelCode());

			if (user == null) {
				session.removeAttribute(Static.username);
				return Static.redirectlogin;
			}

			BigDecimal mainBalance = user.getMainBalance();
			StringBuilder str = new StringBuilder();
			if ((mainBalance == null) || (BigDecimal.ZERO == mainBalance)
					|| (minpayment.compareTo(mainBalance) == Static.one.intValue())) {
				str.append(String.format(Static.minpayment, minpayment, type));
				str.append(Static.n);
				model.addAttribute(Static.modeluser, user);
				model.addAttribute(Static.modelrs, paymentRequestService.getPage(user, page, size));
				if (str.length() > Static.zero) {
					model.addAttribute(Static.error, str);
					return Static.paymentrequest;
				}
			}

			if (paymentmethod == null || Static.blank.equals(paymentmethod)) {
				str.append(Static.paymentmethod);
				str.append(Static.n);
			}

			Boolean check = true;
			if (user.getMethod() != null) {
				if (PayMethod.bitcoin.getCode().equals(paymentmethod)) {

					check = false;
					PaymentRequest pr = new PaymentRequest();
					pr.setDel(Del.NOTDEL.getLevelCode());
					pr.setDone(Done.NOTDONE.getLevelCode());
					pr.setIdUser(user.getId());
					pr.setUsername(user.getUsername());
					pr.setUser(user);
					pr.setMethod(PayMethod.bitcoin.getCode());
					pr.setAccount(user.getAccount());
					pr.setAmount(Util.getPriceNET(mainBalance, fee));
					BigDecimal paymentPending = user.getPaymentPending();
					paymentPending = paymentPending.add(pr.getAmount());
					user.setPaymentPending(paymentPending);
					userService.save(user);
					paymentRequestService.paymentRequest(pr);

				}
				if (PayMethod.payeer.getCode().equals(paymentmethod)) {
					check = false;
					PaymentRequest pr = new PaymentRequest();
					pr.setDel(Del.NOTDEL.getLevelCode());
					pr.setDone(Done.NOTDONE.getLevelCode());
					pr.setIdUser(user.getId());
					pr.setUsername(user.getUsername());
					pr.setUser(user);
					pr.setMethod(PayMethod.payeer.getCode());
					pr.setAccount(user.getAccount());
					pr.setAmount(Util.getPriceNET(mainBalance, fee));
					BigDecimal paymentPending = user.getPaymentPending();
					paymentPending = paymentPending.add(pr.getAmount());
					user.setPaymentPending(paymentPending);
					userService.save(user);
					paymentRequestService.paymentRequest(pr);
				}
				if (PayMethod.paypal.getCode().equals(paymentmethod)) {
					check = false;
					PaymentRequest pr = new PaymentRequest();
					pr.setDel(Del.NOTDEL.getLevelCode());
					pr.setDone(Done.NOTDONE.getLevelCode());
					pr.setIdUser(user.getId());
					pr.setUsername(user.getUsername());
					pr.setUser(user);
					pr.setMethod(PayMethod.paypal.getCode());
					pr.setAccount(user.getAccount());
					pr.setAmount(Util.getPriceNET(mainBalance, fee));
					BigDecimal paymentPending = user.getPaymentPending();
					paymentPending = paymentPending.add(pr.getAmount());
					user.setPaymentPending(paymentPending);
					userService.save(user);
					paymentRequestService.paymentRequest(pr);
				}
			}

			if (check) {
				str.append(Static.paymentmethod_exist);
				str.append(Static.n);
			}
			model.addAttribute(Static.modeluser,
					userService.findTop1ByUsernameAndDel(username, Del.NOTDEL.getLevelCode()));
			model.addAttribute(Static.modelrs, paymentRequestService.getPage(user, page, size));
			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return Static.paymentrequest;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.paymentrequest;
	}

}
