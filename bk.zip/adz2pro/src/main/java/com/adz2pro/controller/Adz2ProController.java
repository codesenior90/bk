package com.adz2pro.controller;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.adz2pro.constant.Active;
import com.adz2pro.constant.Del;
import com.adz2pro.constant.Static;
import com.adz2pro.constant.Status;
import com.adz2pro.constant.Type;
import com.adz2pro.dto.AjaxResponseBody;
import com.adz2pro.entity.PTP;
import com.adz2pro.entity.PTPRequest;
import com.adz2pro.entity.User;
import com.adz2pro.service.PTPRequestService;
import com.adz2pro.service.PTPService;
import com.adz2pro.service.UserService;
import com.adz2pro.util.StringUtil;
import com.adz2pro.util.Util;

@Controller
public class Adz2ProController {

	@Value("${welcome.message}")
	private String message;

	@Value("${host.name}")
	private String hostname;

	@Value("${cpm.price}")
	private BigDecimal price;

	@Value("${cpm.type}")
	private String type;

	@Autowired
	PTPRequestService ptpRequestService;

	@Autowired
	UserService userService;

	@Autowired
	PTPService ptpService;

	@RequestMapping(value = { Static.urlhome }, method = RequestMethod.GET)
	public String index(Model model) {
		try {

		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pagehome;
	}

	@RequestMapping(value = { Static.urlptppromote }, method = RequestMethod.GET)
	public String urlptppromote(@PathVariable Long promote, HttpServletRequest req, HttpServletResponse res,
			HttpSession session, Model model) {
		try {
			if (promote != Static.zero_) {
				User user = userService.findTop1ByIdAndDel(promote, Del.NOTDEL.getLevelCode());
				if (user != null) {
					PTPRequest ptpRequest = new PTPRequest();
					ptpRequest.setType(Type.PTP.getLevelCode());
					ptpRequest.setActive(Active.ACTIVE.getLevelCode());
					ptpRequest.setDel(Del.NOTDEL.getLevelCode());
					ptpRequest.setLink(promote);
					Date now = new Date();
					ptpRequest.setCreaterequest(Util.getDateDisplay(now));
					String ptptoken = UUID.randomUUID().toString();
					ptpRequest.setPtptoken(ptptoken);
					String referer = req.getHeader(Static.Referer);
					if (StringUtil.isNotBlank(referer)) {
						ptpRequest.setReferer(referer);
					}
					String ip = Util.getClientIpAddress(req);
					if (StringUtil.isNotBlank(ip)) {
						ptpRequest.setIp(ip);
					}
					ptpRequest.setUser(user);
					ptpRequestService.save(ptpRequest);
					model.addAttribute(Static.promote, promote);
					model.addAttribute(Static.ptptoken, ptptoken);
					return Static.pageptppromote;
				} else {
					return Static.pageptpmain;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageptpmain;
	}

	@Transactional
	@RequestMapping(value = Static.urlptppromote, method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public AjaxResponseBody ptpPost(
			@PathVariable Long promote,
			@RequestParam(value = Static.ptptoken, required = false, defaultValue = Static.blank) String ptptoken,
			HttpServletRequest req, HttpServletResponse res, HttpSession session) throws Exception {
		AjaxResponseBody result = new AjaxResponseBody();
		result.setMsg(Static.blank);
		try {
			if (promote == Static.zero_) {
				result.setMsg(Static.not_allowed);
			} else {
				String referer = req.getHeader(Static.Referer);
				if (StringUtil.isBlank(referer)) {
					result.setMsg(Static.Unknown_Referrer);
				} else {
					if (ptptoken.equals(Static.blank)) {
						result.setMsg(Static.not_allowed);
					} else {
						if (referer.contains(hostname)) {
							String ip = Util.getClientIpAddress(req);
//							try {
//								RestTemplate restTemplate = new RestTemplate();
//						        ResponseEntity<String> response
//						          = restTemplate.getForEntity(Static.iplocation.concat(ip), String.class);
//						        String json = response.getBody();
//						        if(json.contains(Static.vietnam)) {
//						        	result.setMsg(Static.not_allowed);
//									return result;
//								}
//							} catch (Exception e) {
//							}
//

							Date now = new Date();
							PTPRequest ptpRequest = ptpRequestService
									.findTop1ByLinkAndCreaterequestAndIpAndActiveAndDelOrderByIdDesc(promote,
											Util.getDateDisplay(now), ip, Active.INACTIVE.getLevelCode(),
											Del.NOTDEL.getLevelCode());
							if (ptpRequest == null) {
								ptpRequest = ptpRequestService.findTop1ByLinkAndPtptokenAndActiveAndDelOrderByIdDesc(
										promote, ptptoken, Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode());
								if (ptpRequest == null) {
									result.setMsg(Static.not_allowed);
								} else {
//									if (ptpRequest.getReferer() == null) {
//										result.setMsg(Static.Unknown_Referrer);
//									} else {
									ptpRequest.setActive(Active.INACTIVE.getLevelCode());
									ptpRequestService.makeMoney(ptpRequest, price);
									result.setStatus(Status.SUCCESS.getCode());
									result.setMsg(String.format(Static.earn_success, ptpRequest.getUser().getUsername(),
											price, type));

//									}
								}
							} else {
								result.setMsg(Static.not_allowed);
							}
						} else {
							result.setMsg(Static.not_allowed);
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@RequestMapping(value = { Static.urlptp }, method = RequestMethod.GET)
	public String ptp(HttpServletRequest req, HttpServletResponse res, HttpSession session, Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if (usernameSession == null) {
				return Static.redirectlogin;
			}
			String username = String.valueOf(usernameSession);

			User user = userService.findTop1ByUsernameAndDel(username, Del.NOTDEL.getLevelCode());

			if (user == null) {
				session.removeAttribute(Static.username);
				return Static.redirectlogin;
			}
			PTP ptp = user.getPtp();
			String create = ptp.getCreatePtp();
			Date date = new Date();
			String now = Util.getDateDisplay(date);

			if(!now.equals(create)) {
				ptp.setCreatePtp(now);
				ptp.setToday(BigDecimal.ZERO);
				ptp.setTodayCount(Static.zero_);
				ptpService.save(ptp);
			}
			model.addAttribute(Static.modeluser, user);
			model.addAttribute(Static.price, price);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pageptp;
	}


	@RequestMapping(value = { Static.urlbanner }, method = RequestMethod.GET)
	public String banner(
			@PathVariable Long promote,
			HttpServletRequest req, HttpServletResponse res, HttpSession session, Model model) {
		try {
			if (promote != Static.zero_) {
				User user = userService.findTop1ByIdAndDel(promote, Del.NOTDEL.getLevelCode());
				if (user != null) {
					model.addAttribute(Static.promote, promote);
					return Static.pagebanner;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pagebannerblank;
	}

	@RequestMapping(value = { Static.urlcpm }, method = RequestMethod.GET)
	public String cpm(@PathVariable Long promote,
			HttpServletRequest req, HttpServletResponse res, HttpSession session, Model model) {
		try {
			if (promote != Static.zero_) {
				User user = userService.findTop1ByIdAndDel(promote, Del.NOTDEL.getLevelCode());
				if (user != null) {
					PTPRequest ptpRequest = new PTPRequest();
					ptpRequest.setActive(Active.ACTIVE.getLevelCode());
					ptpRequest.setDel(Del.NOTDEL.getLevelCode());
					ptpRequest.setType(Type.BANNER.getLevelCode());
					ptpRequest.setLink(promote);
					Date now = new Date();
					ptpRequest.setCreaterequest(Util.getDateDisplay(now));
					String ptptoken = UUID.randomUUID().toString();
					ptpRequest.setPtptoken(ptptoken);
					String referer = req.getHeader(Static.Referer);
					if (StringUtil.isNotBlank(referer)) {
						ptpRequest.setReferer(referer);
					}
					String ip = Util.getClientIpAddress(req);
					if (StringUtil.isNotBlank(ip)) {
						ptpRequest.setIp(ip);
					}
					ptpRequest.setUser(user);
					ptpRequestService.save(ptpRequest);
					model.addAttribute(Static.promote, promote);
					model.addAttribute(Static.ptptoken, ptptoken);
					return Static.pagecpm;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pagecpmblank;
	}

	@Transactional
	@RequestMapping(value = Static.urlcpm, method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public AjaxResponseBody cpmPost(
			@PathVariable Long promote,
			@RequestParam(value = Static.ptptoken, required = false, defaultValue = Static.blank) String ptptoken,
			HttpServletRequest req, HttpServletResponse res, HttpSession session) throws Exception {
		AjaxResponseBody result = new AjaxResponseBody();
		result.setMsg(Static.blank);
		try {
			if (promote == Static.zero_) {
				result.setMsg(Static.not_allowed);
			} else {
				String referer = req.getHeader(Static.Referer);
				if (StringUtil.isBlank(referer)) {
					result.setMsg(Static.Unknown_Referrer);
				} else {
					if (ptptoken.equals(Static.blank)) {
						result.setMsg(Static.not_allowed);
					} else {
						if (referer.contains(hostname)) {
							String ip = Util.getClientIpAddress(req);
							Date now = new Date();
							PTPRequest ptpRequest = ptpRequestService
									.findTop1ByLinkAndCreaterequestAndIpAndActiveAndDelOrderByIdDesc(promote,
											Util.getDateDisplay(now), ip, Active.INACTIVE.getLevelCode(),
											Del.NOTDEL.getLevelCode());
							if (ptpRequest == null) {
								ptpRequest = ptpRequestService.findTop1ByLinkAndPtptokenAndActiveAndDelOrderByIdDesc(
										promote, ptptoken, Active.ACTIVE.getLevelCode(), Del.NOTDEL.getLevelCode());
								if (ptpRequest == null) {
									result.setMsg(Static.not_allowed);
								} else {
//									if (ptpRequest.getReferer() == null) {
//										result.setMsg(Static.Unknown_Referrer);
//									} else {
									ptpRequest.setActive(Active.INACTIVE.getLevelCode());
									ptpRequestService.makeMoneyBanner(ptpRequest, price);
									result.setStatus(Status.SUCCESS.getCode());
									result.setMsg(String.format(Static.earn_success, ptpRequest.getUser().getUsername(),
											price, type));

//									}
								}
							} else {
								result.setMsg(Static.not_allowed);
							}
						} else {

							result.setMsg(Static.not_allowed);
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@RequestMapping(value = { Static.urltag }, method = RequestMethod.GET)
	public String tag(HttpServletRequest req, HttpServletResponse res, HttpSession session, Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.username);
			if (usernameSession == null) {
				return Static.redirectlogin;
			}
			String username = String.valueOf(usernameSession);

			User user = userService.findTop1ByUsernameAndDel(username, Del.NOTDEL.getLevelCode());

			if (user == null) {
				session.removeAttribute(Static.username);
				return Static.redirectlogin;
			}
			PTP ptp = user.getPtp();
			String create = ptp.getCreateBanner();
			Date date = new Date();
			String now = Util.getDateDisplay(date);

			if(!now.equals(create)) {
				ptp.setCreateBanner(now);
				ptp.setTodayBanner(BigDecimal.ZERO);
				ptp.setTodayBannerCount(Static.zero_);
				ptpService.save(ptp);
			}
			model.addAttribute(Static.modeluser, user);
			model.addAttribute(Static.price, price);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.pagetag;
	}

}
