package com.adz2pro.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

@RestController
public class Ads {

	public static final boolean TRUE = true;
	public static final boolean FALSE = false;
	public static final int TIMEOUT = 7000;
	public static final long SL = 10000;
	public static final int TIMEOUT_1 = 5000;
	public static final int TIMEOUT_2 = 500;

	private static final String url1 = "https://www.toprevenuegate.com/";

	private static final String url2 = "?key=";

	private static final String url3 = "https://www.toprevenuegate.com/api/users?token=";

	private static final String url4 = "&uuid=&pii=&in=false";

	private static final String data1 = "data1";

	private static final String n1 = "value=\"";

	public static final String n2 = "\"";

	public static final String success = "success";
	public static final String err = "err";


	private static final String PROXY_HOST= "rp.proxyscrape.com";
    private static final int PROXY_PORT=6060;
    private static final String USERNAME = "lhs8iwdinab7ufx-session-7ujgawe6dq-lifetime-2";
    private static final String PASSWORD = "0hn0mv46093qibt";


//	private static final String url = "https://www.toprevenuegate.com/"
//			+ "xtvvurr0tf"
//			+ "?key="
//			+ "333319240c446f31b1a05fb514018774";

	private RestTemplate restT = new RestTemplate();

	@CrossOrigin
	@RequestMapping(value = { "/cors0" }, method = RequestMethod.GET)
	public String cors0(
			@RequestParam(value = "d", required = false, defaultValue = "0") String d,
			@RequestParam(value = "key", required = false, defaultValue = "0") String key,
			@RequestParam(value = "l", required = false, defaultValue = "lhs8iwdinab7ufx-country-us-session-bb6rr0zedq-lifetime-2") String l
			) {
		try {
//			System.out.println("d" + d);
//			System.out.println("key" + key);

//			WebClient webClient = new WebClient();
			WebClient webClient =  new WebClient(BrowserVersion.CHROME, PROXY_HOST, PROXY_PORT);
			webClient.getCredentialsProvider().setCredentials(AuthScope.ANY, new NTCredentials(l, PASSWORD, "", ""));

			webClient.getOptions().setUseInsecureSSL(TRUE);
			webClient.getOptions().setRedirectEnabled(FALSE);
			webClient.getOptions().setJavaScriptEnabled(FALSE);
			webClient.getOptions().setCssEnabled(FALSE);
			webClient.getOptions().setThrowExceptionOnScriptError(FALSE);
			webClient.getOptions().setThrowExceptionOnFailingStatusCode(FALSE);
			webClient.getCookieManager().setCookiesEnabled(TRUE);
			webClient.getOptions().setTimeout(TIMEOUT);
			webClient.setJavaScriptTimeout(TIMEOUT_1);
			webClient.waitForBackgroundJavaScript(TIMEOUT_2);

			String user = getRandomList(useragents);
			webClient.getBrowserVersion().setUserAgent(user);
			String url = url1 + d + url2 + key;
			HtmlPage page = webClient.getPage(url);
//			Map<String, String> rst = new HashMap<String, String>();
			String xml = page.asXml();
//			return xml;
//			System.out.println(xml);

			String[] arr1 = xml.split(n1, 2);
			String data1 = arr1[1];
			String[] arr2 = data1.split(n2, 2);

			String url2 = url3 + arr2[0] + url4;

			page = webClient.getPage(url2);

//			System.out.println(page.asXml());
			return success;
//			System.out.println(page.asXml());

		} catch (Exception e) {
//			e.printStackTrace();
		}
		return err;
	}


//	public static List<String> readFile(String filename) {
//		List<String> urls = new ArrayList<String>();
//		BufferedReader br = null;
//		FileReader fr = null;
//		try {
//			fr = new FileReader(Ads.class.getResource(filename).getPath());
//			br = new BufferedReader(fr);
//			String line;
//			while ((line = br.readLine()) != null) {
//				urls.add(line);
//			}
//		} catch (Exception e) {
//		} finally {
//			try {
//				if (br != null)
//					br.close();
//				if (fr != null)
//					fr.close();
//			} catch (Exception ex) {
//			}
//		}
//		return urls;
//	}
//
	public static List<String> readFile2(String filename) {
		List<String> urls = new ArrayList<String>();
		BufferedReader br = null;
		FileReader fr = null;
		try {
			fr = new FileReader(ResourceUtils.getFile("classpath:" + filename).getPath());
			br = new BufferedReader(fr);
			String line;
			while ((line = br.readLine()) != null) {
				urls.add(line);
			}
		} catch (Exception e) {
		} finally {
			try {
				if (br != null)
					br.close();
				if (fr != null)
					fr.close();
			} catch (Exception ex) {
			}
		}
		return urls;
	}

	public static final String useragent = "useragent.txt";
	public static final List<String> useragents = readFile2(useragent);
//

	private String getRandomList(List<String> list) {
		Random rand = new Random();
		return list.get(rand.nextInt(list.size()));
	}

//	@CrossOrigin
//	@RequestMapping(value = { "/cors1" }, method = RequestMethod.GET)
//	public ResponseEntity<String> cors1() {
//		try {
//			ResponseEntity<String> responseEntity = restT.getForEntity(url, String.class);
//			return responseEntity;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return null;
//	}

//	private static final String url1 = "https://adsnetworkplus.com/display/index.php?page=query/items/&aduid=928&pid=563&width=0&height=0&displaytype=9&native=0&device_type=large_dev_adblock&block_id=0&responsive=0&adcode_count=1&adSectionWidth=0&page_data=";
//	private static final String url2 = "&time=";
//	private static final String url3 = "&deliver=note4you.xyz&search_keywords=&page_referrer=aHR0cHM6Ly9ub3RlNHlvdS54eXovYml0Y29pbg==&page_title=&meta_description=";
//
//	@CrossOrigin
//	@RequestMapping(value = { "/cors2" }, method = RequestMethod.GET)
//	public ResponseEntity<String> cors2(
//			@RequestParam(value = "page_data", required = false, defaultValue = "0") String page_data,
//			@RequestParam(value = "time", required = false, defaultValue = "0") String time
//
//	) {
//		String url4 = url1 + page_data + url2 + time + url3;
//		try {
//			ResponseEntity<String> responseEntity = restT.getForEntity(url4, String.class);
//			return responseEntity;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return null;
//	}

	private static final String aurl1 = "https://ad.a-ads.com/";

	private static final String aurl2 = "?size=728x90";

	private static final String click = "click.a-ads.com/";

	public static final String click1 = "'";

	@CrossOrigin
	@RequestMapping(value = { "/cors2" }, method = RequestMethod.GET)
	public String cors2(
			@RequestParam(value = "id", required = false, defaultValue = "2274617") String id

	) {
		String url4 = aurl1 + id + aurl2;
		try {
//			RestTemplate restT = new RestTemplate();
			String responseEntity = restT.getForObject(url4, String.class);
			String[] arr1 = responseEntity.split(click, 2);
			String data1 = arr1[1];
			String[] arr2 = data1.split(click1, 2);
			return arr2[0];
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
