package com.adz2pro.entity;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.adz2pro.base.BaseModel;
import com.adz2pro.constant.Static;
import com.adz2pro.dto.PTPBannerDto;
import com.adz2pro.dto.PTPDto;


@SqlResultSetMapping(
		name = "PTPDtoMapping",
		classes = @ConstructorResult(targetClass = PTPDto.class,
				columns = { @ColumnResult(name = "id", type = Long.class),
                        @ColumnResult(name = "link"),
                        @ColumnResult(name = "today" , type = BigDecimal.class),
                        @ColumnResult(name = "allTime" , type = BigDecimal.class),
                        @ColumnResult(name = "todayCount" ,type = Long.class),
                        @ColumnResult(name = "allTimeCount" ,type = Long.class),
                        @ColumnResult(name = "userId" ,type = Long.class),
                        @ColumnResult(name = "username")
}))
@SqlResultSetMapping(
		name = "PTPBannerDtoMapping",
		classes = @ConstructorResult(targetClass = PTPBannerDto.class,
				columns = { @ColumnResult(name = "id", type = Long.class),
                        @ColumnResult(name = "banner"),
                        @ColumnResult(name = "todayBanner" , type = BigDecimal.class),
                        @ColumnResult(name = "allTimeBanner" , type = BigDecimal.class),
                        @ColumnResult(name = "todayBannerCount" ,type = Long.class),
                        @ColumnResult(name = "allTimeBannerCount" ,type = Long.class),
                        @ColumnResult(name = "userId" ,type = Long.class),
                        @ColumnResult(name = "username")
}))
@Entity
@Table(indexes = {
		  @Index(name = "ptp_mulitIndex1", columnList = "user_id, del"),
		  @Index(name = "ptp_mulitSortIndex1", columnList = "allTimeCount DESC"),
		  @Index(name = "ptp_mulitSortIndex2", columnList = "allTimeBannerCount DESC")
		})
public class PTP extends BaseModel {

	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String link;
	@Column(length = Static.n999)
	private String banner;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal today;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal yesterday;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal thisWeek;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal previousWeek;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal last30Day;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal allTime	;

	private Long todayCount;
	private Long yesterdayCount;
	private Long thisWeekCount;
	private Long previousWeekCount;
	private Long last30DayCount;
	private Long allTimeCount;

	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal todayBanner;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal yesterdayBanner;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal thisWeekBanner;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal previousWeekBanner;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal last30DayBanner;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal allTimeBanner;

	private Long todayBannerCount;
	private Long yesterdayBannerCount;
	private Long thisWeekBannerCount;
	private Long previousWeekBannerCount;
	private Long last30DayBannerCount;
	private Long allTimeBannerCount;

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

	@Column(length = Static.n999)
	private String createPtp;

	@Column(length = Static.n999)
	private String createBanner;

	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}

	public String getBanner() {
		return banner;
	}
	public void setBanner(String banner) {
		this.banner = banner;
	}
	public BigDecimal getToday() {
		return today;
	}
	public void setToday(BigDecimal today) {
		this.today = today;
	}
	public BigDecimal getYesterday() {
		return yesterday;
	}
	public void setYesterday(BigDecimal yesterday) {
		this.yesterday = yesterday;
	}
	public BigDecimal getThisWeek() {
		return thisWeek;
	}
	public void setThisWeek(BigDecimal thisWeek) {
		this.thisWeek = thisWeek;
	}
	public BigDecimal getPreviousWeek() {
		return previousWeek;
	}
	public void setPreviousWeek(BigDecimal previousWeek) {
		this.previousWeek = previousWeek;
	}
	public BigDecimal getLast30Day() {
		return last30Day;
	}
	public void setLast30Day(BigDecimal last30Day) {
		this.last30Day = last30Day;
	}
	public BigDecimal getAllTime() {
		return allTime;
	}
	public void setAllTime(BigDecimal allTime) {
		this.allTime = allTime;
	}
	public Long getTodayCount() {
		return todayCount;
	}
	public void setTodayCount(Long todayCount) {
		this.todayCount = todayCount;
	}
	public Long getYesterdayCount() {
		return yesterdayCount;
	}
	public void setYesterdayCount(Long yesterdayCount) {
		this.yesterdayCount = yesterdayCount;
	}
	public Long getThisWeekCount() {
		return thisWeekCount;
	}
	public void setThisWeekCount(Long thisWeekCount) {
		this.thisWeekCount = thisWeekCount;
	}
	public Long getPreviousWeekCount() {
		return previousWeekCount;
	}
	public void setPreviousWeekCount(Long previousWeekCount) {
		this.previousWeekCount = previousWeekCount;
	}
	public Long getLast30DayCount() {
		return last30DayCount;
	}
	public void setLast30DayCount(Long last30DayCount) {
		this.last30DayCount = last30DayCount;
	}
	public Long getAllTimeCount() {
		return allTimeCount;
	}
	public void setAllTimeCount(Long allTimeCount) {
		this.allTimeCount = allTimeCount;
	}

	public BigDecimal getTodayBanner() {
		return todayBanner;
	}
	public void setTodayBanner(BigDecimal todayBanner) {
		this.todayBanner = todayBanner;
	}
	public BigDecimal getYesterdayBanner() {
		return yesterdayBanner;
	}
	public void setYesterdayBanner(BigDecimal yesterdayBanner) {
		this.yesterdayBanner = yesterdayBanner;
	}
	public BigDecimal getThisWeekBanner() {
		return thisWeekBanner;
	}
	public void setThisWeekBanner(BigDecimal thisWeekBanner) {
		this.thisWeekBanner = thisWeekBanner;
	}
	public BigDecimal getPreviousWeekBanner() {
		return previousWeekBanner;
	}
	public void setPreviousWeekBanner(BigDecimal previousWeekBanner) {
		this.previousWeekBanner = previousWeekBanner;
	}
	public BigDecimal getLast30DayBanner() {
		return last30DayBanner;
	}
	public void setLast30DayBanner(BigDecimal last30DayBanner) {
		this.last30DayBanner = last30DayBanner;
	}
	public BigDecimal getAllTimeBanner() {
		return allTimeBanner;
	}
	public void setAllTimeBanner(BigDecimal allTimeBanner) {
		this.allTimeBanner = allTimeBanner;
	}
	public Long getTodayBannerCount() {
		return todayBannerCount;
	}
	public void setTodayBannerCount(Long todayBannerCount) {
		this.todayBannerCount = todayBannerCount;
	}
	public Long getYesterdayBannerCount() {
		return yesterdayBannerCount;
	}
	public void setYesterdayBannerCount(Long yesterdayBannerCount) {
		this.yesterdayBannerCount = yesterdayBannerCount;
	}
	public Long getThisWeekBannerCount() {
		return thisWeekBannerCount;
	}
	public void setThisWeekBannerCount(Long thisWeekBannerCount) {
		this.thisWeekBannerCount = thisWeekBannerCount;
	}
	public Long getPreviousWeekBannerCount() {
		return previousWeekBannerCount;
	}
	public void setPreviousWeekBannerCount(Long previousWeekBannerCount) {
		this.previousWeekBannerCount = previousWeekBannerCount;
	}
	public Long getLast30DayBannerCount() {
		return last30DayBannerCount;
	}
	public void setLast30DayBannerCount(Long last30DayBannerCount) {
		this.last30DayBannerCount = last30DayBannerCount;
	}
	public Long getAllTimeBannerCount() {
		return allTimeBannerCount;
	}
	public void setAllTimeBannerCount(Long allTimeBannerCount) {
		this.allTimeBannerCount = allTimeBannerCount;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getCreatePtp() {
		return createPtp;
	}
	public void setCreatePtp(String createPtp) {
		this.createPtp = createPtp;
	}
	public String getCreateBanner() {
		return createBanner;
	}
	public void setCreateBanner(String createBanner) {
		this.createBanner = createBanner;
	}

}
