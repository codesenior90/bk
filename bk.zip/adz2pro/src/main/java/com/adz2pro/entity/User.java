package com.adz2pro.entity;

import java.math.BigDecimal;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.adz2pro.base.BaseModel;
import com.adz2pro.constant.Static;
import com.adz2pro.util.Util;

@Entity
@Table(indexes = {
  @Index(name = "user_mulitIndex1", columnList = "id, del"),
  @Index(name = "user_mulitIndex2", columnList = "username, password, del, active"),
  @Index(name = "user_mulitIndex3", columnList = "username, del"),
  @Index(name = "user_mulitIndex4", columnList = "ip, del"),
  @Index(name = "user_mulitIndex5", columnList = "active, del"),
  @Index(name = "user_mulitIndex6", columnList = "username, del"),
  @Index(name = "user_mulitIndex7", columnList = "email, del"),
  @Index(name = "user_mulitIndex8", columnList = "username, active, del"),
  @Index(name = "user_mulitIndex9", columnList = "email, active, del"),
  @Index(name = "user_mulitIndex10", columnList = "del"),
  @Index(name = "user_mulitSortIndex1", columnList = "id DESC")
})
public class User extends BaseModel {

	private static final long serialVersionUID = 1L;
//	@Column(length = Static.n999)
	private String username;
//	@Lob
	private String password;
//	@Column(length = Static.n999)
	private String ip;
//	@Column(length = Static.n999)
	private String email;
//	@Column(length = Static.n999)
	private String fullname;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal mainBalance;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal paymentPending;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal paymentReceived;
	private String country;
	private int active;

	@Column(length = Static.n999)
	private String method;

	@Column(length = Static.n999)
	private String account;

	@OneToOne(mappedBy = "user")
    private PTP ptp;

	@OneToMany(mappedBy="user")
    private Collection<PaymentProof> paymentProofs;

	@OneToMany(mappedBy="user")
    private Collection<PTPRequest> ptpRequests;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public BigDecimal getMainBalance() {
		return mainBalance;
	}
	public void setMainBalance(BigDecimal mainBalance) {
		this.mainBalance = mainBalance;
	}
	public BigDecimal getPaymentPending() {
		return paymentPending;
	}
	public void setPaymentPending(BigDecimal paymentPending) {
		this.paymentPending = paymentPending;
	}
	public BigDecimal getPaymentReceived() {
		return paymentReceived;
	}
	public void setPaymentReceived(BigDecimal paymentReceived) {
		this.paymentReceived = paymentReceived;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public PTP getPtp() {
		return ptp;
	}

	public void setPtp(PTP ptp) {
		this.ptp = ptp;
	}

	public Collection<PaymentProof> getPaymentProofs() {
		return paymentProofs;
	}

	public void setPaymentProofs(Collection<PaymentProof> paymentProofs) {
		this.paymentProofs = paymentProofs;
	}

	public Collection<PTPRequest> getPtpRequests() {
		return ptpRequests;
	}

	public void setPtpRequests(Collection<PTPRequest> ptpRequests) {
		this.ptpRequests = ptpRequests;
	}

	public String getCreatedDateDisplay() {
		return Util.getDateDisplay(this.getCreatedate());
	}

}
