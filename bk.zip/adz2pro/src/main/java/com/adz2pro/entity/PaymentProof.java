package com.adz2pro.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.adz2pro.base.BaseModel;
import com.adz2pro.constant.Static;

@Entity
public class PaymentProof extends BaseModel {

	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String payeer;
	@Column(length = Static.n999)
	private String bitcoin;
	@Column(length = Static.n999)
	private String paypal;
	private BigDecimal amount;
	private BigDecimal totalPaid;
	@ManyToOne
    @JoinColumn(name = "user_id", nullable=false)
    private User user;
	public String getPayeer() {
		return payeer;
	}
	public void setPayeer(String payeer) {
		this.payeer = payeer;
	}
	public String getBitcoin() {
		return bitcoin;
	}
	public void setBitcoin(String bitcoin) {
		this.bitcoin = bitcoin;
	}
	public String getPaypal() {
		return paypal;
	}
	public void setPaypal(String paypal) {
		this.paypal = paypal;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getTotalPaid() {
		return totalPaid;
	}
	public void setTotalPaid(BigDecimal totalPaid) {
		this.totalPaid = totalPaid;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

}
