package com.adz2pro.entity;

import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.adz2pro.base.BaseModel;

@Entity
@Table(indexes = {
		  @Index(name = "ptp_request_mulitIndex1", columnList = "link, ptptoken, active, del"),
		  @Index(name = "ptp_request_mulitIndex3", columnList = "link, createrequest, ip, active, del"),
		  @Index(name = "ptp_request_mulitIndex2", columnList = "createrequest"),
		  @Index(name = "ptp_request_mulitSortIndex1", columnList = "id DESC")
		})
public class PTPRequest extends BaseModel {

	private static final long serialVersionUID = 1L;
//	@Column(length = Static.n999)
	private Long link;
//	@Column(length = Static.n999)
	private String referer;
//	@Column(length = Static.n999)
	private String ptptoken;
//	@Column(length = Static.n999)
	private String ip;
//	@Column(length = Static.n99)
	private String createrequest;
	private Integer type;
	private Integer active;
	@ManyToOne
    @JoinColumn(name = "user_id", nullable=false)
    private User user;

	public Long getLink() {
		return link;
	}
	public void setLink(Long link) {
		this.link = link;
	}
	public String getReferer() {
		return referer;
	}
	public void setReferer(String referer) {
		this.referer = referer;
	}
	public String getPtptoken() {
		return ptptoken;
	}
	public void setPtptoken(String ptptoken) {
		this.ptptoken = ptptoken;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getCreaterequest() {
		return createrequest;
	}
	public void setCreaterequest(String createrequest) {
		this.createrequest = createrequest;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getActive() {
		return active;
	}
	public void setActive(Integer active) {
		this.active = active;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

}
