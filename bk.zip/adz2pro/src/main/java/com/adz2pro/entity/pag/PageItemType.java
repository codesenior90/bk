package com.adz2pro.entity.pag;

public enum PageItemType {

    DOTS,
    PAGE

}
