package com.adz2pro.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.adz2pro.base.BaseModel;
import com.adz2pro.constant.Static;
import com.adz2pro.dto.PaymentRequestDto;
import com.adz2pro.util.Util;



@SqlResultSetMapping(
		name = "PaymentRequestDtoMapping",
		classes = @ConstructorResult(targetClass = PaymentRequestDto.class,
				columns = { @ColumnResult(name = "id", type = Long.class),
                        @ColumnResult(name = "payeer"),
                        @ColumnResult(name = "bitcoin"),
                        @ColumnResult(name = "paypal"),
                        @ColumnResult(name = "amount" ,type = Long.class),
                        @ColumnResult(name = "done", type = Integer.class),
                        @ColumnResult(name = "createdate", type= Date.class)
}))

@Entity
@Table(indexes = {
		  @Index(name = "payment_request_mulitIndex1", columnList = "user_id, del"),
		  @Index(name = "payment_request_mulitIndex2", columnList = "del"),
		  @Index(name = "payment_request_mulitIndex3", columnList = "del"),
		  @Index(name = "payment_request_mulitIndex4", columnList = "done, del"),
		  @Index(name = "payment_request_mulitSortIndex1", columnList = "id DESC")
		})
public class PaymentRequest extends BaseModel {

	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String method;
	@Column(length = Static.n999)
	private String account;
	@Column(columnDefinition = "DECIMAL(65,5)")
	private BigDecimal amount;
	private Integer done;
	@ManyToOne
    @JoinColumn(name = "user_id", nullable=false)
    private User user;

	private Long idUser;

	@Column(length = Static.n999)
	private String username;

	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Integer getDone() {
		return done;
	}
	public void setDone(Integer done) {
		this.done = done;
	}

	public Long getIdUser() {
		return idUser;
	}
	public void setIdUser(Long idUser) {
		this.idUser = idUser;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAmountDisplay() {
		return Util.getPriceDisplay(this.amount);
	}

	public String getCreatedateDisplay() {
		return Util.getDateDisplay(this.getCreatedate());
	}

}
