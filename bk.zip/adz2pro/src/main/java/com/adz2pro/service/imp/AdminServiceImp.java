package com.adz2pro.service.imp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.adz2pro.base.BaseServiceImpl;
import com.adz2pro.dao.AdminDao;
import com.adz2pro.dao.UserDao;
import com.adz2pro.entity.Admin;
import com.adz2pro.entity.User;
import com.adz2pro.entity.pag.Paged;
import com.adz2pro.entity.pag.Paging;
import com.adz2pro.service.AdminService;

@Service
public class AdminServiceImp extends BaseServiceImpl<Admin> implements AdminService {

	@Autowired
	AdminDao adminDao;

	@Autowired
	UserDao userDao;

	@Override
	public Admin findTop1ByIdAndDel(Long id, Integer del) {
		return adminDao.findTop1ByIdAndDel(id, del);
	}

	@Override
	public Admin findTop1ByUsernameAndPasswordAndDelAndActive(String username, String password, Integer del,
			Integer active) {
		return adminDao.findTop1ByUsernameAndPasswordAndDelAndActive(username, password, del, active);
	}

	@Override
	public Admin findTop1ByUsernameAndDel(String username, Integer del) {
		return adminDao.findTop1ByUsernameAndDel(username, del);
	}

	@Override
	public Admin findTop1ByUsername(String username) {
		return adminDao.findTop1ByUsername(username);
	}

	@Override
	public Paged<User> getPage(Integer active, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<User> page = userDao.findByActiveAndDelOrderByIdDesc(active, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<User> getPage(Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<User> page = userDao.findByDelOrderByIdDesc(del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<User> getPage(String q, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<User> page = userDao.findByUsernameStartsWithOrEmailStartsWithAndDelOrderByIdDesc(q, q, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<User> getPage(String q, Integer active, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<User> page = userDao.findByUsernameStartsWithOrEmailStartsWithAndActiveAndDelOrderByIdDesc(q, q, active, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

}
