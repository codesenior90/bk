package com.adz2pro.service;

import java.util.List;

import com.adz2pro.base.BaseService;
import com.adz2pro.dto.PTPBannerDto;
import com.adz2pro.dto.PTPDto;
import com.adz2pro.entity.PTP;
import com.adz2pro.entity.PTPRequest;
import com.adz2pro.entity.User;
import com.adz2pro.entity.pag.Paged;

public interface PTPService extends BaseService<PTP, Long> {

	PTP findTop1ByUserAndDel(User user, Integer delete);

	Paged<PTPDto> findPTPByDel(Integer delete, int pageNumber, int size);

	Paged<PTPDto> findPTPByQAndDel(String q, Integer delete, int pageNumber, int size);

	Paged<PTPBannerDto> findPTPBannerByDel(Integer delete, int pageNumber, int size);

	Paged<PTPBannerDto> findPTPBannerByQAndDel(String q, Integer delete, int pageNumber, int size);

}
