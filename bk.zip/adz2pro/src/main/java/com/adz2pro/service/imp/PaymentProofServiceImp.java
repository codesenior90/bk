package com.adz2pro.service.imp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adz2pro.base.BaseServiceImpl;
import com.adz2pro.dao.PaymentProofDao;
import com.adz2pro.entity.PaymentProof;
import com.adz2pro.service.PaymentProofService;

@Service
public class PaymentProofServiceImp extends BaseServiceImpl<PaymentProof> implements PaymentProofService {

	@Autowired
	PaymentProofDao paymentProofDao;

}
