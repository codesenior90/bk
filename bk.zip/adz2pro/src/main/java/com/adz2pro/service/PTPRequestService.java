package com.adz2pro.service;

import java.math.BigDecimal;
import java.util.List;

import com.adz2pro.base.BaseService;
import com.adz2pro.entity.PTPRequest;

public interface PTPRequestService extends BaseService<PTPRequest, Long> {

	PTPRequest findTop1ByLinkAndPtptokenAndActiveAndDelOrderByIdDesc(Long link, String ptptoken, Integer active,
			Integer delete);

	PTPRequest findTop1ByLinkAndCreaterequestAndIpAndActiveAndDelOrderByIdDesc(Long link, String create, String ip, Integer active, Integer delete);

	void makeMoney(PTPRequest ptpRequest, BigDecimal price);

	void makeMoneyBanner(PTPRequest ptpRequest, BigDecimal price);

	List<PTPRequest> findByCreateRequest(String createrequest);
}
