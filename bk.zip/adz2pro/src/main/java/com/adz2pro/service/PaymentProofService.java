package com.adz2pro.service;

import com.adz2pro.base.BaseService;
import com.adz2pro.entity.PaymentProof;

public interface PaymentProofService extends BaseService<PaymentProof, Long> {
}
