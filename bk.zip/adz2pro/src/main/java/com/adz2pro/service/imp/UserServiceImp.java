package com.adz2pro.service.imp;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adz2pro.base.BaseServiceImpl;
import com.adz2pro.constant.Del;
import com.adz2pro.constant.Static;
import com.adz2pro.dao.PTPDao;
import com.adz2pro.dao.UserDao;
import com.adz2pro.entity.PTP;
import com.adz2pro.entity.User;
import com.adz2pro.service.UserService;
import com.adz2pro.util.Util;

@Service
public class UserServiceImp extends BaseServiceImpl<User> implements UserService {

	@Value("${host.ptp}")
	private String hostptp;

	@Value("${host.banner}")
	private String hostbanner;

	@Autowired
	UserDao userDao;

	@Autowired
	PTPDao ptpDao;

	@Override
	public User findTop1ByIdAndDel(Long id, Integer del) {
		return userDao.findTop1ByIdAndDel(id, del);
	}

	@Override
	public User findTop1ByUsernameAndPasswordAndDelAndActive(String username, String password, Integer del,
			Integer active) {
		return userDao.findTop1ByUsernameAndPasswordAndDelAndActive(username, password, del, active);
	}

	@Override
	public User findTop1ByUsername(String username) {
		return userDao.findTop1ByUsername(username);
	}

	@Transactional
	@Override
	public PTP signup(User user) {
		user.setMainBalance(BigDecimal.ZERO);
		user.setPaymentPending(BigDecimal.ZERO);
		user.setPaymentReceived(BigDecimal.ZERO);
		user = userDao.save(user);
		PTP ptp = new PTP();
		ptp.setUser(user);
		ptp.setLink(hostptp.concat(user.getId().toString()));
		ptp.setBanner(String.format(Static.banner, hostbanner.concat(user.getId().toString())));
		ptp.setDel(Del.NOTDEL.getLevelCode());
		ptp.setToday(BigDecimal.ZERO);
		ptp.setTodayCount(Static.zero_);
		ptp.setAllTime(BigDecimal.ZERO);
		ptp.setAllTimeCount(Static.zero_);
		Date nowdate = new Date();
		String now = Util.getDateDisplay(nowdate);
		ptp.setCreatePtp(now);

		ptp.setCreateBanner(now);
		ptp.setTodayBanner(BigDecimal.ZERO);
		ptp.setTodayBannerCount(Static.zero_);
		ptp.setAllTimeBanner(BigDecimal.ZERO);
		ptp.setAllTimeBannerCount(Static.zero_);
		return ptpDao.save(ptp);
	}

	@Override
	public User findTop1ByUsernameAndDel(String username, Integer del) {
		return userDao.findTop1ByUsernameAndDel(username, del);
	}

	@Override
	public User findTop1ByIpAndDel(String ip, Integer del) {
		return userDao.findTop1ByIpAndDel(ip, del);
	}

	@Override
	public User findTop1ByIdAndDelAndActive(Long id, Integer del, Integer active) {
		return userDao.findTop1ByIdAndDelAndActive(id, del, active);
	}

}
