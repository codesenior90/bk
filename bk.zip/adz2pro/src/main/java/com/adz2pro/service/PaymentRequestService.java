package com.adz2pro.service;

import com.adz2pro.base.BaseService;
import com.adz2pro.entity.PaymentRequest;
import com.adz2pro.entity.User;
import com.adz2pro.entity.pag.Paged;

public interface PaymentRequestService extends BaseService<PaymentRequest, Long> {

	Paged<PaymentRequest> getPage(User user, int pageNumber, int size);

	PaymentRequest paymentRequest(PaymentRequest pr);

	Paged<PaymentRequest> getPage(Integer del, int pageNumber, int size);

	Paged<PaymentRequest> getPage(String q, Integer del, int pageNumber, int size);

	Paged<PaymentRequest> getPage(String q, Integer done, Integer del, int pageNumber, int size);

	Paged<PaymentRequest> getPage(Integer done, Integer del, int pageNumber, int size);
}
