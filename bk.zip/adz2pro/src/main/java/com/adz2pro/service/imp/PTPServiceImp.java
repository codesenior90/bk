package com.adz2pro.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.adz2pro.base.BaseServiceImpl;
import com.adz2pro.dao.PTPCustomDao;
import com.adz2pro.dao.PTPDao;
import com.adz2pro.dto.PTPBannerDto;
import com.adz2pro.dto.PTPDto;
import com.adz2pro.entity.PTP;
import com.adz2pro.entity.PTPRequest;
import com.adz2pro.entity.User;
import com.adz2pro.entity.pag.Paged;
import com.adz2pro.entity.pag.Paging;
import com.adz2pro.service.PTPService;

@Service
public class PTPServiceImp extends BaseServiceImpl<PTP> implements PTPService {

	@Autowired
	PTPDao PTPDao;

	@Autowired
	PTPCustomDao ptpCustomDao;

	@Override
	public PTP findTop1ByUserAndDel(User user, Integer delete) {
		return PTPDao.findTop1ByUserAndDel(user, delete);
	}

	@Override
	public Paged<PTPDto> findPTPByDel(Integer delete, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PTPDto> postPage = ptpCustomDao.findPTPByDel(delete, request);
		return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<PTPDto> findPTPByQAndDel(String q, Integer delete, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PTPDto> postPage = ptpCustomDao.findPTPByQAndDel(q, delete, request);
		return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<PTPBannerDto> findPTPBannerByDel(Integer delete, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PTPBannerDto> postPage = ptpCustomDao.findPTPBannerByDel(delete, request);
		return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<PTPBannerDto> findPTPBannerByQAndDel(String q, Integer delete, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PTPBannerDto> postPage = ptpCustomDao.findPTPBannerByQAndDel(q, delete, request);
		return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

}
