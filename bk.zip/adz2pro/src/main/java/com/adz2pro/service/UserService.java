package com.adz2pro.service;

import com.adz2pro.base.BaseService;
import com.adz2pro.entity.PTP;
import com.adz2pro.entity.User;

public interface UserService extends BaseService<User, Long> {

	User findTop1ByIdAndDel(Long id, Integer del);

	User findTop1ByUsernameAndPasswordAndDelAndActive(String username, String password,Integer del,Integer active);

	User findTop1ByUsername(String username);

	PTP signup(User user);

	User findTop1ByUsernameAndDel(String username, Integer del);

	User findTop1ByIpAndDel(String ip, Integer del);

	User findTop1ByIdAndDelAndActive(Long id, Integer del, Integer active);
}
