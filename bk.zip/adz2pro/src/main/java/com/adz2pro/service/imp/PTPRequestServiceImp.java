package com.adz2pro.service.imp;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adz2pro.base.BaseServiceImpl;
import com.adz2pro.constant.Del;
import com.adz2pro.constant.Static;
import com.adz2pro.dao.PTPDao;
import com.adz2pro.dao.PTPRequestDao;
import com.adz2pro.entity.PTP;
import com.adz2pro.entity.PTPRequest;
import com.adz2pro.entity.User;
import com.adz2pro.service.PTPRequestService;
import com.adz2pro.util.Util;

@Service
public class PTPRequestServiceImp extends BaseServiceImpl<PTPRequest> implements PTPRequestService {

	@Autowired
	PTPRequestDao ptpRequestDao;

	@Autowired
	PTPDao ptpDao;

	@Override
	public PTPRequest findTop1ByLinkAndPtptokenAndActiveAndDelOrderByIdDesc(Long link, String ptptoken, Integer active,
			Integer delete) {
		return ptpRequestDao.findTop1ByLinkAndPtptokenAndActiveAndDelOrderByIdDesc(link, ptptoken, active, delete);
	}

	@Override
	public PTPRequest findTop1ByLinkAndCreaterequestAndIpAndActiveAndDelOrderByIdDesc(Long link, String create, String ip, Integer active,
			Integer delete) {
		return ptpRequestDao.findTop1ByLinkAndCreaterequestAndIpAndActiveAndDelOrderByIdDesc(link, create, ip, active, delete);
	}

	@Transactional
	@Override
	public void makeMoney(PTPRequest ptpRequest, BigDecimal price) {
		ptpRequestDao.save(ptpRequest);
		User user = new User();
		user.setId(ptpRequest.getLink());
		PTP ptp = ptpDao.findTop1ByUserAndDel(user, Del.NOTDEL.getLevelCode());
		user = ptp.getUser();
		BigDecimal mainBalance = user.getMainBalance();
		BigDecimal allTime = ptp.getAllTime();
		Long allTimeCount = ptp.getAllTimeCount();
		BigDecimal today = ptp.getToday();
		Long todayCount = ptp.getTodayCount();
		String create = ptp.getCreatePtp();
		Date nowdate = new Date();
		String now = Util.getDateDisplay(nowdate);
		if (!now.equals(create)) {
			today = BigDecimal.ZERO;
			todayCount = Static.zero_;
			create = now;
		}
		if(today == null) {
			today = BigDecimal.ZERO;
		}
		if(todayCount == null) {
			todayCount = Static.zero_;
		}
		if(allTime == null) {
			allTime = BigDecimal.ZERO;
		}
		if(allTimeCount == null) {
			allTimeCount = Static.zero_;
		}
		if(mainBalance == null) {
			mainBalance = BigDecimal.ZERO;
		}
		mainBalance = mainBalance.add(price);
		today = today.add(price);
		allTime = allTime.add(price);
		todayCount = Long.sum(todayCount, Static.one);
		allTimeCount = Long.sum(allTimeCount, Static.one);
		user.setMainBalance(mainBalance);
		ptp.setToday(today);
		ptp.setAllTime(allTime);
		ptp.setTodayCount(todayCount);
		ptp.setAllTimeCount(allTimeCount);
		ptp.setCreatePtp(create);
		ptpDao.save(ptp);
	}

	@Override
	public void makeMoneyBanner(PTPRequest ptpRequest, BigDecimal price) {
		ptpRequestDao.save(ptpRequest);
		User user = new User();
		user.setId(ptpRequest.getLink());
		PTP ptp = ptpDao.findTop1ByUserAndDel(user, Del.NOTDEL.getLevelCode());
		user = ptp.getUser();
		BigDecimal mainBalance = user.getMainBalance();
		BigDecimal allTime = ptp.getAllTimeBanner();
		Long allTimeCount = ptp.getAllTimeBannerCount();
		BigDecimal today = ptp.getTodayBanner();
		Long todayCount = ptp.getTodayBannerCount();
		String create = ptp.getCreateBanner();
		Date nowdate = new Date();
		String now = Util.getDateDisplay(nowdate);
		if (!now.equals(create)) {
			today = BigDecimal.ZERO;
			todayCount = Static.zero_;
			create = now;
		}
		if(today == null) {
			today = BigDecimal.ZERO;
		}
		if(todayCount == null) {
			todayCount = Static.zero_;
		}
		if(allTime == null) {
			allTime = BigDecimal.ZERO;
		}
		if(allTimeCount == null) {
			allTimeCount = Static.zero_;
		}
		if(mainBalance == null) {
			mainBalance = BigDecimal.ZERO;
		}
		mainBalance = mainBalance.add(price);
		today = today.add(price);
		allTime = allTime.add(price);
		todayCount = Long.sum(todayCount, Static.one);
		allTimeCount = Long.sum(allTimeCount, Static.one);
		user.setMainBalance(mainBalance);
		ptp.setTodayBanner(today);
		ptp.setAllTimeBanner(allTime);
		ptp.setTodayBannerCount(todayCount);
		ptp.setAllTimeBannerCount(allTimeCount);
		ptp.setCreateBanner(create);
		ptpDao.save(ptp);
	}

	@Override
	public List<PTPRequest> findByCreateRequest(String createrequest) {
		return ptpRequestDao.findByCreateRequest(createrequest);
	}

}
