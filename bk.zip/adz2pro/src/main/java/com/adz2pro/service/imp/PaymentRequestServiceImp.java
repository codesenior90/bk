package com.adz2pro.service.imp;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adz2pro.base.BaseServiceImpl;
import com.adz2pro.constant.Del;
import com.adz2pro.dao.PaymentRequestCustomDao;
import com.adz2pro.dao.PaymentRequestDao;
import com.adz2pro.dao.UserDao;
import com.adz2pro.dto.PaymentRequestDto;
import com.adz2pro.entity.PaymentRequest;
import com.adz2pro.entity.User;
import com.adz2pro.entity.pag.Paged;
import com.adz2pro.entity.pag.Paging;
import com.adz2pro.service.PaymentRequestService;

@Service
public class PaymentRequestServiceImp extends BaseServiceImpl<PaymentRequest> implements PaymentRequestService {

	@Autowired
	PaymentRequestDao paymentRequestDao;

	@Autowired
	PaymentRequestCustomDao paymentRequestCustomDao;

	@Autowired
	UserDao userDao;

	@Override
	public Paged<PaymentRequest> getPage(User user, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PaymentRequest> page = paymentRequestDao.findByUserAndDelOrderByIdDesc(user, Del.NOTDEL.getLevelCode(), request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Transactional
	@Override
	public PaymentRequest paymentRequest(PaymentRequest pr) {
		User user = pr.getUser();
		user.setMainBalance(BigDecimal.ZERO);
		userDao.save(user);
		return paymentRequestDao.save(pr);
	}

	@Override
	public Paged<PaymentRequest> getPage(Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PaymentRequest> page = paymentRequestDao.findByDelOrderByIdDesc(del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<PaymentRequest> getPage(String q, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PaymentRequest> page = paymentRequestDao.findByUsernameStartsWithOrEmailStartsWithAndDelOrderByIdDesc(q, q, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<PaymentRequest> getPage(String q, Integer done, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PaymentRequest> page = paymentRequestDao.findByUsernameStartsWithOrEmailStartsWithAndDoneAndDelOrderByIdDesc(q, q, done, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<PaymentRequest> getPage(Integer done, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<PaymentRequest> page = paymentRequestDao.findByDoneAndDelOrderByIdDesc(done, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

}
