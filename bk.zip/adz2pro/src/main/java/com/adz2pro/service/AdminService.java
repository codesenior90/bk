package com.adz2pro.service;

import com.adz2pro.base.BaseService;
import com.adz2pro.entity.Admin;
import com.adz2pro.entity.User;
import com.adz2pro.entity.pag.Paged;

public interface AdminService extends BaseService<Admin, Long> {
	Admin findTop1ByIdAndDel(Long id, Integer del);

	Admin findTop1ByUsernameAndPasswordAndDelAndActive(String username, String password,Integer del,Integer active);

	Admin findTop1ByUsernameAndDel(String username, Integer del);

	Admin findTop1ByUsername(String username);

	Paged<User> getPage(Integer active, Integer del, int pageNumber, int size);

	Paged<User> getPage(Integer del, int pageNumber, int size);

	Paged<User> getPage(String q, Integer del, int pageNumber, int size);

	Paged<User> getPage(String q, Integer active, Integer del, int pageNumber, int size);
}
