package com.adz2pro.dao;

import com.adz2pro.base.BaseDao;
import com.adz2pro.entity.PTP;
import com.adz2pro.entity.User;

public interface PTPDao extends BaseDao<PTP> {
	PTP findTop1ByUserAndDel(User user, Integer delete);
}
