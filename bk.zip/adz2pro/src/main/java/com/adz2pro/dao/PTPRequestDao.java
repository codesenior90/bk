package com.adz2pro.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.adz2pro.base.BaseDao;
import com.adz2pro.entity.PTPRequest;
import com.adz2pro.entity.PaymentRequest;

public interface PTPRequestDao extends BaseDao<PTPRequest> {

	PTPRequest findTop1ByLinkAndPtptokenAndActiveAndDelOrderByIdDesc(Long link, String ptptoken, Integer active,
			Integer delete);

	PTPRequest findTop1ByLinkAndCreaterequestAndIpAndActiveAndDelOrderByIdDesc(Long link, String create, String ip, Integer active, Integer delete);

	@Query("SELECT p FROM PTPRequest p WHERE p.createrequest <= ?1")
	List<PTPRequest> findByCreateRequest(String createrequest);

}
