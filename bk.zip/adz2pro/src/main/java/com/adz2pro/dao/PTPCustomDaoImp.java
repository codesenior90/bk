package com.adz2pro.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.adz2pro.dto.PTPBannerDto;
import com.adz2pro.dto.PTPDto;

@Repository
public class PTPCustomDaoImp implements PTPCustomDao {

	@PersistenceContext
	private EntityManager em;

	@Override
	public Page<PTPDto> findPTPByDel(Integer delete, Pageable pageable) {
		int pageNumber = pageable.getPageNumber();
		int pageSize = pageable.getPageSize();
		StringBuilder sql = new StringBuilder();
		sql.append("select p.id id,p.link link,p.today today,p.all_time allTime,p.today_count todayCount,p.all_Time_Count allTimeCount,u.id userId,u.username username ");
		sql.append(" from ptp p inner join user u on p.user_id = u.id where u.del = :del ORDER BY p.all_time_count DESC");
		StringBuilder sqlTotal = new StringBuilder("select count(*) from ptp p inner join user u on p.user_id = u.id where u.del = :del ORDER BY p.all_time_count DESC");
		Query query = em.createNativeQuery(sql.toString(), "PTPDtoMapping");
		Query queryTotal = em.createNativeQuery(sqlTotal.toString());
		query.setParameter("del", delete);
		queryTotal.setParameter("del", delete);
		query.setFirstResult((pageNumber) * pageSize);
		query.setMaxResults(pageSize);
		List<PTPDto> list = query.getResultList();
		BigInteger countResult = (BigInteger) queryTotal.getSingleResult();
		return new PageImpl<>(list, pageable, countResult.longValue());
	}

	@Override
	public Page<PTPDto> findPTPByQAndDel(String q, Integer delete, Pageable pageable) {
		int pageNumber = pageable.getPageNumber();
		int pageSize = pageable.getPageSize();
		StringBuilder sql = new StringBuilder();
		sql.append("select p.id id,p.link link,p.today today,p.all_time allTime,p.today_count todayCount,p.all_Time_Count allTimeCount,u.id userId,u.username username ");
		sql.append(" from ptp p inner join user u on p.user_id = u.id where (u.username like CONCAT('%',:q,'%') or u.email like CONCAT('%',:q,'%')) and u.del = :del ORDER BY p.all_time_count DESC");
		StringBuilder sqlTotal = new StringBuilder("select count(*) from ptp p inner join user u on p.user_id = u.id where (u.username like CONCAT('%',:q,'%') or u.email like CONCAT('%',:q,'%')) and u.del = :del ORDER BY p.all_time_count DESC");
		Query query = em.createNativeQuery(sql.toString(), "PTPDtoMapping");
		Query queryTotal = em.createNativeQuery(sqlTotal.toString());
		query.setParameter("del", delete);
		queryTotal.setParameter("del", delete);
		query.setParameter("q", q);
		queryTotal.setParameter("q", q);
		query.setFirstResult((pageNumber) * pageSize);
		query.setMaxResults(pageSize);
		List<PTPDto> list = query.getResultList();
		BigInteger countResult = (BigInteger) queryTotal.getSingleResult();
		return new PageImpl<>(list, pageable, countResult.longValue());
	}

	@Override
	public Page<PTPBannerDto> findPTPBannerByDel(Integer delete, Pageable pageable) {
		int pageNumber = pageable.getPageNumber();
		int pageSize = pageable.getPageSize();
		StringBuilder sql = new StringBuilder();
		sql.append("select p.id id,p.banner banner,p.today_banner todayBanner,p.all_time_banner allTimeBanner,p.today_banner_count todayBannerCount,p.all_Time_Banner_Count allTimeBannerCount,u.id userId,u.username username ");
		sql.append(" from ptp p inner join user u on p.user_id = u.id where u.del = :del ORDER BY p.all_time_banner_count DESC");
		StringBuilder sqlTotal = new StringBuilder("select count(*) from ptp p inner join user u on p.user_id = u.id where u.del = :del ORDER BY p.all_time_banner_count DESC");
		Query query = em.createNativeQuery(sql.toString(), "PTPBannerDtoMapping");
		Query queryTotal = em.createNativeQuery(sqlTotal.toString());
		query.setParameter("del", delete);
		queryTotal.setParameter("del", delete);
		query.setFirstResult((pageNumber) * pageSize);
		query.setMaxResults(pageSize);
		List<PTPBannerDto> list = query.getResultList();
		BigInteger countResult = (BigInteger) queryTotal.getSingleResult();
		return new PageImpl<>(list, pageable, countResult.longValue());
	}

	@Override
	public Page<PTPBannerDto> findPTPBannerByQAndDel(String q, Integer delete, Pageable pageable) {
		int pageNumber = pageable.getPageNumber();
		int pageSize = pageable.getPageSize();
		StringBuilder sql = new StringBuilder();
		sql.append("select p.id id,p.banner banner,p.today_banner todayBanner,p.all_time_banner allTimeBanner,p.today_banner_count todayBannerCount,p.all_Time_Banner_Count allTimeBannerCount,u.id userId,u.username username ");
		sql.append(" from ptp p inner join user u on p.user_id = u.id where (u.username like CONCAT('%',:q,'%') or u.email like CONCAT('%',:q,'%')) and u.del = :del ORDER BY p.all_time_banner_count DESC");
		StringBuilder sqlTotal = new StringBuilder("select count(*) from ptp p inner join user u on p.user_id = u.id where (u.username like CONCAT('%',:q,'%') or u.email like CONCAT('%',:q,'%')) and u.del = :del ORDER BY p.all_time_banner_count DESC");
		Query query = em.createNativeQuery(sql.toString(), "PTPBannerDtoMapping");
		Query queryTotal = em.createNativeQuery(sqlTotal.toString());
		query.setParameter("del", delete);
		queryTotal.setParameter("del", delete);
		query.setParameter("q", q);
		queryTotal.setParameter("q", q);
		query.setFirstResult((pageNumber) * pageSize);
		query.setMaxResults(pageSize);
		List<PTPBannerDto> list = query.getResultList();
		BigInteger countResult = (BigInteger) queryTotal.getSingleResult();
		return new PageImpl<>(list, pageable, countResult.longValue());
	}


}
