package com.adz2pro.dao;

import com.adz2pro.base.BaseDao;
import com.adz2pro.entity.PaymentProof;

public interface PaymentProofDao extends BaseDao<PaymentProof> {

}
