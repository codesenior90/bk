package com.adz2pro.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.adz2pro.base.BaseDao;
import com.adz2pro.entity.User;

public interface UserDao extends BaseDao<User> {

	User findTop1ByIdAndDel(Long id, Integer del);

	User findTop1ByUsernameAndPasswordAndDelAndActive(String username, String password,Integer del,Integer active);

	User findTop1ByUsername(String username);

	User findTop1ByUsernameAndDel(String username, Integer del);

	User findTop1ByIpAndDel(String ip, Integer del);

	Page<User> findByActiveAndDelOrderByIdDesc(Integer active, Integer del, Pageable pageable);

	Page<User> findByDelOrderByIdDesc(Integer del, Pageable pageable);

	@Query("SELECT u FROM User u WHERE (u.username LIKE %?1% or u.email LIKE %?2%) and u.del = ?3 order by u.id desc")
	Page<User> findByUsernameStartsWithOrEmailStartsWithAndDelOrderByIdDesc(String username, String email, Integer del, Pageable pageable);

	User findTop1ByIdAndDelAndActive(Long id, Integer del, Integer active);

	@Query("SELECT u FROM User u WHERE (u.username LIKE %?1% or u.email LIKE %?2%) and u.active = ?3 and u.del = ?4 order by u.id desc")
	Page<User> findByUsernameStartsWithOrEmailStartsWithAndActiveAndDelOrderByIdDesc(String username, String email, Integer active, Integer del, Pageable pageable);
}
