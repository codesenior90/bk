package com.adz2pro.dao;

import com.adz2pro.base.BaseDao;
import com.adz2pro.entity.Admin;

public interface AdminDao extends BaseDao<Admin> {

	Admin findTop1ByIdAndDel(Long id, Integer del);

	Admin findTop1ByUsernameAndPasswordAndDelAndActive(String username, String password,Integer del,Integer active);

	Admin findTop1ByUsernameAndDel(String username, Integer del);

	Admin findTop1ByUsername(String username);

}
