package com.adz2pro.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.adz2pro.dto.PTPBannerDto;
import com.adz2pro.dto.PTPDto;

public interface PTPCustomDao {
	Page<PTPDto> findPTPByDel(Integer delete, Pageable pageable);

	Page<PTPDto> findPTPByQAndDel(String q, Integer delete, Pageable pageable);

	Page<PTPBannerDto> findPTPBannerByDel(Integer delete, Pageable pageable);

	Page<PTPBannerDto> findPTPBannerByQAndDel(String q, Integer delete, Pageable pageable);
}
