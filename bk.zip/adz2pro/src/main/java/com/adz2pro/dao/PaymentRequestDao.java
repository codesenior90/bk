package com.adz2pro.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.adz2pro.base.BaseDao;
import com.adz2pro.entity.PaymentRequest;
import com.adz2pro.entity.User;

public interface PaymentRequestDao extends BaseDao<PaymentRequest> {

	Page<PaymentRequest> findByUserAndDelOrderByIdDesc(User user,Integer del, Pageable pageable);

	Page<PaymentRequest> findByDelOrderByIdDesc(Integer del, Pageable pageable);

	@Query("SELECT p FROM PaymentRequest p JOIN p.user u WHERE (u.username LIKE %?1% or u.email LIKE %?2%) and p.del = ?3 order by p.id desc")
	Page<PaymentRequest> findByUsernameStartsWithOrEmailStartsWithAndDelOrderByIdDesc(String username, String email, Integer del, Pageable pageable);

	Page<PaymentRequest> findByDoneAndDelOrderByIdDesc(Integer done, Integer del, Pageable pageable);

	@Query("SELECT p FROM PaymentRequest p JOIN p.user u WHERE (u.username LIKE %?1% or u.email LIKE %?2%) and p.done = ?3 and p.del = ?4 order by p.id desc")
	Page<PaymentRequest> findByUsernameStartsWithOrEmailStartsWithAndDoneAndDelOrderByIdDesc(String username, String email, Integer done , Integer del, Pageable pageable);
}
