package com.adz2pro.dao;

public interface PaymentRequestCustomDao {
}
