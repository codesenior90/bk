package com.adz2pro.util;

import com.adz2pro.constant.Static;

public class StringUtil {
	public static boolean isNotBlank(String str) {
		return str != null && !str.equals(Static.blank);
	}

	public static boolean isBlank(String str) {
		return str == null || str.equals(Static.blank);
	}
}
