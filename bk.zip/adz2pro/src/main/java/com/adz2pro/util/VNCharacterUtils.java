package com.adz2pro.util;

import java.text.Normalizer;
import java.util.regex.Pattern;

public class VNCharacterUtils {

	private static final String regex = "\\p{InCombiningDiacriticalMarks}+";
	private static final String blank = "";

	public static String removeAccent(String s) {
		String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
		Pattern pattern = Pattern.compile(regex);
		return pattern.matcher(temp).replaceAll(blank);
	}
}
