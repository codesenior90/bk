package com.xdailyx.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.xdailyx.constant.Del;
import com.xdailyx.constant.Static;
import com.xdailyx.entity.Tag;
import com.xdailyx.form.MenuForm;
import com.xdailyx.form.TagForm;
import com.xdailyx.service.MenuService;
import com.xdailyx.service.TagService;
import com.xdailyx.service.VideoService;
import com.xdailyx.util.VNCharacterUtils;

@Controller
@RequestMapping(Static.urladmin)
public class AdminTagController {

	private static final Logger log = LoggerFactory.getLogger(AdminTagController.class);

	@Autowired
	MenuService menuService;

	@Autowired
	TagService tagService;

	@Autowired
	VideoService videoService;

	@RequestMapping(value = { Static.url_tag }, method = RequestMethod.GET)
	public String url_tag(Model model, HttpSession session, HttpServletRequest request,
						@ModelAttribute(Static.tagForm) TagForm tagForm,
						  @RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
						  @RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url1) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}
			model.addAttribute(Static.modelrs, tagService.getPage(page, size));
			model.addAttribute(Static.url, url.toString());
			return Static.page_tag;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.page_tag;
	}

	@Transactional
	@RequestMapping(value = { Static.url_add_tag }, method = { RequestMethod.POST })
	public String url_add_tag(@ModelAttribute(Static.tagForm) TagForm tagForm, HttpServletRequest request,
							  @RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
							  @RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size, HttpSession session,
			Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url4) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}

			model.addAttribute(Static.url, url.toString());

			String name = tagForm.getName();
			String value = tagForm.getValue();
			StringBuilder str = new StringBuilder();
			if (name == null || name.equals(Static.blank)) {
				str.append(Static.mes_name);
				str.append(Static.n);
			} else {
				if (Static.n999 < name.length()) {
					str.append(Static.mes_name_max);
					str.append(Static.n);
				}
				if (value == null || value.equals(Static.blank)) {
					value = VNCharacterUtils.removeAccent(name);
					value = value.replaceAll(Static.separation1, Static.separation2);
				} else {
					if (Static.n999 < value.length()) {
						str.append(Static.mes_url_max);
						str.append(Static.n);
					}
				}

				Tag exits = tagService.findTop1ByValueAndDel(value, Del.NOTDEL.getLevelCode());
				if (exits != null) {
					str.append(Static.mes_tag_exist);
					str.append(Static.n);
				}

			}

			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				model.addAttribute(Static.modelrs, tagService.getPage(page, size));
				return Static.page_tag;
			} else {
				Tag tag = new Tag();
				BeanUtils.copyProperties(tagForm, tag);
				tag.setDel(Del.NOTDEL.getLevelCode());
				tag.setValue(value);
				tagService.save(tag);
				model.addAttribute(Static.error, Static.mes_success);
				model.addAttribute(Static.menuForm, new MenuForm());
				model.addAttribute(Static.modelrs, tagService.getPage(page, size));
				return Static.page_tag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.page_tag;
	}

	@RequestMapping(value = { Static.url_update_tag }, method = RequestMethod.GET)
	public String url_update_tag(Model model, @ModelAttribute(Static.tagForm) TagForm tagForm,
			HttpSession session,
			@PathVariable("id") Long id) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			model.addAttribute(Static.tagForm, tagService.findOne(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.page_update_tag;
	}

	@Transactional
	@RequestMapping(value = { Static.url_update_tag }, method = { RequestMethod.POST })
	public String updatemenu(
			@PathVariable("id") Long id,
			HttpSession session,
			@ModelAttribute(Static.tagForm) TagForm tagForm, HttpServletRequest request, Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			Tag tag = tagService.findOne(id);
			String name = tagForm.getName();
			String value = tagForm.getValue();
			Integer del = tagForm.getDel();
			StringBuilder str = new StringBuilder();

			if (id == null) {
				str.append(Static.mes_id);
				str.append(Static.n);
			}

			if (name == null || name.equals(Static.blank)) {
				str.append(Static.mes_name);
				str.append(Static.n);
			} else {
				if (Static.n999 < name.length()) {
					str.append(Static.mes_name_max);
					str.append(Static.n);
				}
				if (value == null || value.equals(Static.blank)) {
					value = VNCharacterUtils.removeAccent(name);
					value = value.replaceAll(Static.separation1, Static.separation2);
				} else {
					if (Static.n999 < value.length()) {
						str.append(Static.mes_url_max);
						str.append(Static.n);
					}
				}

				if(!tag.getName().equals(name)) {
					Tag exits = tagService.findTop1ByValueAndDel(value, Del.NOTDEL.getLevelCode());
					if (exits != null) {
						str.append(Static.mes_menu_exist);
						str.append(Static.n);
					}
				}
			}

			if (del == null) {
				str.append(Static.mes_del);
				str.append(Static.n);
			} else {
				boolean check = true;
				if (Del.DEL.getLevelCode() == del) {
					check = false;
				} else if (Del.NOTDEL.getLevelCode() == del) {
					check = false;
				}
				if (check) {
					str.append(Static.mes_del);
					str.append(Static.n);
				}
			}

			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return Static.page_update_tag;
			} else {
				BeanUtils.copyProperties(tagForm, tag);
				tag.setDel(del);
				tag.setValue(value);
				tagService.save(tag);
				model.addAttribute(Static.error, Static.mes_success);
				return Static.page_update_tag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.page_update_tag;
	}

	@Transactional
	@GetMapping("/delete-tag/{id}")
	public String deleteUser(
			HttpSession session,
			@PathVariable("id") long id, Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			tagService.delete(id);
		} catch (Exception e) {
			return "error-500";
		}
		return "redirect:/admin/tag";
	}

}
