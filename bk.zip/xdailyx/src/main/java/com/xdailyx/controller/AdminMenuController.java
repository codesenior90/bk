package com.xdailyx.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.xdailyx.constant.Del;
import com.xdailyx.constant.Static;
import com.xdailyx.entity.Menu;
import com.xdailyx.form.MenuForm;
import com.xdailyx.service.MenuService;
import com.xdailyx.service.TagService;
import com.xdailyx.util.VNCharacterUtils;

@Controller
@RequestMapping(Static.urladmin)
public class AdminMenuController {

	@Autowired
	MenuService menuService;

	@Autowired
	TagService tagService;

	@RequestMapping(value = { Static.url_menu }, method = RequestMethod.GET)
	public String index(Model model, HttpSession session, HttpServletRequest request,
			@ModelAttribute(Static.menuForm) MenuForm menuForm,
			@RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
			@RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size) {
		try {

			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url1) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}
			model.addAttribute(Static.modelrs, menuService.getPage(page, size));
			model.addAttribute(Static.url, url.toString());
			return Static.page_menu;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.page_menu;
	}

	@Transactional
	@RequestMapping(value = { Static.url_add_menu }, method = { RequestMethod.POST })
	public String signup(@ModelAttribute(Static.menuForm) MenuForm menuForm, HttpServletRequest request,
						 @RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
						 @RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size, HttpSession session,
			Model model) {
		Object usernameSession = session.getAttribute(Static.admin);
		if (usernameSession == null) {
			return Static.redirect_admin_login;
		}
		model.addAttribute(Static.modelms, menuService.findByDelete(Del.NOTDEL.getLevelCode()));
		model.addAttribute(Static.modelts, tagService.findByDelete(Del.NOTDEL.getLevelCode()));
		try {
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url4) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}

			model.addAttribute(Static.url, url.toString());

			String name = menuForm.getName();
			String value = menuForm.getValue();
			StringBuilder str = new StringBuilder();
			if (name == null || name.equals(Static.blank)) {
				str.append(Static.mestitle);
				str.append(Static.n);
			} else {
				if (Static.n999 < name.length()) {
					str.append(Static.mestitle_max);
					str.append(Static.n);
				}
				if (value == null || value.equals(Static.blank)) {
					value = VNCharacterUtils.removeAccent(name);
					value = value.replaceAll(Static.separation1, Static.separation2);
				} else {
					if (Static.n999 < value.length()) {
						str.append(Static.mes_url_max);
						str.append(Static.n);
					}
				}

				Menu exits = menuService.findTop1ByValueAndDel(value, Del.NOTDEL.getLevelCode());
				if (exits != null) {
					str.append(Static.mes_menu_exist);
					str.append(Static.n);
				}

			}

			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				model.addAttribute(Static.modelrs, menuService.getPage(page, size));
				return Static.page_menu;
			} else {
				Menu menu = new Menu();
				BeanUtils.copyProperties(menuForm, menu);
				menu.setDel(Del.NOTDEL.getLevelCode());
				menu.setValue(value);
				menuService.save(menu);
				model.addAttribute(Static.error, Static.mes_success);
				model.addAttribute(Static.menuForm, new MenuForm());
				model.addAttribute(Static.modelrs, menuService.getPage(page, size));
				return Static.page_menu;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.page_menu;
	}

	@RequestMapping(value = { Static.url_update_menu }, method = RequestMethod.GET)
	public String urladminupdatemenu(Model model, @ModelAttribute(Static.menuForm) MenuForm menuForm,
			@PathVariable("id") Long id,
			 HttpSession session) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			model.addAttribute(Static.menuForm, menuService.findOne(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.page_update_menu;
	}

	@Transactional
	@RequestMapping(value = { Static.url_update_menu }, method = { RequestMethod.POST })
	public String updatemenu(
			@PathVariable("id") Long id,
			 HttpSession session,
			@ModelAttribute(Static.menuForm) MenuForm menuForm, HttpServletRequest request, Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			Menu menu = menuService.findOne(id);
			String name = menuForm.getName();
			String value = menuForm.getValue();
			Integer del = menuForm.getDel();
			StringBuilder str = new StringBuilder();

			if (id == null) {
				str.append(Static.mes_id);
				str.append(Static.n);
			}

			if (name == null || name.equals(Static.blank)) {
				str.append(Static.mestitle);
				str.append(Static.n);
			} else {
				if (Static.n999 < name.length()) {
					str.append(Static.mestitle_max);
					str.append(Static.n);
				}
				if (value == null || value.equals(Static.blank)) {
					value = VNCharacterUtils.removeAccent(name);
					value = value.replaceAll(Static.separation1, Static.separation2);
				} else {
					if (Static.n999 < value.length()) {
						str.append(Static.mes_url_max);
						str.append(Static.n);
					}
				}

				if(!menu.getName().equals(name)) {
					Menu exits = menuService.findTop1ByValueAndDel(value, Del.NOTDEL.getLevelCode());
					if (exits != null) {
						str.append(Static.mes_menu_exist);
						str.append(Static.n);
					}
				}
			}

			if (del == null) {
				str.append(Static.mes_del);
				str.append(Static.n);
			} else {
				boolean check = true;
				if (Del.DEL.getLevelCode() == del) {
					check = false;
				} else if (Del.NOTDEL.getLevelCode() == del) {
					check = false;
				}
				if (check) {
					str.append(Static.mes_del);
					str.append(Static.n);
				}
			}

			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return Static.page_update_menu;
			} else {
				BeanUtils.copyProperties(menuForm, menu);
				menu.setDel(del);
				menu.setValue(value);
				menuService.save(menu);
				model.addAttribute(Static.error, Static.mes_success);
				return Static.page_update_menu;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Static.page_update_menu;
	}

	@Transactional
	@GetMapping("/delete-menu/{id}")
	public String deleteUser(@PathVariable("id") long id,
			 HttpSession session,Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			menuService.delete(id);
		} catch (Exception e) {
			return "error-500";
		}
		return "redirect:/admin/menu";
	}

}
