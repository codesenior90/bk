package com.xdailyx.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.xdailyx.constant.Static;
import com.xdailyx.form.VideoForm;

@Controller
@RequestMapping(Static.urladmin)
public class AdminController {

	@Value("${admin.login}")
	private String admin;

	@RequestMapping(value = { "/login" }, method = { RequestMethod.GET })
	public String addnew(@ModelAttribute("videoForm") VideoForm videoForm, Model model) {
		try {
		} catch (Exception e) {
		}
		return "admin/login";
	}

	@Transactional
	@RequestMapping(value = { "/login" }, method = { RequestMethod.POST })
	public String addnew(@RequestParam(value = "username", required = false, defaultValue = "") String username,
			HttpServletRequest request, HttpSession session, Model model) {
		try {
			if(admin.equals(username)) {
				session.setAttribute(Static.admin, username);
				return Static.redirect_admin_addnew;
			}
			return "admin/login";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "admin/login";
	}

	@RequestMapping(value = { "logout" }, method = { RequestMethod.POST, RequestMethod.GET })
	public String logout(HttpSession session) {
		try {
			session.removeAttribute(Static.admin);
		} catch (Exception e) {
		}
		return Static.redirect_admin_login;
	}

}
