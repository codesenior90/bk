package com.xdailyx.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.xdailyx.constant.Del;
import com.xdailyx.constant.Static;
import com.xdailyx.entity.Video;
import com.xdailyx.service.MenuService;
import com.xdailyx.service.TagService;
import com.xdailyx.service.VideoService;

@Controller
public class XdailyXController {

	@Value("${welcome.message}")
	private String message;

	@Autowired
	VideoService videoService;

	@Autowired
	MenuService menuService;

	@Autowired
	TagService tagService;

	@RequestMapping(value = { "/" }, method = { RequestMethod.GET, RequestMethod.POST })
	public String index(Model model, HttpServletRequest request,
			@RequestParam(value = "q", required = false, defaultValue = "") String q,
			@RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
			@RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size) {
		try {
			model.addAttribute(Static.modelms, menuService.findByDelete(Del.NOTDEL.getLevelCode()));
			model.addAttribute(Static.modelts, tagService.findByDelete(Del.NOTDEL.getLevelCode()));
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url1) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}

			if (q == null || Static.blank.equals(q)) {
				model.addAttribute(Static.modelrs, videoService.getPage(Del.NOTDEL.getLevelCode(), page, size));
			} else {
				model.addAttribute(Static.modelrs, videoService.getPage(q, Del.NOTDEL.getLevelCode(), page, size));
			}

			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, q);
			return "xdailyx";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "xdailyx";
	}

	@RequestMapping(value = { "/video/{url}" }, method = RequestMethod.GET)
	public String video(@PathVariable String url,
			@RequestParam(value = Static.show, required = false, defaultValue = Static.page_value) int show,
			Model model) {
		try {
			model.addAttribute(Static.modelms, menuService.findByDelete(Del.NOTDEL.getLevelCode()));
			model.addAttribute(Static.modelts, tagService.findByDelete(Del.NOTDEL.getLevelCode()));
			if (!Static.blank.equals(url)) {
				Video video = videoService.findTop1ByUrlAndDel(url, Del.NOTDEL.getLevelCode());
				if (video != null) {
					List<Long> ids = video.getTags().stream().map(t -> t.getId()).collect(Collectors.toList());
					model.addAttribute("vs", videoService.findTop10ByTags_IdInOrderByIdDesc(ids));
					model.addAttribute("url", url);
					model.addAttribute("v", video);
					model.addAttribute("show", show);
					return "video";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "video";
	}

	@RequestMapping(value = { "/menu/{value}" }, method = { RequestMethod.GET, RequestMethod.POST })
	public String menu(Model model, HttpServletRequest request,
			@PathVariable("value") String value,
			@RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
			@RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size) {
		try {
			model.addAttribute(Static.modelms, menuService.findByDelete(Del.NOTDEL.getLevelCode()));
			model.addAttribute(Static.modelts, tagService.findByDelete(Del.NOTDEL.getLevelCode()));
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url1) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}

			model.addAttribute(Static.modelrs, videoService.findByMenu_ValueAndDelOrderByIdDesc(value, Del.NOTDEL.getLevelCode(), page, size));

			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, Static.blank);
			return "xdailyx";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "xdailyx";
	}

	@RequestMapping(value = { "/tag/{value}" }, method = { RequestMethod.GET, RequestMethod.POST })
	public String tag(Model model, HttpServletRequest request,
			@PathVariable("value") String value,
			@RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
			@RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size) {
		try {
			model.addAttribute(Static.modelms, menuService.findByDelete(Del.NOTDEL.getLevelCode()));
			model.addAttribute(Static.modelts, tagService.findByDelete(Del.NOTDEL.getLevelCode()));
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url1) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}

			model.addAttribute(Static.modelrs, videoService.findByTags_ValueAndDelOrderByIdDesc(value, Del.NOTDEL.getLevelCode(), page, size));

			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, Static.blank);
			return "xdailyx";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "xdailyx";
	}

}
