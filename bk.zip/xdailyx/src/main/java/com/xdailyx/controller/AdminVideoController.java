package com.xdailyx.controller;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import com.xdailyx.constant.Del;
import com.xdailyx.constant.Static;
import com.xdailyx.entity.Menu;
import com.xdailyx.entity.Tag;
import com.xdailyx.entity.Video;
import com.xdailyx.form.VideoForm;
import com.xdailyx.service.MenuService;
import com.xdailyx.service.TagService;
import com.xdailyx.service.VideoService;
import com.xdailyx.util.Util;
import com.xdailyx.util.VNCharacterUtils;

@Controller
@RequestMapping(Static.urladmin)
public class AdminVideoController {

	@Autowired
	VideoService videoService;

	@Autowired
	MenuService menuService;

	@Autowired
	TagService tagService;

	@RequestMapping(value = { "/add-new" }, method = { RequestMethod.GET })
	public String addnew(
			HttpSession session,
			@ModelAttribute("videoForm") VideoForm videoForm, Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			model.addAttribute(Static.modelms, menuService.findByDelete(Del.NOTDEL.getLevelCode()));
			model.addAttribute(Static.modelts, tagService.findByDelete(Del.NOTDEL.getLevelCode()));
		} catch (Exception e) {
		}
		return "admin/add-new";
	}

	@Transactional
	@RequestMapping(value = { "add-new" }, method = { RequestMethod.POST })
	public String addnew(@ModelAttribute("videoForm") VideoForm videoForm, HttpServletRequest request,
			HttpSession session, Model model) {
		model.addAttribute(Static.modelms, menuService.findByDelete(Del.NOTDEL.getLevelCode()));
		model.addAttribute(Static.modelts, tagService.findByDelete(Del.NOTDEL.getLevelCode()));
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			String title = videoForm.getTitle();
			String imagehidden = videoForm.getImagehidden();
			videoForm.setImg(imagehidden);
			String img = videoForm.getImg();
			String url = videoForm.getUrl();
			Long menuId = videoForm.getMenuId();
			List<Long> tagIds = videoForm.getTagIds();
			StringBuilder str = new StringBuilder();
			if (title == null || title.equals(Static.blank)) {
				str.append(Static.mestitle);
				str.append(Static.n);
			} else {
				if (Static.n999 < title.length()) {
					str.append(Static.mestitle_max);
					str.append(Static.n);
				}
				if (url == null || url.equals(Static.blank)) {
					url = VNCharacterUtils.removeAccent(title);
					url = url.replaceAll(Static.separation1, Static.separation2);
				} else {
					if (Static.n999 < url.length()) {
						str.append(Static.mes_url_max);
						str.append(Static.n);
					}
				}
			}

			if (img == null || img.equals(Static.blank)) {
				str.append(Static.mes_image);
				str.append(Static.n);
			} else {
				if (Static.n999 < img.length()) {
					str.append(Static.mes_img_max);
					str.append(Static.n);
				}
			}

			if (menuId == null || menuId.intValue() == Static.zero) {
				str.append(Static.mes_menu);
				str.append(Static.n);
			}

			if (tagIds == null || tagIds.size() == Static.zero) {
				str.append(Static.mes_tag);
				str.append(Static.n);
			}

			if (str.length() > Static.zero) {
				model.addAttribute(Static.error, str);
				return "admin/add-new";
			} else {

				Menu menu = menuService.findTop1ByIdAndDel(menuId, Del.NOTDEL.getLevelCode());
				if (menu == null) {
					str.append(Static.mes_menu);
					str.append(Static.n);
				}
				List<Tag> tags = tagService.findByDelAndIdIn(Del.NOTDEL.getLevelCode(), tagIds);

				if (tags == null || tags.isEmpty()) {
					str.append(Static.mes_tag);
					str.append(Static.n);
				}

				if (str.length() > Static.zero) {
					model.addAttribute(Static.error, str);
					return "admin/add-new";
				}
				Video video = new Video();
				BeanUtils.copyProperties(videoForm, video);
				video.setUrl(url);
				video.setMenu(menu);
				video.setTags(tags);
				video.setDel(Del.NOTDEL.getLevelCode());
				video = videoService.save(video);
				url = video.getUrl().concat(Static.separation2).concat(String.valueOf(video.getId()));
				video.setUrl(url);
				videoService.save(video);
				model.addAttribute(Static.error, Static.mes_success);
				model.addAttribute(Static.videoForm, new VideoForm());
				return "admin/add-new";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "admin/add-new";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/upload")
	@ResponseBody
	public Map<String, Object> uploadFile(@RequestParam(value = "image", required = false) MultipartFile image,
			@RequestParam(value = "key", required = false) String key) {
		Map<String, Object> result = new HashMap<>();
		if (null == key || "".equals(key)) {
			UUID uuid = UUID.randomUUID();
			StringBuilder sb1 = saveImage(image, uuid.toString());
			if (sb1 != null) {
				result.put("uuid", uuid);
				result.put("src", sb1.toString());
			}
		} else {
			StringBuilder sb1 = saveImage(image, key);
			if (sb1 != null) {
				result.put("uuid", key);
				result.put("src", sb1.toString());
			}
		}

		return result;
	}

	private static final String UPLOAD_FOLDER = Util.getPath("static/xdailyx/");
	private static final int scaledWidth = 640;
	private static final int scaledHeight = 480;

	private StringBuilder saveImage(MultipartFile carimage1, String uuid) {
		if (!carimage1.isEmpty()) {
			try {
				if (carimage1.getContentType() != null
						&& !carimage1.getContentType().toLowerCase().startsWith(Static.image)) {
					throw new MultipartException(Static.notimage);
				}
				StringBuilder uploadFolderId = new StringBuilder();
				uploadFolderId.append(UPLOAD_FOLDER);
				uploadFolderId.append(Static.separation);
				uploadFolderId.append(uuid);
				uploadFolderId.append(Static.separation);

				if ((!Files.exists(Paths.get(uploadFolderId.toString())))) {
					Files.createDirectories(Paths.get(uploadFolderId.toString()));
				}
				BufferedImage originalImage = ImageIO.read(carimage1.getInputStream());

				int width = originalImage.getWidth();
				int height = originalImage.getHeight();
				if (width < scaledWidth) {
					BufferedImage newResizedImage = new BufferedImage(width, height, BufferedImage.SCALE_SMOOTH);
					Graphics2D g = newResizedImage.createGraphics();
					g.setComposite(AlphaComposite.Src);
					g.fillRect(0, 0, width, height);

					g.drawImage(originalImage, 0, 0, width, height, null);
					g.dispose();
					String s = carimage1.getOriginalFilename();
					String fileExtension = s.substring(s.lastIndexOf(".") + 1);

					ImageIO.write(newResizedImage, fileExtension,
							Paths.get(uploadFolderId.toString(), carimage1.getOriginalFilename()).toFile());
					StringBuilder url = new StringBuilder();
					url.append(uuid).append(Static.separation).append(s);
					return url;
				} else {
					float f = (float) width / scaledWidth;
					int scaleHeight = (int) Math.round(height / f);

					BufferedImage newResizedImage = new BufferedImage(scaledWidth, scaleHeight,
							BufferedImage.SCALE_SMOOTH);
					Graphics2D g = newResizedImage.createGraphics();
					g.setComposite(AlphaComposite.Src);
					g.fillRect(0, 0, scaledWidth, scaleHeight);

					g.drawImage(originalImage, 0, 0, scaledWidth, scaleHeight, null);
					g.dispose();
					String s = carimage1.getOriginalFilename();
					String fileExtension = s.substring(s.lastIndexOf(".") + 1);

					ImageIO.write(newResizedImage, fileExtension,
							Paths.get(uploadFolderId.toString(), carimage1.getOriginalFilename()).toFile());
					StringBuilder url = new StringBuilder();
					url.append(uuid).append(Static.separation).append(s);
					return url;
				}
//				BufferedImage newResizedImage = new BufferedImage(scaledWidth, scaledHeight,
//						BufferedImage.SCALE_SMOOTH);
//				Graphics2D g = newResizedImage.createGraphics();
//				g.setComposite(AlphaComposite.Src);
//				g.fillRect(0, 0, scaledWidth, scaledHeight);
//
//				g.drawImage(originalImage, 0, 0, scaledWidth, scaledHeight, null);qqqqq
//					Files.copy(file.getInputStream(),
//							Paths.get(uploadFolderId.toString(), file.getOriginalFilename()));
			} catch (IOException | RuntimeException e) {

			}
		}
		return null;
	}

	@RequestMapping(value = { "/video" }, method = RequestMethod.GET)
	public String url_tag(Model model, HttpSession session, HttpServletRequest request,
			@RequestParam(value = "q", required = false, defaultValue = "") String q,
			@RequestParam(value = Static.page, required = false, defaultValue = Static.page_value) int page,
			@RequestParam(value = Static.size, required = false, defaultValue = Static.size_value) int size) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			StringBuilder url = new StringBuilder(request.getRequestURI());
			String query = request.getQueryString();
			if (query != null && !Static.blank.equals(query)) {
				url.append(Static.url1);
				url.append(request.getQueryString());
			}
			int idx = url.lastIndexOf(Static.url2);
			if (idx >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url2), url.length(), Static.blank);
			}
			int index = url.lastIndexOf(Static.url3);
			if (index >= Static.zero.intValue()) {
				url.replace(url.lastIndexOf(Static.url3), url.length(), Static.blank);
			}
			if (url.indexOf(Static.url1) >= 0) {
				url.append(Static.url4);
			} else {
				url.append(Static.url1);
			}

			if (q == null || Static.blank.equals(q)) {
				model.addAttribute(Static.modelrs, videoService.getPage(page, size));
			} else {
				model.addAttribute(Static.modelrs, videoService.getPage(q, page, size));
			}

			model.addAttribute(Static.url, url.toString());
			model.addAttribute(Static.q, q);
			return "admin/x";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "admin/x";
	}

	@RequestMapping(value = { "/update-video/{id}" }, method = RequestMethod.GET)
	public String url_update_tag(Model model,
			HttpSession session,
			@PathVariable("id") Long id) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			model.addAttribute("video", videoService.findOne(id));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "admin/update-video";
	}

	@Transactional
	@GetMapping("/delete-video/{id}")
	public String deleteUser(@PathVariable("id") long id,
			HttpSession session,
			Model model) {
		try {
			Object usernameSession = session.getAttribute(Static.admin);
			if (usernameSession == null) {
				return Static.redirect_admin_login;
			}
			videoService.delete(id);
		} catch (Exception e) {
			return "error-500";
		}
		return "redirect:/admin/video";
	}

}
