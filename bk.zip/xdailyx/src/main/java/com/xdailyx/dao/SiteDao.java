package com.xdailyx.dao;

import java.util.List;

import com.xdailyx.base.BaseDao;
import com.xdailyx.entity.Site;

public interface SiteDao extends BaseDao<Site> {
	List<Site> findByDel(Integer delete);
	Site findByNameAndDel(String name, Integer delete);
}
