package com.xdailyx.dao;

import java.util.List;

import com.xdailyx.base.BaseDao;
import com.xdailyx.entity.Menu;
import com.xdailyx.entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface TagDao extends BaseDao<Tag> {
	List<Tag> findByDel(Integer delete);

	Tag findByNameAndDel(String name, Integer delete);

	Tag findTop1ByValueAndDel(String value, Integer del);

	List<Tag> findByDelAndValueIn(Integer delete, List<String> valueList);

	List<Tag> findByDelAndIdIn(Integer delete, List<Long> ids);

	Page<Tag> findByOrderByIdDesc(Pageable pageable);

}
