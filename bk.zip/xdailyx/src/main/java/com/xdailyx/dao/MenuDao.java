package com.xdailyx.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.xdailyx.base.BaseDao;
import com.xdailyx.entity.Menu;

public interface MenuDao extends BaseDao<Menu> {
	List<Menu> findByDel(Integer delete);

	Menu findTop1ByNameAndDel(String name, Integer delete);

	Menu findTop1ByIdAndDel(Long id, Integer del);

	Page<Menu> findByOrderByIdDesc(Pageable pageable);

	Menu findTop1ByValueAndDel(String value, Integer delete);
}
