package com.xdailyx.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.xdailyx.base.BaseDao;
import com.xdailyx.entity.Video;

public interface VideoDao extends BaseDao<Video> {

	Video findTop1ByUrlWebAndDel(String urlWeb, Integer del);

	Page<Video> findByDelOrderByIdDesc(Integer del, Pageable pageable);

	Video findTop1ByUrlAndDel(String url, Integer del);

	Page<Video> findByOrderByIdDesc(Pageable pageable);

	@Query("SELECT v FROM Video v WHERE (v.title LIKE %?1%) and v.del = ?2 order by v.id desc")
	Page<Video> findByTitleStartsWithAndDelOrderByIdDesc(String title, Integer del, Pageable pageable);

	List<Video> findTop8ByTags_IdInOrderByIdDesc(List<Long> ids);

	Page<Video> findByTags_ValueAndDelOrderByIdDesc(String value, Integer del, Pageable pageable);

	Page<Video> findByMenu_ValueAndDelOrderByIdDesc(String value,Integer del, Pageable pageable);

	@Query("SELECT v FROM Video v WHERE (v.title LIKE %?1%) order by v.id desc")
	Page<Video> findByTitleStartsWithOrderByIdDesc(String title, Pageable pageable);

	@Query(value = "select sub.id from (SELECT id FROM video v order by v.id desc limit ?1) as sub order by sub.id asc limit 1", nativeQuery = true)
	Long findLastId(Long limit);


	@Query("SELECT v FROM Video v WHERE v.id < ?1")
	List<Video> findAllById(Long id);


	@Query(value = "SELECT v.url FROM video v ORDER BY RAND() limit ?1", nativeQuery = true)
	Object[] findRandom(Integer limit);



}
