package com.xdailyx.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class FileUtil {

	public static void copy(InputStream is, FileOutputStream fos) throws IOException {
		// Max length per line = 1024.
		byte[] buffer = new byte[1024];

		int lineLength;
		while ((lineLength = is.read(buffer)) > 0) {
			fos.write(buffer, 0, lineLength);
		}
	}

	public static void copyInputStreamToFile(InputStream inputStream, File file) throws IOException {

		try (FileOutputStream outputStream = new FileOutputStream(file)) {

			int read;
			byte[] bytes = new byte[1024];

			while ((read = inputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read);
			}
		}
	}

	public static void deleteFolder(File file) {
		for (File subFile : file.listFiles()) {
			if (subFile.isDirectory()) {
				deleteFolder(subFile);
			} else {
				subFile.delete();
			}
		}
		file.delete();
	}
}
