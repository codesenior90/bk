package com.xdailyx.form;

import java.util.List;

public class VideoForm {

	private String title;

	private String img;

	private String url;

	private String src;

    private String imagehidden;

    private Long menuId;

	private List<Long> tagIds;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public String getImagehidden() {
		return imagehidden;
	}

	public void setImagehidden(String imagehidden) {
		this.imagehidden = imagehidden;
	}

	public Long getMenuId() {
		return menuId;
	}

	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}

	public List<Long> getTagIds() {
		return tagIds;
	}

	public void setTagIds(List<Long> tagIds) {
		this.tagIds = tagIds;
	}

}
