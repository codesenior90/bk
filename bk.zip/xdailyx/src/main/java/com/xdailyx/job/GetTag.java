//package com.xdailyx.job;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
//import org.jsoup.select.Elements;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import com.xdailyx.constant.Del;
//import com.xdailyx.constant.Static;
//import com.xdailyx.entity.Tag;
//import com.xdailyx.service.SiteService;
//import com.xdailyx.service.TagService;
//
//@Component
//public class GetTag {
//
//	private static final Logger log = LoggerFactory.getLogger(GetTag.class);
//
//	private static final String url = "https://mobiblog.lol/tags/";
//	private static final String url_ = "https://mobiblog.lol/tag/";
//
//	private static final String tag_item = "tag-item";
//
//	@Autowired
//	SiteService siteService;
//	@Autowired
//	TagService tagService;
//
//	@Scheduled(initialDelay = 3 * 1000, fixedDelay = Long.MAX_VALUE)
//	public void get() {
//		log.info("start GetTag");
//		try {
//			Document doc = Jsoup.connect(url).get();
//			Elements es = doc.getElementsByClass(tag_item);
//			List<Tag> taglist = new ArrayList<Tag>();
//			for (Element e : es) {
//				try {
//					Element a = e.selectFirst(Static.a);
//					String href = a.attr(Static.href);
//					href = href.replaceAll(url_, Static.blank);
//					href = href.replaceAll(Static.separation, Static.blank);
//					Tag tagExits = tagService.findTop1ByValueAndDel(href, Del.NOTDEL.getLevelCode());
//					if (tagExits == null) {
//						Tag tag = new Tag();
//						tag.setDel(Del.NOTDEL.getLevelCode());
//						tag.setValue(href);
//						tag.setName(a.ownText().trim());
//						taglist.add(tag);
//					}
//				} catch (Exception ex) {
//					ex.printStackTrace();
//				}
//			}
//			if (!taglist.isEmpty()) {
//				tagService.save(taglist);
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		log.info("end GetTag");
//	}
//
//}
