package com.xdailyx.job;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.xdailyx.constant.Del;
import com.xdailyx.constant.SiteName;
import com.xdailyx.constant.Static;
import com.xdailyx.entity.Site;
import com.xdailyx.entity.Tag;
import com.xdailyx.entity.Video;
import com.xdailyx.service.MenuService;
import com.xdailyx.service.SiteService;
import com.xdailyx.service.TagService;
import com.xdailyx.service.VideoService;
import com.xdailyx.util.Util;

@Component
public class Getclipsexhaynet {

	private static final Logger log = LoggerFactory.getLogger(Getclipsexhaynet.class);

	private final static Integer one = 1;
	private final static String p = "/?p=";
	private final static Integer ten = 10;

	@Autowired
	SiteService siteService;
	@Autowired
	VideoService videoService;

	@Autowired
	MenuService menuService;

	@Autowired
	TagService tagService;

	@Transactional
//	@Scheduled(initialDelay = 3 * 1000, fixedDelay = 43200 * 1000)
	public void get() {
//		log.info("start GetX");
		try {
			Site site = siteService.findByNameAndDel(SiteName.clipsexhay_net.getCode(), Del.NOTDEL.getLevelCode());
			if (site != null) {
				String url = site.getUrl();
				Integer done = site.getDone();
				if(one.equals(done)) {
					getData(url, site);
				} else {
					int i = one.intValue();
					while(i <= ten) {
						url = url.concat(p).concat(String.valueOf(i));
						getData(url, site);
						i++;
						url = site.getUrl();
					}
					site.setDone(one.intValue());
					siteService.save(site);
				}
			}
		} catch (Exception exx) {
			exx.printStackTrace();
		}

//		log.info("end GetX");
	}

	private void getData(String url, Site site) {
		try {
			Document doc = Jsoup.connect(url).get();
			Elements es = doc.getElementsByClass(Static.post);
			List<Video> videolist = new ArrayList<Video>();
			for (Element e : es) {
				try {
					Element a = e.selectFirst(Static.a);
					String href = a.attr(Static.href);
					Video videoExits = videoService.findTop1ByUrlWebAndDel(href, Del.NOTDEL.getLevelCode());
					if (videoExits == null) {
						Element img = a.selectFirst(Static.img);
						String title = img.attr(Static.alt);
						String imgSrc = img.attr(Static.data_src);
						Video video = new Video();
						video.setDel(Del.NOTDEL.getLevelCode());
						video.setTitle(title);
						video.setUrlWeb(href);
						video.setImg(imgSrc);
						video.setMenu(menuService.findOne(Long.parseLong(String.valueOf(Util.randInt(1, 6)))  ));
						doc = Jsoup.connect(href).get();
						Element player = doc.selectFirst(Static.video_server);
						if (player != null) {
							String iframesrc = player.attr(Static.data_url);
							video.setSrc(iframesrc);
							List<Tag> taglist = new ArrayList<Tag>();
							taglist.add(tagService.findOne(Long.parseLong(String.valueOf(Util.randInt(1, 6)))));
							video.setTags(taglist);

							videolist.add(video);
						}

					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
			if (!videolist.isEmpty()) {
				List<Video> savelist = videoService.save(videolist);
				videolist = new ArrayList<Video>();
				for (Video video : savelist) {
					try {
						String urlVideo = video.getUrlWeb().replaceAll(site.getRoot(), Static.blank);
						urlVideo = urlVideo.replaceAll(Static.separation, Static.blank);
						urlVideo = urlVideo.concat(Static.separation_);
						urlVideo = urlVideo + video.getId();
//					urlVideo = Static.video_.concat(urlVideo);
						video.setUrl(urlVideo);
						videolist.add(video);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				if (!videolist.isEmpty()) {
					videoService.save(videolist);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
