package com.xdailyx.job;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.xdailyx.entity.Video;
import com.xdailyx.service.VideoService;

@Component
public class DeleteVideo {

	private static final Logger log = LoggerFactory.getLogger(DeleteVideo.class);

	private static final long max = 1000L;

	@Autowired
	VideoService videoService;

//	@Scheduled(initialDelay = 3 * 1000, fixedDelay = 2 * 1000)
	@Transactional
//	@Scheduled(cron = "0 0 12 * * *")
	public void get() {
//		log.info("start DeleteVideo");
		try {
			long total = videoService.count();
			if(max < total) {
				long id = videoService.findLastId(max);
				List<Video> list = videoService.findAllById(id);
				if(!list.isEmpty()) {
					videoService.delete(list);
				 }
			}
		} catch (Exception exx) {
			exx.printStackTrace();
		}

//		log.info("end DeleteVideo");
	}

}
