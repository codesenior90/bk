package com.xdailyx.constant;

public enum MenuValue {
	vietnam("clip-sex-viet"),
	jav("clip-jav"),
	chauau("clip-sex-chau-au"),
	nhieutheloai("clip-nhieu-the-loai");
	private final String code;

    private MenuValue(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
