package com.xdailyx.constant;

public enum IsWeb {
	ISWEB(1),
	NOTWEB(0);

	private final int levelCode;

    private IsWeb(int levelCode) {
        this.levelCode = levelCode;
    }

    public int getLevelCode() {
        return this.levelCode;
    }
}
