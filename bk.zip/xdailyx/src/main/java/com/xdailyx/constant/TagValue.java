package com.xdailyx.constant;

public enum TagValue {
	quaylen("quay-len"),
	thudam("thu-dam"),
	tuquay("tu-quay"),
	bopvu("bop-vu"),
	doggy("doggy"),
	nhieutheloai("nhieu-the-loai");
	private final String code;

    private TagValue(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
