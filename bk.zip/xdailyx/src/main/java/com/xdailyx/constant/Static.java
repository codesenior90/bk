package com.xdailyx.constant;

import java.util.regex.Pattern;

public interface Static {
	int n999 = 999;
	Integer zero = 0;
	Integer z39 = 39;
	Integer z40 = 40;
	String zeroS = "0";
	String blank = "";
	String separation = "/";
	String separation1 = " ";
	String separation2 = "-";
	String n = "\n";

	String url1 = "?";
	String url2 = "&page";
	String url3 = "?page";
	String url4 = "&";

	String url = "url";
	String q = "q";

	String znamealphanumber = "^[a-zA-Z0-9]*$";

	Pattern robustPattern = Pattern.compile(
			// Robust expression from before
			"^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$"
					// Area code, within or without parentheses,
					// followed by groups of 3-4 numbers with or without hyphens
					+ "| ((\\(\\d{3}\\) ?)|(\\d{3}-))?\\d{3}-\\d{4}"
					// (+) followed by 10-12 numbers
					+ "|^\\+\\d{10,12}");

	String md5 = "MD5";

	// GetX
	String post = "video-artic";
	String a = "a";
	String href = "href";
	String img = "img";
	String alt = "alt";
	String player = ".video-player";
	String video_server = ".video-server";
	String iframe = "iframe";
	String src = "src";
	String data_src = "data-src";
	String data_url = "data-url";
	String meta_image = "meta[name=twitter:image]";
	String content = "content";
	String tags_list_a = ".tags-list a";
	String title = "title";
	String category = "category";
	String video_ = "/video/";
	String separation_ = "-";

	String modelrs = "rs";
	String modelms = "ms";
	String modelts = "ts";


	String mestitle = "you must enter title";
	String mes_name = "you must enter name";
	String mes_id = "you must enter id";
	String mes_del = "you must enter del";
	String mes_image = "you must enter image";
	String mes_menu = "you must enter menu";
	String mes_tag = "you must enter tag";
	String mestitle_max = "title max length 999";

	String mes_name_max = "name max length 999";
	String mes_url_max = "url max length 999";
	String mes_img_max = "image max length 999";
	String mes_url_exist = "url is exist";
	String mes_menu_exist = "menu is exist";
	String mes_tag_exist = "tag is exist";
	String mes_success = "add new success.";
	String error = "error";


	String notimage = "not image";
	String image = "image";
	String videoForm = "videoForm";
	String menuForm = "menuForm";
	String page = "page";
	String show = "show";
	String page_value = "1";
	String size = "size";
	String size_value = "24";

	String page_tag = "admin/tag";
	String page_update_tag = "admin/update-tag";

	String page_menu = "admin/menu";
	String page_update_menu = "admin/update-menu";


	String urladmin = "/admin";
	String url_tag = "/tag";
	String url_add_tag = "/add-tag";
	String url_update_tag = "update-tag/{id}";
	String url_menu = "/menu";
	String url_add_menu = "/add-menu";
	String url_update_menu = "update-menu/{id}";
	String tagForm = "tagForm";

	String admin = "admin";

	String redirect_admin_addnew = "redirect:/admin/add-new";
	String redirect_admin_login = "redirect:/admin/login";

}
