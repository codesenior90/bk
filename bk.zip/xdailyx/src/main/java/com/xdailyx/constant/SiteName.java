package com.xdailyx.constant;

public enum SiteName {
	mobiblog_lol("mobiblog.lol"),
	clipsexhay_net("clipsexhay.net");
	private final String code;

    private SiteName(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
