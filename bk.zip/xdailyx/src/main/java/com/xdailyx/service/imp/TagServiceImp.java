package com.xdailyx.service.imp;

import java.util.List;

import com.xdailyx.entity.Menu;
import com.xdailyx.entity.pag.Paged;
import com.xdailyx.entity.pag.Paging;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.xdailyx.base.BaseServiceImpl;
import com.xdailyx.dao.TagDao;
import com.xdailyx.entity.Tag;
import com.xdailyx.service.TagService;

@Service
public class TagServiceImp extends BaseServiceImpl<Tag> implements TagService {

	@Autowired
	TagDao tagDao;

	@Override
	public List<Tag> findByDelete(Integer delete) {
		return tagDao.findByDel(delete);
	}

	@Override
	public Tag findByNameAndDel(String name, Integer delete) {
		return tagDao.findByNameAndDel(name, delete);
	}

	@Override
	public Tag findTop1ByValueAndDel(String value, Integer del) {
		return tagDao.findTop1ByValueAndDel(value, del);
	}

	@Override
	public List<Tag> findByDelAndValueIn(Integer delete, List<String> valueList) {
		return tagDao.findByDelAndValueIn(delete, valueList);
	}

	@Override
	public List<Tag> findByDelAndIdIn(Integer delete, List<Long> ids) {
		return tagDao.findByDelAndIdIn(delete, ids);
	}

	@Override
	public Paged<Tag> getPage(int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Tag> page = tagDao.findByOrderByIdDesc(request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

}
