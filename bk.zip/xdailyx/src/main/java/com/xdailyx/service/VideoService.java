package com.xdailyx.service;

import java.util.List;

import com.xdailyx.base.BaseService;
import com.xdailyx.entity.Video;
import com.xdailyx.entity.pag.Paged;

public interface VideoService extends BaseService<Video, Long> {

	Video findTop1ByUrlWebAndDel(String urlWeb, Integer del);

	Paged<Video> getPage(Integer del, int pageNumber, int size);

	Video findTop1ByUrlAndDel(String url, Integer del);

	Paged<Video> getPage(int pageNumber, int size);

	Paged<Video> getPage(String q, Integer del, int pageNumber, int size);

	List<Video> findTop10ByTags_IdInOrderByIdDesc(List<Long> ids);

	Paged<Video> findByTags_ValueAndDelOrderByIdDesc(String value, Integer del, int pageNumber, int size);

	Paged<Video> findByMenu_ValueAndDelOrderByIdDesc(String value,Integer del, int pageNumber, int size);

	Paged<Video> getPage(String q, int pageNumber, int size);

	Long findLastId(Long limit);

	List<Video> findAllById(Long id);

	Object[] findRandom(Integer limit);
}
