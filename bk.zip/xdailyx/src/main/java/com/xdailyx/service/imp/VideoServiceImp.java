package com.xdailyx.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.xdailyx.base.BaseServiceImpl;
import com.xdailyx.dao.VideoDao;
import com.xdailyx.entity.Video;
import com.xdailyx.entity.pag.Paged;
import com.xdailyx.entity.pag.Paging;
import com.xdailyx.service.VideoService;

@Service
public class VideoServiceImp extends BaseServiceImpl<Video> implements VideoService {

	@Autowired
	VideoDao videoDao;

	@Override
	public Video findTop1ByUrlWebAndDel(String urlWeb, Integer del) {
		return videoDao.findTop1ByUrlWebAndDel(urlWeb, del);
	}

	@Override
	public Paged<Video> getPage(Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Video> page = videoDao.findByDelOrderByIdDesc(del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Video findTop1ByUrlAndDel(String url, Integer del) {
		return videoDao.findTop1ByUrlAndDel(url, del);
	}

	@Override
	public Paged<Video> getPage(int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Video> page = videoDao.findByOrderByIdDesc(request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<Video> getPage(String q, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Video> page = videoDao.findByTitleStartsWithAndDelOrderByIdDesc(q, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public List<Video> findTop10ByTags_IdInOrderByIdDesc(List<Long> ids) {
		return videoDao.findTop8ByTags_IdInOrderByIdDesc(ids);
	}

	@Override
	public Paged<Video> findByTags_ValueAndDelOrderByIdDesc(String value, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Video> page = videoDao.findByTags_ValueAndDelOrderByIdDesc(value, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<Video> findByMenu_ValueAndDelOrderByIdDesc(String value, Integer del, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Video> page = videoDao.findByMenu_ValueAndDelOrderByIdDesc(value, del, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Paged<Video> getPage(String q, int pageNumber, int size) {
		PageRequest request = PageRequest.of(pageNumber - 1, size);
		Page<Video> page = videoDao.findByTitleStartsWithOrderByIdDesc(q, request);
		return new Paged<>(page, Paging.of(page.getTotalPages(), pageNumber, size));
	}

	@Override
	public Long findLastId(Long limit) {
		return videoDao.findLastId(limit);
	}

	@Override
	public List<Video> findAllById(Long id) {
		return videoDao.findAllById(id);
	}

	@Override
	public Object[] findRandom(Integer limit) {
		return videoDao.findRandom(limit);
	}


}
