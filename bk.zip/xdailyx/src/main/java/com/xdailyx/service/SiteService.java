package com.xdailyx.service;

import java.util.List;

import com.xdailyx.base.BaseService;
import com.xdailyx.entity.Site;

public interface SiteService extends BaseService<Site, Long> {
	List<Site> findByDelete(Integer delete);

	Site findByNameAndDel(String name, Integer delete);
}
