package com.xdailyx.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xdailyx.base.BaseServiceImpl;
import com.xdailyx.dao.SiteDao;
import com.xdailyx.entity.Site;
import com.xdailyx.service.SiteService;

@Service
public class SiteServiceImp extends BaseServiceImpl<Site> implements SiteService {

	@Autowired
	SiteDao siteDao;

	@Override
	public List<Site> findByDelete(Integer delete) {
		return siteDao.findByDel(delete);
	}

	@Override
	public Site findByNameAndDel(String name, Integer delete) {
		return siteDao.findByNameAndDel(name, delete);
	}

}
