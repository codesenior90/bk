package com.xdailyx.service;

import java.util.List;

import com.xdailyx.base.BaseService;
import com.xdailyx.entity.Menu;
import com.xdailyx.entity.Tag;
import com.xdailyx.entity.pag.Paged;

public interface TagService extends BaseService<Tag, Long> {
	List<Tag> findByDelete(Integer delete);

	Tag findByNameAndDel(String name, Integer delete);

	Tag findTop1ByValueAndDel(String value, Integer del);

	List<Tag> findByDelAndValueIn(Integer delete, List<String> valueList);

	List<Tag> findByDelAndIdIn(Integer delete, List<Long> ids);

	Paged<Tag> getPage(int pageNumber, int size);
}
