package com.xdailyx.entity;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;

import com.xdailyx.base.BaseModel;
import com.xdailyx.constant.Static;

/**
 * The persistent class for the brand database table.
 *
 */
@Entity
public class Tag extends BaseModel {

	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String name;

	@Column(length = Static.n999)
	private String value;

	@ManyToMany(mappedBy = "tags")
	private Collection<Video> videos;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Collection<Video> getVideos() {
		return videos;
	}

	public void setVideos(Collection<Video> videos) {
		this.videos = videos;
	}

}