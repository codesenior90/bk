package com.xdailyx.entity;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

import com.xdailyx.base.BaseModel;
import com.xdailyx.constant.Static;


/**
 * The persistent class for the brand database table.
 *
 */
@Entity
public class Menu extends BaseModel {

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = 1L;

	@Column(length = Static.n999)
	private String iss;

	@Column(length = Static.n999)
	private String name;

	@Column(length = Static.n999)
	private String value;

	@OneToMany(mappedBy="menu")
    private Collection<Video> videos;

	public String getIss() {
		return iss;
	}

	public void setIss(String iss) {
		this.iss = iss;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Collection<Video> getVideos() {
		return videos;
	}

	public void setVideos(Collection<Video> videos) {
		this.videos = videos;
	}

}