package com.xdailyx.entity.pag;

public enum PageItemType {

    DOTS,
    PAGE

}
