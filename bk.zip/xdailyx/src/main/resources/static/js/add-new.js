$(document).ready(function() {

	$('#image1check').hide();
	let image1Error = true;
//	$('#carimage1').change(function() {
//		validateCarimage1();
//	});

	function validateImage1() {
		let image1Value = $('#uuid').val();
		if (image1Value.length == '') {
			$('#image1check').show();
			image1Error = false;
			$('#image1check').html('You must upload one image your car');
		} else {
			image1Error = true;
			$('#image1check').hide();
		}
	}

	$(function() {
		var token = $("input[name='_csrf']").val();
		var header = "X-CSRF-TOKEN";
		$(document).ajaxSend(function(e, xhr, options) {
			xhr.setRequestHeader(header, token);
		});
	});

	function upload(x, y, z) {
		let form_data = new FormData();
		let files = $(x)[0].files;
		if (files.length > 0) {
			form_data.append(y, files[0]);
			form_data.append('key', $("#uuid").val());
			$.ajax({
				//dataType: 'json',
				url: "/admin/upload",
				data: form_data,
				type: "POST",
				enctype: 'multipart/form-data',
				processData: false,
				contentType: false,
				success: function(result) {
					if (result.src) {
						let src = "/xdailyx/" + result.src;
						if($(".pip")) {
							$(".pip").remove();
						}
						$("<span class=\"pip\">" +
							"<img class=\"imageThumb\" src=\"" + src + "\" title=\"" + "\"/>" +
							"<br/><span class=\"remove\">Remove</span>" +
							"<input type=\"hidden\" id=\"imagehidden\" name=\"imagehidden\" value=\""+ src +"\">"
							+"</span>").insertBefore(x);
						$(".remove").click(function() {
							$(this).parent(".pip").remove();
							$(x).val('');
						});
						$(x).val('');
//						$(z).val(result.src);
					}
					if (result.uuid) {
						$("#uuid").val(result.uuid);
					}

				},
				error: function(result) {

				}
			});
		}
	}
	$('#image1').change(function(e) {

		upload('#image1', 'image', '#image1hidden');
	});

});
